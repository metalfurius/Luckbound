using System;
using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.Gameplay.Inventory
{
    /// <summary>
    /// Captures one physical contact only. This observation is not a reward, claim, save, or
    /// proof that the resolved catalog permits the cache; App must validate those independently.
    /// </summary>
    public sealed class ExplorationGoldCacheContact
    {
        internal ExplorationGoldCacheContact(ExplorationGoldCachePickup2D pickup, RoomLifetimeScope scope,
            RoomPositionMarker2D marker, PlayerMotor2D player, Collider2D playerCollider,
            string cacheId, long activationGeneration, long sequence)
        {
            Pickup = pickup;
            Scope = scope;
            Marker = marker;
            Player = player;
            PlayerCollider = playerCollider;
            RoomInstanceId = scope.RoomInstanceId;
            ActorId = player.ActorId;
            CacheId = cacheId;
            ActivationGeneration = activationGeneration;
            Sequence = sequence;
            CapturedFrame = Time.frameCount;
            CapturedFixedTime = Time.fixedTimeAsDouble;
        }

        public ExplorationGoldCachePickup2D Pickup { get; }
        public RoomLifetimeScope Scope { get; }
        public RoomPositionMarker2D Marker { get; }
        public PlayerMotor2D Player { get; }
        public Collider2D PlayerCollider { get; }
        public RoomInstanceId RoomInstanceId { get; }
        public ActorId ActorId { get; }
        public string CacheId { get; }
        public long ActivationGeneration { get; }
        public long Sequence { get; }
        public int CapturedFrame { get; }
        public double CapturedFixedTime { get; }
    }

    /// <summary>
    /// Reports contact with the exact configured actor. It never grants gold or consumes itself.
    /// A room-scoped App owner must revalidate the pinned plan and commit before removing the pickup.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider2D))]
    public sealed class ExplorationGoldCachePickup2D : MonoBehaviour, IDisposable
    {
        public const string F10MarkerId = "cache.exploration";

        private Collider2D _trigger;
        private RoomLifetimeScope _scope;
        private RoomPositionMarker2D _marker;
        private PlayerMotor2D _player;
        private Rigidbody2D _playerBody;
        private string _cacheId;
        private long _activationGeneration;
        private long _sequence;
        private double _lastRequestedFixedTime = double.NegativeInfinity;
        private bool _initialized;
        private bool _disposed;
        private ExplorationGoldCacheContact _pending;

        public event Action<ExplorationGoldCacheContact> ContactRequested;

        public bool HasPendingContact => _pending != null;

        /// <summary>
        /// The root must be inactive. This method adopts it into the room and establishes
        /// observation only; a cache ID here does not authorize an inventory mutation.
        /// </summary>
        public void Initialize(RoomLifetimeScope scope, RoomPositionMarker2D marker,
            PlayerMotor2D player, string cacheId, long activationGeneration)
        {
            if (_initialized || _disposed)
                throw new InvalidOperationException("A cache pickup can only be initialized once.");
            if (scope == null || scope.IsDisposed || !scope.isActiveAndEnabled || !scope.RoomInstanceId.IsValid)
                throw new ArgumentException("An active room scope is required.", nameof(scope));
            if (marker == null || !marker.isActiveAndEnabled || !marker.transform.IsChildOf(scope.transform) ||
                !string.Equals(marker.MarkerId, F10MarkerId, StringComparison.Ordinal) ||
                !string.Equals(marker.Kind, "treasure", StringComparison.Ordinal))
                throw new ArgumentException("The exact exploration cache marker must belong to the room.", nameof(marker));
            if (player == null || !player.isActiveAndEnabled || !player.ActorId.IsValid || player.IsDead ||
                player.CombatStats == null || player.CurrentHealth <= 0 || player.GetComponent<Rigidbody2D>() == null ||
                !player.GetComponent<Rigidbody2D>().simulated)
                throw new ArgumentException("An initialized live player with 2D physics is required.", nameof(player));
            if (string.IsNullOrWhiteSpace(cacheId) || HasWhitespace(cacheId))
                throw new ArgumentException("A stable cache ID is required.", nameof(cacheId));
            if (activationGeneration <= 0) throw new ArgumentOutOfRangeException(nameof(activationGeneration));
            if (gameObject.activeSelf)
                throw new InvalidOperationException("The cache root must be inactive before room ownership.");
            if (transform.parent != null && !ReferenceEquals(transform.parent, scope.transform))
                throw new InvalidOperationException("The cache root cannot belong to another parent.");
            if ((transform.position - marker.transform.position).sqrMagnitude > 0.000001f)
                throw new InvalidOperationException("The cache root must be placed at its exact room marker.");

            Collider2D[] colliders = GetComponents<Collider2D>();
            if (colliders.Length != 1 || colliders[0] == null)
                throw new InvalidOperationException("A cache root requires exactly one trigger collider.");
            Collider2D trigger = colliders[0];
            trigger.isTrigger = true;
            trigger.enabled = true;

            _scope = scope;
            _marker = marker;
            _player = player;
            _playerBody = player.GetComponent<Rigidbody2D>();
            _trigger = trigger;
            _cacheId = cacheId;
            _activationGeneration = activationGeneration;
            if (!ReferenceEquals(scope.OwnActor(gameObject), gameObject) ||
                !ReferenceEquals(transform.parent, scope.transform))
                throw new InvalidOperationException("The cache root was not adopted by the exact room scope.");
            scope.OwnResource(this);
            _initialized = true;
        }

        /// <summary>
        /// Called by the owner only after rejecting an observation before a durable mutation starts.
        /// Releasing it does not grant anything; a future physical Stay may request again.
        /// </summary>
        public bool ReleaseRejectedContact(ExplorationGoldCacheContact contact)
        {
            if (_disposed || !ReferenceEquals(contact, _pending)) return false;
            _pending = null;
            return true;
        }

        /// <summary>Rechecks the captured actor, collider and room before App handles a queued contact.</summary>
        public bool IsPendingContactCurrent(ExplorationGoldCacheContact contact)
        {
            return !_disposed && ReferenceEquals(contact, _pending) && IsEligibleContact(contact?.PlayerCollider) &&
                ReferenceEquals(contact.Scope, _scope) && ReferenceEquals(contact.Marker, _marker) &&
                ReferenceEquals(contact.Player, _player) && contact.RoomInstanceId == _scope.RoomInstanceId &&
                contact.ActorId == _player.ActorId && contact.ActivationGeneration == _activationGeneration &&
                string.Equals(contact.CacheId, _cacheId, StringComparison.Ordinal);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _pending = null;
            ContactRequested = null;
            if (_trigger != null) _trigger.enabled = false;
        }

        private void OnTriggerEnter2D(Collider2D other) => ObserveContact(other);
        private void OnTriggerStay2D(Collider2D other) => ObserveContact(other);

        private void ObserveContact(Collider2D other)
        {
            if (_pending != null || ContactRequested == null || !IsEligibleContact(other) ||
                Time.fixedTimeAsDouble <= _lastRequestedFixedTime) return;
            if (_sequence == long.MaxValue)
            {
                Dispose();
                return;
            }

            var contact = new ExplorationGoldCacheContact(this, _scope, _marker, _player, other,
                _cacheId, _activationGeneration, ++_sequence);
            _pending = contact;
            _lastRequestedFixedTime = contact.CapturedFixedTime;
            foreach (Action<ExplorationGoldCacheContact> handler in ContactRequested.GetInvocationList())
            {
                try { handler(contact); }
                catch (Exception exception) { Debug.LogException(exception, this); }
            }
        }

        private bool IsEligibleContact(Collider2D other)
        {
            if (!_initialized || _disposed || !isActiveAndEnabled || Time.timeScale <= 0f ||
                _scope == null || _scope.IsDisposed || !_scope.isActiveAndEnabled ||
                _marker == null || !_marker.isActiveAndEnabled || !_marker.transform.IsChildOf(_scope.transform) ||
                !string.Equals(_marker.MarkerId, F10MarkerId, StringComparison.Ordinal) ||
                !string.Equals(_marker.Kind, "treasure", StringComparison.Ordinal) ||
                !ReferenceEquals(transform.parent, _scope.transform) ||
                (transform.position - _marker.transform.position).sqrMagnitude > 0.000001f ||
                _player == null || !_player.isActiveAndEnabled || !_player.ActorId.IsValid || _player.IsDead ||
                _player.CombatStats == null || _player.CurrentHealth <= 0 ||
                _playerBody == null || !_playerBody.simulated ||
                !ReferenceEquals(_player.GetComponent<Rigidbody2D>(), _playerBody) ||
                _trigger == null || !_trigger.enabled || !_trigger.isTrigger ||
                other == null || !other.isActiveAndEnabled ||
                !ReferenceEquals(other.attachedRigidbody, _playerBody) ||
                !ReferenceEquals(other.GetComponentInParent<PlayerMotor2D>(), _player))
                return false;

            Collider2D[] cacheColliders = GetComponents<Collider2D>();
            return cacheColliders.Length == 1 && ReferenceEquals(cacheColliders[0], _trigger) &&
                _trigger.IsTouching(other);
        }

        private void OnDisable()
        {
            if (_initialized) Dispose();
        }

        private void OnDestroy() => Dispose();

        private static bool HasWhitespace(string value)
        {
            for (int index = 0; index < value.Length; index++)
                if (char.IsWhiteSpace(value[index])) return true;
            return false;
        }
    }
}
