#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    internal enum F10ExtractionSettlementState
    {
        SetupFailed,
        WaitingForExtraction,
        Resolving,
        PendingRetry,
        Failed,
        Completed
    }

    /// <summary>Hands the exact F10 safe-extraction interaction to the app-owned settlement lane.</summary>
    [DisallowMultipleComponent]
    internal sealed class F10ExtractionSettlementCoordinator : MonoBehaviour, IF10ObjectiveObservationHandoff
    {
        private const string GuardianNodeId = "sample.patio.guardian";
        private const string ExtractionNodeId = "sample.safe_extraction";
        private const string ExtractionTemplateId = "room.sample.extraction";

        private ApplicationBootstrapper _application;
        private ExpeditionGameplayComposition _composition;
        private ExpeditionSessionReadinessRegistration _registration;
        private RoomEncounterRuntimeContext _context;
        private ExpeditionEncounterSessionSnapshotSource _snapshotSource;
        private F10ObjectiveDriver2D _driver;
        private Task _attemptTask;
        private F10ObjectiveObservation _observation;
        private RunId _runId;
        private bool _attemptInProgress;
        private bool _observationAccepted;
        private F10ExtractionSettlementState _state = F10ExtractionSettlementState.SetupFailed;
        private string _error = string.Empty;

        internal F10ExtractionSettlementState State => _state;
        internal string Error => _error;
        internal bool Persisted => _state == F10ExtractionSettlementState.Completed;
        internal string ObservationId => _observation == null ? string.Empty : _observation.ObservationId;
        internal F10ObjectiveDriver2D ObjectiveDriver => _driver;

        internal static F10ExtractionSettlementCoordinator Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));

            F10ExtractionSettlementCoordinator existing = composition.GetComponent<F10ExtractionSettlementCoordinator>();
            if (existing != null)
            {
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition)) return existing;
                throw new InvalidOperationException("This composition already owns another F10 extraction coordinator.");
            }

            AttachmentView attachment = ValidateAttachment(application, composition);
            F10ExtractionSettlementCoordinator coordinator =
                composition.gameObject.AddComponent<F10ExtractionSettlementCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._registration = attachment.Registration;
            coordinator._context = attachment.Context;
            coordinator._snapshotSource = attachment.Source;
            coordinator._runId = attachment.Run.RunId;
            coordinator.TryAttachObjectiveDriver(attachment);
            return coordinator;
        }

        public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
        {
            // This is the only place that starts a fresh policy-bearing extraction call.
            if (_driver == null || !_driver.IsDeliveringTo(this, observation) ||
                !IsExactExtractionObservation(observation) || !IsCurrentExtractionActivation())
                return F10ObjectiveHandoffResult.RetryLater;

            if (_observation != null && !ReferenceEquals(_observation, observation))
                return F10ObjectiveHandoffResult.RetryLater;
            if (_state == F10ExtractionSettlementState.Completed ||
                _application.OwnsF10ExtractionCandidate(_driver, this, observation))
            {
                _observation = observation;
                _observationAccepted = true;
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
            if (_state == F10ExtractionSettlementState.PendingRetry)
                return _observationAccepted
                    ? F10ObjectiveHandoffResult.AcceptedLocalObservation
                    : F10ObjectiveHandoffResult.RetryLater;
            if (_attemptInProgress || _state == F10ExtractionSettlementState.Failed ||
                _state == F10ExtractionSettlementState.SetupFailed)
                return F10ObjectiveHandoffResult.RetryLater;

            _observation = observation;
            StartSettlementAttempt(observation);
            if (_application.OwnsF10ExtractionCandidate(_driver, this, observation))
            {
                _observationAccepted = true;
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
            return F10ObjectiveHandoffResult.RetryLater;
        }

        /// <summary>Retries only the retained candidate; a fresh attempt is rearmed through the same queued fact.</summary>
        internal Task RetryAsync()
        {
            if (_state == F10ExtractionSettlementState.Completed) return Task.CompletedTask;
            if (_attemptInProgress) return _attemptTask ?? Task.CompletedTask;
            if (_application == null) return Task.CompletedTask;

            if (_state == F10ExtractionSettlementState.SetupFailed)
            {
                TryAttachObjectiveDriver();
                return Task.CompletedTask;
            }

            if (_application.HasPendingF10ExtractionRetry)
            {
                StartSettlementRetry();
                return _attemptTask ?? Task.CompletedTask;
            }

            if (_state == F10ExtractionSettlementState.Failed && !_observationAccepted)
            {
                // The driver still owns the exact fact because it received RetryLater.
                _state = F10ExtractionSettlementState.WaitingForExtraction;
                _error = string.Empty;
                _attemptTask = null;
                return Task.CompletedTask;
            }

            if (_state == F10ExtractionSettlementState.Failed && _observationAccepted)
            {
                _state = F10ExtractionSettlementState.PendingRetry;
                _error = "The accepted extraction candidate is unavailable; retry is held fail-closed.";
            }
            return Task.CompletedTask;
        }

        private static AttachmentView ValidateAttachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun))
                throw new InvalidOperationException("Extraction requires the exact owned isolated F10 run in Play Mode.");

            ExpeditionReadinessCompositionView view = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = view == null ? null : view.Run;
            ExpeditionRoomTransitionController transitions = view == null ? null : view.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = view == null ? null : view.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null ? null : registration.CurrentActivation;
            RoomEncounterRuntimeContext context = activation == null ? null : activation.Context;
            if (!composition.isActiveAndEnabled || !composition.IsReady || view == null || !view.IsReady ||
                !ReferenceEquals(view.Owner, composition) || !ReferenceEquals(view.Application, application) ||
                run == null || run.RunId != application.ActiveRun.RunId || run.Route == null ||
                run.Route.GenerationVersion != 2 || transitions == null || !ReferenceEquals(transitions, composition.RoomTransitions) ||
                !SameRunRoute(application.ActiveRun, run) || registration == null || registration.IsDisposed ||
                !registration.IsOwnerActive || activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Controller, transitions) || activation.RunId != run.RunId ||
                !SameRunRoute(activation.BoundRun, run) || activation.Scope == null ||
                !ReferenceEquals(activation.Scope, transitions.ActiveScope) ||
                activation.Scope.IsDisposed || !activation.Scope.isActiveAndEnabled ||
                !string.Equals(activation.NodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, ExtractionTemplateId, StringComparison.Ordinal) ||
                context != null && (!ReferenceEquals(context.Scope, activation.Scope) ||
                    !ReferenceEquals(context.Controller, transitions) || !ReferenceEquals(context.Player, view.PlayerMotor) ||
                    context.Plan != null || context.RunId != run.RunId ||
                    !string.Equals(context.NodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                    !string.Equals(context.TemplateId, ExtractionTemplateId, StringComparison.Ordinal) ||
                    !context.IsCurrentRoomScope()) ||
                context == null && activation.Source != null ||
                view.PlayerMotor == null || !view.PlayerMotor.isActiveAndEnabled || !view.PlayerMotor.ActorId.IsValid ||
                view.PlayerObject == null || !ReferenceEquals(view.PlayerObject, view.PlayerMotor.gameObject) ||
                view.PlayerObject.GetComponent<Collider2D>() == null || view.PlayerObject.GetComponent<Rigidbody2D>() == null ||
                application.HasPendingSessionMutation || application.HasPendingRoomAdvance || application.IsRoomAdvanceInFlight)
                throw new InvalidOperationException("Readiness must own the exact Bound F10 safe-extraction room and actor.");

            ExpeditionSaveData save = application.ActiveExpedition;
            if (save == null || !string.Equals(save.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                !string.Equals(save.currentNodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(transitions.CurrentNodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                transitions.CurrentRoomId != application.ActiveRoomInstanceId ||
                !HasDurableGuardianDefeat(run, save))
                throw new InvalidOperationException("The saved route must be at SafeExtraction after its durable Guardian completion.");

            return new AttachmentView(registration, activation, run, context, activation.Source,
                view.PlayerObject.GetComponent<Collider2D>());
        }

        private void TryAttachObjectiveDriver(AttachmentView attachment = null)
        {
            try
            {
                attachment = EnsureContextAndSource(attachment ?? ValidateAttachment(_application, _composition));
                if (!ReferenceEquals(attachment.Registration, _registration) ||
                    !ReferenceEquals(attachment.Context, _context) || !ReferenceEquals(attachment.Source, _snapshotSource) ||
                    attachment.Run.RunId != _runId)
                    throw new InvalidOperationException("The active extraction activation changed before objective setup.");

                F10ObjectiveDriver2D existing = _context.Scope.GetComponent<F10ObjectiveDriver2D>();
                _driver = existing != null
                    ? existing
                    : F10ObjectiveSetupDemo.Attach(_context, _snapshotSource, attachment.PlayerCollider, this);
                if (existing != null) existing.BindObservationHandoff(this);
                if (_driver == null || _driver.IsDisposed || _driver.IsFaulted)
                    throw new InvalidOperationException("The exact F10 extraction objective driver did not bind.");
                _state = F10ExtractionSettlementState.WaitingForExtraction;
                _error = string.Empty;
            }
            catch (Exception exception)
            {
                _state = F10ExtractionSettlementState.SetupFailed;
                _error = exception.Message;
            }
        }

        private AttachmentView EnsureContextAndSource(AttachmentView attachment)
        {
            if (attachment == null || !ReferenceEquals(attachment.Registration, _registration) ||
                attachment.Run == null || attachment.Run.RunId != _runId || attachment.Activation == null ||
                attachment.Activation.State != ExpeditionRoomActivationState.Bound)
                throw new InvalidOperationException("The exact Bound extraction activation is unavailable for objective setup.");

            ExpeditionReadinessCompositionView readiness = _composition.CaptureReadinessCompositionView();
            ExpeditionRoomActivationRegistration activation = _registration.CurrentActivation;
            if (readiness == null || !readiness.IsReady || activation == null ||
                !ReferenceEquals(activation, attachment.Activation) || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, _composition.RoomTransitions.ActiveScope) ||
                !ReferenceEquals(readiness.PlayerMotor, activation.PlayerMotor))
                throw new InvalidOperationException("Readiness changed before the extraction context could be registered.");

            RoomEncounterRuntimeContext context = activation.Context;
            if (context == null)
            {
                if (activation.Source != null)
                    throw new InvalidOperationException("The extraction activation has a snapshot source without its context.");
                context = RoomEncounterRuntimeContext.Create(_runId, ExtractionNodeId,
                    ExtractionTemplateId, activation.RoomInstanceId, activation.Scope,
                    activation.Controller, readiness.PlayerMotor, plan: null,
                    routeGenerationVersion: _registration.RouteGenerationVersion);
            }

            if (!ReferenceEquals(context.Scope, activation.Scope) ||
                !ReferenceEquals(context.Controller, activation.Controller) ||
                !ReferenceEquals(context.Player, readiness.PlayerMotor) || context.RunId != _runId ||
                context.RouteGenerationVersion != _registration.RouteGenerationVersion || context.Plan != null ||
                !string.Equals(context.NodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, ExtractionTemplateId, StringComparison.Ordinal) ||
                context.RoomInstanceId != activation.RoomInstanceId || !context.IsCurrentRoomScope())
                throw new InvalidOperationException("The one extraction context must match the exact activation and use Plan == null.");

            ExpeditionEncounterSessionSnapshotSource source = _registration.CreateSnapshotSource(context);
            if (source == null || !ReferenceEquals(activation.Context, context) || !ReferenceEquals(activation.Source, source))
                throw new InvalidOperationException("The readiness registration did not retain the exact extraction context and snapshot source.");

            _context = context;
            _snapshotSource = source;
            return new AttachmentView(_registration, activation, attachment.Run,
                context, source, attachment.PlayerCollider);
        }

        private void StartSettlementAttempt(F10ObjectiveObservation observation)
        {
            if (_attemptInProgress) return;
            _attemptInProgress = true;
            _state = F10ExtractionSettlementState.Resolving;
            _error = string.Empty;
            try
            {
                Task<ExpeditionSettlementCommitResult> task = _application.SettleF10ExtractionAsync(
                    _composition, _driver, this, observation);
                _attemptTask = ObserveSettlementAsync(task);
            }
            catch (Exception exception)
            {
                _attemptInProgress = false;
                _state = F10ExtractionSettlementState.Failed;
                _error = exception.Message;
            }
        }

        private void StartSettlementRetry()
        {
            if (_attemptInProgress) return;
            _attemptInProgress = true;
            _state = F10ExtractionSettlementState.Resolving;
            _error = string.Empty;
            _attemptTask = ObserveSettlementAsync(_application.RetryPendingF10ExtractionAsync());
        }

        private async Task ObserveSettlementAsync(Task<ExpeditionSettlementCommitResult> task)
        {
            try
            {
                ExpeditionSettlementCommitResult result = await task;
                if (this == null) return;
                if (result != null && result.Persisted)
                {
                    _state = F10ExtractionSettlementState.Completed;
                    _error = string.Empty;
                }
                else if (_application != null && _observation != null &&
                    _application.OwnsF10ExtractionCandidate(_driver, this, _observation))
                {
                    _observationAccepted = true;
                    _state = F10ExtractionSettlementState.PendingRetry;
                    _error = result == null ? "The accepted extraction is awaiting persistence retry." : result.Message;
                }
                else
                {
                    _state = F10ExtractionSettlementState.Failed;
                    _error = result == null ? "The extraction was not accepted." : result.Message;
                }
            }
            catch (Exception exception)
            {
                if (this != null)
                {
                    _state = _application != null && _application.HasPendingF10ExtractionRetry
                        ? F10ExtractionSettlementState.PendingRetry
                        : F10ExtractionSettlementState.Failed;
                    _error = exception.Message;
                }
            }
            finally
            {
                if (this != null) _attemptInProgress = false;
            }
        }

        private bool IsExactExtractionObservation(F10ObjectiveObservation observation)
        {
            return observation != null && _context != null && observation.Kind == F10ObjectiveObservationKind.ExtractionInteractionRequested &&
                observation.RunId == _runId && observation.ActorId == _context.Player.ActorId &&
                string.Equals(observation.NodeId, ExtractionNodeId, StringComparison.Ordinal) &&
                string.Equals(observation.TemplateId, ExtractionTemplateId, StringComparison.Ordinal) &&
                observation.RoomInstanceId == _context.RoomInstanceId &&
                ReferenceEquals(observation.Scope, _context.Scope) &&
                ReferenceEquals(observation.Controller, _context.Controller) &&
                ReferenceEquals(observation.Player, _context.Player) &&
                observation.ActivationGeneration == _context.ActivationGeneration;
        }

        private bool IsCurrentExtractionActivation()
        {
            if (_application == null || _composition == null || _registration == null ||
                _context == null || _snapshotSource == null || _driver == null) return false;
            ExpeditionReadinessCompositionView view = _composition.CaptureReadinessCompositionView();
            ExpeditionRoomActivationRegistration activation = _registration.CurrentActivation;
            ExpeditionReadinessTransitionView transition = _composition.RoomTransitions == null
                ? null
                : _composition.RoomTransitions.CaptureReadinessTransitionView();
            return ReferenceEquals(ApplicationBootstrapper.Instance, _application) &&
                _application.OwnsF10DiagnosticRun(_application.ActiveRun) &&
                _composition.isActiveAndEnabled && _composition.IsReady && view != null && view.IsReady &&
                ReferenceEquals(view.Owner, _composition) && ReferenceEquals(view.Application, _application) &&
                ReferenceEquals(view.ReadinessRegistration, _registration) && view.Run != null && view.Run.RunId == _runId &&
                ReferenceEquals(view.PlayerMotor, _context.Player) && ReferenceEquals(view.RoomTransitions, _context.Controller) &&
                activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Context, _context) && ReferenceEquals(activation.Source, _snapshotSource) &&
                ReferenceEquals(activation.Scope, _context.Scope) && ReferenceEquals(activation.Controller, _context.Controller) &&
                activation.RunId == _runId && SameRunRoute(activation.BoundRun, _application.ActiveRun) &&
                string.Equals(activation.NodeId, ExtractionNodeId, StringComparison.Ordinal) &&
                string.Equals(activation.TemplateId, ExtractionTemplateId, StringComparison.Ordinal) &&
                transition != null && transition.IsInitialized && !transition.IsDisposed &&
                !transition.IsTransitioning && !transition.HasPreparedTransition &&
                ReferenceEquals(transition.ActiveScope, _context.Scope) &&
                string.Equals(transition.ActiveNodeId, ExtractionNodeId, StringComparison.Ordinal) &&
                string.Equals(transition.ActiveTemplateId, ExtractionTemplateId, StringComparison.Ordinal) &&
                _context.IsCurrentRoomScope();
        }

        private static bool HasDurableGuardianDefeat(ExpeditionRunConfiguration run, ExpeditionSaveData save)
        {
            if (run == null || save == null || save.completedRoomIds == null ||
                !save.completedRoomIds.Contains(GuardianNodeId, StringComparer.Ordinal) ||
                save.completedRoomResults == null) return false;
            string roomId = ExpeditionRoomIdentity.ForNode(run.RunId, GuardianNodeId).ToString();
            ExpeditionRoomCompletionSaveData[] results = save.completedRoomResults.Where(result => result != null &&
                string.Equals(result.roomNodeId, GuardianNodeId, StringComparison.Ordinal)).ToArray();
            if (results.Length != 1 || !string.Equals(results[0].resultId,
                    "room-result.v1:" + roomId, StringComparison.Ordinal)) return false;
            try
            {
                DurableRoomResult result = JsonUtility.FromJson<DurableRoomResult>(results[0].resultJson);
                return result != null && result.schema == 1 &&
                    string.Equals(result.outcome, "cleared", StringComparison.Ordinal) &&
                    string.Equals(result.roomInstanceId, roomId, StringComparison.Ordinal) &&
                    string.Equals(result.sourceNodeId, GuardianNodeId, StringComparison.Ordinal) &&
                    string.Equals(result.targetNodeId, ExtractionNodeId, StringComparison.Ordinal);
            }
            catch { return false; }
        }

        private static bool SameRunRoute(ExpeditionRunConfiguration left, ExpeditionRunConfiguration right)
        {
            return left != null && right != null && left.RunId == right.RunId && left.Seed == right.Seed &&
                left.Route != null && right.Route != null && left.Route.GenerationVersion == right.Route.GenerationVersion &&
                string.Equals(left.Route.CanonicalForm, right.Route.CanonicalForm, StringComparison.Ordinal);
        }

        [Serializable]
        private sealed class DurableRoomResult
        {
            public int schema;
            public string outcome;
            public string roomInstanceId;
            public string sourceNodeId;
            public string targetNodeId;
        }

        private sealed class AttachmentView
        {
            internal AttachmentView(ExpeditionSessionReadinessRegistration registration,
                ExpeditionRoomActivationRegistration activation, ExpeditionRunConfiguration run,
                RoomEncounterRuntimeContext context,
                ExpeditionEncounterSessionSnapshotSource source, Collider2D playerCollider)
            {
                Registration = registration;
                Activation = activation;
                Run = run;
                Context = context;
                Source = source;
                PlayerCollider = playerCollider;
            }
            internal ExpeditionSessionReadinessRegistration Registration { get; }
            internal ExpeditionRoomActivationRegistration Activation { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal RoomEncounterRuntimeContext Context { get; }
            internal ExpeditionEncounterSessionSnapshotSource Source { get; }
            internal Collider2D PlayerCollider { get; }
        }
    }
}
#endif
