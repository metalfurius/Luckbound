#if UNITY_EDITOR
using System;
using System.IO;
using System.Threading.Tasks;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;

namespace Luckbound.App
{
    /// <summary>
    /// Editor-only V6 resume exception for one manifest-bound disposable diagnostic session.
    /// It does not change the access policy for any other SaveRepository instance.
    /// </summary>
    public sealed partial class SaveRepository
    {
        private F10DiagnosticResumeAccess _f10DiagnosticResumeAccess;

        internal async Task<SaveLoadResult<ProfileSaveEnvelope>> LoadF10DiagnosticResumeAsync(
            F10DiagnosticResumeAccess access)
        {
            if (access == null) throw new ArgumentNullException(nameof(access));
            await _gate.WaitAsync();
            try
            {
                // Resume is only valid for a genuinely new repository. Preserve all existing
                // V6/V7 ownership, caches, and exact bytes when any protocol already owns it.
                if (_pendingProfile != null || _f10V7PendingSessionMutation != null ||
                    _v7ExtractedSettlementOwner != null)
                    return new SaveLoadResult<ProfileSaveEnvelope>(SaveLoadStatus.Incompatible, null,
                        "WritePending: an existing profile write, V7 session mutation, or extracted settlement owns this repository.",
                        SaveDataAccess.Unavailable);
                if (_v7V6ProfileWriteAdmissionBarrierArmed || _v7ProfileProtocolLatched ||
                    _f10V7SessionHandle != null)
                    return new SaveLoadResult<ProfileSaveEnvelope>(SaveLoadStatus.Incompatible, null,
                        "ProtocolConflict: this repository has entered V7 admission/protocol or retains an authenticated V7 session handle.",
                        SaveDataAccess.Unavailable);

                if (!ReferenceEquals(_store, access.RepositoryStore))
                    throw new InvalidOperationException("Diagnostic resume authority belongs to a different save store.");
                if (!ReferenceEquals(_store, access.Permit.RepositoryStore) ||
                    !ReferenceEquals(access.PhysicalStore, access.Permit.PhysicalStore))
                    throw new InvalidOperationException("Diagnostic resume authority is not bound to the exact physical FileSaveStore instance.");
                if (!ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(
                        access.SessionDirectory, UnityEngine.Application.persistentDataPath) ||
                    !IsEqualOrWithin(access.SessionDirectory,
                        Path.Combine(access.CopyRoot, "Logs/F10V6Resume-20261120/sessions".Replace('/', Path.DirectorySeparatorChar))))
                    throw new InvalidOperationException("Diagnostic resume authority is not bound to a disjoint fixed session path in this copy.");
                if (!access.IsStillVerified())
                    throw new InvalidOperationException("The fixed copy/session evidence changed before V6 authentication.");

                ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(access.SessionDirectory,
                    requireProfilePrimary: true);
                string primaryPath = access.PhysicalStore.GetPrimaryPath(SaveDocument.Profile);
                if (!PathEquals(Path.GetDirectoryName(primaryPath), access.SessionDirectory) ||
                    !PathEquals(primaryPath, Path.Combine(access.SessionDirectory, FileSaveStore.ProfileFileName)))
                    throw new InvalidOperationException("The diagnostic profile path escaped its manifest-bound session directory.");

                SaveStorageSnapshot storage = await _store.ReadAsync(SaveDocument.Profile);
                if (!access.IsStillVerified())
                    throw new InvalidOperationException("The fixed copy/session evidence changed while reading the profile.");
                ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(access.SessionDirectory,
                    requireProfilePrimary: true);

                DecodeStatus status = SaveJsonCodec.Decode(storage.PrimaryJson, out ProfileSaveEnvelope envelope,
                    out int sourceContentVersion);
                ExpeditionSaveData active = envelope == null ? null : envelope.activeExpedition;
                if (status != DecodeStatus.Valid || sourceContentVersion != 6 || SaveFormat.ContentVersion != 6 ||
                    envelope == null || envelope.profile == null || !envelope.hasActiveExpedition || active == null ||
                    active.contentVersion != 6 || !string.Equals(active.runId, access.RunId, StringComparison.Ordinal) ||
                    active.generationVersion != access.GenerationVersion || active.seed != access.Seed ||
                    !string.Equals(active.routeSnapshotJson, access.RouteSnapshotJson, StringComparison.Ordinal) ||
                    !string.Equals(F10DiagnosticSessionManifest.Sha256(active.routeSnapshotJson),
                        access.RouteSnapshotSha256, StringComparison.Ordinal))
                    throw new InvalidOperationException("The primary profile is not the authenticated V6 save for this exact diagnostic run and route.");

                RunId.Parse(active.runId);
                ExpeditionRoutePlan route = ExpeditionRoutePlan.ParseCanonical(active.routeSnapshotJson);
                if (route.GenerationVersion != access.GenerationVersion || route.Seed != access.Seed)
                    throw new InvalidOperationException("The durable route does not match its fixed diagnostic session provenance.");
                ExpeditionSaveMapper.ValidateRoomEntryCheckpoint(active);

                _profile = envelope;
                _profilePrimaryJson = storage.PrimaryJson;
                _loadedProfileJson = storage.PrimaryJson;
                _profilePrimaryValid = true;
                _profileBlocked = false;
                _profileAccess = SaveDataAccess.ReadWrite;
                _profileLoaded = true;
                _f10DiagnosticResumeAccess = access;

                return new SaveLoadResult<ProfileSaveEnvelope>(SaveLoadStatus.LoadedPrimary, envelope,
                    "The manifest-bound V6 diagnostic profile was authenticated for this isolated repository.",
                    SaveDataAccess.ReadWrite);
            }
            finally { _gate.Release(); }
        }

        internal static F10DiagnosticResumeAccess CreateF10DiagnosticResumeAccess(ISaveStore repositoryStore,
            FileSaveStore physicalStore, ApplicationBootstrapper owner,
            ApplicationBootstrapper.F10DiagnosticResumePermit permit)
        {
            return F10DiagnosticResumeAccess.Create(repositoryStore, physicalStore, owner, permit);
        }

        internal sealed class F10DiagnosticResumeAccess
        {
            private F10DiagnosticResumeAccess(ISaveStore repositoryStore, FileSaveStore physicalStore,
                ApplicationBootstrapper owner, ApplicationBootstrapper.F10DiagnosticResumePermit permit)
            {
                if (!ApplicationBootstrapper.IsF10DiagnosticResumePermitValid(permit, owner,
                        physicalStore, repositoryStore))
                    throw new InvalidOperationException("Only the verified fixed-copy resume entry can issue V6 diagnostic authority.");
                RepositoryStore = repositoryStore ?? throw new ArgumentNullException(nameof(repositoryStore));
                PhysicalStore = physicalStore ?? throw new ArgumentNullException(nameof(physicalStore));
                Owner = owner ?? throw new ArgumentNullException(nameof(owner));
                Permit = permit ?? throw new ArgumentNullException(nameof(permit));
                SessionDirectory = permit.SessionDirectory;
                RunId = permit.RunId;
                GenerationVersion = permit.GenerationVersion;
                Seed = permit.Seed;
                RouteSnapshotJson = permit.RouteSnapshotJson;
                RouteSnapshotSha256 = permit.RouteSnapshotSha256;
                CopyRoot = permit.ProjectRoot;
                CopyCertificateSha256 = permit.CopyCertificateSha256;
                ContentManifestSha256 = permit.ContentManifestSha256;
            }

            internal static F10DiagnosticResumeAccess Create(ISaveStore repositoryStore,
                FileSaveStore physicalStore, ApplicationBootstrapper owner,
                ApplicationBootstrapper.F10DiagnosticResumePermit permit)
            {
                return new F10DiagnosticResumeAccess(repositoryStore, physicalStore, owner, permit);
            }

            internal ISaveStore RepositoryStore { get; }
            internal FileSaveStore PhysicalStore { get; }
            internal ApplicationBootstrapper Owner { get; }
            internal ApplicationBootstrapper.F10DiagnosticResumePermit Permit { get; }
            internal string SessionDirectory { get; }
            internal string RunId { get; }
            internal int GenerationVersion { get; }
            internal uint Seed { get; }
            internal string RouteSnapshotJson { get; }
            internal string RouteSnapshotSha256 { get; }
            internal string CopyRoot { get; }
            internal string CopyCertificateSha256 { get; }
            internal string ContentManifestSha256 { get; }
            internal bool IsStillVerified()
            {
                return ApplicationBootstrapper.IsF10DiagnosticResumePermitValid(Permit, Owner,
                    PhysicalStore, RepositoryStore);
            }
        }

        private static bool PathEquals(string left, string right)
        {
            if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right)) return false;
            StringComparison comparison = Path.DirectorySeparatorChar == '\\'
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal;
            return string.Equals(Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), comparison);
        }

        private static bool IsEqualOrWithin(string candidate, string parent)
        {
            if (string.IsNullOrWhiteSpace(candidate) || string.IsNullOrWhiteSpace(parent)) return false;
            string fullCandidate = Path.GetFullPath(candidate).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string fullParent = Path.GetFullPath(parent).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            StringComparison comparison = Path.DirectorySeparatorChar == '\\'
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal;
            return string.Equals(fullCandidate, fullParent, comparison) ||
                fullCandidate.StartsWith(fullParent + Path.DirectorySeparatorChar, comparison);
        }
    }

    /// <summary>Runs the existing FileSaveStore transaction path behind per-operation leaf checks.</summary>
    internal sealed class F10DiagnosticGuardedFileSaveStore : ISaveStore
    {
        private readonly FileSaveStore _inner;
        private readonly string _sessionDirectory;

        internal F10DiagnosticGuardedFileSaveStore(FileSaveStore inner, string sessionDirectory)
        {
            _inner = inner ?? throw new ArgumentNullException(nameof(inner));
            _sessionDirectory = Path.GetFullPath(sessionDirectory ?? throw new ArgumentNullException(nameof(sessionDirectory)));
        }

        public async Task<SaveStorageSnapshot> ReadAsync(SaveDocument document)
        {
            ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(_sessionDirectory,
                requireProfilePrimary: false);
            SaveStorageSnapshot snapshot = await _inner.ReadAsync(document);
            ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(_sessionDirectory,
                requireProfilePrimary: false);
            return snapshot;
        }

        public async Task WriteAsync(SaveDocument document, string json, string lastKnownGoodPrimaryJson)
        {
            ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(_sessionDirectory,
                requireProfilePrimary: false);
            try
            {
                await _inner.WriteAsync(document, json, lastKnownGoodPrimaryJson);
            }
            finally
            {
                ApplicationBootstrapper.VerifyF10DiagnosticStoreLeafIntegrity(_sessionDirectory,
                    requireProfilePrimary: false);
            }
        }
    }
}
#endif
