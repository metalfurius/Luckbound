#if UNITY_EDITOR
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;

namespace Luckbound.App
{
    /// <summary>Editor-only admission bridge; it retains authenticated state but never publishes gameplay.</summary>
    public sealed partial class ApplicationBootstrapper
    {
        private bool _f10V7AdmissionProfileWriteBlock;
        private object _f10V7AdmissionOwner;
        private F10V7AdmissionContext _f10V7AdmissionContext;
        private string _f10V7AdmissionFailure;

        internal async Task<F10V7AppAdmissionResult> AdmitActiveV7ForPreproductionAsync(
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry)
        {
            if (!SaveDataReady || _saveRepository == null || itemCatalog == null || exactRegistry == null)
                return F10V7AppAdmissionResult.Rejected("AdmissionInputsUnavailable: App readiness, repository, exact ItemCatalog, and exact registry are required.");

            await _profileMutationGate.WaitAsync();
            try
            {
                if (!ReferenceEquals(_instance, this) || _f10V7AdmissionOwner != null ||
                    _f10V7AdmissionContext != null)
                    return F10V7AppAdmissionResult.Rejected("AppOwnerMismatch: this bootstrapper is not the sole current V7 admission owner.");
                if (HasBlockingV6StateForV7Admission())
                    return F10V7AppAdmissionResult.Rejected("V6SessionOrPendingOperation: an active physical/session owner or pending App mutation blocks V7 admission.");

                ApplicationBootstrapper capturedBootstrapper = _instance;
                if (!ReferenceEquals(capturedBootstrapper, this))
                    return F10V7AppAdmissionResult.Rejected("AppOwnerMismatch: this bootstrapper is not the current App singleton.");
                SaveRepository capturedRepository = _saveRepository;
                ItemCatalog capturedItemCatalog = itemCatalog;
                EncounterCatalogRegistryV1 capturedRegistry = exactRegistry;
                object capturedSimulationOwner = _expeditionSimulationPauseLeaseProviderOwner;
                object capturedMutationOwner = _expeditionSessionMutationPublicationOwner;
                long capturedRevision = _activeExpeditionRevision;
                object admissionOwner = new object();

                _f10V7AdmissionOwner = admissionOwner;
                _f10V7AdmissionProfileWriteBlock = true;
                _f10V7AdmissionFailure = null;

                F10V7SafeOpenResult admission;
                try
                {
                    admission = await capturedRepository.TryOpenActiveV7ForPreproductionAsync(
                        capturedItemCatalog, capturedRegistry);
                }
                catch (Exception exception)
                {
                    // The call may have armed the repository barrier before throwing. Keep the
                    // App barrier until a later explicit recovery path can inspect that owner.
                    _f10V7AdmissionFailure = "AdmissionUncertain: " + exception.Message;
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                }

                if (admission == null)
                {
                    _f10V7AdmissionFailure = "AdmissionUncertain: repository returned no result after the attempt.";
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                }

                bool appReviewIsCurrent = ReferenceEquals(_instance, capturedBootstrapper) &&
                    ReferenceEquals(_f10V7AdmissionOwner, admissionOwner) &&
                    ReferenceEquals(_saveRepository, capturedRepository) &&
                    ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, capturedSimulationOwner) &&
                    ReferenceEquals(_expeditionSessionMutationPublicationOwner, capturedMutationOwner) &&
                    _activeExpeditionRevision == capturedRevision && !HasBlockingV6StateForV7Admission();
                if (!appReviewIsCurrent)
                {
                    // Keep this App barrier even when the repository reports no barrier: the
                    // captured App/retry owner changed while admission was awaiting storage.
                    _f10V7AdmissionFailure = "AppReviewChanged: bootstrapper owner, repository, or expedition revision changed while V7 admission was in flight.";
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure,
                        admissionArmed: admission.AdmissionArmed);
                }

                if (!admission.AdmissionArmed)
                {
                    // No repository barrier was left armed. Release only this call's temporary
                    // App block so a pre-existing repository retry keeps its original owner.
                    if (ReferenceEquals(_f10V7AdmissionOwner, admissionOwner))
                    {
                        _f10V7AdmissionProfileWriteBlock = false;
                        _f10V7AdmissionOwner = null;
                        _f10V7AdmissionFailure = null;
                    }
                    string message = admission.Error.Code == SaveV7ErrorCode.None
                        ? "AdmissionNotArmed: repository did not arm V7 admission."
                        : admission.Error.Code + ": " + admission.Error.Message;
                    return F10V7AppAdmissionResult.Rejected(message, admissionArmed: false);
                }

                if (!admission.Opened || admission.View == null ||
                    (admission.View.Status != SaveLoadStatus.LoadedPrimary &&
                     admission.View.Status != SaveLoadStatus.RecoveredBackup) ||
                    admission.View.SourceContentVersion != 7 ||
                    admission.View.Access != SaveDataAccess.ReadWrite || admission.View.Envelope == null ||
                    admission.View.Envelope.activeExpedition == null ||
                    string.IsNullOrWhiteSpace(admission.View.OriginalJson))
                {
                    _f10V7AdmissionFailure = admission.Error.Code == SaveV7ErrorCode.None
                        ? "AuthenticatedActiveV7Required: repository admission did not return a writable active V7 profile."
                        : admission.Error.Code + ": " + admission.Error.Message;
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                }

                byte[] confirmedBytes;
                ProfileSaveEnvelopeV7 envelope;
                try
                {
                    confirmedBytes = new UTF8Encoding(false, true).GetBytes(admission.View.OriginalJson);
                    if (!SaveV7JsonCodec.TryDecodeProfile(confirmedBytes, out envelope, out SaveV7Error decodeError))
                    {
                        _f10V7AdmissionFailure = decodeError.Code + ": " + decodeError.Message;
                        return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                    }
                    if (envelope.generation != admission.View.Envelope.generation ||
                        envelope.sequence != admission.View.Envelope.sequence ||
                        !string.Equals(envelope.checksum, admission.View.Envelope.checksum, StringComparison.Ordinal) ||
                        envelope.activeExpedition == null ||
                        !string.Equals(envelope.activeExpedition.runId,
                            admission.View.Envelope.activeExpedition.runId, StringComparison.Ordinal))
                    {
                        _f10V7AdmissionFailure = "ExactSnapshotMismatch: retained JSON differs from the repository's authenticated V7 view.";
                        return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                    }
                }
                catch (Exception exception) when (exception is EncoderFallbackException ||
                    exception is SaveV7ValidationException || exception is ArgumentException)
                {
                    _f10V7AdmissionFailure = "AuthenticatedV7ProfileRequired: " + exception.Message;
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                }

                if (!RunId.TryParse(envelope.activeExpedition.runId, out RunId admittedRunId) ||
                    admission.SessionHandle == null ||
                    !capturedRepository.IsRetainedF10V7SessionHandle(admission.SessionHandle,
                        admission.View.OriginalJson, admittedRunId, capturedItemCatalog, capturedRegistry))
                {
                    _f10V7AdmissionFailure = "SessionCapabilityMismatch: repository did not retain the exact authenticated opening capability.";
                    return F10V7AppAdmissionResult.Rejected(_f10V7AdmissionFailure, admissionArmed: true);
                }

                // The context is private and exact. This bridge deliberately does not assign
                // ActiveRun, _activeExpedition, or any gameplay composition state.
                _f10V7AdmissionContext = new F10V7AdmissionContext(capturedBootstrapper,
                    admissionOwner, capturedRepository, capturedItemCatalog, capturedRegistry,
                    admission.SessionHandle,
                    admission.View.OriginalJson, envelope.activeExpedition.runId,
                    envelope.generation, envelope.sequence, capturedRevision);
                return F10V7AppAdmissionResult.Accepted("Authenticated active V7 profile retained privately; gameplay remains unpublished.");
            }
            finally { _profileMutationGate.Release(); }
        }

        private bool HasBlockingV6StateForV7Admission()
        {
            return ActiveRun != null || _activeExpedition != null ||
                _expeditionSimulationPauseLeaseProviderOwner != null ||
                _expeditionSessionMutationPublicationOwner != null ||
                _pendingSettlement != null || _pendingPermanentUpgradePurchase != null ||
                _pendingContractProgression != null || _pendingCraft != null ||
                _pendingEconomyMutation != null || _pendingExpeditionCandidate != null ||
                _pendingExpeditionProfile != null || _pendingExpeditionRun != null ||
                _pendingExpeditionSessionPublication != null || _pendingExpeditionSessionPauseLease != null ||
                _pendingRoomAdvance != null || _isDrainingGameplayProgressEvents ||
                _queuedGameplayProgressEvents.Count != 0;
        }

        private sealed class F10V7AdmissionContext
        {
            internal F10V7AdmissionContext(ApplicationBootstrapper bootstrapper, object owner,
                SaveRepository repository, ItemCatalog itemCatalog, EncounterCatalogRegistryV1 registry,
                SaveRepository.F10V7SessionHandle sessionHandle, string confirmedJson,
                string runId, int generation, long sequence, long appRevision)
            {
                Bootstrapper = bootstrapper;
                Owner = owner;
                Repository = repository;
                ItemCatalog = itemCatalog;
                Registry = registry;
                SessionHandle = sessionHandle ?? throw new ArgumentNullException(nameof(sessionHandle));
                // This JSON is the opening snapshot only. Future commit ownership must update its
                // confirmed bytes and any rollback reservation under the repository gate.
                ConfirmedJson = confirmedJson;
                RunId = runId;
                Generation = generation;
                Sequence = sequence;
                AppRevision = appRevision;
            }

            internal ApplicationBootstrapper Bootstrapper { get; }
            internal object Owner { get; }
            internal SaveRepository Repository { get; }
            internal ItemCatalog ItemCatalog { get; }
            internal EncounterCatalogRegistryV1 Registry { get; }
            internal SaveRepository.F10V7SessionHandle SessionHandle { get; }
            internal string ConfirmedJson { get; }
            internal string RunId { get; }
            internal int Generation { get; }
            internal long Sequence { get; }
            internal long AppRevision { get; }
        }
    }

    internal sealed class F10V7AppAdmissionResult
    {
        private F10V7AppAdmissionResult(bool admitted, bool admissionArmed, string message)
        {
            Admitted = admitted;
            AdmissionArmed = admissionArmed;
            Message = message ?? string.Empty;
        }

        internal bool Admitted { get; }
        internal bool AdmissionArmed { get; }
        internal string Message { get; }

        internal static F10V7AppAdmissionResult Accepted(string message) =>
            new F10V7AppAdmissionResult(true, true, message);

        internal static F10V7AppAdmissionResult Rejected(string message, bool admissionArmed = false) =>
            new F10V7AppAdmissionResult(false, admissionArmed, message);
    }
}
#endif
