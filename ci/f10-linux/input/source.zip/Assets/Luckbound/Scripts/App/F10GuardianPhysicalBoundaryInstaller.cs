#if UNITY_EDITOR
using System;
using System.Linq;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Editor-only installation of invisible, scope-owned Guardian side walls. The walls are derived from the
    /// validated real floor collider and do not alter the room prefab, boss motion, or encounter outcome.
    /// </summary>
    internal static class F10GuardianPhysicalBoundaryInstaller
    {
        internal const string GuardianNodeId = "sample.patio.guardian";
        internal const string GuardianTemplateId = "room.patio.guardian";
        internal const string LeftWallName = "F10GuardianBoundary.Left";
        internal const string RightWallName = "F10GuardianBoundary.Right";

        private const string CustodianMarkerId = "boss.custodian";
        private const float GeometryTolerance = 0.01f;
        private const float MinimumWallThickness = 0.1f;
        private static readonly object WitnessIssuer = new object();

        /// <summary>Opaque evidence that these exact two colliders were installed on this exact room scope.</summary>
        internal readonly struct InstallationWitness
        {
            private readonly object _receipt;

            internal InstallationWitness(RoomLifetimeScope scope, RoomTemplatePrefab2D room,
                GameObject leftWall, GameObject rightWall, RoomInstanceId roomInstanceId,
                float leftEdgeX, float rightEdgeX, float floorTopY, float wallBottomY, float wallTopY,
                float wallThickness, float tileSize, int groundLayer, object receipt)
            {
                Scope = scope;
                Room = room;
                LeftWall = leftWall;
                RightWall = rightWall;
                RoomInstanceId = roomInstanceId;
                LeftEdgeX = leftEdgeX;
                RightEdgeX = rightEdgeX;
                FloorTopY = floorTopY;
                WallBottomY = wallBottomY;
                WallTopY = wallTopY;
                WallThickness = wallThickness;
                TileSize = tileSize;
                GroundLayer = groundLayer;
                _receipt = receipt;
            }

            internal RoomLifetimeScope Scope { get; }
            internal RoomTemplatePrefab2D Room { get; }
            internal GameObject LeftWall { get; }
            internal GameObject RightWall { get; }
            internal RoomInstanceId RoomInstanceId { get; }
            internal float LeftEdgeX { get; }
            internal float RightEdgeX { get; }
            internal float FloorTopY { get; }
            internal float WallBottomY { get; }
            internal float WallTopY { get; }
            internal float WallThickness { get; }
            internal float TileSize { get; }
            internal int GroundLayer { get; }
            internal bool WasIssuedByInstaller => ReferenceEquals(_receipt, WitnessIssuer);
        }

        /// <summary>
        /// Creates two hidden static colliders after validating the exact generation-2 Guardian room. A successful
        /// witness proves installation only; it is not physical-test acceptance or permission to arm Guardian.
        /// </summary>
        internal static bool TryInstall(ExpeditionRunConfiguration run, RoomLifetimeScope scope,
            RoomTemplatePrefab2D room, out InstallationWitness witness, out string error)
        {
            witness = default(InstallationWitness);
            error = string.Empty;
            if (!TryReadGuardianGeometry(run, scope, room, out RoomTemplateData roomData,
                out Bounds floorBounds, out Bounds cameraBounds, out int groundLayer, out error))
                return false;

            if (Physics2D.GetIgnoreLayerCollision(groundLayer, LayerMask.NameToLayer("Enemies")))
                return Fail("Physics2D ignores Ground-to-Enemies collisions, so Guardian side walls would not confine the Custodian.", out error);

            Transform[] namedChildren = scope.GetComponentsInChildren<Transform>(true);
            if (namedChildren.Any(item => item != null &&
                (string.Equals(item.name, LeftWallName, StringComparison.Ordinal) ||
                 string.Equals(item.name, RightWallName, StringComparison.Ordinal))))
                return Fail("Guardian scope already contains a boundary installation; refusing duplicate walls.", out error);

            float leftEdgeX = floorBounds.min.x;
            float rightEdgeX = floorBounds.max.x;
            float wallBottomY = floorBounds.min.y - roomData.tileSize;
            float wallTopY = cameraBounds.max.y + roomData.tileSize;
            float wallHeight = wallTopY - wallBottomY;
            float wallThickness = Mathf.Max(MinimumWallThickness, roomData.tileSize * 0.1f);
            if (!IsFinite(leftEdgeX) || !IsFinite(rightEdgeX) || leftEdgeX >= rightEdgeX ||
                !IsFinite(wallBottomY) || !IsFinite(wallTopY) || wallHeight <= 0f ||
                !IsFinite(wallThickness) || wallThickness <= 0f)
                return Fail("The real Guardian floor and camera bounds do not produce finite side-wall geometry.", out error);

            GameObject leftWall = null;
            GameObject rightWall = null;
            try
            {
                float centerY = (wallBottomY + wallTopY) * 0.5f;
                float z = room.transform.position.z;
                leftWall = CreateInactiveWall(LeftWallName, leftEdgeX, centerY, z,
                    wallThickness, wallHeight, groundLayer);
                rightWall = CreateInactiveWall(RightWallName, rightEdgeX, centerY, z,
                    wallThickness, wallHeight, groundLayer);

                GameObject ownedLeft = scope.OwnActor(leftWall);
                GameObject ownedRight = scope.OwnActor(rightWall);
                if (!ReferenceEquals(ownedLeft, leftWall) || !ReferenceEquals(ownedRight, rightWall) ||
                    !ReferenceEquals(leftWall.transform.parent, scope.transform) ||
                    !ReferenceEquals(rightWall.transform.parent, scope.transform) ||
                    !scope.isActiveAndEnabled || scope.IsDisposed)
                    throw new InvalidOperationException("The exact boundary colliders were not retained by the active Guardian scope.");

                leftWall.SetActive(true);
                rightWall.SetActive(true);
                Physics2D.SyncTransforms();
                var candidate = new InstallationWitness(scope, room, leftWall, rightWall,
                    scope.RoomInstanceId, leftEdgeX, rightEdgeX, floorBounds.max.y, wallBottomY, wallTopY,
                    wallThickness, roomData.tileSize, groundLayer, WitnessIssuer);
                if (!IsCurrent(candidate, run, scope, room))
                    throw new InvalidOperationException("The installed static wall colliders did not pass their immediate scope and geometry audit.");

                witness = candidate;
                return true;
            }
            catch (Exception exception)
            {
                RetireWall(leftWall);
                RetireWall(rightWall);
                return Fail("Guardian physical boundary installation failed closed: " + exception.GetType().Name + ".", out error);
            }
        }

        /// <summary>Checks that the witness still names both live colliders and the same validated room geometry.</summary>
        internal static bool IsCurrent(InstallationWitness witness, ExpeditionRunConfiguration run,
            RoomLifetimeScope scope, RoomTemplatePrefab2D room)
        {
            if (!witness.WasIssuedByInstaller || !IsFinite(witness.FloorTopY) || scope == null || room == null ||
                !ReferenceEquals(witness.Scope, scope) || !ReferenceEquals(witness.Room, room) ||
                witness.RoomInstanceId != scope.RoomInstanceId)
                return false;

            if (!TryReadGuardianGeometry(run, scope, room, out _, out Bounds floorBounds,
                out Bounds cameraBounds, out int groundLayer, out _))
                return false;
            if (groundLayer != witness.GroundLayer ||
                Mathf.Abs(floorBounds.min.x - witness.LeftEdgeX) > GeometryTolerance ||
                Mathf.Abs(floorBounds.max.x - witness.RightEdgeX) > GeometryTolerance ||
                Mathf.Abs(floorBounds.max.y - witness.FloorTopY) > GeometryTolerance ||
                Mathf.Abs((floorBounds.min.y - witness.TileSize) - witness.WallBottomY) > GeometryTolerance ||
                Mathf.Abs((cameraBounds.max.y + witness.TileSize) - witness.WallTopY) > GeometryTolerance ||
                Physics2D.GetIgnoreLayerCollision(groundLayer, LayerMask.NameToLayer("Enemies")))
                return false;

            float expectedHeight = witness.WallTopY - witness.WallBottomY;
            float expectedCenterY = (witness.WallBottomY + witness.WallTopY) * 0.5f;
            return IsValidWall(witness.LeftWall, scope, LeftWallName, witness.LeftEdgeX,
                    expectedCenterY, room.transform.position.z, witness.WallThickness, expectedHeight, groundLayer) &&
                IsValidWall(witness.RightWall, scope, RightWallName, witness.RightEdgeX,
                    expectedCenterY, room.transform.position.z, witness.WallThickness, expectedHeight, groundLayer);
        }

        private static bool TryReadGuardianGeometry(ExpeditionRunConfiguration run,
            RoomLifetimeScope scope, RoomTemplatePrefab2D room, out RoomTemplateData roomData,
            out Bounds floorBounds, out Bounds cameraBounds, out int groundLayer, out string error)
        {
            roomData = null;
            floorBounds = default(Bounds);
            cameraBounds = default(Bounds);
            groundLayer = LayerMask.NameToLayer("Ground");
            error = string.Empty;

            if (groundLayer < 0 || LayerMask.NameToLayer("Enemies") < 0)
                return Fail("Guardian physical boundaries require both Ground and Enemies layers.", out error);
            if (run == null || run.Route == null || run.Route.GenerationVersion != 2)
                return Fail("Guardian boundaries require the explicit F10 generation-2 run.", out error);

            ExpeditionRouteNode[] nodes = run.Route.Nodes.Where(item => item != null &&
                string.Equals(item.NodeId, GuardianNodeId, StringComparison.Ordinal)).ToArray();
            if (nodes.Length != 1 || nodes[0].Kind != ExpeditionRouteNodeKind.Guardian ||
                !nodes[0].IsMandatory || nodes[0].MainPathIndex != 3 ||
                !string.Equals(nodes[0].TemplateId, GuardianTemplateId, StringComparison.Ordinal))
                return Fail("The run does not contain the exact mandatory F10 Guardian node/template pair.", out error);

            RoomInstanceId expectedRoomId;
            try
            {
                expectedRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, GuardianNodeId);
            }
            catch (Exception exception)
            {
                return Fail("The Guardian node cannot derive its room identity: " + exception.GetType().Name + ".", out error);
            }

            if (scope == null || room == null || !scope.isActiveAndEnabled || scope.IsDisposed ||
                scope.RoomInstanceId != expectedRoomId ||
                !string.Equals(scope.TemplateId, GuardianTemplateId, StringComparison.Ordinal) ||
                !room.isActiveAndEnabled || !room.gameObject.activeInHierarchy ||
                !room.transform.IsChildOf(scope.transform))
                return Fail("Guardian boundaries require the active scope and room instance for the exact route node.", out error);

            RoomTemplatePrefab2D[] rooms = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (rooms.Length != 1 || !ReferenceEquals(rooms[0], room))
                return Fail("The exact Guardian scope must contain one matching RoomTemplatePrefab2D.", out error);

            try
            {
                roomData = room.ValidateGeneratedPrefab();
            }
            catch (Exception exception)
            {
                return Fail("Guardian source, Ground tilemap, ports, or markers are invalid: " +
                    exception.GetType().Name + ".", out error);
            }

            if (roomData == null || room.SourceDefinition == null || roomData.schemaVersion != 1 ||
                !string.Equals(roomData.templateId, GuardianTemplateId, StringComparison.Ordinal) ||
                roomData.widthTiles != 20 || roomData.heightTiles != 12 ||
                Mathf.Abs(roomData.tileSize - 1f) > GeometryTolerance ||
                roomData.gridRows == null || roomData.gridRows.Length == 0 ||
                RoomTemplateJsonLoader.GetCell(roomData, 0, 0) != '#' ||
                RoomTemplateJsonLoader.GetCell(roomData, roomData.widthTiles - 1, 0) != '#')
                return Fail("Guardian source must retain its 20x12 generation-1 floor with solid physical endpoints.", out error);

            RoomPositionMarker2D[] bossMarkers = room.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(item => item != null && string.Equals(item.MarkerId, CustodianMarkerId, StringComparison.Ordinal))
                .ToArray();
            RoomPositionMarkerData[] bossDefinitions = roomData.markers.Where(item => item != null &&
                string.Equals(item.id, CustodianMarkerId, StringComparison.Ordinal)).ToArray();
            if (bossMarkers.Length != 1 || bossDefinitions.Length != 1 ||
                !string.Equals(bossDefinitions[0].kind, "boss_spawn", StringComparison.Ordinal) ||
                !string.Equals(bossMarkers[0].Kind, "boss_spawn", StringComparison.Ordinal) ||
                bossMarkers[0].TilePosition != new Vector2Int(bossDefinitions[0].tileX, bossDefinitions[0].tileY) ||
                !bossMarkers[0].enabled || !bossMarkers[0].gameObject.activeInHierarchy ||
                !bossMarkers[0].transform.IsChildOf(room.transform))
                return Fail("Guardian must contain the unique real boss.custodian marker from its room definition.", out error);

            Quaternion roomRotation = room.transform.rotation;
            Vector3 roomScale = room.transform.lossyScale;
            if (Quaternion.Angle(roomRotation, Quaternion.identity) > GeometryTolerance ||
                (roomScale - Vector3.one).sqrMagnitude > GeometryTolerance * GeometryTolerance)
                return Fail("Guardian floor must remain world-axis aligned and unscaled for Custodian's horizontal physics.", out error);

            Physics2D.SyncTransforms();
            floorBounds = room.GroundCollider.bounds;
            cameraBounds = room.CameraBounds.bounds;
            float expectedLeft = room.transform.position.x;
            float expectedRight = expectedLeft + roomData.widthTiles * roomData.tileSize;
            float expectedFloorTop = room.transform.position.y + roomData.tileSize;
            if (!IsFinite(floorBounds.min.x) || !IsFinite(floorBounds.max.x) ||
                !IsFinite(floorBounds.min.y) || !IsFinite(floorBounds.max.y) || !IsFinite(cameraBounds.max.y) ||
                Mathf.Abs(floorBounds.min.x - expectedLeft) > GeometryTolerance ||
                Mathf.Abs(floorBounds.max.x - expectedRight) > GeometryTolerance ||
                Mathf.Abs(floorBounds.max.y - expectedFloorTop) > GeometryTolerance ||
                cameraBounds.max.y <= floorBounds.max.y)
                return Fail("GroundCollider bounds do not match the real Guardian floor endpoints and camera ceiling.", out error);

            return true;
        }

        private static GameObject CreateInactiveWall(string name, float x, float centerY, float z,
            float width, float height, int layer)
        {
            var wall = new GameObject(name);
            wall.SetActive(false);
            wall.layer = layer;
            wall.transform.position = new Vector3(x, centerY, z);
            wall.transform.rotation = Quaternion.identity;
            wall.transform.localScale = Vector3.one;
            Rigidbody2D body = wall.AddComponent<Rigidbody2D>();
            body.bodyType = RigidbodyType2D.Static;
            body.gravityScale = 0f;
            body.simulated = true;
            BoxCollider2D collider = wall.AddComponent<BoxCollider2D>();
            collider.size = new Vector2(width, height);
            collider.isTrigger = false;
            return wall;
        }

        private static bool IsValidWall(GameObject wall, RoomLifetimeScope scope, string expectedName,
            float edgeX, float centerY, float z, float width, float height, int groundLayer)
        {
            if (wall == null || !wall.activeInHierarchy || wall.layer != groundLayer ||
                !string.Equals(wall.name, expectedName, StringComparison.Ordinal) ||
                !ReferenceEquals(wall.transform.parent, scope.transform) ||
                wall.GetComponents<Rigidbody2D>().Length != 1 ||
                wall.GetComponents<BoxCollider2D>().Length != 1 ||
                wall.GetComponents<Collider2D>().Length != 1 || wall.GetComponent<SpriteRenderer>() != null)
                return false;

            Rigidbody2D body = wall.GetComponent<Rigidbody2D>();
            BoxCollider2D collider = wall.GetComponent<BoxCollider2D>();
            Vector3 expectedPosition = new Vector3(edgeX, centerY, z);
            Bounds effectiveBounds = collider.bounds;
            return body.bodyType == RigidbodyType2D.Static && body.simulated &&
                collider.enabled && !collider.isTrigger &&
                (wall.transform.position - expectedPosition).sqrMagnitude <= GeometryTolerance * GeometryTolerance &&
                Quaternion.Angle(wall.transform.rotation, Quaternion.identity) <= GeometryTolerance &&
                (wall.transform.lossyScale - Vector3.one).sqrMagnitude <= GeometryTolerance * GeometryTolerance &&
                collider.offset.sqrMagnitude <= GeometryTolerance * GeometryTolerance &&
                (collider.size - new Vector2(width, height)).sqrMagnitude <= GeometryTolerance * GeometryTolerance &&
                Mathf.Abs(effectiveBounds.min.x - (edgeX - width * 0.5f)) <= GeometryTolerance &&
                Mathf.Abs(effectiveBounds.max.x - (edgeX + width * 0.5f)) <= GeometryTolerance &&
                Mathf.Abs(effectiveBounds.min.y - (centerY - height * 0.5f)) <= GeometryTolerance &&
                Mathf.Abs(effectiveBounds.max.y - (centerY + height * 0.5f)) <= GeometryTolerance;
        }

        private static void RetireWall(GameObject wall)
        {
            if (wall == null) return;
            wall.SetActive(false);
            if (Application.isPlaying) UnityEngine.Object.Destroy(wall);
            else UnityEngine.Object.DestroyImmediate(wall);
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static bool Fail(string reason, out string error)
        {
            error = reason;
            return false;
        }
    }
}
#endif
