#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Inventory;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Rooms;
using UnityEditor;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Binds one inactive diagnostic cache actor to the exact active F10 E1 room. It only forwards
    /// sensor contacts to ApplicationBootstrapper; the room scope owns actor and subscription cleanup.
    /// </summary>
    internal sealed class F10ExplorationGoldCacheBinding2D : IDisposable
    {
        private const string NodeId = "sample.patio.exploration";
        private const string TemplateId = "room.patio.e1";
        private const string CacheId = ExplorationGoldCachePickup2D.F10MarkerId;
        private const string DefinitionResource = "Luckbound/Data/Rooms/F10PatioExplorationE1Room";
        private const string DiagnosticPrefabName = "F10ExplorationGoldCacheDiagnostic";
        private const float PoseTolerance = 0.001f;

        private readonly ApplicationBootstrapper _application;
        private readonly ExpeditionGameplayComposition _owner;
        private readonly RoomEncounterRuntimeContext _context;
        private readonly RoomLifetimeScope _scope;
        private readonly ExplorationGoldCachePickup2D _pickup;
        private ExplorationGoldCacheContact _pendingContact;
        private ExpeditionMutationCommitResult<InventoryOperationOutcome> _lastResult;
        private string _lastError = string.Empty;
        private bool _requestInFlight;
        private bool _disposed;

        private F10ExplorationGoldCacheBinding2D(ApplicationBootstrapper application,
            ExpeditionGameplayComposition owner, RoomEncounterRuntimeContext context,
            ExplorationGoldCachePickup2D pickup)
        {
            _application = application;
            _owner = owner;
            _context = context;
            _scope = context.Scope;
            _pickup = pickup;
        }

        internal ExplorationGoldCachePickup2D Pickup => _pickup;
        internal ExplorationGoldCacheContact PendingContact => _pendingContact;
        internal ExpeditionMutationCommitResult<InventoryOperationOutcome> LastResult => _lastResult;
        internal string LastError => _lastError;
        internal bool IsRequestInFlight => _requestInFlight;
        internal bool HasRetainedContact => _pendingContact != null;
        internal bool CanRetry => !_requestInFlight && _pendingContact != null;
        internal bool IsDisposed => _disposed;

        /// <summary>Creates the exact room-local actor, subscribes, registers cleanup, then activates it.</summary>
        internal static F10ExplorationGoldCacheBinding2D Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition owner, RoomEncounterRuntimeContext context,
            GameObject inactiveCachePrefab)
        {
            if (!Application.isPlaying)
                throw new InvalidOperationException("The F10 cache binding requires an active Editor play session.");
            ValidateSessionAndContext(application, owner, context);
            if (!IsValidInactivePrefab(inactiveCachePrefab))
                throw new InvalidOperationException("The cache binding requires the inactive diagnostic cache prefab asset.");

            RoomPositionMarker2D marker = FindUniqueE1CacheMarker(context.Scope);
            if (context.Scope.GetComponentsInChildren<ExplorationGoldCachePickup2D>(true).Length != 0)
                throw new InvalidOperationException("The exact active E1 scope already contains a cache pickup.");

            GameObject instance = UnityEngine.Object.Instantiate(inactiveCachePrefab,
                marker.transform.position, marker.transform.rotation);
            F10ExplorationGoldCacheBinding2D binding = null;
            try
            {
                if (instance == null)
                    throw new InvalidOperationException("Unity did not instantiate the inactive diagnostic cache prefab.");
                instance.name = DiagnosticPrefabName + ".Runtime";
                if (instance.activeSelf || instance.activeInHierarchy || instance.transform.parent != null ||
                    !IsNear(instance.transform.position, marker.transform.position))
                    throw new InvalidOperationException("The cache actor must remain inactive and unowned at the exact marker pose before initialization.");

                ExplorationGoldCachePickup2D pickup = instance.GetComponent<ExplorationGoldCachePickup2D>();
                if (pickup == null || instance.GetComponentsInChildren<ExplorationGoldCachePickup2D>(true).Length != 1)
                    throw new InvalidOperationException("The instantiated cache root must contain exactly one pickup sensor.");

                pickup.Initialize(context.Scope, marker, context.Player, CacheId, context.ActivationGeneration);
                if (!ReferenceEquals(instance.transform.parent, context.Scope.transform))
                    throw new InvalidOperationException("The active room scope did not adopt its cache actor.");

                binding = new F10ExplorationGoldCacheBinding2D(application, owner, context, pickup);
                pickup.ContactRequested += binding.OnContactRequested;
                context.Scope.OwnResource(binding);
                instance.SetActive(true);
                return binding;
            }
            catch
            {
                binding?.Dispose();
                // Before Initialize adopts the clone, a failed attachment owns only this inactive instance.
                // Once the scope has parented it, leave actor cleanup to that scope and preserve any later pending contact.
                if (instance != null && !ReferenceEquals(instance.transform.parent, context.Scope.transform))
                    UnityEngine.Object.Destroy(instance);
                throw;
            }
        }

        /// <summary>
        /// Retries the exact retained sensor contact through the same application API. It never constructs
        /// a replacement contact or a new reward identity.
        /// </summary>
        internal async Task<ExpeditionMutationCommitResult<InventoryOperationOutcome>> RetryAsync()
        {
            if (_requestInFlight)
                return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(null, false,
                    _lastResult != null && _lastResult.Pending,
                    "The exact cache contact is already being processed.");
            if (_pendingContact == null)
                return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(null, false, false,
                    "There is no retained physical cache contact to retry.");

            ExplorationGoldCacheContact contact = _pendingContact;
            _lastError = string.Empty;
            _requestInFlight = true;
            return await ProcessContactAsync(contact);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            if (_pickup != null) _pickup.ContactRequested -= OnContactRequested;

            if (_pendingContact != null)
            {
                _lastError = "The room scope disposed this binding while its exact cache contact was retained. " +
                    "The contact was not released or replaced; retry it through this binding if the pending save requires it.";
                if (_pickup != null) Debug.LogError(_lastError, _pickup);
                else Debug.LogError(_lastError);
            }
        }

        private void OnContactRequested(ExplorationGoldCacheContact contact)
        {
            if (_disposed)
            {
                ReportError("The cache sensor raised a contact after its room binding was disposed.");
                return;
            }
            if (contact == null || !ReferenceEquals(contact.Pickup, _pickup) ||
                !ReferenceEquals(contact.Scope, _scope) || !ReferenceEquals(contact.Player, _context.Player))
            {
                ReportError("The cache sensor supplied a contact outside this exact room binding.");
                return;
            }
            if (_requestInFlight)
            {
                if (!ReferenceEquals(_pendingContact, contact))
                    ReportError("A second cache contact arrived while the first exact contact was in flight.");
                return;
            }
            if (_pendingContact != null)
            {
                if (!ReferenceEquals(_pendingContact, contact))
                    ReportError("A different cache contact cannot replace the retained physical contact.");
                return;
            }

            _pendingContact = contact;
            _lastResult = null;
            _lastError = string.Empty;
            _requestInFlight = true;
            _ = ProcessContactAsync(contact);
        }

        private async Task<ExpeditionMutationCommitResult<InventoryOperationOutcome>> ProcessContactAsync(
            ExplorationGoldCacheContact contact)
        {
            try
            {
                ExpeditionMutationCommitResult<InventoryOperationOutcome> result =
                    await _application.CollectF10ExplorationCacheAsync(_owner, contact);
                if (!ReferenceEquals(_pendingContact, contact))
                {
                    ReportError("The application completed a cache contact that no longer matches this binding.");
                    return result;
                }

                _lastResult = result;
                _lastError = result.Persisted ? string.Empty : result.Message;
                if (!result.Pending) _pendingContact = null;
                return result;
            }
            catch (Exception exception)
            {
                bool applicationOwnsPendingContact = false;
                if (_application != null)
                {
                    try
                    {
                        applicationOwnsPendingContact = _application.OwnsPendingF10CacheContact(_owner, contact);
                    }
                    catch (Exception ownershipException)
                    {
                        _lastError = "The cache failure was followed by an error checking its exact pending owner: " +
                            ownershipException.Message;
                        if (_pickup != null) Debug.LogException(ownershipException, _pickup);
                        else Debug.LogError(_lastError);
                    }
                }

                _lastError = string.IsNullOrEmpty(_lastError)
                    ? "The application cache operation failed: " + exception.Message
                    : _lastError + " Original operation error: " + exception.Message;
                if (_pickup != null) Debug.LogException(exception, _pickup);
                else Debug.LogError(_lastError);

                if (applicationOwnsPendingContact)
                {
                    _lastResult = new ExpeditionMutationCommitResult<InventoryOperationOutcome>(
                        null, false, true, _lastError);
                    return _lastResult;
                }

                // Only this exact old contact may be released. ReleaseRejectedContact is reference checked,
                // so a newer sensor contact can never be adopted or rejected by this catch path.
                if (contact != null && contact.Pickup != null && contact.Pickup.HasPendingContact)
                    contact.Pickup.ReleaseRejectedContact(contact);
                if (ReferenceEquals(_pendingContact, contact)) _pendingContact = null;
                _lastResult = new ExpeditionMutationCommitResult<InventoryOperationOutcome>(
                    null, false, false, _lastError);
                return _lastResult;
            }
            finally
            {
                _requestInFlight = false;
            }
        }

        private void ReportError(string message)
        {
            _lastError = message ?? string.Empty;
            if (_pickup != null) Debug.LogError(_lastError, _pickup);
            else Debug.LogError(_lastError);
        }

        private static void ValidateSessionAndContext(ApplicationBootstrapper application,
            ExpeditionGameplayComposition owner, RoomEncounterRuntimeContext context)
        {
            if (application == null || owner == null || context == null || application.ActiveRun == null)
                throw new ArgumentNullException(nameof(context), "A saved F10 session, ready composition, and exact room context are required.");
            if (context.Scope == null || context.Controller == null || context.Player == null ||
                application.ActiveRun.Route == null)
                throw new InvalidOperationException("The F10 room context or active route has been disposed or is incomplete.");
            if (!ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun) || !owner.IsReady ||
                !ReferenceEquals(owner.PlayerMotor, context.Player) ||
                !ReferenceEquals(owner.PlayerObject, context.Player.gameObject) ||
                !ReferenceEquals(owner.RoomTransitions, context.Controller) ||
                !ReferenceEquals(context.Controller.ActiveScope, context.Scope) ||
                !ReferenceEquals(context.Controller.ActiveRoomRoot, context.Scope.gameObject) ||
                !context.Controller.IsCurrentRoom(context.RoomInstanceId) ||
                context.Controller.CurrentRoomId != context.RoomInstanceId ||
                context.Scope.IsDisposed || !context.Scope.isActiveAndEnabled ||
                !context.IsCurrentRoomScope() || context.RunId != application.ActiveRun.RunId ||
                context.RouteGenerationVersion != application.ActiveRun.Route.GenerationVersion ||
                context.ActivationGeneration <= 0 ||
                !string.Equals(context.NodeId, NodeId, StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, TemplateId, StringComparison.Ordinal) ||
                !string.Equals(context.Controller.CurrentNodeId, NodeId, StringComparison.Ordinal) ||
                !string.Equals(context.Scope.TemplateId, TemplateId, StringComparison.Ordinal) ||
                application.ActiveRoomInstanceId != context.RoomInstanceId)
                throw new InvalidOperationException("The binding does not own the exact current F10 Patio E1 session and room activation.");

            ExpeditionRouteNode[] nodes = application.ActiveRun.Route.Nodes.Where(node =>
                string.Equals(node.NodeId, NodeId, StringComparison.Ordinal)).ToArray();
            if (nodes.Length != 1 || nodes[0].Kind != ExpeditionRouteNodeKind.Exploration ||
                !string.Equals(nodes[0].TemplateId, TemplateId, StringComparison.Ordinal) ||
                !string.Equals(nodes[0].SectorId, "patio", StringComparison.Ordinal))
                throw new InvalidOperationException("The owned F10 route does not identify its exact Patio E1 exploration node.");
        }

        private static RoomPositionMarker2D FindUniqueE1CacheMarker(RoomLifetimeScope scope)
        {
            if (scope == null || scope.IsDisposed || !scope.isActiveAndEnabled)
                throw new InvalidOperationException("The Patio E1 room scope is not active.");
            RoomTemplatePrefab2D[] templates = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            TextAsset canonicalDefinition = Resources.Load<TextAsset>(DefinitionResource);
            if (templates.Length != 1 || templates[0] == null || !templates[0].isActiveAndEnabled ||
                EditorUtility.IsPersistent(templates[0].gameObject) || canonicalDefinition == null ||
                templates[0].SourceDefinition == null ||
                !string.Equals(templates[0].SourceDefinition.text, canonicalDefinition.text, StringComparison.Ordinal) ||
                !(ReferenceEquals(templates[0].transform, scope.transform) || templates[0].transform.IsChildOf(scope.transform)))
                throw new InvalidOperationException("The active E1 scope must own one room template with the canonical E1 JSON source.");

            RoomTemplateData definition = RoomTemplateJsonLoader.Load(templates[0].SourceDefinition.text);
            if (definition == null || !string.Equals(definition.templateId, TemplateId, StringComparison.Ordinal) ||
                definition.markers == null)
                throw new InvalidOperationException("The active room source is not the E1 template definition.");
            RoomPositionMarkerData[] cacheDefinitions = definition.markers.Where(marker => marker != null &&
                string.Equals(marker.id, CacheId, StringComparison.Ordinal)).ToArray();
            if (cacheDefinitions.Length != 1 || !string.Equals(cacheDefinitions[0].kind, "treasure", StringComparison.Ordinal) ||
                cacheDefinitions[0].tileX != 21 || cacheDefinitions[0].tileY != 8 || definition.tileSize <= 0)
                throw new InvalidOperationException("The E1 JSON must define one treasure cache at tile (21, 8).");

            RoomPositionMarker2D[] markers = scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(marker => marker != null && string.Equals(marker.MarkerId, CacheId, StringComparison.Ordinal)).ToArray();
            if (markers.Length != 1)
                throw new InvalidOperationException("The active E1 scope must contain exactly one cache.exploration marker.");

            RoomPositionMarker2D marker = markers[0];
            RoomPositionMarkerData cacheDefinition = cacheDefinitions[0];
            Vector3 expectedPose = templates[0].transform.TransformPoint(new Vector3(
                (cacheDefinition.tileX + 0.5f) * definition.tileSize, cacheDefinition.tileY * definition.tileSize, 0f));
            if (!marker.isActiveAndEnabled || !marker.gameObject.activeInHierarchy ||
                !string.Equals(marker.Kind, "treasure", StringComparison.Ordinal) ||
                marker.TilePosition != new Vector2Int(21, 8) ||
                !(ReferenceEquals(marker.transform, templates[0].transform) || marker.transform.IsChildOf(templates[0].transform)) ||
                !IsNear(marker.transform.position, expectedPose) ||
                Quaternion.Angle(marker.transform.rotation, templates[0].transform.rotation) > PoseTolerance ||
                !IsNear(marker.transform.lossyScale, templates[0].transform.lossyScale))
                throw new InvalidOperationException("The unique live cache marker does not match its JSON-derived E1 pose.");
            return marker;
        }

        private static bool IsValidInactivePrefab(GameObject prefab)
        {
            if (prefab == null || !string.Equals(prefab.name, DiagnosticPrefabName, StringComparison.Ordinal) ||
                prefab.activeSelf || prefab.activeInHierarchy || !EditorUtility.IsPersistent(prefab) ||
                !PrefabUtility.IsPartOfPrefabAsset(prefab) || prefab.GetComponent<Rigidbody2D>() != null)
                return false;

            ExplorationGoldCachePickup2D[] pickups = prefab.GetComponentsInChildren<ExplorationGoldCachePickup2D>(true);
            Collider2D[] colliders = prefab.GetComponentsInChildren<Collider2D>(true);
            BoxCollider2D box = prefab.GetComponent<BoxCollider2D>();
            return pickups.Length == 1 && ReferenceEquals(pickups[0].gameObject, prefab) &&
                colliders.Length == 1 && ReferenceEquals(colliders[0], box) && box != null && box.enabled &&
                box.isTrigger && box.size == Vector2.one && !pickups[0].HasPendingContact;
        }

        private static bool IsNear(Vector3 actual, Vector3 expected)
        {
            return (actual - expected).sqrMagnitude <= PoseTolerance * PoseTolerance;
        }
    }
}
#endif
