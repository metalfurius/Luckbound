#if UNITY_EDITOR
using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;

namespace Luckbound.App
{
    public sealed partial class SaveRepository
    {
        private PendingV7SessionMutation _f10V7PendingSessionMutation;
        private string _f10V7SessionConfirmedJson;
        private string _f10V7SessionLastConfirmedJson;
        private bool _f10V7SessionRollbackConsumed;
        private bool _f10V7SessionRollbackReserved;

        /// <summary>
        /// Commits a complete V7 candidate through the one capability minted by authenticated
        /// SafeOpen. This stores no gameplay state and never publishes ActiveRun.
        /// </summary>
        internal async Task<F10V7SessionCommitResult> CommitF10V7SessionForPreproductionAsync(
            F10V7SessionHandle handle, PinnedProfileCandidateV7 candidate)
        {
            if (handle == null || candidate == null)
                return F10V7SessionCommitResult.Rejected("SessionHandleRequired: an authenticated handle and full V7 candidate are required.");

            await _gate.WaitAsync();
            try
            {
                if (!IsRetainedF10V7SessionHandle(handle, handle.ExactJson, handle.RunId,
                    handle.ItemCatalog, handle.Registry))
                    return F10V7SessionCommitResult.Rejected("SessionHandleMismatch: this repository does not retain that authenticated session capability.");
                if (_v7ExtractedSettlementOwner != null)
                    return F10V7SessionCommitResult.Rejected("WritePending: an extracted settlement already owns the repository.");
                if (_pendingProfile != null || _f10V7PendingSessionMutation != null)
                    return F10V7SessionCommitResult.Rejected(
                        "WritePending: resolve the exact pending V7 session mutation through its handle-bound retry.", pending: true);
                if (!_v7ProfileProtocolLatched || _v7StorageView == null)
                    return F10V7SessionCommitResult.Rejected("ProtocolConflict: an authenticated V7 session is required.");

                string expectedJson = _f10V7SessionConfirmedJson ?? handle.ExactJson;
                if (string.IsNullOrWhiteSpace(expectedJson))
                    return F10V7SessionCommitResult.Rejected("SessionSourceMissing: no exact confirmed session JSON is retained.");

                SessionV7FreshSelection fresh;
                try { fresh = await ReadFreshF10V7SessionSelectionUnderLockAsync(); }
                catch (Exception exception)
                { return F10V7SessionCommitResult.Rejected("FreshReadFailed: " + exception.Message); }
                if (fresh == null || fresh.View == null ||
                    (fresh.View.Status != SaveLoadStatus.LoadedPrimary &&
                     fresh.View.Status != SaveLoadStatus.RecoveredBackup) ||
                    fresh.View.SourceContentVersion != 7 || fresh.View.Access != SaveDataAccess.ReadWrite ||
                    fresh.View.Envelope == null || fresh.View.Envelope.activeExpedition == null)
                    return F10V7SessionCommitResult.Rejected(
                        "AuthenticatedActiveV7Required: fresh storage did not select an active writable V7 profile.");
                if (!string.Equals(fresh.View.OriginalJson, expectedJson, StringComparison.Ordinal))
                    return F10V7SessionCommitResult.Rejected(
                        "SessionSourceMismatch: fresh authenticated primary/backup selection differs from the exact confirmed JSON.");

                ProfileSaveEnvelopeV7 prior = fresh.View.Envelope;
                if (!RunId.TryParse(prior.activeExpedition.runId, out RunId priorRunId) || priorRunId != handle.RunId)
                    return F10V7SessionCommitResult.Rejected("RunIdentityMismatch: the fresh V7 profile is not bound to this session handle.");

                if (!SaveV7CandidateMapper.TryRestoreCurrentForSettlement(prior, handle.ItemCatalog,
                    handle.Registry, out ExpeditionRunConfiguration exactRun,
                    out ExpeditionSaveDataV7 currentState, out ResolvedEncounterPlanV1 ignoredPlan,
                    out SaveV7Error restoreError))
                    return F10V7SessionCommitResult.Rejected(restoreError.Code + ": " + restoreError.Message);
                if (exactRun == null || currentState == null || exactRun.RunId != handle.RunId ||
                    exactRun.Inventory == null || !ReferenceEquals(exactRun.Inventory.Catalog, handle.ItemCatalog))
                    return F10V7SessionCommitResult.Rejected(
                        "CatalogRevisionUnavailable: the authenticated run did not restore with the exact retained item catalog.");

                ExpeditionSaveDataV7 baseline = handle.BaselineState;
                if (baseline == null || !RunId.TryParse(baseline.runId, out RunId baselineRunId) ||
                    baselineRunId != handle.RunId || !ValidClaimSet(baseline.claimedRewardIds) ||
                    !ValidClaimSet(currentState.claimedRewardIds))
                    return F10V7SessionCommitResult.Rejected(
                        "RollbackBaselineInvalid: the handle's authenticated opening baseline or current claims are invalid.");

                int generation = prior.generation;
                long sequence = prior.sequence;
                ProfileSaveEnvelopeV7 next;
                string json;
                try
                {
                    next = candidate.CreateEnvelope(NextGeneration(generation), NextSequence(sequence),
                        DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture));
                    if (!SaveV7CandidateMapper.TryValidateCommit(next, exactRun, handle.Registry,
                        out SaveV7Error validationError))
                        return F10V7SessionCommitResult.Rejected(validationError.Code + ": " + validationError.Message);
                    if (!SaveV7CandidateMapper.TryValidateTransition(prior, null, next, out validationError))
                        return F10V7SessionCommitResult.Rejected(validationError.Code + ": " + validationError.Message);
                    if (!SaveV7CandidateMapper.HasSameProfilePayload(prior.profile, next.profile))
                        return F10V7SessionCommitResult.Rejected(
                            "ProfileMutationNotAllowed: a room session mutation must preserve the complete permanent profile.");
                    if (next.activeExpedition == null || !RunId.TryParse(next.activeExpedition.runId, out RunId nextRunId) ||
                        nextRunId != handle.RunId || !ValidClaimSet(next.activeExpedition.claimedRewardIds))
                        return F10V7SessionCommitResult.Rejected("PlanMismatch: the candidate must retain this active run and a valid claim set.");

                    string[] priorClaims = currentState.claimedRewardIds;
                    string[] candidateClaims = next.activeExpedition.claimedRewardIds;
                    bool openingRollback = !_f10V7SessionRollbackConsumed;
                    if (openingRollback)
                    {
                        // The first mutation preserves every claim in the authenticated room-entry
                        // rollback baseline. It may remove claims outside that baseline and may add
                        // claims whose gameplay authority is checked by the App caller.
                        if (_f10V7SessionRollbackReserved || !ContainsAll(priorClaims, baseline.claimedRewardIds) ||
                            !ContainsAll(candidateClaims, baseline.claimedRewardIds))
                            return F10V7SessionCommitResult.Rejected(
                                "RollbackTransitionRejected: the first candidate must retain every claim in the authenticated opening baseline.");
                    }
                    else if (!ContainsAll(candidateClaims, priorClaims))
                    {
                        return F10V7SessionCommitResult.Rejected(
                            "ClaimRegression: later session commits must retain every claim in the last confirmed V7 JSON.");
                    }

                    byte[] bytes = SaveV7JsonCodec.EncodeProfile(next);
                    json = V7Utf8.GetString(bytes);
                    if (!SaveV7JsonCodec.TryDecodeProfile(bytes, out next, out validationError))
                        return F10V7SessionCommitResult.Rejected(validationError.Code + ": " + validationError.Message);
                    if (!SaveV7CandidateMapper.TryValidateCommit(next, exactRun, handle.Registry, out validationError) ||
                        !SaveV7CandidateMapper.TryValidateTransition(prior, null, next, out validationError))
                        return F10V7SessionCommitResult.Rejected(validationError.Code + ": " + validationError.Message);
                    if (!SaveV7CandidateMapper.HasSameProfilePayload(prior.profile, next.profile))
                        return F10V7SessionCommitResult.Rejected(
                            "ProfileMutationNotAllowed: encoding changed the permanent profile payload.");
                    if (next.activeExpedition == null ||
                        (openingRollback && !ContainsAll(next.activeExpedition.claimedRewardIds, baseline.claimedRewardIds)) ||
                        (!openingRollback && !ContainsAll(next.activeExpedition.claimedRewardIds, priorClaims)))
                        return F10V7SessionCommitResult.Rejected("PlanMismatch: encoded candidate changed the authorized claim transition.");
                }
                catch (SaveV7ValidationException exception)
                { return F10V7SessionCommitResult.Rejected(exception.Error.Code + ": " + exception.Message); }
                catch (Exception exception) when (exception is ArgumentException || exception is FormatException ||
                    exception is OverflowException || exception is InvalidOperationException)
                { return F10V7SessionCommitResult.Rejected("InvalidData: " + exception.Message); }

                // A recovered backup is the confirmed source, but it is never promoted merely by
                // reading. The write receives a last-known-good primary only when primary won selection.
                var pending = new PendingWrite(SaveDocument.Profile, json,
                    fresh.PrimaryValid ? fresh.View.OriginalJson : null, next, 7);
                _pendingProfile = pending;
                _f10V7PendingSessionMutation = new PendingV7SessionMutation(pending, handle,
                    consumesOpeningRollback: !_f10V7SessionRollbackConsumed);
                _f10V7SessionRollbackReserved = _f10V7PendingSessionMutation.ConsumesOpeningRollback;
                return await CommitPendingF10V7SessionUnderLockAsync(_f10V7PendingSessionMutation);
            }
            finally { _gate.Release(); }
        }

        /// <summary>Retries only the exact pending bytes or returns the latest confirmed JSON idempotently.</summary>
        internal async Task<F10V7SessionCommitResult> RetryF10V7SessionForPreproductionAsync(
            F10V7SessionHandle handle)
        {
            if (handle == null)
                return F10V7SessionCommitResult.Rejected("SessionHandleRequired: retry requires the authenticated handle.");
            await _gate.WaitAsync();
            try
            {
                if (!IsRetainedF10V7SessionHandle(handle, handle.ExactJson, handle.RunId,
                    handle.ItemCatalog, handle.Registry))
                    return F10V7SessionCommitResult.Rejected("SessionHandleMismatch: this repository does not retain that authenticated session capability.");
                if (!_v7ProfileProtocolLatched || _v7ExtractedSettlementOwner != null)
                    return F10V7SessionCommitResult.Rejected(
                        "ProtocolConflict: the V7 session cannot retry while another settlement owns the repository.",
                        pending: _f10V7PendingSessionMutation != null);
                if (_f10V7PendingSessionMutation == null)
                {
                    if (_pendingProfile != null)
                        return F10V7SessionCommitResult.Rejected(
                            "WritePending: another profile operation owns the pending slot.", pending: true);
                    string expectedJson = _f10V7SessionLastConfirmedJson;
                    if (string.IsNullOrWhiteSpace(expectedJson) ||
                        !string.Equals(expectedJson, _f10V7SessionConfirmedJson, StringComparison.Ordinal))
                        return F10V7SessionCommitResult.Rejected("NoSessionMutationPending: this handle has no matching confirmed mutation.");

                    // Confirmation may have reached storage before the App observed the result.
                    // Recheck the exact primary and authenticate it; never rewrite on this path.
                    SaveStorageSnapshot readback;
                    try { readback = await _store.ReadAsync(SaveDocument.Profile); }
                    catch (Exception exception)
                    {
                        return F10V7SessionCommitResult.Rejected(
                            "ReadbackPending: could not recheck the confirmed session primary: " + exception.Message,
                            pending: true);
                    }
                    if (readback == null || !string.Equals(readback.PrimaryJson, expectedJson, StringComparison.Ordinal))
                        return F10V7SessionCommitResult.Rejected(
                            "ReadbackPending: the current primary differs from the previously confirmed session bytes.",
                            pending: true);
                    SaveV7LoadView view = DecodeV7Storage(readback.PrimaryJson, SaveLoadStatus.LoadedPrimary);
                    if (!IsV7Usable(view) || view.SourceContentVersion != 7 ||
                        view.Access != SaveDataAccess.ReadWrite || view.Envelope == null ||
                        view.Envelope.activeExpedition == null ||
                        !RunId.TryParse(view.Envelope.activeExpedition.runId, out RunId confirmedRunId) ||
                        confirmedRunId != handle.RunId)
                        return F10V7SessionCommitResult.Rejected(
                            "ReadbackPending: the exact session primary no longer authenticates for this handle.",
                            pending: true);
                    return F10V7SessionCommitResult.Confirmed(expectedJson,
                        "The already confirmed session JSON was rechecked against the authenticated primary.");
                }
                if (!ReferenceEquals(_f10V7PendingSessionMutation.Handle, handle))
                    return F10V7SessionCommitResult.Rejected("SessionHandleMismatch: the pending mutation belongs to another handle.", pending: true);
                if (_pendingProfile == null || !ReferenceEquals(_pendingProfile, _f10V7PendingSessionMutation.Pending))
                    return F10V7SessionCommitResult.Rejected("ProtocolConflict: the exact pending session mutation lost its repository owner.", pending: true);
                return await CommitPendingF10V7SessionUnderLockAsync(_f10V7PendingSessionMutation);
            }
            finally { _gate.Release(); }
        }

        private async Task<SessionV7FreshSelection> ReadFreshF10V7SessionSelectionUnderLockAsync()
        {
            SaveStorageSnapshot storage = await _store.ReadAsync(SaveDocument.Profile);
            if (storage == null) return null;

            SaveV7LoadView primary = DecodeV7Storage(storage.PrimaryJson, SaveLoadStatus.LoadedPrimary);
            // Preserve normal SafeOpen precedence: a usable or incompatible primary always wins.
            if (IsV7Usable(primary) || primary.Status == SaveLoadStatus.Incompatible)
                return new SessionV7FreshSelection(primary, IsV7Usable(primary));

            SaveV7LoadView backup = DecodeV7Storage(storage.BackupJson, SaveLoadStatus.RecoveredBackup);
            if (IsV7Usable(backup) || backup.Status == SaveLoadStatus.Incompatible)
                return new SessionV7FreshSelection(backup, false);
            if (primary.Status == SaveLoadStatus.Missing && backup.Status == SaveLoadStatus.Missing)
                return new SessionV7FreshSelection(primary, false);
            return new SessionV7FreshSelection(new SaveV7LoadView(SaveLoadStatus.Corrupted, 0,
                SaveDataAccess.Unavailable, storage.PrimaryJson ?? storage.BackupJson, null, null,
                new SaveV7Error(SaveV7ErrorCode.Corrupted, "profile",
                    "Fresh primary and backup copies are invalid; their bytes were preserved.")), false);
        }

        private async Task<F10V7SessionCommitResult> CommitPendingF10V7SessionUnderLockAsync(
            PendingV7SessionMutation pendingMutation)
        {
            if (pendingMutation == null || !ReferenceEquals(_f10V7PendingSessionMutation, pendingMutation) ||
                !ReferenceEquals(_pendingProfile, pendingMutation.Pending) ||
                !ReferenceEquals(_f10V7SessionHandle, pendingMutation.Handle) ||
                !IsRetainedF10V7SessionHandle(pendingMutation.Handle, pendingMutation.Handle.ExactJson,
                    pendingMutation.Handle.RunId, pendingMutation.Handle.ItemCatalog, pendingMutation.Handle.Registry))
                return F10V7SessionCommitResult.Rejected(
                    "ProtocolConflict: the pending bytes are not retained by the exact authenticated session handle.", pending: true);

            if (!pendingMutation.WriteSucceeded)
            {
                try
                {
                    await _store.WriteAsync(SaveDocument.Profile, pendingMutation.Pending.Json,
                        pendingMutation.Pending.LastKnownGoodPrimaryJson);
                    pendingMutation.WriteSucceeded = true;
                }
                catch (Exception exception)
                {
                    return F10V7SessionCommitResult.Rejected(
                        "WritePending: exact V7 session bytes and the one-use rollback reservation are retained for handle-bound retry: " + exception.Message,
                        pending: true);
                }
            }

            SaveStorageSnapshot readback;
            try { readback = await _store.ReadAsync(SaveDocument.Profile); }
            catch (Exception exception)
            {
                return F10V7SessionCommitResult.Rejected(
                    "ReadbackPending: the write succeeded; handle-bound retry will only read the primary again: " + exception.Message,
                    pending: true);
            }
            if (readback == null || !string.Equals(readback.PrimaryJson, pendingMutation.Pending.Json,
                StringComparison.Ordinal))
                return F10V7SessionCommitResult.Rejected(
                    "ReadbackPending: primary bytes differ from the exact candidate; handle-bound retry will only re-read.",
                    pending: true);

            SaveV7LoadView confirmed = DecodeV7Storage(readback.PrimaryJson, SaveLoadStatus.LoadedPrimary);
            ProfileSaveEnvelopeV7 expected = pendingMutation.Pending.Envelope as ProfileSaveEnvelopeV7;
            if (!IsV7Usable(confirmed) || confirmed.SourceContentVersion != 7 ||
                confirmed.Access != SaveDataAccess.ReadWrite || confirmed.Envelope == null ||
                !SameF10V7SessionEnvelopeIdentity(expected, confirmed.Envelope))
                return F10V7SessionCommitResult.Rejected(
                    "ReadbackPending: exact primary bytes did not authenticate as the expected active V7 envelope; retry will only re-read.",
                    pending: true);

            string confirmedJson = confirmed.OriginalJson;
            _v7StorageView = confirmed;
            _profilePrimaryJson = confirmedJson;
            _loadedProfileJson = confirmedJson;
            _profilePrimaryValid = true;
            _profile = null;
            _profileAccess = SaveDataAccess.Unavailable;
            _profileBlocked = true;
            _profileLoaded = true;
            _f10V7SessionConfirmedJson = confirmedJson;
            _f10V7SessionLastConfirmedJson = confirmedJson;
            if (pendingMutation.ConsumesOpeningRollback)
            {
                _f10V7SessionRollbackConsumed = true;
                _f10V7SessionRollbackReserved = false;
            }
            _pendingProfile = null;
            _f10V7PendingSessionMutation = null;
            return F10V7SessionCommitResult.Confirmed(confirmedJson,
                "V7 session mutation was synchronized and confirmed by exact authenticated primary readback.");
        }

        private static bool ValidClaimSet(string[] values)
        {
            return values != null && !values.Any(string.IsNullOrWhiteSpace) &&
                values.Distinct(StringComparer.Ordinal).Count() == values.Length;
        }

        private static bool ContainsAll(string[] superset, string[] subset)
        {
            return superset != null && subset != null && subset.All(value =>
                superset.Contains(value, StringComparer.Ordinal));
        }

        private static bool SameF10V7SessionEnvelopeIdentity(ProfileSaveEnvelopeV7 expected,
            ProfileSaveEnvelopeV7 actual)
        {
            return expected != null && actual != null && expected.activeExpedition != null &&
                actual.activeExpedition != null && expected.generation == actual.generation &&
                expected.sequence == actual.sequence &&
                string.Equals(expected.checksum, actual.checksum, StringComparison.Ordinal) &&
                string.Equals(expected.activeExpedition.runId, actual.activeExpedition.runId, StringComparison.Ordinal);
        }

        private sealed class PendingV7SessionMutation
        {
            internal PendingV7SessionMutation(PendingWrite pending, F10V7SessionHandle handle,
                bool consumesOpeningRollback)
            {
                Pending = pending ?? throw new ArgumentNullException(nameof(pending));
                Handle = handle ?? throw new ArgumentNullException(nameof(handle));
                ConsumesOpeningRollback = consumesOpeningRollback;
            }

            internal PendingWrite Pending { get; }
            internal F10V7SessionHandle Handle { get; }
            internal bool ConsumesOpeningRollback { get; }
            internal bool WriteSucceeded { get; set; }
        }

        private sealed class SessionV7FreshSelection
        {
            internal SessionV7FreshSelection(SaveV7LoadView view, bool primaryValid)
            { View = view; PrimaryValid = primaryValid; }
            internal SaveV7LoadView View { get; }
            internal bool PrimaryValid { get; }
        }
    }

    internal sealed class F10V7SessionCommitResult
    {
        private F10V7SessionCommitResult(bool persisted, bool pending, string message, string confirmedJson)
        {
            Persisted = persisted;
            Pending = pending;
            Message = message ?? string.Empty;
            ConfirmedJson = confirmedJson;
        }

        internal bool Persisted { get; }
        internal bool Pending { get; }
        internal string Message { get; }
        /// <summary>Exact authenticated primary JSON read back before the repository gate was released.</summary>
        internal string ConfirmedJson { get; }

        internal static F10V7SessionCommitResult Confirmed(string json, string message) =>
            new F10V7SessionCommitResult(true, false, message, json);

        internal static F10V7SessionCommitResult Rejected(string message, bool pending = false) =>
            new F10V7SessionCommitResult(false, pending, message, null);
    }
}
#endif
