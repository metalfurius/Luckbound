#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Scope-owned bridge from the isolated F10 C1 room to the real room encounter runtime.
    /// It only exposes physical clear evidence; rewards, saves and route advancement belong to later packages.
    /// </summary>
    [DisallowMultipleComponent]
    internal sealed class F10C1RuntimeCoordinator : MonoBehaviour, IRoomEncounterClearObserver, IDisposable
    {
        private const string C1NodeId = F10TechnicalEncounterPlanProvider.C1NodeId;
        private const string C1TemplateId = F10TechnicalEncounterPlanProvider.C1TemplateId;

        private ApplicationBootstrapper _application;
        private ExpeditionGameplayComposition _composition;
        private F10TechnicalEncounterPlanProvider _provider;
        private ExpeditionSessionReadinessRegistration _registration;
        private ExpeditionRoomActivationRegistration _activation;
        private ExpeditionRunConfiguration _run;
        private RoomLifetimeScope _scope;
        private RoomTemplatePrefab2D _room;
        private RoomEncounterRuntimeContext _context;
        private ExpeditionEncounterSessionSnapshotSource _snapshotSource;
        private RoomEncounterRuntimePlan _plan;
        private RoomEncounterRuntime _runtime;
        private RoomEncounterClearObservation _clearObservation;
        private ApplicationBootstrapper.F10V7SessionInitializationBinding _v7SessionBinding;
        private ApplicationBootstrapper.F10V7CombatPlanRuntimeBinding _v7PlanBinding;
        private string _setupFailure = string.Empty;
        private bool _clearAccepted;
        private bool _disposed;

        internal RoomEncounterRuntimeStatus RuntimeStatus => _runtime == null
            ? RoomEncounterRuntimeStatus.NotReady
            : _runtime.Status;

        internal int CurrentWaveNumber => _runtime == null ? 0 : _runtime.CurrentWaveNumber;
        internal int CompletedWaveCount => _runtime == null ? 0 : _runtime.CompletedWaveCount;
        internal RoomEncounterRuntime Runtime => _runtime;
        internal RoomEncounterRuntimeContext Context => _context;
        internal ExpeditionEncounterSessionSnapshotSource SnapshotSource => _snapshotSource;
        internal ApplicationBootstrapper.F10V7CombatPlanRuntimeBinding V7PlanBinding => _v7PlanBinding;
        internal bool IsSetupFailed => !string.IsNullOrEmpty(_setupFailure);
        internal bool IsDisposed => _disposed;
        internal bool HasPhysicalClearObservation => _clearAccepted && _clearObservation != null;
        internal RoomEncounterClearObservation PhysicalClearObservation =>
            HasPhysicalClearObservation ? _clearObservation : null;

        /// <summary>A read-only status surface for the isolated demo HUD/runner.</summary>
        internal string StatusMessage
        {
            get
            {
                if (!string.IsNullOrEmpty(_setupFailure)) return _setupFailure;
                if (_clearAccepted && _clearObservation != null)
                    return "C1 physical roster clear observed (" + _clearObservation.Actors.Count +
                        " actors). No reward, save, or route advancement was issued.";
                if (_disposed && _runtime == null)
                    return "C1 coordinator was disposed with its room scope before runtime preparation.";
                if (_disposed)
                    return "C1 coordinator was disposed with its room scope.";
                if (_runtime == null) return "C1 encounter runtime has not been prepared.";

                switch (_runtime.Status)
                {
                    case RoomEncounterRuntimeStatus.WaitingForSession:
                        return "C1 is waiting for real session readiness; the runtime will retry arming while this gate remains open.";
                    case RoomEncounterRuntimeStatus.Armed:
                        return "C1 encounter armed; wave " + _runtime.CurrentWaveNumber + " is active.";
                    case RoomEncounterRuntimeStatus.Cleared:
                        return "C1 runtime cleared without a retained physical roster observation.";
                    case RoomEncounterRuntimeStatus.Faulted:
                        return "C1 encounter faulted: " + _runtime.FaultReason;
                    case RoomEncounterRuntimeStatus.SessionEnded:
                        return "C1 session ended; encounter progression is inhibited.";
                    case RoomEncounterRuntimeStatus.Disposed:
                        return "C1 encounter runtime was disposed with its room scope.";
                    default:
                        return "C1 encounter runtime is not ready.";
                }
            }
        }

        /// <summary>
        /// Attaches only to the exact active C1 activation of the persisted diagnostic run.
        /// Invalid ownership/readiness preconditions throw before this method mutates the room scope.
        /// </summary>
        internal static F10C1RuntimeCoordinator Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, F10TechnicalEncounterPlanProvider provider)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            if (provider == null) throw new ArgumentNullException(nameof(provider));

            RoomLifetimeScope candidateScope = composition.RoomTransitions == null
                ? null
                : composition.RoomTransitions.ActiveScope;
            F10C1RuntimeCoordinator existing = candidateScope == null
                ? null
                : candidateScope.GetComponent<F10C1RuntimeCoordinator>();
            if (existing != null)
            {
                AttachmentView existingAttachment = ValidateAttachment(application, composition,
                    requireFreshEncounterContext: false);
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition) &&
                    ReferenceEquals(existing._provider, provider) &&
                    ReferenceEquals(existing._scope, existingAttachment.Scope) &&
                    ReferenceEquals(existing._activation, existingAttachment.Activation) &&
                    (existing._context == null || ReferenceEquals(existing._activation.Context, existing._context)) &&
                    (existing._snapshotSource == null || ReferenceEquals(existing._activation.Source, existing._snapshotSource)))
                    return existing;
                throw new InvalidOperationException("The active C1 room scope already owns another F10 runtime coordinator.");
            }

            AttachmentView attachment = ValidateAttachment(application, composition,
                requireFreshEncounterContext: true);

            F10C1RuntimeCoordinator coordinator = attachment.Scope.gameObject.AddComponent<F10C1RuntimeCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._provider = provider;
            coordinator._registration = attachment.Registration;
            coordinator._activation = attachment.Activation;
            coordinator._run = attachment.Run;
            coordinator._scope = attachment.Scope;
            coordinator._room = attachment.Room;

            try
            {
                F10C1RuntimeCoordinator ownedCoordinator = attachment.Scope.OwnResource(coordinator);
                if (!ReferenceEquals(ownedCoordinator, coordinator))
                    throw new InvalidOperationException("The active room scope did not retain the exact F10 coordinator.");
                coordinator.PrepareEncounter();
            }
            catch (Exception exception)
            {
                coordinator.FailSetup("C1 encounter setup failed closed: " + exception.Message);
            }

            return coordinator;
        }

        /// <summary>
        /// Attaches through the App's authenticated V7 plan binding. No plan, digest, provider,
        /// asset map, or clear authority is accepted from the caller.
        /// </summary>
        internal static F10C1RuntimeCoordinator AttachV7(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            if (!application.TryCreateF10V7CombatPlanRuntimeBinding(composition,
                    out ApplicationBootstrapper.F10V7CombatPlanRuntimeBinding binding,
                    out string bindingError))
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(bindingError)
                    ? "App refused the authenticated V7 C1 runtime binding."
                    : bindingError);

            RoomLifetimeScope candidateScope = binding.Scope;
            F10C1RuntimeCoordinator existing = candidateScope == null
                ? null
                : candidateScope.GetComponent<F10C1RuntimeCoordinator>();
            if (existing != null)
            {
                if (existing.IsBoundToV7PlanBinding(binding, binding.SessionBinding,
                        application, composition, existing._context, existing._runtime, binding.Revision) &&
                    ReferenceEquals(existing._scope, binding.Scope) &&
                    ReferenceEquals(existing._activation, binding.Activation) &&
                    ReferenceEquals(existing._snapshotSource, binding.Activation.Source))
                    return existing;
                throw new InvalidOperationException(
                    "The active C1 room scope already owns another F10 runtime coordinator.");
            }

            F10C1RuntimeCoordinator coordinator = candidateScope.gameObject
                .AddComponent<F10C1RuntimeCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._v7SessionBinding = binding.SessionBinding;
            coordinator._v7PlanBinding = binding;
            coordinator._registration = binding.Registration;
            coordinator._activation = binding.Activation;
            coordinator._run = binding.Run;
            coordinator._scope = binding.Scope;
            coordinator._room = binding.Room;

            try
            {
                F10C1RuntimeCoordinator ownedCoordinator = binding.Scope.OwnResource(coordinator);
                if (!ReferenceEquals(ownedCoordinator, coordinator))
                    throw new InvalidOperationException(
                        "The active room scope did not retain the exact F10 V7 coordinator.");
                coordinator.PrepareEncounter();
            }
            catch (Exception exception)
            {
                coordinator.FailSetup("V7 C1 encounter setup failed closed: " + exception.Message);
            }

            return coordinator;
        }

        private static AttachmentView ValidateAttachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, bool requireFreshEncounterContext)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun))
                throw new InvalidOperationException("C1 runtime requires the exact persisted F10 diagnostic run in Play Mode.");

            ExpeditionReadinessCompositionView readiness = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = readiness == null ? null : readiness.Run;
            ExpeditionRoomTransitionController transitions = readiness == null ? null : readiness.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = readiness == null ? null : readiness.ReadinessRegistration;
            if (!composition.isActiveAndEnabled || !composition.IsReady || readiness == null || !readiness.IsReady ||
                !ReferenceEquals(readiness.Owner, composition) || !ReferenceEquals(readiness.Application, application) ||
                !ReferenceEquals(run, application.ActiveRun) || run == null || run.Route == null ||
                run.Route.GenerationVersion != 2 || transitions == null ||
                !ReferenceEquals(transitions, composition.RoomTransitions) || registration == null ||
                registration.IsDisposed || !registration.IsOwnerActive ||
                !ReferenceEquals(registration.Owner, composition) ||
                registration.RouteGenerationVersion != run.Route.GenerationVersion)
                throw new InvalidOperationException("C1 runtime requires the ready composition and its live real-session readiness registration.");

            ExpeditionSaveData activeSave = application.ActiveExpedition;
            if (activeSave == null || !string.Equals(activeSave.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                !string.Equals(activeSave.currentNodeId, C1NodeId, StringComparison.Ordinal) ||
                activeSave.visitedNodeIds == null || activeSave.visitedNodeIds.Length == 0 ||
                !string.Equals(activeSave.visitedNodeIds[activeSave.visitedNodeIds.Length - 1], C1NodeId, StringComparison.Ordinal) ||
                !string.Equals(transitions.CurrentNodeId, C1NodeId, StringComparison.Ordinal) ||
                application.HasPendingSessionMutation || application.HasPendingRoomAdvance)
                throw new InvalidOperationException("The saved and active F10 route cursor must be settled on sample.patio.combat.");

            ExpeditionReadinessTransitionView transition = transitions.CaptureReadinessTransitionView();
            RoomLifetimeScope scope = transition == null ? null : transition.ActiveScope;
            RoomInstanceId expectedRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, C1NodeId);
            if (transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !string.Equals(transition.ActiveNodeId, C1NodeId, StringComparison.Ordinal) ||
                !string.Equals(transition.ActiveTemplateId, C1TemplateId, StringComparison.Ordinal) ||
                scope == null || !ReferenceEquals(scope, transitions.ActiveScope) ||
                !ReferenceEquals(transition.ActiveRoomRoot, scope.gameObject) || scope.IsDisposed ||
                !scope.isActiveAndEnabled || scope.RoomInstanceId != expectedRoomId ||
                !string.Equals(scope.TemplateId, C1TemplateId, StringComparison.Ordinal) ||
                !transitions.IsCurrentRoom(expectedRoomId) || transitions.CurrentRoomId != application.ActiveRoomInstanceId)
                throw new InvalidOperationException("C1 runtime requires the exact active sample.patio.combat room scope and settled route activation.");

            ExpeditionRoomActivationRegistration activation = registration.CurrentActivation;
            if (activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, scope) || !ReferenceEquals(activation.Controller, transitions) ||
                activation.RunId != run.RunId || !ReferenceEquals(activation.BoundRun, run) ||
                !string.Equals(activation.NodeId, C1NodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, C1TemplateId, StringComparison.Ordinal) ||
                (requireFreshEncounterContext && (activation.Context != null || activation.Source != null)))
                throw new InvalidOperationException("C1 readiness must own one bound activation with no prior encounter context or snapshot source.");

            if (readiness.PlayerMotor == null || !readiness.PlayerMotor.isActiveAndEnabled ||
                !readiness.PlayerMotor.ActorId.IsValid || readiness.PlayerObject == null ||
                !ReferenceEquals(readiness.PlayerMotor.gameObject, readiness.PlayerObject) ||
                readiness.PlayerObject.GetComponent<Collider2D>() == null)
                throw new InvalidOperationException("C1 runtime requires the bound live player actor and its real collider.");

            RoomTemplatePrefab2D[] roomComponents = transition.ActiveRoomRoot
                .GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            RoomTemplatePrefab2D room = roomComponents.Length == 1 ? roomComponents[0] : null;
            if (room == null || !room.isActiveAndEnabled || !room.gameObject.activeInHierarchy ||
                !room.transform.IsChildOf(scope.transform))
                throw new InvalidOperationException("C1 runtime requires exactly one active RoomTemplatePrefab2D under the active room scope.");

            return new AttachmentView(registration, activation, run, transitions, scope, room);
        }

        private void PrepareEncounter()
        {
            RoomEncounterRuntimePlan plan;
            string planError = string.Empty;
            if (_v7PlanBinding != null)
                plan = _v7PlanBinding.RuntimePlan;
            else if (_provider == null || !_provider.TryBuildC1(_run, _scope, _room,
                         out plan, out planError))
            {
                FailSetup("C1 plan provider refused the active room: " +
                    (_provider == null ? "no technical provider is retained." : planError));
                return;
            }
            if (plan == null || ( _v7PlanBinding != null &&
                    !ReferenceEquals(plan, _v7PlanBinding.RuntimePlan)))
            {
                FailSetup("The App-retained C1 runtime plan binding is absent or changed.");
                return;
            }
            _plan = plan;

            _context = RoomEncounterRuntimeContext.Create(_run.RunId, C1NodeId, C1TemplateId,
                _activation.RoomInstanceId, _scope, _activation.Controller,
                _composition.PlayerMotor, _plan, _run.Route.GenerationVersion);
            _snapshotSource = _registration.CreateSnapshotSource(_context);
            if (_snapshotSource == null || !ReferenceEquals(_activation.Context, _context) ||
                !ReferenceEquals(_activation.Source, _snapshotSource))
                throw new InvalidOperationException("The real readiness registration did not retain this exact C1 context and snapshot source.");

            _runtime = RoomEncounterRuntime.Prepare(_context, _snapshotSource, this);
            TryArmOnlyWhileWaiting();
        }

        private void Update()
        {
            if (_disposed || _runtime == null) return;
            TryArmOnlyWhileWaiting();
        }

        private void TryArmOnlyWhileWaiting()
        {
            if (_runtime == null || _runtime.Status != RoomEncounterRuntimeStatus.WaitingForSession) return;
            _runtime.ConfirmSessionReadyForScope();
        }

        void IRoomEncounterClearObserver.OnRoomEncounterCleared(RoomEncounterClearObservation observation)
        {
            if (_runtime == null || _context == null || _plan == null || observation == null ||
                !_runtime.ClearNotificationIssued || !ReferenceEquals(_runtime.LastClearObservation, observation) ||
                _runtime.Status != RoomEncounterRuntimeStatus.Armed ||
                observation.RunId != _context.RunId || observation.RoomInstanceId != _context.RoomInstanceId ||
                observation.ActivationGeneration != _context.ActivationGeneration ||
                !string.Equals(observation.NodeId, _context.NodeId, StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, _context.TemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(observation.Scope, _context.Scope) ||
                !HasExactPlannedRoster(observation, _plan))
            {
                _setupFailure = "C1 runtime clear callback did not match the exact physical roster and activation.";
                throw new InvalidOperationException(_setupFailure);
            }

            if (_clearAccepted)
            {
                _setupFailure = "C1 runtime attempted to publish more than one physical clear observation.";
                throw new InvalidOperationException(_setupFailure);
            }
            _clearObservation = observation;
            _clearAccepted = true;
            if (_v7PlanBinding != null &&
                (_v7SessionBinding == null || _application == null ||
                 !_application.IsCurrentF10V7CombatPlanRuntimeBinding(_v7PlanBinding,
                     _v7SessionBinding, _composition, _context, _runtime,
                     _v7PlanBinding.Revision)))
            {
                _clearObservation = null;
                _clearAccepted = false;
                _setupFailure = "V7 C1 clear is not owned by the exact current App coordinator and plan binding.";
                throw new InvalidOperationException(_setupFailure);
            }
        }

        internal bool IsBoundToV7PlanBinding(
            ApplicationBootstrapper.F10V7CombatPlanRuntimeBinding planBinding,
            ApplicationBootstrapper.F10V7SessionInitializationBinding sessionBinding,
            ApplicationBootstrapper application, ExpeditionGameplayComposition composition,
            RoomEncounterRuntimeContext context, RoomEncounterRuntime runtime, long revision)
        {
            return planBinding != null && sessionBinding != null && application != null &&
                composition != null && ReferenceEquals(_application, application) &&
                ReferenceEquals(_composition, composition) &&
                ReferenceEquals(_v7SessionBinding, sessionBinding) &&
                ReferenceEquals(_v7PlanBinding, planBinding) &&
                ReferenceEquals(planBinding.SessionBinding, sessionBinding) &&
                ReferenceEquals(planBinding.Bootstrapper, application) &&
                ReferenceEquals(planBinding.Composition, composition) &&
                ReferenceEquals(_run, planBinding.Run) &&
                ReferenceEquals(_registration, planBinding.Registration) &&
                ReferenceEquals(_activation, planBinding.Activation) &&
                ReferenceEquals(_scope, planBinding.Scope) &&
                ReferenceEquals(_room, planBinding.Room) &&
                ReferenceEquals(_plan, planBinding.RuntimePlan) &&
                ReferenceEquals(_context, context) && ReferenceEquals(_runtime, runtime) &&
                ReferenceEquals(_context?.Plan, planBinding.RuntimePlan) &&
                revision == planBinding.Revision;
        }

        internal bool HasExactV7PhysicalClearObservation()
        {
            RoomEncounterClearObservation observation = _clearObservation;
            return _v7PlanBinding != null && _clearAccepted && observation != null &&
                _runtime != null && _context != null && _plan != null &&
                _runtime.ClearNotificationIssued &&
                ReferenceEquals(_runtime.LastClearObservation, observation) &&
                (_runtime.Status == RoomEncounterRuntimeStatus.Armed ||
                 _runtime.Status == RoomEncounterRuntimeStatus.Cleared) &&
                observation.RunId == _context.RunId &&
                observation.RoomInstanceId == _context.RoomInstanceId &&
                observation.ActivationGeneration == _context.ActivationGeneration &&
                string.Equals(observation.NodeId, _context.NodeId, StringComparison.Ordinal) &&
                string.Equals(observation.TemplateId, _context.TemplateId, StringComparison.Ordinal) &&
                ReferenceEquals(observation.Scope, _context.Scope) &&
                HasExactPlannedRoster(observation, _plan);
        }

        private static bool HasExactPlannedRoster(RoomEncounterClearObservation observation,
            RoomEncounterRuntimePlan plan)
        {
            if (observation == null || plan == null || plan.Roster == null || observation.Actors == null)
                return false;

            var expected = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (ExpeditionEncounterWavePlan wave in plan.Roster.Waves)
            {
                foreach (string spawnKey in wave.SpawnKeys)
                {
                    if (string.IsNullOrEmpty(spawnKey) || expected.ContainsKey(spawnKey)) return false;
                    expected.Add(spawnKey, wave.WaveNumber);
                }
            }
            if (expected.Count == 0 || observation.Actors.Count != expected.Count) return false;

            foreach (RoomEncounterDefeatedActorObservation actor in observation.Actors)
            {
                if (!expected.TryGetValue(actor.SpawnKey, out int waveNumber) ||
                    waveNumber != actor.WaveNumber || !actor.ActorId.IsValid)
                    return false;
                expected.Remove(actor.SpawnKey);
            }
            return expected.Count == 0;
        }

        private void FailSetup(string message)
        {
            _setupFailure = string.IsNullOrWhiteSpace(message)
                ? "C1 encounter setup failed closed."
                : message;
        }

        public void Dispose()
        {
            _disposed = true;
        }

        private void OnDestroy()
        {
            Dispose();
        }

        private sealed class AttachmentView
        {
            internal AttachmentView(ExpeditionSessionReadinessRegistration registration,
                ExpeditionRoomActivationRegistration activation, ExpeditionRunConfiguration run,
                ExpeditionRoomTransitionController transitions, RoomLifetimeScope scope,
                RoomTemplatePrefab2D room)
            {
                Registration = registration;
                Activation = activation;
                Run = run;
                Transitions = transitions;
                Scope = scope;
                Room = room;
            }

            internal ExpeditionSessionReadinessRegistration Registration { get; }
            internal ExpeditionRoomActivationRegistration Activation { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal ExpeditionRoomTransitionController Transitions { get; }
            internal RoomLifetimeScope Scope { get; }
            internal RoomTemplatePrefab2D Room { get; }
        }
    }
}
#endif
