#if UNITY_EDITOR
using System;
using System.Linq;
using System.Text;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves.V7;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Builds the terminal V7 Extracted profile candidate from authenticated durable data.
    /// This calculator does not authorize extraction, write storage, or publish gameplay state.
    /// </summary>
    internal static class SaveV7ExtractedSettlementCandidate
    {
        private const string ExtractionNodeId = "sample.safe_extraction";
        private const string ComparableTimestamp = "2000-01-01T00:00:00.0000000Z";
        private static readonly object FactoryKey = new object();

        internal sealed class Candidate
        {
            private readonly ProfileSaveEnvelopeV7 _envelope;

            internal Candidate(ProfileSaveEnvelopeV7 envelope, ExpeditionSettlementReceipt receipt,
                string encodedJson, object factoryKey)
            {
                if (!ReferenceEquals(factoryKey, FactoryKey))
                    throw new InvalidOperationException("V7 settlement candidates must come from the authenticated factory.");
                _envelope = SaveV7Clone.Clone(envelope);
                Receipt = receipt ?? throw new ArgumentNullException(nameof(receipt));
                EncodedJson = encodedJson ?? throw new ArgumentNullException(nameof(encodedJson));
            }

            internal ProfileSaveEnvelopeV7 Envelope => SaveV7Clone.Clone(_envelope);
            internal ExpeditionSettlementReceipt Receipt { get; }
            internal string EncodedJson { get; }
        }

        internal static bool TryCreate(ProfileSaveEnvelopeV7 prior, ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 registry, out Candidate candidate, out SaveV7Error error)
        {
            candidate = null;
            error = default(SaveV7Error);

            if (!SaveV7JsonCodec.TryAuthenticateProfile(prior, out error)) return false;
            if (!SaveV7CandidateMapper.TryValidatePrepared(prior, out error)) return false;
            if (!prior.hasActiveExpedition || prior.activeExpedition == null)
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition",
                    "Extracted settlement requires an authenticated active V7 expedition.", out error);
            if (itemCatalog == null || registry == null)
                return Fail(SaveV7ErrorCode.CatalogRevisionUnavailable, "catalog/registry",
                    "The authoritative item catalog and exact retained encounter registry are required.", out error);

            ExpeditionSaveDataV7 durableState = prior.activeExpedition;
            if (!string.Equals(durableState.currentNodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                durableState.completedRoomIds == null ||
                durableState.completedRoomIds.Contains(ExtractionNodeId, StringComparer.Ordinal))
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition.currentNodeId",
                    "Extracted settlement requires the unfinished durable SafeExtraction cursor.", out error);

            try
            {
                // Restore through the mapper's explicit no-rollback boundary: use the latest
                // durable inventory/resources, never the room-entry checkpoint as settlement input.
                if (!SaveV7CandidateMapper.TryRestoreCurrentForSettlement(prior, itemCatalog, registry,
                    out ExpeditionRunConfiguration run, out ExpeditionSaveDataV7 currentState,
                    out ResolvedEncounterPlanV1 ignoredPlan, out error)) return false;
                durableState = currentState;
                if (!TryValidateF10ExtractionRoute(run, durableState, out error)) return false;

                // Also verifies every retained binding against this exact registry for the complete route.
                if (!SaveV7CandidateMapper.TryValidateCommit(prior, run, registry, out error)) return false;
                ExpeditionInventory inventory = run.Inventory;

                var ledger = new ExpeditionSettlementLedger(prior.profile.availableRenown,
                    prior.profile.processedSettlementRunIds.Select(RunId.Parse));
                if (ledger.ProcessedRunIds.Contains(run.RunId))
                    return Fail(SaveV7ErrorCode.PlanMismatch, "profile.processedSettlementRunIds",
                        "This RunId already has a durable settlement receipt.", out error);

                ExpeditionSettlementReceipt calculated = ledger.Settle(run.RunId,
                    ExpeditionOutcome.Extracted, durableState.accumulatedRenown,
                    inventory, run.StartingEquipmentInstanceIds);
                if (calculated.AlreadyProcessed)
                    return Fail(SaveV7ErrorCode.PlanMismatch, "profile.processedSettlementRunIds",
                        "The settlement ledger rejected a repeated RunId.", out error);

                ProfileSaveDataV7 profile = SaveV7Clone.Clone(prior.profile);
                profile.availableRenown = calculated.BalanceAfter;
                profile.processedSettlementRunIds = prior.profile.processedSettlementRunIds
                    .Concat(new[] { run.RunId.ToString() }).ToArray();

                var envelopeCandidate = new ProfileSaveEnvelopeV7
                {
                    schemaVersion = 1,
                    contentVersion = 7,
                    generation = checked(prior.generation + 1),
                    sequence = checked(prior.sequence + 1),
                    savedAtUtc = DateTime.UtcNow.ToString("O", System.Globalization.CultureInfo.InvariantCulture),
                    checksum = new string('0', 64),
                    profile = profile,
                    hasActiveExpedition = false,
                    activeExpedition = null
                };

                byte[] bytes = SaveV7JsonCodec.EncodeProfile(envelopeCandidate);
                if (!SaveV7JsonCodec.TryDecodeProfile(bytes, out ProfileSaveEnvelopeV7 authenticated,
                    out error)) return false;
                if (!TryValidateTerminalTransition(prior, authenticated, run.RunId, calculated, out error))
                    return false;

                candidate = new Candidate(authenticated, calculated,
                    new UTF8Encoding(false, true).GetString(bytes), FactoryKey);
                return true;
            }
            catch (SaveV7ValidationException exception)
            {
                error = exception.Error;
                return false;
            }
            catch (Exception exception) when (exception is ArgumentException || exception is FormatException ||
                exception is InvalidOperationException || exception is OverflowException ||
                exception is System.Collections.Generic.KeyNotFoundException)
            {
                return Fail(SaveV7ErrorCode.InvalidData, "activeExpedition", exception.Message, out error);
            }
        }

        private static bool TryValidateTerminalTransition(ProfileSaveEnvelopeV7 prior,
            ProfileSaveEnvelopeV7 next, RunId runId, ExpeditionSettlementReceipt receipt,
            out SaveV7Error error)
        {
            error = default(SaveV7Error);
            if (!SaveV7JsonCodec.TryAuthenticateProfile(prior, out error) ||
                !SaveV7JsonCodec.TryAuthenticateProfile(next, out error)) return false;
            if (!SaveV7CandidateMapper.TryValidatePrepared(prior, out error) ||
                !SaveV7CandidateMapper.TryValidatePrepared(next, out error)) return false;
            if (prior == null || next == null || prior.profile == null || next.profile == null ||
                !prior.hasActiveExpedition || prior.activeExpedition == null ||
                next.hasActiveExpedition || next.activeExpedition != null || receipt == null ||
                !runId.IsValid || !RunId.TryParse(prior.activeExpedition.runId, out RunId priorRunId) ||
                priorRunId != runId || !string.Equals(prior.activeExpedition.currentNodeId,
                    ExtractionNodeId, StringComparison.Ordinal))
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition",
                    "The terminal transition must close this exact active SafeExtraction RunId.", out error);

            if (prior.generation == int.MaxValue || prior.sequence == long.MaxValue ||
                next.schemaVersion != prior.schemaVersion || next.contentVersion != 7 ||
                next.generation != prior.generation + 1 || next.sequence != prior.sequence + 1)
                return Fail(SaveV7ErrorCode.InvalidData, "generation/sequence",
                    "The terminal profile must advance its authenticated V7 envelope exactly once.", out error);

            string runIdText = runId.ToString();
            string[] processed = prior.profile.processedSettlementRunIds ?? Array.Empty<string>();
            if (processed.Contains(runIdText, StringComparer.Ordinal) ||
                !next.profile.processedSettlementRunIds.SequenceEqual(
                    processed.Concat(new[] { runIdText }), StringComparer.Ordinal))
                return Fail(SaveV7ErrorCode.PlanMismatch, "profile.processedSettlementRunIds",
                    "The terminal profile must append exactly this previously unprocessed RunId.", out error);

            if (receipt.RunId != runId || receipt.Outcome != ExpeditionOutcome.Extracted ||
                receipt.AlreadyProcessed || receipt.BalanceAfter != next.profile.availableRenown ||
                receipt.AccumulatedRenown != prior.activeExpedition.accumulatedRenown ||
                receipt.BalanceAfter != checked(prior.profile.availableRenown + receipt.RenownAwarded) ||
                receipt.RenownAwarded != checked(receipt.AccumulatedRenown + receipt.LootRenown))
                return Fail(SaveV7ErrorCode.PlanMismatch, "profile.availableRenown",
                    "The profile balance must match the Extracted ledger receipt.", out error);

            ProfileSaveDataV7 expectedProfile = SaveV7Clone.Clone(prior.profile);
            expectedProfile.availableRenown = next.profile.availableRenown;
            expectedProfile.processedSettlementRunIds = (string[])next.profile.processedSettlementRunIds.Clone();
            if (!CanonicalProfileEquals(expectedProfile, next.profile))
                return Fail(SaveV7ErrorCode.PlanMismatch, "profile",
                    "Terminal settlement may change only AvailableRenown and the processed RunId list.", out error);

            error = default(SaveV7Error);
            return true;
        }

        private static bool TryValidateF10ExtractionRoute(ExpeditionRunConfiguration run,
            ExpeditionSaveDataV7 state, out SaveV7Error error)
        {
            error = default(SaveV7Error);
            const string guardianNodeId = "sample.patio.guardian";
            if (run == null || state == null || run.Route == null ||
                !string.Equals(state.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                state.seed != run.Seed || state.generationVersion != 2 ||
                !string.Equals(state.routeSnapshotJson, run.Route.CanonicalForm, StringComparison.Ordinal) ||
                !string.Equals(state.currentNodeId, ExtractionNodeId, StringComparison.Ordinal) ||
                state.visitedNodeIds == null || state.visitedNodeIds.Length < 2 ||
                !string.Equals(state.visitedNodeIds[state.visitedNodeIds.Length - 2], guardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(state.visitedNodeIds[state.visitedNodeIds.Length - 1], ExtractionNodeId, StringComparison.Ordinal) ||
                state.completedRoomIds == null || !state.completedRoomIds.Contains(guardianNodeId, StringComparer.Ordinal) ||
                state.completedRoomResults == null || state.completedRoomResults.Length == 0)
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition.route",
                    "The durable F10 cursor must be SafeExtraction immediately after its completed Guardian.", out error);

            ExpeditionRouteNode[] guardians = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, guardianNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteNode[] extractions = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, ExtractionNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, guardianNodeId, StringComparison.Ordinal)).ToArray();
            if (guardians.Length != 1 || guardians[0].Kind != ExpeditionRouteNodeKind.Guardian ||
                !string.Equals(guardians[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(guardians[0].TemplateId, "room.patio.guardian", StringComparison.Ordinal) ||
                extractions.Length != 1 || extractions[0].Kind != ExpeditionRouteNodeKind.SafeExtraction ||
                !string.Equals(extractions[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(extractions[0].TemplateId, "room.sample.extraction", StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, ExtractionNodeId, StringComparison.Ordinal))
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition.route.connections",
                    "The Guardian-to-SafeExtraction edge must be the exact mandatory F10 route edge.", out error);

            string guardianRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, guardianNodeId).ToString();
            ExpeditionRoomCompletionSaveDataV7[] results = state.completedRoomResults.Where(result => result != null &&
                string.Equals(result.roomNodeId, guardianNodeId, StringComparison.Ordinal)).ToArray();
            if (results.Length != 1 || !string.Equals(results[0].resultId,
                    "room-result.v1:" + guardianRoomId, StringComparison.Ordinal) ||
                !MatchesGuardianCompletionResult(results[0].resultJson, guardianRoomId, guardianNodeId))
                return Fail(SaveV7ErrorCode.PlanMismatch, "activeExpedition.completedRoomResults",
                    "An exact durable cleared Guardian result must immediately precede extraction.", out error);

            return true;
        }

        [Serializable]
        private sealed class DurableGuardianRoomResult
        {
            public int schema;
            public string outcome;
            public string roomInstanceId;
            public string sourceNodeId;
            public string targetNodeId;
        }

        private static bool MatchesGuardianCompletionResult(string json, string guardianRoomId,
            string guardianNodeId)
        {
            if (string.IsNullOrWhiteSpace(json)) return false;
            try
            {
                DurableGuardianRoomResult result = JsonUtility.FromJson<DurableGuardianRoomResult>(json);
                return result != null && result.schema == 1 &&
                    string.Equals(result.outcome, "cleared", StringComparison.Ordinal) &&
                    string.Equals(result.roomInstanceId, guardianRoomId, StringComparison.Ordinal) &&
                    string.Equals(result.sourceNodeId, guardianNodeId, StringComparison.Ordinal) &&
                    string.Equals(result.targetNodeId, ExtractionNodeId, StringComparison.Ordinal);
            }
            catch { return false; }
        }

        private static bool CanonicalProfileEquals(ProfileSaveDataV7 left, ProfileSaveDataV7 right)
        {
            var leftEnvelope = ComparableEnvelope(left);
            var rightEnvelope = ComparableEnvelope(right);
            return SaveV7JsonCodec.EncodeProfile(leftEnvelope)
                .SequenceEqual(SaveV7JsonCodec.EncodeProfile(rightEnvelope));
        }

        private static ProfileSaveEnvelopeV7 ComparableEnvelope(ProfileSaveDataV7 profile)
        {
            return new ProfileSaveEnvelopeV7
            {
                schemaVersion = 1,
                contentVersion = 7,
                generation = 1,
                sequence = 1,
                savedAtUtc = ComparableTimestamp,
                checksum = new string('0', 64),
                profile = profile,
                hasActiveExpedition = false,
                activeExpedition = null
            };
        }

        private static bool Fail(SaveV7ErrorCode code, string path, string message, out SaveV7Error error)
        {
            error = new SaveV7Error(code, path, message);
            return false;
        }
    }
}
#endif
