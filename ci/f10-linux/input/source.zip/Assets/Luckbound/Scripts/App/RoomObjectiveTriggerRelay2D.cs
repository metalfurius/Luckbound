using System;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>Forwards real contact with one configured room exit trigger to its exact objective activation.</summary>
    [DisallowMultipleComponent]
    internal sealed class RoomObjectiveTriggerRelay2D : MonoBehaviour, IDisposable
    {
        private F10ObjectiveDriver2D _driver;
        private RoomEncounterRuntimeContext _context;
        private Collider2D _sourceTrigger;
        private Collider2D _playerCollider;
        private bool _initialized;
        private bool _disposed;

        internal bool IsDisposed => _disposed;

        internal void Initialize(F10ObjectiveDriver2D driver, RoomEncounterRuntimeContext context,
            Collider2D sourceTrigger, Collider2D playerCollider)
        {
            if (_initialized) throw new InvalidOperationException("Objective trigger relay can only be initialized once.");
            if (driver == null) throw new ArgumentNullException(nameof(driver));
            if (context == null) throw new ArgumentNullException(nameof(context));
            if (sourceTrigger == null || !ReferenceEquals(sourceTrigger.gameObject, gameObject) || !sourceTrigger.isTrigger)
                throw new ArgumentException("Objective relay must be attached to its configured trigger collider.", nameof(sourceTrigger));
            if (playerCollider == null) throw new ArgumentNullException(nameof(playerCollider));

            _driver = driver;
            _context = context;
            _sourceTrigger = sourceTrigger;
            _playerCollider = playerCollider;
            _initialized = true;
        }

        internal void Detach(F10ObjectiveDriver2D driver)
        {
            if (!ReferenceEquals(_driver, driver)) return;
            Dispose();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _driver = null;
            _context = null;
            _sourceTrigger = null;
            _playerCollider = null;
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            Observe(other);
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            Observe(other);
        }

        private void Observe(Collider2D other)
        {
            if (!_initialized || _disposed || _driver == null || _context == null ||
                _context.ActivationGeneration <= 0 || _sourceTrigger == null || _playerCollider == null)
                return;
            _driver.ObserveExitTriggerTouch(this, other);
        }

        private void OnDisable()
        {
            Dispose();
        }

        private void OnDestroy()
        {
            Dispose();
        }
    }
}
