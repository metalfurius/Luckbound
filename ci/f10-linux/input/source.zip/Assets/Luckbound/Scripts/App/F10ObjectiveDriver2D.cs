using System;
using System.Collections.Generic;
using System.Linq;
using Luckbound.Content;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>Room-local F10 objective observer. It never saves, settles, or advances the route.</summary>
    [DisallowMultipleComponent]
    internal sealed class F10ObjectiveDriver2D : MonoBehaviour, IDisposable
    {
        internal const int QueueCapacity = 64;
        private const float EffectiveMoveDeadZone = 0.001f;
        private const float EffectiveDisplacementThreshold = 0.001f;
        private const float MarkerPoseTolerance = 0.001f;

        private enum FactKind
        {
            Command,
            EffectiveMovement,
            ExplorationExitTouch
        }

        private enum ObjectiveRole
        {
            TutorialInteraction,
            ExplorationExit,
            ExtractionInteraction
        }

        private sealed class TriggerBinding
        {
            internal TriggerBinding(ObjectiveRole role, RoomTemplatePrefab2D roomPrefab,
                TextAsset sourceDefinition, string sourceText, RoomTemplateData roomData, RoomPositionMarkerData markerDefinition,
                RoomPositionMarker2D marker, Collider2D collider)
            {
                Role = role;
                RoomPrefab = roomPrefab;
                SourceDefinition = sourceDefinition;
                SourceText = sourceText;
                RoomData = roomData;
                MarkerDefinition = markerDefinition;
                Marker = marker;
                Collider = collider;
            }

            internal ObjectiveRole Role { get; }
            internal RoomTemplatePrefab2D RoomPrefab { get; }
            internal TextAsset SourceDefinition { get; }
            internal string SourceText { get; }
            internal RoomTemplateData RoomData { get; }
            internal RoomPositionMarkerData MarkerDefinition { get; }
            internal RoomPositionMarker2D Marker { get; }
            internal Collider2D Collider { get; }
        }

        private readonly struct Fact
        {
            internal Fact(FactKind kind, RoomEncounterRuntimeContext context, ActorId actorId,
                long activationGeneration, long tick, PlayerCommand command,
                bool roleInteractionOverlapped, float moveX, Vector2 movementDelta)
            {
                Kind = kind;
                Context = context;
                Scope = context.Scope;
                Player = context.Player;
                ActorId = actorId;
                ActivationGeneration = activationGeneration;
                Tick = tick;
                Command = command;
                RoleInteractionOverlapped = roleInteractionOverlapped;
                MoveX = moveX;
                MovementDelta = movementDelta;
            }

            internal FactKind Kind { get; }
            internal RoomEncounterRuntimeContext Context { get; }
            internal RoomLifetimeScope Scope { get; }
            internal PlayerMotor2D Player { get; }
            internal ActorId ActorId { get; }
            internal long ActivationGeneration { get; }
            internal long Tick { get; }
            internal PlayerCommand Command { get; }
            internal bool RoleInteractionOverlapped { get; }
            internal float MoveX { get; }
            internal Vector2 MovementDelta { get; }
        }

        private RoomEncounterRuntimeContext _context;
        private IRoomEncounterRuntimeSessionSnapshotSource _sessionSource;
        private IF10ObjectiveObservationHandoff _observationHandoff;
        private F10ObjectiveObservation _handoffBeingDelivered;
        private PlayerMotor2D _player;
        private Collider2D _playerCollider;
        private Rigidbody2D _playerBody;
        private TriggerBinding _binding;
        private RoomObjectiveTriggerRelay2D _exitRelay;
        private readonly Queue<Fact> _facts = new Queue<Fact>(QueueCapacity);
        private readonly Queue<F10ObjectiveObservation> _pendingHandoffs =
            new Queue<F10ObjectiveObservation>(QueueCapacity);
        private ActorId _actorId;
        private long _activationGeneration;
        private long _lastCommandTick = -1;
        private long _lastDrainedCommandTick = -1;
        private long _pendingMovementTick;
        private float _pendingMovementInput;
        private Vector2 _pendingMovementStart;
        private long _drainSequence;
        private bool _initialized;
        private bool _disposed;
        private bool _faulted;
        private bool _hasPendingMovement;
        private bool _hasEffectiveTutorialMovement;
        private bool _tutorialCompleted;
        private bool _tutorialHandoffPending;
        private bool _explorationObserved;
        private bool _explorationHandoffPending;
        private bool _explorationTouchQueued;
        private string _faultReason = string.Empty;

        internal bool IsDisposed => _disposed;
        internal bool IsFaulted => _faulted;
        internal string FaultReason => _faultReason;
        internal int PendingFactCount => _facts.Count;
        internal int PendingHandoffCount => _pendingHandoffs.Count;
        internal bool HasEffectiveTutorialMovement => _hasEffectiveTutorialMovement;
        internal long LastDrainedCommandTick => _lastDrainedCommandTick;
        internal long DrainSequence => _drainSequence;

        /// <summary>
        /// Uses the exact context and readiness source already created for this room activation. Noncombat
        /// F10 rooms legitimately have Plan == null; the objective driver never reads or fabricates a roster.
        /// </summary>
        internal static F10ObjectiveDriver2D Prepare(RoomEncounterRuntimeContext context,
            IRoomEncounterRuntimeSessionSnapshotSource sessionSource, Collider2D playerCollider,
            Collider2D tutorialInteraction, Collider2D exitTrigger,
            Collider2D extractionInteraction, IF10ObjectiveObservationHandoff observationHandoff = null)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            if (sessionSource == null) throw new ArgumentNullException(nameof(sessionSource));
            if (!context.IsCurrentRoomScope())
                throw new InvalidOperationException("Objective runtime can only attach to its exact active room scope.");
            if (context.Player == null || playerCollider == null ||
                !ReferenceEquals(playerCollider.gameObject, context.Player.gameObject) ||
                !ReferenceEquals(playerCollider.GetComponent<PlayerMotor2D>(), context.Player) ||
                context.Player.GetComponent<Rigidbody2D>() == null || !context.Player.ActorId.IsValid ||
                context.ActivationGeneration <= 0)
                throw new InvalidOperationException("Objective runtime requires the exact bound player, collider, and activation.");

            RoomLifetimeScope scope = context.Scope;
            if (scope.GetComponent<F10ObjectiveDriver2D>() != null)
                throw new InvalidOperationException("A room scope can own only one F10 objective driver.");

            TriggerBinding binding = CreateRoleBinding(context, tutorialInteraction,
                exitTrigger, extractionInteraction);
            var driver = scope.gameObject.AddComponent<F10ObjectiveDriver2D>();
            try
            {
                driver.Initialize(context, sessionSource, playerCollider, binding, observationHandoff);
                F10ObjectiveDriver2D owned = scope.OwnResource(driver);
                if (!ReferenceEquals(owned, driver))
                    throw new InvalidOperationException("RoomLifetimeScope did not retain the exact objective driver.");
                if (driver._exitRelay != null)
                {
                    RoomObjectiveTriggerRelay2D ownedRelay = scope.OwnResource(driver._exitRelay);
                    if (!ReferenceEquals(ownedRelay, driver._exitRelay))
                        throw new InvalidOperationException("RoomLifetimeScope did not retain the exact exit relay.");
                }
                return driver;
            }
            catch
            {
                driver.Dispose();
                UnityEngine.Object.Destroy(driver);
                throw;
            }
        }

        private void Initialize(RoomEncounterRuntimeContext context,
            IRoomEncounterRuntimeSessionSnapshotSource sessionSource, Collider2D playerCollider,
            TriggerBinding binding, IF10ObjectiveObservationHandoff observationHandoff)
        {
            if (_initialized) throw new InvalidOperationException("F10 objective driver can only be initialized once.");
            _context = context;
            _sessionSource = sessionSource;
            _observationHandoff = observationHandoff;
            _player = context.Player;
            _playerCollider = playerCollider;
            _playerBody = context.Player.GetComponent<Rigidbody2D>();
            _binding = binding;
            _actorId = context.Player.ActorId;
            _activationGeneration = context.ActivationGeneration;
            _initialized = true;
            _player.CommandConsumed += OnCommandConsumed;

            if (_binding.Role == ObjectiveRole.ExplorationExit)
            {
                if (_binding.Collider.GetComponents<Collider2D>().Length != 1 ||
                    _binding.Collider.GetComponent<RoomObjectiveTriggerRelay2D>() != null)
                    throw new InvalidOperationException("The unique E1 exit trigger cannot share its GameObject with another collider or relay.");
                _exitRelay = _binding.Collider.gameObject.AddComponent<RoomObjectiveTriggerRelay2D>();
                _exitRelay.Initialize(this, _context, _binding.Collider, _playerCollider);
            }
        }

        /// <summary>Attach the exact room owner later; pending local observations are retried after physics.</summary>
        internal void BindObservationHandoff(IF10ObjectiveObservationHandoff observationHandoff)
        {
            if (observationHandoff == null) throw new ArgumentNullException(nameof(observationHandoff));
            if (!_initialized || _disposed || !IsExactActiveBinding())
                throw new InvalidOperationException("Observation handoff requires the live exact objective activation.");
            if (_observationHandoff != null && !ReferenceEquals(_observationHandoff, observationHandoff))
                throw new InvalidOperationException("A different observation handoff already owns this activation.");
            _observationHandoff = observationHandoff;
        }

        /// <summary>Checks the exact fact currently being delivered to its bound handoff.</summary>
        internal bool IsDeliveringTo(IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation)
        {
            return !_disposed && handoff != null && observation != null &&
                ReferenceEquals(_observationHandoff, handoff) &&
                ReferenceEquals(_handoffBeingDelivered, observation) &&
                _pendingHandoffs.Count > 0 && ReferenceEquals(_pendingHandoffs.Peek(), observation) &&
                IsExactActiveBinding();
        }

        internal void DrainAfterPhysics()
        {
            if (!_initialized || _disposed) return;
            _drainSequence++;
            if (!IsExactActiveBinding())
            {
                FaultAndDispose("The exact objective activation, scope, or actor is no longer current.");
                return;
            }
            if (!TryReadAdmittedSnapshot(out _))
            {
                ClearPendingFacts();
                return;
            }

            ResolvePendingMovement(_playerBody.position);
            if (_disposed) return;

            while (_facts.Count > 0)
            {
                if (!IsExactActiveBinding())
                {
                    FaultAndDispose("The objective activation changed while draining local facts.");
                    return;
                }
                if (!TryReadAdmittedSnapshot(out _))
                {
                    ClearPendingFacts();
                    return;
                }

                Fact fact = _facts.Dequeue();
                if (!FactMatchesCurrentActivation(fact))
                {
                    FaultAndDispose("A queued objective fact did not match the exact activation and actor.");
                    return;
                }

                switch (fact.Kind)
                {
                    case FactKind.Command:
                        _lastDrainedCommandTick = Math.Max(_lastDrainedCommandTick, fact.Tick);
                        ProcessCommandFact(fact);
                        break;
                    case FactKind.EffectiveMovement:
                        if (IsCoherentHorizontalDisplacement(fact.MoveX, fact.MovementDelta.x))
                            _hasEffectiveTutorialMovement = true;
                        break;
                    case FactKind.ExplorationExitTouch:
                        _explorationTouchQueued = false;
                        if (!_explorationObserved && !_explorationHandoffPending &&
                            IsCurrentPhysicalOverlap(_binding))
                        {
                            F10ObjectiveObservation observation = CreateObservation(
                                F10ObjectiveObservationKind.ExplorationExitTouched, fact.Tick);
                            if (!TryQueueHandoff(observation)) return;
                            _explorationHandoffPending = true;
                        }
                        break;
                    default:
                        FaultAndDispose("The objective queue contained an unknown fact kind.");
                        return;
                }
                if (_disposed) return;
            }

            TryDeliverPendingHandoffs();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _facts.Clear();
            _pendingHandoffs.Clear();
            _hasPendingMovement = false;
            _explorationTouchQueued = false;
            if (_player != null) _player.CommandConsumed -= OnCommandConsumed;
            _exitRelay?.Detach(this);
            _exitRelay = null;
            _context = null;
            _sessionSource = null;
            _observationHandoff = null;
            _handoffBeingDelivered = null;
            _player = null;
            _playerCollider = null;
            _playerBody = null;
            _binding = null;
        }

        private void OnCommandConsumed(PlayerMotor2D sender, PlayerCommand command)
        {
            if (!_initialized || _disposed) return;
            if (!ReferenceEquals(sender, _player) || command.ActorId != _actorId || command.Tick < 0 ||
                command.Tick <= _lastCommandTick)
                return;
            _lastCommandTick = command.Tick;

            if (!IsExactActiveBinding())
            {
                FaultAndDispose("A consumed command arrived after the exact objective activation became stale.");
                return;
            }
            if (!TryReadAdmittedSnapshot(out _))
            {
                ClearPendingFacts();
                return;
            }

            ResolvePendingMovement(_playerBody.position);
            if (_disposed) return;

            bool roleNear = command.WasPressed(PlayerAction.Interact) && IsCurrentPhysicalOverlap(_binding);
            if (!TryEnqueue(new Fact(FactKind.Command, _context, _actorId,
                    _activationGeneration, command.Tick, command, roleNear, 0f, Vector2.zero)))
                return;

            if (Mathf.Abs(command.MoveX) > EffectiveMoveDeadZone)
            {
                _hasPendingMovement = true;
                _pendingMovementTick = command.Tick;
                _pendingMovementInput = command.MoveX;
                _pendingMovementStart = _playerBody.position;
            }
        }

        internal void ObserveExitTriggerTouch(RoomObjectiveTriggerRelay2D relay, Collider2D other)
        {
            if (!_initialized || _disposed || _binding == null ||
                _binding.Role != ObjectiveRole.ExplorationExit || !ReferenceEquals(relay, _exitRelay) ||
                !ReferenceEquals(other, _playerCollider) || !IsCurrentPhysicalOverlap(_binding))
                return;
            if (!IsExactActiveBinding())
            {
                FaultAndDispose("An E1 exit callback arrived after its exact room activation became stale.");
                return;
            }
            if (!TryReadAdmittedSnapshot(out _))
            {
                ClearPendingFacts();
                return;
            }
            if (_explorationObserved || _explorationHandoffPending || _explorationTouchQueued) return;

            long tick = _player.SimulationTick;
            if (!TryEnqueue(new Fact(FactKind.ExplorationExitTouch, _context,
                    _actorId, _activationGeneration, tick, default, false, 0f, Vector2.zero)))
                return;
            _explorationTouchQueued = true;
        }

        private void ProcessCommandFact(Fact fact)
        {
            if (!fact.Command.WasPressed(PlayerAction.Interact) || !fact.RoleInteractionOverlapped ||
                !IsCurrentPhysicalOverlap(_binding))
                return;

            if (_binding.Role == ObjectiveRole.TutorialInteraction && _hasEffectiveTutorialMovement &&
                !_tutorialCompleted && !_tutorialHandoffPending)
            {
                F10ObjectiveObservation observation = CreateObservation(
                    F10ObjectiveObservationKind.TutorialCompleted, fact.Tick);
                if (!TryQueueHandoff(observation)) return;
                _tutorialHandoffPending = true;
            }
            else if (_binding.Role == ObjectiveRole.ExtractionInteraction)
            {
                F10ObjectiveObservation observation = CreateObservation(
                    F10ObjectiveObservationKind.ExtractionInteractionRequested, fact.Tick);
                if (!TryQueueHandoff(observation)) return;
            }
        }

        private void TryDeliverPendingHandoffs()
        {
            IF10ObjectiveObservationHandoff handoff = _observationHandoff;
            if (handoff == null || _handoffBeingDelivered != null) return;

            int remaining = _pendingHandoffs.Count;
            while (remaining-- > 0 && _pendingHandoffs.Count > 0)
            {
                if (!IsExactActiveBinding() || !TryReadAdmittedSnapshot(out _)) return;

                F10ObjectiveObservation observation = _pendingHandoffs.Peek();
                F10ObjectiveHandoffResult result;
                try
                {
                    _handoffBeingDelivered = observation;
                    result = handoff.TryAcceptLocalObservation(observation);
                }
                catch (Exception exception)
                {
                    Debug.LogException(exception, this);
                    return;
                }
                finally
                {
                    _handoffBeingDelivered = null;
                }

                // An accepting owner may synchronously complete a room and dispose this scope.
                if (_disposed || !IsExactActiveBinding()) return;
                if (_pendingHandoffs.Count == 0 || !ReferenceEquals(_pendingHandoffs.Peek(), observation))
                {
                    FaultAndDispose("The objective handoff queue changed during delivery.");
                    return;
                }
                if (result != F10ObjectiveHandoffResult.AcceptedLocalObservation) return;
                _pendingHandoffs.Dequeue();
                if (observation.Kind == F10ObjectiveObservationKind.TutorialCompleted)
                {
                    _tutorialCompleted = true;
                    _tutorialHandoffPending = false;
                }
                else if (observation.Kind == F10ObjectiveObservationKind.ExplorationExitTouched)
                {
                    _explorationObserved = true;
                    _explorationHandoffPending = false;
                }
            }
        }

        private bool TryQueueHandoff(F10ObjectiveObservation observation)
        {
            if (_pendingHandoffs.Count >= QueueCapacity)
            {
                FaultAndDispose("The finite objective handoff queue reached its capacity.");
                return false;
            }
            _pendingHandoffs.Enqueue(observation);
            return true;
        }

        private void ResolvePendingMovement(Vector2 endPosition)
        {
            if (!_hasPendingMovement) return;
            float moveX = _pendingMovementInput;
            long tick = _pendingMovementTick;
            Vector2 delta = endPosition - _pendingMovementStart;
            _hasPendingMovement = false;
            if (!IsCoherentHorizontalDisplacement(moveX, delta.x)) return;
            TryEnqueue(new Fact(FactKind.EffectiveMovement, _context,
                _actorId, _activationGeneration, tick, default, false, moveX, delta));
        }

        private bool TryEnqueue(Fact fact)
        {
            if (_facts.Count >= QueueCapacity)
            {
                FaultAndDispose("The finite objective fact queue reached its capacity.");
                return false;
            }
            _facts.Enqueue(fact);
            return true;
        }

        private bool TryReadAdmittedSnapshot(out RoomEncounterRuntimeSessionSnapshot snapshot)
        {
            snapshot = default;
            if (_context == null || _sessionSource == null || Time.timeScale <= 0f ||
                Physics2D.simulationMode != SimulationMode2D.FixedUpdate)
                return false;
            try
            {
                if (!_sessionSource.TryCapture(_context, out snapshot)) return false;
            }
            catch (Exception exception)
            {
                FaultAndDispose("The typed session readiness snapshot failed: " + exception.GetType().Name + ".");
                return false;
            }

            if (!snapshot.IsInitialized || !snapshot.Matches(_context) ||
                snapshot.ActivationGeneration != _activationGeneration)
            {
                FaultAndDispose("The readiness snapshot did not match the exact objective activation.");
                return false;
            }
            return snapshot.CanArmOrDrain && _player != null && _player.isActiveAndEnabled &&
                _player.ActorId == _actorId && _player.CombatStats != null && !_player.IsDead &&
                _player.CurrentHealth > 0;
        }

        private bool IsExactActiveBinding()
        {
            RoomEncounterRuntimeContext context = _context;
            RoomLifetimeScope scope = context == null ? null : context.Scope;
            PlayerMotor2D player = context == null ? null : context.Player;
            return !_disposed && context != null && context.ActivationGeneration == _activationGeneration &&
                ReferenceEquals(scope, GetComponent<RoomLifetimeScope>()) && scope != null &&
                scope.isActiveAndEnabled && !scope.IsDisposed && context.IsCurrentRoomScope() &&
                ReferenceEquals(player, _player) && player != null && player.isActiveAndEnabled &&
                player.ActorId == _actorId && _actorId.IsValid && _playerCollider != null &&
                ReferenceEquals(_playerCollider.GetComponent<PlayerMotor2D>(), player) &&
                _playerBody != null && ReferenceEquals(player.GetComponent<Rigidbody2D>(), _playerBody) &&
                IsBindingCurrent(_binding);
        }

        private bool IsBindingCurrent(TriggerBinding binding)
        {
            RoomEncounterRuntimeContext context = _context;
            if (binding == null || context == null || context.Scope == null ||
                !string.Equals(context.NodeId, ExpectedNodeId(binding.Role), StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, ExpectedTemplateId(binding.Role), StringComparison.Ordinal) ||
                !string.Equals(context.Scope.TemplateId, context.TemplateId, StringComparison.Ordinal))
                return false;

            RoomTemplatePrefab2D[] roomPrefabs = context.Scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (roomPrefabs.Length != 1 || !ReferenceEquals(roomPrefabs[0], binding.RoomPrefab) ||
                binding.RoomPrefab == null || !binding.RoomPrefab.isActiveAndEnabled ||
                !IsDescendantOf(binding.RoomPrefab.transform, context.Scope.transform) ||
                binding.RoomPrefab.SourceDefinition == null ||
                !ReferenceEquals(binding.RoomPrefab.SourceDefinition, binding.SourceDefinition) ||
                !string.Equals(binding.RoomPrefab.SourceDefinition.text, binding.SourceText, StringComparison.Ordinal))
                return false;

            RoomTemplateData roomData = binding.RoomData;
            RoomPositionMarkerData definition = binding.MarkerDefinition;
            RoomPositionMarker2D marker = binding.Marker;
            Collider2D collider = binding.Collider;
            string markerId = ExpectedMarkerId(binding.Role);
            string markerKind = ExpectedMarkerKind(binding.Role);
            if (roomData == null || roomData.markers == null ||
                !string.Equals(roomData.templateId, context.TemplateId, StringComparison.Ordinal) ||
                roomData.markers.Count(item => item != null && item.id == markerId) != 1 ||
                roomData.markers.Count(item => item != null && item.id == markerId && item.kind == markerKind) != 1 ||
                !ReferenceEquals(roomData.markers.SingleOrDefault(item => item.id == markerId && item.kind == markerKind), definition) ||
                marker == null || !marker.enabled || !marker.gameObject.activeInHierarchy ||
                !string.Equals(marker.MarkerId, markerId, StringComparison.Ordinal) ||
                !string.Equals(marker.Kind, markerKind, StringComparison.Ordinal) ||
                marker.TilePosition != new Vector2Int(definition.tileX, definition.tileY))
                return false;

            RoomPositionMarker2D[] markers = context.Scope.GetComponentsInChildren<RoomPositionMarker2D>(true);
            RoomPositionMarker2D[] matching = markers.Where(item => item != null &&
                string.Equals(item.MarkerId, markerId, StringComparison.Ordinal)).ToArray();
            if (matching.Length != 1 || !ReferenceEquals(matching[0], marker)) return false;
            if (!IsDescendantOf(marker.transform, binding.RoomPrefab.transform)) return false;

            Vector3 expectedMarkerPosition = binding.RoomPrefab.transform.TransformPoint(new Vector3(
                (definition.tileX + 0.5f) * roomData.tileSize, definition.tileY * roomData.tileSize, 0f));
            if (!IsNear(marker.transform.position, expectedMarkerPosition)) return false;

            if (collider == null || !collider.enabled || !collider.isTrigger ||
                !collider.gameObject.activeInHierarchy || collider.GetComponents<Collider2D>().Length != 1 ||
                !IsDescendantOf(collider.transform, marker.transform) ||
                !IsDescendantOf(marker.transform, context.Scope.transform) ||
                !IsNear(collider.transform.position, marker.transform.position) ||
                Quaternion.Angle(collider.transform.rotation, marker.transform.rotation) > MarkerPoseTolerance ||
                !IsNear(collider.transform.lossyScale, marker.transform.lossyScale) ||
                !IsNear(collider.bounds.center, marker.transform.position))
                return false;
            return true;
        }

        private bool IsCurrentPhysicalOverlap(TriggerBinding binding)
        {
            if (!IsBindingCurrent(binding) || _playerCollider == null ||
                !_playerCollider.enabled || !_playerCollider.gameObject.activeInHierarchy)
                return false;
            ColliderDistance2D distance = _playerCollider.Distance(binding.Collider);
            return distance.isValid && distance.distance <= 0f;
        }

        private bool FactMatchesCurrentActivation(Fact fact)
        {
            return ReferenceEquals(fact.Context, _context) && ReferenceEquals(fact.Scope, _context.Scope) &&
                ReferenceEquals(fact.Player, _player) && fact.ActorId == _actorId &&
                fact.ActivationGeneration == _activationGeneration && fact.Tick >= 0;
        }

        private void ClearPendingFacts()
        {
            _facts.Clear();
            _hasPendingMovement = false;
            _explorationTouchQueued = false;
        }

        private void FaultAndDispose(string reason)
        {
            _faulted = true;
            _faultReason = string.IsNullOrWhiteSpace(reason) ? "Objective driver failed closed." : reason;
            Dispose();
        }

        private F10ObjectiveObservation CreateObservation(F10ObjectiveObservationKind kind, long tick)
        {
            return new F10ObjectiveObservation(kind, _context, _actorId, tick);
        }

        private void LateUpdate()
        {
            DrainAfterPhysics();
        }

        private void OnDisable()
        {
            Dispose();
        }

        private void OnDestroy()
        {
            Dispose();
        }

        private static TriggerBinding CreateRoleBinding(RoomEncounterRuntimeContext context,
            Collider2D tutorialInteraction, Collider2D exitTrigger, Collider2D extractionInteraction)
        {
            ObjectiveRole role = GetRole(context);
            Collider2D collider;
            if (role == ObjectiveRole.TutorialInteraction)
            {
                if (tutorialInteraction == null || exitTrigger != null || extractionInteraction != null)
                    throw new InvalidOperationException("sample.tutorial accepts only its tutorial.interaction trigger.");
                collider = tutorialInteraction;
            }
            else if (role == ObjectiveRole.ExplorationExit)
            {
                if (exitTrigger == null || tutorialInteraction != null || extractionInteraction != null)
                    throw new InvalidOperationException("sample.patio.exploration accepts only its E1 exit.trigger collider.");
                collider = exitTrigger;
            }
            else
            {
                if (extractionInteraction == null || tutorialInteraction != null || exitTrigger != null)
                    throw new InvalidOperationException("sample.safe_extraction accepts only its extraction.interact trigger.");
                collider = extractionInteraction;
            }

            (string markerId, string markerKind, int tileX, int tileY) = GetMarkerContract(role);
            RoomLifetimeScope scope = context.Scope;
            RoomTemplatePrefab2D[] roomPrefabs = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (roomPrefabs.Length != 1 || roomPrefabs[0] == null || roomPrefabs[0].SourceDefinition == null)
                throw new InvalidOperationException("Objective role requires one room template with its source definition.");
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomPrefabs[0].SourceDefinition.text);
            if (!string.Equals(roomData.templateId, context.TemplateId, StringComparison.Ordinal))
                throw new InvalidOperationException("Objective source definition does not match the exact route template.");

            RoomPositionMarkerData[] definitions = roomData.markers.Where(item => item != null &&
                string.Equals(item.id, markerId, StringComparison.Ordinal) &&
                string.Equals(item.kind, markerKind, StringComparison.Ordinal)).ToArray();
            if (definitions.Length != 1 || roomData.markers.Count(item => item != null && item.id == markerId) != 1 ||
                definitions[0].tileX != tileX || definitions[0].tileY != tileY)
                throw new InvalidOperationException("Objective marker ID, kind, or fixed F10 tile does not match its role.");

            RoomPositionMarker2D[] markers = scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(item => item != null && string.Equals(item.MarkerId, markerId, StringComparison.Ordinal))
                .ToArray();
            if (markers.Length != 1)
                throw new InvalidOperationException("The active room must contain exactly one marker with the objective ID.");

            string sourceText = roomPrefabs[0].SourceDefinition.text;
            var binding = new TriggerBinding(role, roomPrefabs[0], roomPrefabs[0].SourceDefinition, sourceText, roomData,
                definitions[0], markers[0], collider);
            if (!markers[0].enabled || !markers[0].gameObject.activeInHierarchy ||
                markers[0].TilePosition != new Vector2Int(tileX, tileY) ||
                !string.Equals(markers[0].Kind, markerKind, StringComparison.Ordinal) ||
                !IsDescendantOf(markers[0].transform, roomPrefabs[0].transform) ||
                !IsBindingPoseValid(binding))
                throw new InvalidOperationException("Objective collider must be enabled, trigger-configured, and co-located under its exact source marker.");
            return binding;
        }

        private static bool IsBindingPoseValid(TriggerBinding binding)
        {
            RoomPositionMarker2D marker = binding.Marker;
            Collider2D collider = binding.Collider;
            RoomPositionMarkerData definition = binding.MarkerDefinition;
            Vector3 expected = binding.RoomPrefab.transform.TransformPoint(new Vector3(
                (definition.tileX + 0.5f) * binding.RoomData.tileSize, definition.tileY * binding.RoomData.tileSize, 0f));
            return IsNear(marker.transform.position, expected) && collider != null && collider.enabled &&
                collider.isTrigger && collider.gameObject.activeInHierarchy && collider.GetComponents<Collider2D>().Length == 1 &&
                IsDescendantOf(collider.transform, marker.transform) &&
                IsNear(collider.transform.position, marker.transform.position) &&
                Quaternion.Angle(collider.transform.rotation, marker.transform.rotation) <= MarkerPoseTolerance &&
                IsNear(collider.transform.lossyScale, marker.transform.lossyScale) &&
                IsNear(collider.bounds.center, marker.transform.position);
        }

        private static ObjectiveRole GetRole(RoomEncounterRuntimeContext context)
        {
            if (string.Equals(context.NodeId, "sample.tutorial", StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, "room.sample.tutorial", StringComparison.Ordinal))
                return ObjectiveRole.TutorialInteraction;
            if (string.Equals(context.NodeId, "sample.patio.exploration", StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, "room.patio.e1", StringComparison.Ordinal))
                return ObjectiveRole.ExplorationExit;
            if (string.Equals(context.NodeId, "sample.safe_extraction", StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, "room.sample.extraction", StringComparison.Ordinal))
                return ObjectiveRole.ExtractionInteraction;
            throw new InvalidOperationException("The exact F10 node/template pair has no noncombat objective role.");
        }

        private static string ExpectedNodeId(ObjectiveRole role)
        {
            switch (role)
            {
                case ObjectiveRole.TutorialInteraction: return "sample.tutorial";
                case ObjectiveRole.ExplorationExit: return "sample.patio.exploration";
                default: return "sample.safe_extraction";
            }
        }

        private static string ExpectedTemplateId(ObjectiveRole role)
        {
            switch (role)
            {
                case ObjectiveRole.TutorialInteraction: return "room.sample.tutorial";
                case ObjectiveRole.ExplorationExit: return "room.patio.e1";
                default: return "room.sample.extraction";
            }
        }

        private static string ExpectedMarkerId(ObjectiveRole role)
        {
            switch (role)
            {
                case ObjectiveRole.TutorialInteraction: return "tutorial.interaction";
                case ObjectiveRole.ExplorationExit: return "exit.trigger";
                default: return "extraction.interact";
            }
        }

        private static string ExpectedMarkerKind(ObjectiveRole role)
        {
            switch (role)
            {
                case ObjectiveRole.TutorialInteraction: return "encounter_anchor";
                case ObjectiveRole.ExplorationExit: return "exit_trigger";
                default: return "extraction";
            }
        }

        private static (string id, string kind, int tileX, int tileY) GetMarkerContract(ObjectiveRole role)
        {
            switch (role)
            {
                case ObjectiveRole.TutorialInteraction: return ("tutorial.interaction", "encounter_anchor", 13, 1);
                case ObjectiveRole.ExplorationExit: return ("exit.trigger", "exit_trigger", 43, 3);
                default: return ("extraction.interact", "extraction", 12, 1);
            }
        }

        private static bool IsCoherentHorizontalDisplacement(float moveX, float deltaX)
        {
            return moveX > EffectiveMoveDeadZone && deltaX > EffectiveDisplacementThreshold ||
                moveX < -EffectiveMoveDeadZone && deltaX < -EffectiveDisplacementThreshold;
        }

        private static bool IsNear(Vector3 actual, Vector3 expected)
        {
            return (actual - expected).sqrMagnitude <= MarkerPoseTolerance * MarkerPoseTolerance;
        }

        private static bool IsNear(Vector2 actual, Vector2 expected)
        {
            return (actual - expected).sqrMagnitude <= MarkerPoseTolerance * MarkerPoseTolerance;
        }

        private static bool IsDescendantOf(Transform candidate, Transform root)
        {
            return candidate != null && root != null &&
                (ReferenceEquals(candidate, root) || candidate.IsChildOf(root));
        }
    }
}
