using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Rooms;

namespace Luckbound.App
{
    internal enum F10ObjectiveObservationKind
    {
        TutorialCompleted,
        ExplorationExitTouched,
        ExtractionInteractionRequested
    }

    /// <summary>
    /// A room-local observation tied to one exact in-memory activation. It is not a durable objective result,
    /// settlement, or permission to advance the route.
    /// </summary>
    internal sealed class F10ObjectiveObservation
    {
        internal F10ObjectiveObservation(F10ObjectiveObservationKind kind,
            RoomEncounterRuntimeContext context, ActorId actorId, long tick)
        {
            Kind = kind;
            RunId = context.RunId;
            NodeId = context.NodeId;
            TemplateId = context.TemplateId;
            RoomInstanceId = context.RoomInstanceId;
            Scope = context.Scope;
            Controller = context.Controller;
            Player = context.Player;
            ActivationGeneration = context.ActivationGeneration;
            ActorId = actorId;
            Tick = tick;
            ObservationId = string.Concat(context.RunId, "|", context.NodeId, "|",
                context.RoomInstanceId, "|", context.ActivationGeneration, "|", kind, "|", actorId, "|", tick);
        }

        internal F10ObjectiveObservationKind Kind { get; }
        internal Luckbound.Core.Identifiers.RunId RunId { get; }
        internal string NodeId { get; }
        internal string TemplateId { get; }
        internal RoomInstanceId RoomInstanceId { get; }
        internal RoomLifetimeScope Scope { get; }
        internal ExpeditionRoomTransitionController Controller { get; }
        internal Luckbound.Gameplay.Movement.PlayerMotor2D Player { get; }
        internal long ActivationGeneration { get; }
        internal ActorId ActorId { get; }
        internal long Tick { get; }
        /// <summary>Stable retry key; consumers should deduplicate this local handoff, not treat it as a commit.</summary>
        internal string ObservationId { get; }
    }

    /// <summary>
    /// Accepts an in-memory observation into the owning room/session pipeline. Accepted means local handoff only;
    /// it does not persist, settle, complete an objective, or authorize route advancement. Consumers should
    /// deduplicate ObservationId because a declined or throwing handoff is retried. Extraction settlement and
    /// advancement must independently prove durable Custodian defeat plus the V7 pin/publication proof.
    /// </summary>
    internal interface IF10ObjectiveObservationHandoff
    {
        F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation);
    }

    internal enum F10ObjectiveHandoffResult
    {
        RetryLater,
        AcceptedLocalObservation
    }
}
