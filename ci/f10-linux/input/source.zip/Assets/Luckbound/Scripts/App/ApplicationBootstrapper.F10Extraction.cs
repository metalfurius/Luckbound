#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    public sealed partial class ApplicationBootstrapper
    {
        private const string F10GuardianNodeId = "sample.patio.guardian";
        private const string F10ExtractionNodeId = "sample.safe_extraction";
        private const string F10ExtractionTemplateId = "room.sample.extraction";
        private const string F10ExtractionMarkerId = "extraction.interact";
        private const float F10ExtractionMarkerTolerance = 0.001f;

        private F10ExtractionSettlementOperation _f10ExtractionSettlement;

        internal sealed class F10ExtractionCandidateOwnership
        {
            private object _candidate;
            private bool _saveStarted;

            internal bool TryAdoptBeforeSave(object candidate)
            {
                if (_saveStarted || candidate == null || _candidate != null) return false;
                _candidate = candidate;
                return true;
            }

            internal void MarkSaveStarted()
            {
                if (_candidate != null) _saveStarted = true;
            }

            internal bool OwnsExact(object candidate) => candidate != null && ReferenceEquals(_candidate, candidate);
            internal bool IsAdoptedBeforeSave => _candidate != null;
            internal bool HasStartedSave => _saveStarted;
        }

        internal static bool IsForeignF10ExtractionProfileGateBusy(bool gateBusy, bool underOwnGate)
        {
            return gateBusy && !underOwnGate;
        }

        private sealed class F10ExtractionSettlementOperation
        {
            internal F10ExtractionSettlementOperation(ExpeditionGameplayComposition composition,
                F10ObjectiveDriver2D driver, IF10ObjectiveObservationHandoff handoff,
                F10ObjectiveObservation observation, F10ExtractionCapture capture, IDisposable lease)
            {
                Composition = composition;
                Driver = driver;
                Handoff = handoff;
                Observation = observation;
                Capture = capture;
                Lease = lease;
            }

            internal ExpeditionGameplayComposition Composition { get; }
            internal F10ObjectiveDriver2D Driver { get; }
            internal IF10ObjectiveObservationHandoff Handoff { get; }
            internal F10ObjectiveObservation Observation { get; }
            internal F10ExtractionCapture Capture { get; }
            internal IDisposable Lease { get; set; }
            internal PendingSettlement Pending { get; set; }
            internal F10ExtractionCandidateOwnership CandidateOwnership { get; } = new F10ExtractionCandidateOwnership();
            internal string ProfileEnvelopeBaselineJson { get; set; }
            internal Task<ExpeditionSettlementCommitResult> Task { get; set; }
            internal bool GateHeld { get; set; }
            internal bool CandidateAdopted { get; set; }
            internal bool Persisted { get; set; }
            internal bool Finished { get; set; }
            internal string Error { get; set; }
            internal ExpeditionSettlementCommitResult LastResult { get; set; }
        }

        private sealed class F10ExtractionCapture
        {
            internal ExpeditionRunConfiguration Run;
            internal ExpeditionSaveData Save;
            internal RoomEncounterRuntimeContext Context;
            internal ExpeditionSessionReadinessRegistration Registration;
            internal ExpeditionRoomActivationRegistration Activation;
            internal ExpeditionGameplayComposition Composition;
            internal ExpeditionRoomTransitionController Controller;
            internal long Revision;
            internal string SaveJson;
            internal string InventoryJson;
            internal RunId RunId;
            internal ActorId ActorId;
        }

        // Kept as a separate API from the public settlement entry point: callers cannot choose outcome or amount.
        internal Task<ExpeditionSettlementCommitResult> SettleF10ExtractionAsync(
            ExpeditionGameplayComposition composition, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation)
        {
            if (!TryCaptureF10Extraction(composition, driver, handoff, observation,
                    requireDelivery: true, underOwnGate: false,
                    out F10ExtractionCapture capture, out string error))
                return Task.FromResult(F10ExtractionFailure(error));

            F10ExtractionSettlementOperation existing = _f10ExtractionSettlement;
            if (existing != null)
            {
                if (!SameF10ExtractionRequest(existing, composition, driver, handoff, observation))
                    return Task.FromResult(F10ExtractionFailure("A different F10 extraction request already owns settlement."));
                if (existing.Task != null) return existing.Task;
                return Task.FromResult(existing.LastResult ?? F10ExtractionFailure(existing.Error));
            }

            if (!TryAcquireExpeditionSimulationPauseLease(out IDisposable lease, out error))
                return Task.FromResult(F10ExtractionFailure(error));

            try
            {
                if (!TryCaptureF10Extraction(composition, driver, handoff, observation,
                        requireDelivery: false, underOwnGate: false,
                        out F10ExtractionCapture pausedCapture, out error) ||
                    !SameF10ExtractionCapture(capture, pausedCapture))
                {
                    lease.Dispose();
                    return Task.FromResult(F10ExtractionFailure(string.IsNullOrEmpty(error)
                        ? "The F10 extraction witness changed while acquiring its simulation lease."
                        : error));
                }

                var operation = new F10ExtractionSettlementOperation(composition, driver,
                    handoff, observation, pausedCapture, lease);
                _f10ExtractionSettlement = operation;
                operation.Task = RunF10ExtractionSettlementAsync(operation);
                return operation.Task;
            }
            catch
            {
                lease?.Dispose();
                throw;
            }
        }

        internal bool OwnsF10ExtractionCandidate(F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation)
        {
            F10ExtractionSettlementOperation operation = _f10ExtractionSettlement;
            return operation != null && SameF10ExtractionRequest(operation,
                operation.Composition, driver, handoff, observation) &&
                (operation.Persisted || operation.CandidateAdopted && operation.Pending != null &&
                    operation.CandidateOwnership.OwnsExact(operation.Pending));
        }

        internal bool HasPendingF10ExtractionRetry =>
            _f10ExtractionSettlement != null && _f10ExtractionSettlement.CandidateAdopted &&
            _f10ExtractionSettlement.Pending != null &&
            _f10ExtractionSettlement.CandidateOwnership.OwnsExact(_f10ExtractionSettlement.Pending) &&
            (_pendingSettlement == null || ReferenceEquals(_f10ExtractionSettlement.Pending, _pendingSettlement));

        internal async Task<ExpeditionSettlementCommitResult> RetryPendingF10ExtractionAsync()
        {
            F10ExtractionSettlementOperation operation = _f10ExtractionSettlement;
            if (operation == null || !operation.CandidateAdopted)
                return F10ExtractionFailure("There is no accepted F10 extraction settlement to retry.");

            if (IsF10ExtractionProfileDurable(operation))
            {
                ConfirmF10ExtractionSettlement(operation);
                return operation.LastResult ?? F10ExtractionSuccessResult(operation, "The extraction was already durably confirmed.");
            }

            if (operation.Pending == null || operation.Pending.Receipt == null ||
                operation.Pending.Receipt.RunId != operation.Capture.RunId)
                return F10ExtractionFailure("The exact F10 extraction PendingSettlement is no longer available.");

            await _profileMutationGate.WaitAsync();
            operation.GateHeld = true;
            try
            {
                if (_pendingSettlement != null && !ReferenceEquals(_pendingSettlement, operation.Pending))
                {
                    return new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                        persisted: false, pending: true,
                        "Another settlement owns the application pending slot; the exact extraction candidate remains retained.");
                }

                // A completed store write may outlive an exception before the in-memory publication. Adopt
                // only SaveRepository's authenticated current envelope for this exact pending candidate.
                if (TryPublishDurableF10ExtractionCandidate(operation, out ExpeditionSettlementCommitResult committed))
                {
                    ConfirmF10ExtractionSettlement(operation);
                    return committed;
                }
                if (_pendingSettlement == null) _pendingSettlement = operation.Pending;
                if (!ReferenceEquals(_pendingSettlement, operation.Pending))
                    return new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                        persisted: false, pending: true,
                        "The exact extraction candidate remains retained outside the application pending slot.");

                ExpeditionSettlementCommitResult result;
                if (_saveRepository.ExportPendingJson(SaveDocument.Profile) != null)
                {
                    string pendingJson = _saveRepository.ExportPendingJson(SaveDocument.Profile);
                    if (!TryAuthenticateExactF10ExtractionPendingProfileJson(pendingJson,
                            operation.Capture.RunId, operation.Pending.Profile, out string pendingError))
                    {
                        operation.Error = pendingError;
                        operation.LastResult = new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                            persisted: false, pending: true, pendingError);
                        return operation.LastResult;
                    }
                    result = await RetryPendingSettlementUnderGateAsync();
                }
                else
                {
                    if (!ProvesF10ExtractionWriteWasNotStarted(operation))
                    {
                        operation.Error = "No authenticated durable candidate or repository write state proves that an exact retry is safe.";
                        operation.LastResult = new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                            persisted: false, pending: true, operation.Error);
                        return operation.LastResult;
                    }
                    // No repository write is pending. Retry the already adopted profile payload directly;
                    // never rebuild the ledger receipt or re-run extraction policy.
                    SaveWriteResult save = await _saveRepository.SaveProfileAsync(operation.Pending.Profile);
                    if (!save.Succeeded)
                    {
                        operation.Error = save.Message;
                        operation.LastResult = new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                            persisted: false, pending: true, save.Message);
                        return operation.LastResult;
                    }
                    if (TryPublishDurableF10ExtractionCandidate(operation, out ExpeditionSettlementCommitResult exactCommit))
                    {
                        ConfirmF10ExtractionSettlement(operation);
                        return exactCommit;
                    }
                    operation.Error = "The exact extraction profile write succeeded without a matching authenticated current-profile snapshot.";
                    operation.LastResult = new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                        persisted: false, pending: true, operation.Error);
                    return operation.LastResult;
                }
                operation.LastResult = result;
                operation.Error = result == null ? "The settlement retry returned no result." : result.Message;
                if (result != null && result.Persisted && IsF10ExtractionProfileDurable(operation))
                    ConfirmF10ExtractionSettlement(operation);
                return result;
            }
            catch (Exception exception)
            {
                operation.Error = exception.Message;
                return new ExpeditionSettlementCommitResult(operation.Pending?.Receipt,
                    persisted: false, pending: operation.CandidateAdopted, exception.Message);
            }
            finally
            {
                operation.GateHeld = false;
                _profileMutationGate.Release();
                ScheduleGameplayProgressEventDrain();
            }
        }

        private async Task<ExpeditionSettlementCommitResult> RunF10ExtractionSettlementAsync(
            F10ExtractionSettlementOperation operation)
        {
            bool gateHeld = false;
            try
            {
                await _profileMutationGate.WaitAsync();
                gateHeld = true;
                operation.GateHeld = true;
                string error = string.Empty;

                if (!ReferenceEquals(_f10ExtractionSettlement, operation) ||
                    !TryCaptureF10Extraction(operation.Composition, operation.Driver,
                        operation.Handoff, operation.Observation, requireDelivery: false, underOwnGate: true,
                        out F10ExtractionCapture current, out error) ||
                    !SameF10ExtractionCapture(operation.Capture, current))
                    return FailF10ExtractionBeforeAdoption(operation,
                        string.IsNullOrEmpty(error) ? "The F10 extraction witness changed before settlement." : error);

                if (_saveRepository == null || _saveRepository.ExportPendingJson(SaveDocument.Profile) != null)
                    return FailF10ExtractionBeforeAdoption(operation,
                        "An orphaned profile write already exists; extraction will not adopt or retry its payload.");

                // Renown is read from the latest authoritative save only after acquiring the profile gate.
                int accumulatedRenown = _activeExpedition.accumulatedRenown;
                operation.ProfileEnvelopeBaselineJson = JsonUtility.ToJson(_saveRepository.CurrentProfile);
                ExpeditionSettlementCommitResult result = await SettleActiveRunUnderGateAsync(
                    ExpeditionOutcome.Extracted, accumulatedRenown);
                operation.LastResult = result;
                operation.Error = result == null ? "The settlement returned no result." : result.Message;

                if (operation.CandidateAdopted && _pendingSettlement != null &&
                    ReferenceEquals(_pendingSettlement, operation.Pending))
                {
                    if (result != null && result.Persisted && IsF10ExtractionProfileDurable(operation))
                        ConfirmF10ExtractionSettlement(operation);
                    else
                    {
                        operation.Error = result == null ? "The accepted extraction is awaiting persistence retry." : result.Message;
                    }
                    return result ?? new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                        persisted: false, pending: true, operation.Error);
                }

                if (result != null && result.Persisted && IsF10ExtractionProfileDurable(operation))
                {
                    operation.CandidateAdopted = true;
                    operation.Persisted = true;
                    ConfirmF10ExtractionSettlement(operation);
                    return result;
                }

                return FailF10ExtractionBeforeAdoption(operation,
                    result == null ? "The extraction settlement returned no durable result." : result.Message, result);
            }
            catch (Exception exception)
            {
                operation.Error = exception.Message;
                if (operation.CandidateAdopted && operation.Pending != null &&
                    ReferenceEquals(_pendingSettlement, operation.Pending))
                {
                    operation.LastResult = new ExpeditionSettlementCommitResult(operation.Pending.Receipt,
                        persisted: false, pending: true, exception.Message);
                    return operation.LastResult;
                }

                return FailF10ExtractionBeforeAdoption(operation, exception.Message);
            }
            finally
            {
                operation.GateHeld = false;
                if (gateHeld) _profileMutationGate.Release();
            }
        }

        private PendingSettlement AdoptF10ExtractionPendingSettlement(
            ExpeditionSettlementLedger ledger, ProfileSaveData profile,
            ExpeditionSettlementReceipt receipt)
        {
            F10ExtractionSettlementOperation operation = _f10ExtractionSettlement;
            if (operation == null || !operation.GateHeld || operation.Capture.RunId != receipt.RunId ||
                receipt.Outcome != ExpeditionOutcome.Extracted)
                return null;
            if (_saveRepository == null || _saveRepository.ExportPendingJson(SaveDocument.Profile) != null)
                throw new InvalidOperationException("An orphaned profile write blocks F10 extraction candidate adoption.");

            var pending = new PendingSettlement(ledger, profile, receipt);
            if (!operation.CandidateOwnership.TryAdoptBeforeSave(pending)) return null;
            operation.Pending = pending;
            operation.CandidateAdopted = true;
            _pendingSettlement = pending;
            return pending;
        }

        private void MarkF10ExtractionSaveStarted(PendingSettlement pending)
        {
            F10ExtractionSettlementOperation operation = _f10ExtractionSettlement;
            if (operation != null && ReferenceEquals(operation.Pending, pending) &&
                operation.CandidateOwnership.OwnsExact(pending))
                operation.CandidateOwnership.MarkSaveStarted();
        }

        private ExpeditionSettlementCommitResult FailF10ExtractionBeforeAdoption(
            F10ExtractionSettlementOperation operation, string error,
            ExpeditionSettlementCommitResult result = null)
        {
            operation.Error = string.IsNullOrWhiteSpace(error) ? "The extraction was not accepted." : error;
            operation.LastResult = result ?? F10ExtractionFailure(operation.Error);
            operation.Finished = true;
            bool exactPending = operation.CandidateAdopted && operation.Pending != null &&
                ReferenceEquals(_pendingSettlement, operation.Pending);
            if (!exactPending)
            {
                operation.CandidateAdopted = false;
                operation.Pending = null;
                if (ReferenceEquals(_f10ExtractionSettlement, operation)) _f10ExtractionSettlement = null;
                ReleaseF10ExtractionLease(operation);
            }
            return operation.LastResult;
        }

        private bool IsF10ExtractionProfileDurable(F10ExtractionSettlementOperation operation)
        {
            if (operation == null || !SaveDataReady || _profileData == null ||
                _profileData.processedSettlementRunIds == null || _activeExpedition != null)
                return false;
            string runId = operation.Capture.RunId.ToString();
            return _profileData.processedSettlementRunIds.Contains(runId, StringComparer.Ordinal) &&
                _settlementLedger != null && _settlementLedger.ProcessedRunIds.Contains(operation.Capture.RunId);
        }

        private bool TryPublishDurableF10ExtractionCandidate(
            F10ExtractionSettlementOperation operation, out ExpeditionSettlementCommitResult result)
        {
            result = null;
            PendingSettlement pending = operation == null ? null : operation.Pending;
            ProfileSaveEnvelope envelope = _saveRepository?.CurrentProfile;
            if (pending == null || pending.Receipt == null || !operation.CandidateAdopted ||
                !operation.CandidateOwnership.OwnsExact(pending) ||
                pending.Receipt.RunId != operation.Capture.RunId ||
                _pendingSettlement != null && !ReferenceEquals(_pendingSettlement, pending) ||
                envelope == null || envelope.profile == null || envelope.hasActiveExpedition ||
                envelope.activeExpedition != null ||
                envelope.profile.processedSettlementRunIds == null ||
                !envelope.profile.processedSettlementRunIds.Contains(operation.Capture.RunId.ToString(), StringComparer.Ordinal))
                return false;

            ProfileSaveData expected = pending.Profile?.Clone();
            if (expected == null) return false;
            expected.NormalizeForSave();
            if (!string.Equals(JsonUtility.ToJson(expected), JsonUtility.ToJson(envelope.profile), StringComparison.Ordinal))
                return false;

            if (_activeExpedition != null) _activeExpeditionRevision++;
            _settlementLedger = pending.Ledger;
            _profileData = envelope.profile.Clone();
            _contractProgression = CreateContractProgressionSnapshot(_profileData);
            _activeExpedition = null;
            if (ReferenceEquals(_pendingSettlement, pending)) _pendingSettlement = null;
            operation.Pending = pending;
            operation.LastResult = new ExpeditionSettlementCommitResult(pending.Receipt,
                persisted: true, pending: false, "The retained extraction candidate is authenticated as the durable current profile.");
            result = operation.LastResult;
            return true;
        }

        private bool ProvesF10ExtractionWriteWasNotStarted(F10ExtractionSettlementOperation operation)
        {
            if (operation == null || string.IsNullOrEmpty(operation.ProfileEnvelopeBaselineJson) ||
                _saveRepository == null || _saveRepository.ExportPendingJson(SaveDocument.Profile) != null)
                return false;
            string current = JsonUtility.ToJson(_saveRepository.CurrentProfile);
            return string.Equals(current, operation.ProfileEnvelopeBaselineJson, StringComparison.Ordinal);
        }

        internal static bool TryAuthenticateExactF10ExtractionPendingProfileJson(string json,
            RunId runId, ProfileSaveData expectedProfile, out string error)
        {
            error = string.Empty;
            if (!runId.IsValid || expectedProfile == null || string.IsNullOrWhiteSpace(json))
                return FailF10Extraction("The pending extraction profile payload or RunId is missing.", out error);

            ProfileSaveEnvelope envelope;
            int sourceContentVersion;
            DecodeStatus status = SaveJsonCodec.Decode(json, out envelope, out sourceContentVersion);
            if (status != DecodeStatus.Valid || envelope == null ||
                sourceContentVersion != SaveFormat.ContentVersion ||
                envelope.contentVersion != SaveFormat.ContentVersion || envelope.profile == null)
                return FailF10Extraction("The pending profile is not an authenticated V6 envelope.", out error);
            if (envelope.hasActiveExpedition || envelope.activeExpedition != null)
                return FailF10Extraction("An extraction settlement profile must not retain an active expedition.", out error);

            ProfileSaveData actual = envelope.profile.Clone();
            ProfileSaveData expected = expectedProfile.Clone();
            actual.NormalizeForSave();
            expected.NormalizeForSave();
            if (!string.Equals(JsonUtility.ToJson(actual), JsonUtility.ToJson(expected), StringComparison.Ordinal))
                return FailF10Extraction("The pending V6 profile differs from the retained extraction candidate.", out error);
            if (actual.processedSettlementRunIds == null ||
                !actual.processedSettlementRunIds.Contains(runId.ToString(), StringComparer.Ordinal))
                return FailF10Extraction("The pending V6 profile does not mark this RunId processed.", out error);
            return true;
        }

        private void ConfirmF10ExtractionSettlement(F10ExtractionSettlementOperation operation)
        {
            if (!IsF10ExtractionProfileDurable(operation)) return;
            operation.CandidateAdopted = true;
            operation.Persisted = true;
            operation.Finished = true;
            operation.Error = string.Empty;
            if (operation.LastResult == null || !operation.LastResult.Persisted)
                operation.LastResult = F10ExtractionSuccessResult(operation, "The extraction profile is durably confirmed.");

            // The profile commit owns completion. Clear the in-memory run and close only this technical gameplay.
            ClearActiveRun();
            if (operation.Composition != null) Destroy(operation.Composition.gameObject);
            ReleaseF10ExtractionLease(operation);
        }

        private static ExpeditionSettlementCommitResult F10ExtractionSuccessResult(
            F10ExtractionSettlementOperation operation, string message)
        {
            return new ExpeditionSettlementCommitResult(operation?.Pending?.Receipt,
                persisted: true, pending: false, message);
        }

        private void ReleaseF10ExtractionLease(F10ExtractionSettlementOperation operation)
        {
            IDisposable lease = operation?.Lease;
            if (operation != null) operation.Lease = null;
            try { lease?.Dispose(); }
            catch (Exception exception) { Debug.LogException(exception, this); }
        }

        private static ExpeditionSettlementCommitResult F10ExtractionFailure(string message)
        {
            return new ExpeditionSettlementCommitResult(null, persisted: false,
                pending: false, string.IsNullOrWhiteSpace(message) ? "F10 extraction settlement was rejected." : message);
        }

        private bool TryCaptureF10Extraction(ExpeditionGameplayComposition composition,
            F10ObjectiveDriver2D driver, IF10ObjectiveObservationHandoff handoff,
            F10ObjectiveObservation observation, bool requireDelivery, bool underOwnGate,
            out F10ExtractionCapture capture, out string error)
        {
            capture = null;
            error = string.Empty;
            if (requireDelivery && (driver == null || handoff == null || observation == null ||
                !driver.IsDeliveringTo(handoff, observation)))
                return FailF10Extraction("Extraction requires this exact observation during its exact handoff delivery.", out error);

            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, this) ||
                composition == null || !composition.isActiveAndEnabled || !composition.IsReady ||
                !OwnsF10DiagnosticRun(ActiveRun) || ActiveRun.Route == null ||
                ActiveRun.Route.GenerationVersion != 2 || !CanWriteProfile ||
                HasPendingExpeditionWrite || HasPendingSettlement || HasPendingContractProgression ||
                HasPendingCraftingWrite || HasPendingEconomyMutation || HasPendingPermanentUpgradePurchase ||
                HasPendingRoomAdvance || IsRoomAdvanceInFlight ||
                IsForeignF10ExtractionProfileGateBusy(IsProfileMutationInFlight, underOwnGate))
                return FailF10Extraction("Extraction requires the exact writable isolated F10 run and a clear profile mutation lane.", out error);

            ExpeditionReadinessCompositionView view = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = ActiveRun;
            ExpeditionSaveData save = _activeExpedition == null ? null : _activeExpedition.Clone();
            ExpeditionRoomTransitionController transitions = composition.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = view == null ? null : view.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null ? null : registration.CurrentActivation;
            ExpeditionReadinessTransitionView transition = transitions == null ? null : transitions.CaptureReadinessTransitionView();
            RoomEncounterRuntimeContext context = activation == null ? null : activation.Context;

            if (view == null || !view.IsReady || !ReferenceEquals(view.Owner, composition) ||
                !ReferenceEquals(view.Application, this) || view.Run == null || view.Run.RunId != run.RunId ||
                view.Run.Seed != run.Seed || view.Run.Route == null ||
                !string.Equals(view.Run.Route.CanonicalForm, run.Route.CanonicalForm, StringComparison.Ordinal) ||
                !ReferenceEquals(view.RoomTransitions, transitions) || transitions == null || transitions.IsDisposed ||
                activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !registration.IsOwnerActive || !ReferenceEquals(registration.Owner, composition) ||
                !ReferenceEquals(activation.Controller, transitions) || activation.RunId != run.RunId ||
                !RunsHaveSameRoute(activation.BoundRun, run) || context == null ||
                !ReferenceEquals(context.Scope, activation.Scope) || !ReferenceEquals(context.Controller, transitions) ||
                !ReferenceEquals(context.Player, view.PlayerMotor) ||
                activation.Source == null || context.Plan != null || !context.IsCurrentRoomScope() ||
                transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !ReferenceEquals(transition.ActiveScope, context.Scope) ||
                !ReferenceEquals(transition.ActiveRoomRoot, context.Scope.gameObject) ||
                !string.Equals(transition.ActiveNodeId, F10ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(transition.ActiveTemplateId, F10ExtractionTemplateId, StringComparison.Ordinal) ||
                context.RunId != run.RunId || context.RouteGenerationVersion != 2 ||
                !string.Equals(context.NodeId, F10ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, F10ExtractionTemplateId, StringComparison.Ordinal) ||
                context.RoomInstanceId != ExpeditionRoomIdentity.ForNode(run.RunId, F10ExtractionNodeId) ||
                view.PlayerMotor == null || !ReferenceEquals(view.PlayerMotor, composition.PlayerMotor) ||
                view.PlayerObject == null || !ReferenceEquals(view.PlayerObject, view.PlayerMotor.gameObject) ||
                view.PlayerMotor.GetComponent<Rigidbody2D>() == null || !view.PlayerMotor.ActorId.IsValid ||
                run.Inventory == null || view.ItemCollector == null || !view.ItemCollector.isActiveAndEnabled ||
                !ReferenceEquals(view.ItemCollector.gameObject, view.PlayerObject) ||
                !ReferenceEquals(view.ItemCollector.Inventory, run.Inventory) ||
                !TryValidateF10ExtractionRoute(run, save, transitions, out error) ||
                !TryValidateF10ExtractionObservation(context, driver, handoff, observation,
                    view.PlayerMotor, requireDelivery, out error) ||
                !TryValidateF10ExtractionMarker(context.Scope, out error))
                return FailF10Extraction(string.IsNullOrEmpty(error)
                    ? "The active readiness owner, actor, bound extraction scope, or save cursor is stale."
                    : error, out error);

            if (run.Inventory == null)
                return FailF10Extraction("The active F10 run has no inventory to settle.", out error);
            string inventoryJson;
            try { inventoryJson = JsonUtility.ToJson(run.Inventory.CreateSnapshot()); }
            catch (Exception exception) { return FailF10Extraction("Could not capture the F10 extraction inventory: " + exception.Message, out error); }
            capture = new F10ExtractionCapture
            {
                Run = run,
                Save = save,
                Context = context,
                Registration = registration,
                Activation = activation,
                Composition = composition,
                Controller = transitions,
                Revision = ActiveExpeditionRevision,
                SaveJson = JsonUtility.ToJson(save),
                InventoryJson = inventoryJson,
                RunId = run.RunId,
                ActorId = view.PlayerMotor.ActorId
            };
            return true;
        }

        private static bool RunsHaveSameRoute(ExpeditionRunConfiguration left, ExpeditionRunConfiguration right)
        {
            return left != null && right != null && left.RunId == right.RunId && left.Seed == right.Seed &&
                left.Route != null && right.Route != null && left.Route.GenerationVersion == right.Route.GenerationVersion &&
                string.Equals(left.Route.CanonicalForm, right.Route.CanonicalForm, StringComparison.Ordinal);
        }

        private static bool TryValidateF10ExtractionRoute(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, ExpeditionRoomTransitionController transitions, out string error)
        {
            error = string.Empty;
            if (run == null || save == null || transitions == null || run.Route == null ||
                !string.Equals(save.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                save.seed != run.Seed || save.generationVersion != 2 ||
                !string.Equals(save.routeSnapshotJson, run.Route.CanonicalForm, StringComparison.Ordinal) ||
                !string.Equals(save.currentNodeId, F10ExtractionNodeId, StringComparison.Ordinal) ||
                save.visitedNodeIds == null || save.visitedNodeIds.Length < 2 ||
                !string.Equals(save.visitedNodeIds[save.visitedNodeIds.Length - 2], F10GuardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(save.visitedNodeIds[save.visitedNodeIds.Length - 1], F10ExtractionNodeId, StringComparison.Ordinal) ||
                save.completedRoomIds == null || !save.completedRoomIds.Contains(F10GuardianNodeId, StringComparer.Ordinal) ||
                save.completedRoomResults == null || save.completedRoomResults.Length == 0 ||
                !string.Equals(transitions.CurrentNodeId, F10ExtractionNodeId, StringComparison.Ordinal) ||
                transitions.CurrentRoomId != ExpeditionRoomIdentity.ForNode(run.RunId, F10ExtractionNodeId))
                return FailF10Extraction("The durable F10 cursor must be the exact SafeExtraction room immediately after Guardian.", out error);

            ExpeditionRouteNode[] guardians = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, F10GuardianNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteNode[] extractions = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, F10ExtractionNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, F10GuardianNodeId, StringComparison.Ordinal)).ToArray();
            if (guardians.Length != 1 || guardians[0].Kind != ExpeditionRouteNodeKind.Guardian ||
                !string.Equals(guardians[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(guardians[0].TemplateId, "room.patio.guardian", StringComparison.Ordinal) ||
                extractions.Length != 1 || extractions[0].Kind != ExpeditionRouteNodeKind.SafeExtraction ||
                !string.Equals(extractions[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(extractions[0].TemplateId, F10ExtractionTemplateId, StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, F10ExtractionNodeId, StringComparison.Ordinal))
                return FailF10Extraction("The F10 Guardian-to-SafeExtraction edge is not the exact mandatory route edge.", out error);

            string guardianRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, F10GuardianNodeId).ToString();
            ExpeditionRoomCompletionSaveData[] results = save.completedRoomResults.Where(result => result != null &&
                string.Equals(result.roomNodeId, F10GuardianNodeId, StringComparison.Ordinal)).ToArray();
            if (results.Length != 1 || !string.Equals(results[0].resultId,
                    "room-result.v1:" + guardianRoomId, StringComparison.Ordinal) ||
                !MatchesGuardianCompletionResult(results[0].resultJson, guardianRoomId))
                return FailF10Extraction("No exact durable cleared Guardian room result precedes extraction.", out error);
            return true;
        }

        [Serializable]
        private sealed class DurableF10RoomResult
        {
            public int schema;
            public string outcome;
            public string roomInstanceId;
            public string sourceNodeId;
            public string targetNodeId;
        }

        private static bool MatchesGuardianCompletionResult(string json, string guardianRoomId)
        {
            if (string.IsNullOrWhiteSpace(json)) return false;
            try
            {
                DurableF10RoomResult result = JsonUtility.FromJson<DurableF10RoomResult>(json);
                return result != null && result.schema == 1 &&
                    string.Equals(result.outcome, "cleared", StringComparison.Ordinal) &&
                    string.Equals(result.roomInstanceId, guardianRoomId, StringComparison.Ordinal) &&
                    string.Equals(result.sourceNodeId, F10GuardianNodeId, StringComparison.Ordinal) &&
                    string.Equals(result.targetNodeId, F10ExtractionNodeId, StringComparison.Ordinal);
            }
            catch { return false; }
        }

        private static bool TryValidateF10ExtractionObservation(RoomEncounterRuntimeContext context,
            F10ObjectiveDriver2D driver, IF10ObjectiveObservationHandoff handoff,
            F10ObjectiveObservation observation, PlayerMotor2D player, bool requireDelivery,
            out string error)
        {
            error = string.Empty;
            if (driver == null || handoff == null || observation == null || context == null ||
                context.Scope == null || player == null ||
                !ReferenceEquals(driver, context.Scope.GetComponent<F10ObjectiveDriver2D>()) || driver.IsDisposed ||
                requireDelivery && !driver.IsDeliveringTo(handoff, observation) ||
                observation.Kind != F10ObjectiveObservationKind.ExtractionInteractionRequested ||
                observation.RunId != context.RunId || observation.ActorId != player.ActorId ||
                !string.Equals(observation.NodeId, F10ExtractionNodeId, StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, F10ExtractionTemplateId, StringComparison.Ordinal) ||
                observation.RoomInstanceId != context.RoomInstanceId ||
                !ReferenceEquals(observation.Scope, context.Scope) ||
                !ReferenceEquals(observation.Controller, context.Controller) ||
                !ReferenceEquals(observation.Player, player) ||
                observation.ActivationGeneration != context.ActivationGeneration)
                return FailF10Extraction("The extraction fact does not match the exact actor, scope, room, and activation.", out error);
            return true;
        }

        private static bool TryValidateF10ExtractionMarker(RoomLifetimeScope scope, out string error)
        {
            error = string.Empty;
            if (scope == null || scope.IsDisposed || !scope.isActiveAndEnabled ||
                !string.Equals(scope.TemplateId, F10ExtractionTemplateId, StringComparison.Ordinal))
                return FailF10Extraction("The F10 extraction scope is not the active safe-extraction room.", out error);

            RoomTemplatePrefab2D[] prefabs = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (prefabs.Length != 1 || prefabs[0] == null || prefabs[0].SourceDefinition == null ||
                !prefabs[0].isActiveAndEnabled)
                return FailF10Extraction("Extraction requires one active source room template.", out error);
            RoomTemplateData data;
            try { data = RoomTemplateJsonLoader.Load(prefabs[0].SourceDefinition.text); }
            catch { return FailF10Extraction("The safe-extraction source definition is invalid.", out error); }
            RoomPositionMarkerData[] definitions = data.markers.Where(marker => marker != null &&
                string.Equals(marker.id, F10ExtractionMarkerId, StringComparison.Ordinal)).ToArray();
            RoomPositionMarker2D[] markers = scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(marker => marker != null && string.Equals(marker.MarkerId, F10ExtractionMarkerId, StringComparison.Ordinal)).ToArray();
            if (!string.Equals(data.templateId, F10ExtractionTemplateId, StringComparison.Ordinal) ||
                definitions.Length != 1 || !string.Equals(definitions[0].kind, "extraction", StringComparison.Ordinal) ||
                definitions[0].tileX != 12 || definitions[0].tileY != 1 || markers.Length != 1 ||
                !markers[0].enabled || !markers[0].gameObject.activeInHierarchy ||
                markers[0].TilePosition != new Vector2Int(12, 1) ||
                !string.Equals(markers[0].Kind, "extraction", StringComparison.Ordinal))
                return FailF10Extraction("The extraction.interact source/runtime marker must be the exact extraction marker at tile (12, 1).", out error);

            BoxCollider2D[] triggers = markers[0].GetComponentsInChildren<BoxCollider2D>(true)
                .Where(collider => collider != null && collider.gameObject.name == "F10ObjectiveTrigger.extraction.interact")
                .ToArray();
            if (triggers.Length != 1 || !triggers[0].enabled || !triggers[0].isTrigger ||
                !triggers[0].gameObject.activeInHierarchy || triggers[0].GetComponents<Collider2D>().Length != 1 ||
                !ReferenceEquals(triggers[0].transform.parent, markers[0].transform) ||
                (triggers[0].transform.position - markers[0].transform.position).sqrMagnitude >
                    F10ExtractionMarkerTolerance * F10ExtractionMarkerTolerance ||
                triggers[0].size != Vector2.one * data.tileSize)
                return FailF10Extraction("The extraction.interact trigger is not the one exact scope-owned marker trigger.", out error);
            return true;
        }

        private static bool SameF10ExtractionRequest(F10ExtractionSettlementOperation operation,
            ExpeditionGameplayComposition composition, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation)
        {
            return operation != null && ReferenceEquals(operation.Composition, composition) &&
                ReferenceEquals(operation.Driver, driver) && ReferenceEquals(operation.Handoff, handoff) &&
                ReferenceEquals(operation.Observation, observation) && observation != null &&
                string.Equals(operation.Observation.ObservationId, observation.ObservationId, StringComparison.Ordinal);
        }

        private static bool SameF10ExtractionCapture(F10ExtractionCapture left, F10ExtractionCapture right)
        {
            return left != null && right != null && left.RunId == right.RunId && left.ActorId == right.ActorId &&
                left.Revision == right.Revision && ReferenceEquals(left.Composition, right.Composition) &&
                ReferenceEquals(left.Controller, right.Controller) &&
                ReferenceEquals(left.Context, right.Context) && ReferenceEquals(left.Registration, right.Registration) &&
                ReferenceEquals(left.Activation, right.Activation) &&
                string.Equals(left.SaveJson, right.SaveJson, StringComparison.Ordinal) &&
                string.Equals(left.InventoryJson, right.InventoryJson, StringComparison.Ordinal);
        }

        private static bool FailF10Extraction(string message, out string error)
        {
            error = message;
            return false;
        }
    }
}
#endif
