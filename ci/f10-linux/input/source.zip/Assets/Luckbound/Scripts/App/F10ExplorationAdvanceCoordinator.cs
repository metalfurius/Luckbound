#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    internal enum F10ExplorationAdvanceState
    {
        SetupFailed,
        WaitingForExplorationExit,
        WaitingForCacheSettlement,
        WaitingForSessionMutation,
        Resolving,
        PendingRetry,
        Failed,
        Completed
    }

    /// <summary>Connects only the isolated F10 E1 exit fact to its durable guardian route edge.</summary>
    [DisallowMultipleComponent]
    internal sealed class F10ExplorationAdvanceCoordinator : MonoBehaviour, IF10ObjectiveObservationHandoff
    {
        private const string ExplorationNodeId = "sample.patio.exploration";
        private const string ExplorationTemplateId = "room.patio.e1";
        private const string GuardianNodeId = "sample.patio.guardian";
        private const string GuardianTemplateId = "room.patio.guardian";

        private ApplicationBootstrapper _application;
        private ExpeditionGameplayComposition _composition;
        private ExpeditionSessionReadinessRegistration _registration;
        private RoomLifetimeScope _scope;
        private PlayerMotor2D _player;
        private Collider2D _playerCollider;
        private GameObject _inactiveCachePrefab;
        private RoomEncounterRuntimeContext _context;
        private ExpeditionEncounterSessionSnapshotSource _snapshotSource;
        private F10ObjectiveDriver2D _objectiveDriver;
        private F10ExplorationGoldCacheBinding2D _cacheBinding;
        private Task _attemptTask;
        private Task _cacheRetryTask;
        private RunId _runId;
        private F10ObjectiveObservation _acceptedObservation;
        private object _lastOutcome;
        private F10ExplorationAdvanceState _state = F10ExplorationAdvanceState.SetupFailed;
        private string _error = string.Empty;
        private bool _attemptInProgress;
        private bool _cacheRetryInProgress;
        private bool _observationAccepted;
        private bool _advanceAttemptStarted;
        private bool _hadPendingRoomAdvance;
        private bool _retryExactPendingAdvance;
        private bool _persistedConfirmed;
        private bool _activatedConfirmed;

        internal F10ExplorationAdvanceState State => _state;
        internal string Error => _error;
        internal bool Persisted => _persistedConfirmed;
        internal bool Activated => _activatedConfirmed;
        internal string TargetNodeId => GuardianNodeId;
        internal string AcceptedObservationId => _acceptedObservation == null
            ? string.Empty
            : _acceptedObservation.ObservationId;
        internal object LastOutcome => _lastOutcome;
        internal F10ObjectiveDriver2D ObjectiveDriver => _objectiveDriver;
        internal F10ExplorationGoldCacheBinding2D CacheBinding => _cacheBinding;

        /// <summary>
        /// Attaches only to the exact owned F10 diagnostic E1 activation. Attachment failures are retained
        /// on the scope-owned component so the diagnostic runner can inspect and retry setup.
        /// </summary>
        internal static F10ExplorationAdvanceCoordinator Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, GameObject inactiveCachePrefab)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            if (inactiveCachePrefab == null) throw new ArgumentNullException(nameof(inactiveCachePrefab));

            AttachmentView attachment = ValidateAttachment(application, composition);
            F10ExplorationAdvanceCoordinator existing = attachment.Scope.GetComponent<F10ExplorationAdvanceCoordinator>();
            if (existing != null)
            {
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition) &&
                    ReferenceEquals(existing._inactiveCachePrefab, inactiveCachePrefab))
                    return existing;
                throw new InvalidOperationException("The active E1 scope already owns another exploration advance coordinator.");
            }

            F10ExplorationAdvanceCoordinator coordinator =
                attachment.Scope.gameObject.AddComponent<F10ExplorationAdvanceCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._registration = attachment.Registration;
            coordinator._scope = attachment.Scope;
            coordinator._player = attachment.Player;
            coordinator._playerCollider = attachment.PlayerCollider;
            coordinator._inactiveCachePrefab = inactiveCachePrefab;
            coordinator._runId = attachment.Run.RunId;
            coordinator.TryAttachRoomBindings(attachment);
            return coordinator;
        }

        /// <summary>Retains one exact E1 exit observation and starts its durable request once.</summary>
        public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
        {
            if (_objectiveDriver == null || !_objectiveDriver.IsDeliveringTo(this, observation) ||
                !IsExactExplorationObservationForContext(_context, observation))
                return F10ObjectiveHandoffResult.RetryLater;

            if (_acceptedObservation != null && !ReferenceEquals(_acceptedObservation, observation))
                return F10ObjectiveHandoffResult.RetryLater;
            _acceptedObservation = observation;
            if (_attemptInProgress) return F10ObjectiveHandoffResult.RetryLater;

            bool ownsExactPendingAdvance = _retryExactPendingAdvance &&
                _application != null && _application.HasPendingRoomAdvance;
            if (CanAcknowledgeExplorationObservation(_attemptInProgress, ownsExactPendingAdvance,
                _persistedConfirmed) || _observationAccepted)
            {
                _observationAccepted = true;
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }

            if (!CanStartFreshExplorationAttempt(_attemptInProgress, _advanceAttemptStarted,
                _hadPendingRoomAdvance, _persistedConfirmed))
                return F10ObjectiveHandoffResult.RetryLater;

            if (_snapshotSource == null || _registration == null || _cacheBinding == null ||
                _registration.CurrentActivation == null ||
                !ReferenceEquals(_registration.CurrentActivation.Source, _snapshotSource) ||
                !IsCurrentExplorationActivation())
                return F10ObjectiveHandoffResult.RetryLater;

            if (!CanStartAdvance(out F10ExplorationAdvanceState blockedState, out string blockedReason))
            {
                _state = blockedState;
                _error = blockedReason;
                // RetryLater keeps this exact observation in the driver's handoff queue.
                return F10ObjectiveHandoffResult.RetryLater;
            }

            StartAdvanceAttempt(alreadyAdmittedByHandoff: true);
            ownsExactPendingAdvance = _retryExactPendingAdvance &&
                _application != null && _application.HasPendingRoomAdvance;
            if (CanAcknowledgeExplorationObservation(_attemptInProgress, ownsExactPendingAdvance,
                _persistedConfirmed))
            {
                _observationAccepted = true;
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
            return F10ObjectiveHandoffResult.RetryLater;
        }

        /// <summary>
        /// Retries setup or the exact retained operation. Once a PendingRoomAdvance exists, this calls only
        /// RetryPendingRoomAdvanceAsync and never re-runs the exploration result policy.
        /// </summary>
        internal Task RetryAsync()
        {
            if (_state == F10ExplorationAdvanceState.Completed) return Task.CompletedTask;
            if (_attemptInProgress) return _attemptTask ?? Task.CompletedTask;
            if (_cacheRetryInProgress) return _cacheRetryTask ?? Task.CompletedTask;

            // A retained room advance always wins over the still-queued local observation.
            if (_retryExactPendingAdvance)
            {
                if (TryReconcileSavedActivation()) return Task.CompletedTask;
                if (_application != null && _application.HasPendingRoomAdvance)
                    return StartAdvanceAttempt();
                _retryExactPendingAdvance = false;
                _state = F10ExplorationAdvanceState.Failed;
                _error = _persistedConfirmed
                    ? "The durable E1 result is saved, but its exact Guardian activation is not confirmed."
                    : "The exact pending room advance cleared without confirming its durable result.";
                return Task.CompletedTask;
            }

            if (_hadPendingRoomAdvance || _persistedConfirmed)
            {
                TryReconcileSavedActivation();
                if (_state != F10ExplorationAdvanceState.Completed)
                {
                    _state = F10ExplorationAdvanceState.Failed;
                    if (string.IsNullOrEmpty(_error))
                        _error = "This request already reached the application commit path and cannot be replayed as a new policy request.";
                }
                return Task.CompletedTask;
            }

            if (!_advanceAttemptStarted && (_objectiveDriver == null || _cacheBinding == null))
            {
                TryAttachRoomBindings();
                if (_objectiveDriver == null || _cacheBinding == null) return Task.CompletedTask;
            }

            if (_state == F10ExplorationAdvanceState.Failed && _advanceAttemptStarted &&
                !_hadPendingRoomAdvance && !_persistedConfirmed)
            {
                _advanceAttemptStarted = false;
                _observationAccepted = false;
                _state = F10ExplorationAdvanceState.WaitingForExplorationExit;
                _error = string.Empty;
                // The queued driver fact will make the next attempt only through its exact handoff callback.
                return Task.CompletedTask;
            }

            if (_acceptedObservation != null && !_observationAccepted)
            {
                if (IsCacheSettlementPending())
                    return _cacheBinding != null && _cacheBinding.CanRetry
                        ? RetryPendingCacheAsync()
                        : Task.CompletedTask;

                // The driver still owns the queued observation and will retry this exact handoff itself.
                _state = F10ExplorationAdvanceState.WaitingForExplorationExit;
                _error = string.Empty;
                return Task.CompletedTask;
            }

            if (IsCacheSettlementPending())
                return _cacheBinding != null && _cacheBinding.CanRetry
                    ? RetryPendingCacheAsync()
                    : Task.CompletedTask;

            if (_acceptedObservation == null) return Task.CompletedTask;
            return Task.CompletedTask;
        }

        private static AttachmentView ValidateAttachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun))
                throw new InvalidOperationException("Exploration advance requires the exact owned F10 diagnostic run in Play Mode.");

            ExpeditionReadinessCompositionView readiness = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = readiness == null ? null : readiness.Run;
            ExpeditionRoomTransitionController transitions = readiness == null ? null : readiness.RoomTransitions;
            if (!composition.isActiveAndEnabled || !composition.IsReady || readiness == null || !readiness.IsReady ||
                !ReferenceEquals(readiness.Owner, composition) || !ReferenceEquals(readiness.Application, application) ||
                !ReferenceEquals(run, application.ActiveRun) || run == null || run.Route == null ||
                run.Route.GenerationVersion != 2 || transitions == null ||
                !ReferenceEquals(transitions, composition.RoomTransitions))
                throw new InvalidOperationException("The E1 composition must be ready for its exact active F10 run.");

            ExpeditionSaveData activeSave = application.ActiveExpedition;
            if (activeSave == null || !string.Equals(activeSave.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                activeSave.generationVersion != 2 ||
                !string.Equals(activeSave.currentNodeId, ExplorationNodeId, StringComparison.Ordinal) ||
                activeSave.visitedNodeIds == null || activeSave.visitedNodeIds.Length == 0 ||
                !string.Equals(activeSave.visitedNodeIds[activeSave.visitedNodeIds.Length - 1],
                    ExplorationNodeId, StringComparison.Ordinal) ||
                !string.Equals(transitions.CurrentNodeId, ExplorationNodeId, StringComparison.Ordinal) ||
                transitions.CurrentRoomId != application.ActiveRoomInstanceId ||
                application.HasPendingSessionMutation || application.HasPendingRoomAdvance ||
                application.IsRoomAdvanceInFlight)
                throw new InvalidOperationException("The saved and active route cursor must still be the ready F10 E1 room.");

            ExpeditionRouteNode[] explorationNodes = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, ExplorationNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteNode[] guardianNodes = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, GuardianNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, ExplorationNodeId, StringComparison.Ordinal)).ToArray();
            if (explorationNodes.Length != 1 || explorationNodes[0].Kind != ExpeditionRouteNodeKind.Exploration ||
                !string.Equals(explorationNodes[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(explorationNodes[0].TemplateId, ExplorationTemplateId, StringComparison.Ordinal) ||
                guardianNodes.Length != 1 || guardianNodes[0].Kind != ExpeditionRouteNodeKind.Guardian ||
                !string.Equals(guardianNodes[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(guardianNodes[0].TemplateId, GuardianTemplateId, StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, GuardianNodeId, StringComparison.Ordinal))
                throw new InvalidOperationException("The owned F10 route must have the exact Patio E1-to-Guardian edge.");

            ExpeditionReadinessTransitionView transition = transitions.CaptureReadinessTransitionView();
            ExpeditionSessionReadinessRegistration registration = readiness.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null ? null : registration.CurrentActivation;
            if (transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !string.Equals(transition.ActiveNodeId, ExplorationNodeId, StringComparison.Ordinal) ||
                !string.Equals(transition.ActiveTemplateId, ExplorationTemplateId, StringComparison.Ordinal) ||
                transition.ActiveScope == null || !ReferenceEquals(transition.ActiveScope, transitions.ActiveScope) ||
                !ReferenceEquals(transition.ActiveRoomRoot, transition.ActiveScope.gameObject) ||
                registration == null || registration.IsDisposed || !registration.IsOwnerActive ||
                !ReferenceEquals(registration.Owner, composition) ||
                activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, transition.ActiveScope) ||
                !ReferenceEquals(activation.Controller, transitions) ||
                activation.RunId != run.RunId ||
                activation.BoundRun == null || activation.BoundRun.RunId != run.RunId ||
                activation.BoundRun.Route == null ||
                activation.BoundRun.Route.GenerationVersion != run.Route.GenerationVersion ||
                !string.Equals(activation.NodeId, ExplorationNodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, ExplorationTemplateId, StringComparison.Ordinal) ||
                activation.RoomInstanceId != application.ActiveRoomInstanceId ||
                readiness.PlayerMotor == null || !ReferenceEquals(readiness.PlayerMotor, composition.PlayerMotor) ||
                readiness.PlayerObject == null || !ReferenceEquals(readiness.PlayerObject, readiness.PlayerMotor.gameObject) ||
                readiness.PlayerObject.GetComponent<Rigidbody2D>() == null ||
                readiness.PlayerObject.GetComponent<Collider2D>() == null || !readiness.PlayerMotor.ActorId.IsValid)
                throw new InvalidOperationException("Readiness must own the exact Bound E1 activation and live player actor.");

            return new AttachmentView(registration, run, transition.ActiveScope,
                readiness.PlayerMotor, readiness.PlayerObject.GetComponent<Collider2D>());
        }

        private void TryAttachRoomBindings(AttachmentView attachment = null)
        {
            try
            {
                attachment = attachment ?? ValidateAttachment(_application, _composition);
                if (!ReferenceEquals(attachment.Registration, _registration) ||
                    !ReferenceEquals(attachment.Scope, _scope) || !ReferenceEquals(attachment.Player, _player) ||
                    !ReferenceEquals(attachment.PlayerCollider, _playerCollider) || attachment.Run.RunId != _runId)
                    throw new InvalidOperationException("The current F10 E1 activation differs from this scope-owned coordinator.");

                ExpeditionReadinessCompositionView readiness = _composition == null
                    ? null
                    : _composition.CaptureReadinessCompositionView();
                ExpeditionRoomActivationRegistration activation = _registration == null
                    ? null
                    : _registration.CurrentActivation;
                if (readiness == null || !readiness.IsReady || activation == null ||
                    activation.State != ExpeditionRoomActivationState.Bound)
                    throw new InvalidOperationException("The exact ready F10 E1 activation is no longer available for setup.");

                EnsureSingleContextAndSource(readiness, activation);
                if (_objectiveDriver == null)
                {
                    _objectiveDriver = F10ObjectiveSetupDemo.Attach(_context, _snapshotSource,
                        _playerCollider, this);
                }

                if (_cacheBinding == null)
                {
                    _cacheBinding = F10ExplorationGoldCacheBinding2D.Attach(_application,
                        _composition, _context, _inactiveCachePrefab);
                }

                _state = _acceptedObservation == null
                    ? F10ExplorationAdvanceState.WaitingForExplorationExit
                    : IsCacheSettlementPending()
                        ? F10ExplorationAdvanceState.WaitingForCacheSettlement
                        : F10ExplorationAdvanceState.WaitingForSessionMutation;
                _error = string.Empty;
            }
            catch (Exception exception)
            {
                _state = F10ExplorationAdvanceState.SetupFailed;
                _error = exception.Message;
            }
        }

        private void EnsureSingleContextAndSource(ExpeditionReadinessCompositionView readiness,
            ExpeditionRoomActivationRegistration activation)
        {
            if (activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, _scope) || !ReferenceEquals(activation.Controller, _composition.RoomTransitions))
                throw new InvalidOperationException("The E1 activation registration is no longer Bound to its active scope.");

            if (_context == null)
            {
                RoomEncounterRuntimeContext registeredContext = activation.Context;
                if (registeredContext != null)
                {
                    if (registeredContext.Plan != null || !IsExactExplorationContext(registeredContext,
                        activation, readiness, _application))
                        throw new InvalidOperationException("This E1 activation already owns a different encounter context.");
                    _context = registeredContext;
                }
                else
                {
                    if (activation.Source != null)
                        throw new InvalidOperationException("The E1 activation has a source without its exact context.");
                    _context = RoomEncounterRuntimeContext.Create(_runId, ExplorationNodeId,
                        ExplorationTemplateId, activation.RoomInstanceId, activation.Scope,
                        activation.Controller, readiness.PlayerMotor, plan: null,
                        routeGenerationVersion: _registration.RouteGenerationVersion);
                }
            }

            if (!IsExactExplorationContext(_context, activation, readiness, _application) || _context.Plan != null)
                throw new InvalidOperationException("The one E1 context must match the exact activation and use Plan == null.");
            _snapshotSource = _registration.CreateSnapshotSource(_context);
            if (_snapshotSource == null || !ReferenceEquals(activation.Context, _context) ||
                !ReferenceEquals(activation.Source, _snapshotSource))
                throw new InvalidOperationException("The readiness registration did not return its exact E1-owned snapshot source.");
        }

        private bool IsCacheSettlementPending()
        {
            return _cacheBinding != null && (_cacheBinding.IsRequestInFlight || _cacheBinding.HasRetainedContact ||
                (_cacheBinding.Pickup != null && _cacheBinding.Pickup.HasPendingContact));
        }

        private async Task RetryPendingCacheAsync()
        {
            if (_cacheRetryInProgress || _cacheBinding == null || !_cacheBinding.CanRetry) return;
            _cacheRetryInProgress = true;
            _state = F10ExplorationAdvanceState.WaitingForCacheSettlement;
            _cacheRetryTask = RetryCacheContactAsync();
            await _cacheRetryTask;
        }

        private async Task RetryCacheContactAsync()
        {
            try
            {
                F10ExplorationGoldCacheBinding2D binding = _cacheBinding;
                var result = await binding.RetryAsync();
                if (IsCacheSettlementPending())
                {
                    _state = F10ExplorationAdvanceState.WaitingForCacheSettlement;
                    _error = result == null ? "The exact cache contact is still pending." : result.Message;
                    return;
                }

                _state = F10ExplorationAdvanceState.WaitingForExplorationExit;
                _error = string.Empty;
            }
            catch (Exception exception)
            {
                _state = IsCacheSettlementPending()
                    ? F10ExplorationAdvanceState.WaitingForCacheSettlement
                    : F10ExplorationAdvanceState.WaitingForExplorationExit;
                _error = exception.Message;
            }
            finally
            {
                _cacheRetryInProgress = false;
            }
        }

        private Task StartAdvanceAttempt(bool alreadyAdmittedByHandoff = false)
        {
            if (_attemptInProgress) return _attemptTask ?? Task.CompletedTask;
            bool retryPending = _retryExactPendingAdvance;
            if (retryPending && (_application == null || !_application.HasPendingRoomAdvance))
            {
                if (TryReconcileSavedActivation()) return Task.CompletedTask;
                _retryExactPendingAdvance = false;
                _state = F10ExplorationAdvanceState.Failed;
                _error = "The retained exploration request has no PendingRoomAdvance to retry.";
                return Task.CompletedTask;
            }
            if (!retryPending && (!alreadyAdmittedByHandoff || _acceptedObservation == null ||
                !CanStartFreshExplorationAttempt(_attemptInProgress, _advanceAttemptStarted,
                    _hadPendingRoomAdvance, _persistedConfirmed)))
            {
                return Task.CompletedTask;
            }

            if (!retryPending) _advanceAttemptStarted = true;
            _attemptInProgress = true;
            _state = F10ExplorationAdvanceState.Resolving;
            _error = string.Empty;
            _attemptTask = retryPending ? RetryPendingAdvanceAsync() : CompleteCapturedExplorationAsync();
            return _attemptTask;
        }

        private bool CanStartAdvance(out F10ExplorationAdvanceState blockedState, out string blockedReason)
        {
            blockedState = F10ExplorationAdvanceState.Failed;
            blockedReason = string.Empty;
            if (_cacheBinding != null && (_cacheBinding.IsRequestInFlight || _cacheBinding.HasRetainedContact ||
                (_cacheBinding.Pickup != null && _cacheBinding.Pickup.HasPendingContact)))
            {
                blockedState = F10ExplorationAdvanceState.WaitingForCacheSettlement;
                blockedReason = "The optional physical cache still owns a pending contact or request; E1 cannot change rooms yet.";
                return false;
            }

            if (_retryExactPendingAdvance)
            {
                if (_application == null || !_application.HasPendingRoomAdvance)
                {
                    blockedReason = "The exact pending room advance is no longer available for retry.";
                    return false;
                }
                return true;
            }

            if (!IsCurrentExplorationActivation())
            {
                blockedReason = "The exact F10 E1 activation is no longer current.";
                return false;
            }

            if (_application.HasPendingRoomAdvance || _application.IsRoomAdvanceInFlight ||
                _application.HasPendingSessionMutation)
            {
                blockedState = F10ExplorationAdvanceState.WaitingForSessionMutation;
                blockedReason = "Another durable session mutation is active; retain the exit fact and retry after it settles.";
                return false;
            }

            return true;
        }

        internal static bool CanAcknowledgeExplorationObservation(bool attemptInProgress,
            bool exactPendingRoomAdvance, bool durableCommitConfirmed)
        {
            return !attemptInProgress && (exactPendingRoomAdvance || durableCommitConfirmed);
        }

        internal static bool CanStartFreshExplorationAttempt(bool attemptInProgress,
            bool requestAlreadyStarted, bool applicationPreviouslyOwnedPendingAdvance,
            bool durableCommitConfirmed)
        {
            return !attemptInProgress && !requestAlreadyStarted &&
                !applicationPreviouslyOwnedPendingAdvance && !durableCommitConfirmed;
        }

        private async Task CompleteCapturedExplorationAsync()
        {
            try
            {
                ApplicationBootstrapper application = _application;
                ExpeditionGameplayComposition composition = _composition;
                F10ObjectiveDriver2D driver = _objectiveDriver;
                IF10ObjectiveObservationHandoff handoff = this;
                F10ObjectiveObservation observation = _acceptedObservation;
                if (application == null || composition == null || driver == null || observation == null ||
                    !driver.IsDeliveringTo(handoff, observation))
                    throw new InvalidOperationException("The F10 E1 advance API can only run inside the exact driver handoff.");

                var outcome = await application.CompleteAndAdvanceF10ExplorationAsync(
                    composition, driver, handoff, observation);
                _lastOutcome = outcome;
                ApplyAdvanceOutcome(outcome != null && outcome.Persisted,
                    outcome != null && outcome.Pending,
                    outcome != null && outcome.Activated,
                    outcome == null ? "The F10 exploration advance API returned no outcome." : outcome.Message);
            }
            catch (Exception exception)
            {
                _retryExactPendingAdvance = _application != null && _application.HasPendingRoomAdvance;
                _hadPendingRoomAdvance |= _retryExactPendingAdvance;
                _state = _retryExactPendingAdvance
                    ? F10ExplorationAdvanceState.PendingRetry
                    : F10ExplorationAdvanceState.Failed;
                _error = exception.Message;
            }
            finally
            {
                _attemptInProgress = false;
            }
        }

        private async Task RetryPendingAdvanceAsync()
        {
            try
            {
                // ApplicationBootstrapper retains the exact result, candidate inventory and prepared room lease.
                // Do not call the policy-bearing CompleteAndAdvance API a second time.
                var outcome = await _application.RetryPendingRoomAdvanceAsync();
                _lastOutcome = outcome;
                ApplyAdvanceOutcome(outcome != null && outcome.Persisted,
                    outcome != null && outcome.Pending,
                    outcome != null && outcome.Activated,
                    outcome == null ? "The pending room advance retry returned no outcome." : outcome.Message);
            }
            catch (Exception exception)
            {
                _retryExactPendingAdvance = _application != null && _application.HasPendingRoomAdvance;
                _hadPendingRoomAdvance |= _retryExactPendingAdvance;
                _state = _retryExactPendingAdvance
                    ? F10ExplorationAdvanceState.PendingRetry
                    : F10ExplorationAdvanceState.Failed;
                _error = exception.Message;
            }
            finally
            {
                _attemptInProgress = false;
            }
        }

        private void ApplyAdvanceOutcome(bool persisted, bool pending, bool activated, string message)
        {
            _persistedConfirmed |= persisted;
            _activatedConfirmed |= activated;
            _retryExactPendingAdvance = _application != null && _application.HasPendingRoomAdvance;
            _hadPendingRoomAdvance |= _retryExactPendingAdvance;
            if (TryReconcileSavedActivation()) return;

            if (_retryExactPendingAdvance)
            {
                _state = F10ExplorationAdvanceState.PendingRetry;
                _error = message ?? string.Empty;
                return;
            }

            if (pending)
            {
                _state = F10ExplorationAdvanceState.Failed;
                _error = "The advance reported a pending result without an exact PendingRoomAdvance to retry.";
                return;
            }

            _state = F10ExplorationAdvanceState.Failed;
            _error = !string.IsNullOrEmpty(message)
                ? message
                : persisted
                    ? "E1 was durably completed, but the exact Guardian activation was not confirmed."
                    : "The F10 E1 result was not durably committed.";
        }

        private bool TryReconcileSavedActivation()
        {
            if (!_persistedConfirmed || _application == null || _composition == null || _registration == null)
                return false;

            ExpeditionRunConfiguration activeRun = _application.ActiveRun;
            ExpeditionSaveData saved = _application.ActiveExpedition;
            ExpeditionRoomTransitionController transitions = _composition.RoomTransitions;
            ExpeditionReadinessCompositionView readiness = _composition.CaptureReadinessCompositionView();
            ExpeditionSessionReadinessRegistration registration = readiness == null
                ? null
                : readiness.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null
                ? null
                : registration.CurrentActivation;
            bool exactSavedGuardian = activeRun != null && activeRun.RunId == _runId && saved != null &&
                string.Equals(saved.runId, _runId.ToString(), StringComparison.Ordinal) &&
                string.Equals(saved.currentNodeId, GuardianNodeId, StringComparison.Ordinal) &&
                saved.visitedNodeIds != null && saved.visitedNodeIds.Length >= 2 &&
                string.Equals(saved.visitedNodeIds[saved.visitedNodeIds.Length - 2], ExplorationNodeId, StringComparison.Ordinal) &&
                string.Equals(saved.visitedNodeIds[saved.visitedNodeIds.Length - 1], GuardianNodeId, StringComparison.Ordinal);
            bool exactActiveGuardian = _composition.isActiveAndEnabled && _composition.IsReady && readiness != null &&
                readiness.IsReady && ReferenceEquals(readiness.Owner, _composition) &&
                ReferenceEquals(readiness.Application, _application) && ReferenceEquals(readiness.Run, activeRun) &&
                ReferenceEquals(registration, _registration) && transitions != null &&
                ReferenceEquals(readiness.RoomTransitions, transitions) &&
                string.Equals(transitions.CurrentNodeId, GuardianNodeId, StringComparison.Ordinal) &&
                transitions.CurrentRoomId == ExpeditionRoomIdentity.ForNode(_runId, GuardianNodeId) &&
                _application.ActiveRoomInstanceId == transitions.CurrentRoomId &&
                activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Scope, transitions.ActiveScope) &&
                ReferenceEquals(activation.Controller, transitions) && activation.RunId == _runId &&
                activation.BoundRun != null && activation.BoundRun.RunId == activeRun.RunId &&
                string.Equals(activation.NodeId, GuardianNodeId, StringComparison.Ordinal) &&
                string.Equals(activation.TemplateId, GuardianTemplateId, StringComparison.Ordinal);

            if (!exactSavedGuardian || !exactActiveGuardian || _application.HasPendingRoomAdvance ||
                _application.IsRoomAdvanceInFlight || _application.HasPendingSessionMutation)
                return false;

            _persistedConfirmed = true;
            _activatedConfirmed = true;
            _retryExactPendingAdvance = false;
            _state = F10ExplorationAdvanceState.Completed;
            _error = string.Empty;
            return true;
        }

        private bool IsCurrentExplorationActivation()
        {
            if (_application == null || _composition == null || _registration == null || _context == null ||
                _snapshotSource == null || _objectiveDriver == null || _scope == null || _player == null)
                return false;

            ExpeditionReadinessCompositionView readiness = _composition.CaptureReadinessCompositionView();
            ExpeditionRoomActivationRegistration activation = _registration.CurrentActivation;
            ExpeditionReadinessTransitionView transition = _composition.RoomTransitions == null
                ? null
                : _composition.RoomTransitions.CaptureReadinessTransitionView();
            return _composition.isActiveAndEnabled && _composition.IsReady && readiness != null && readiness.IsReady &&
                ReferenceEquals(ApplicationBootstrapper.Instance, _application) &&
                _application.OwnsF10DiagnosticRun(_application.ActiveRun) &&
                ReferenceEquals(readiness.Owner, _composition) && ReferenceEquals(readiness.Application, _application) &&
                ReferenceEquals(readiness.ReadinessRegistration, _registration) &&
                _player != null && ReferenceEquals(readiness.PlayerMotor, _player) &&
                ReferenceEquals(readiness.PlayerObject, _player.gameObject) &&
                ReferenceEquals(readiness.RoomTransitions, _composition.RoomTransitions) &&
                _registration.IsOwnerActive && activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Context, _context) && ReferenceEquals(activation.Source, _snapshotSource) &&
                ReferenceEquals(activation.Scope, _context.Scope) && ReferenceEquals(activation.Controller, _context.Controller) &&
                activation.RunId == _runId && activation.BoundRun != null &&
                readiness.Run != null && activation.BoundRun.RunId == readiness.Run.RunId &&
                string.Equals(activation.NodeId, ExplorationNodeId, StringComparison.Ordinal) &&
                string.Equals(activation.TemplateId, ExplorationTemplateId, StringComparison.Ordinal) &&
                transition != null && transition.IsInitialized && !transition.IsDisposed &&
                !transition.IsTransitioning && !transition.HasPreparedTransition &&
                ReferenceEquals(transition.ActiveScope, _scope) &&
                string.Equals(transition.ActiveNodeId, ExplorationNodeId, StringComparison.Ordinal) &&
                string.Equals(transition.ActiveTemplateId, ExplorationTemplateId, StringComparison.Ordinal) &&
                _context.Plan == null && _context.IsCurrentRoomScope() &&
                string.Equals(_application.ActiveExpedition?.currentNodeId, ExplorationNodeId, StringComparison.Ordinal) &&
                _application.ActiveRun != null && _application.ActiveRun.RunId == _runId &&
                _application.ActiveRoomInstanceId == _context.RoomInstanceId;
        }

        private static bool IsExactExplorationContext(RoomEncounterRuntimeContext context,
            ExpeditionRoomActivationRegistration activation, ExpeditionReadinessCompositionView readiness,
            ApplicationBootstrapper application)
        {
            return context != null && activation != null && readiness != null && application != null &&
                context.Plan == null && context.IsCurrentRoomScope() &&
                string.Equals(context.NodeId, ExplorationNodeId, StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, ExplorationTemplateId, StringComparison.Ordinal) &&
                context.RunId == activation.RunId && context.RoomInstanceId == activation.RoomInstanceId &&
                ReferenceEquals(context.Scope, activation.Scope) && ReferenceEquals(context.Controller, activation.Controller) &&
                ReferenceEquals(context.Player, readiness.PlayerMotor) &&
                activation.BoundRun != null && activation.BoundRun.Route != null &&
                context.RouteGenerationVersion == activation.BoundRun.Route.GenerationVersion &&
                application.ActiveRun != null && application.ActiveRun.RunId == context.RunId;
        }

        internal static bool IsExactExplorationObservationForContext(RoomEncounterRuntimeContext context,
            F10ObjectiveObservation observation)
        {
            return context != null && observation != null && context.Plan == null && context.IsCurrentRoomScope() &&
                string.Equals(context.NodeId, ExplorationNodeId, StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, ExplorationTemplateId, StringComparison.Ordinal) &&
                observation.Kind == F10ObjectiveObservationKind.ExplorationExitTouched &&
                observation.RunId == context.RunId && observation.RoomInstanceId == context.RoomInstanceId &&
                string.Equals(observation.NodeId, context.NodeId, StringComparison.Ordinal) &&
                string.Equals(observation.TemplateId, context.TemplateId, StringComparison.Ordinal) &&
                ReferenceEquals(observation.Scope, context.Scope) &&
                ReferenceEquals(observation.Controller, context.Controller) &&
                ReferenceEquals(observation.Player, context.Player) && context.Player != null &&
                context.Player.ActorId.IsValid && observation.ActorId == context.Player.ActorId &&
                observation.ActivationGeneration == context.ActivationGeneration && observation.Tick >= 0 &&
                !string.IsNullOrWhiteSpace(observation.ObservationId);
        }

        private void Update()
        {
            if (_state == F10ExplorationAdvanceState.Completed) return;
            TryReconcileSavedActivation();
        }

        private void OnDestroy()
        {
            _objectiveDriver = null;
            _cacheBinding = null;
            _snapshotSource = null;
            _context = null;
            _acceptedObservation = null;
            _scope = null;
        }

        private sealed class AttachmentView
        {
            internal AttachmentView(ExpeditionSessionReadinessRegistration registration,
                ExpeditionRunConfiguration run, RoomLifetimeScope scope, PlayerMotor2D player,
                Collider2D playerCollider)
            {
                Registration = registration;
                Run = run;
                Scope = scope;
                Player = player;
                PlayerCollider = playerCollider;
            }

            internal ExpeditionSessionReadinessRegistration Registration { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal RoomLifetimeScope Scope { get; }
            internal PlayerMotor2D Player { get; }
            internal Collider2D PlayerCollider { get; }
        }
    }
}
#endif
