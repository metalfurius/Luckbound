#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Crafting;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Fortune;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Pacts;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Rooms;
using Luckbound.Gameplay.Enemies;
using UnityEngine;

namespace Luckbound.App
{
    public sealed partial class ApplicationBootstrapper
    {
        private const string F10RoomExplorationNodeId = "sample.patio.exploration";
        private const string F10RoomExplorationTemplateId = "room.patio.e1";
        private const string F10RoomExtractionNodeId = "sample.safe_extraction";
        private const string F10RoomExtractionTemplateId = "room.sample.extraction";
        private const string F10RoomC08EncounterId = "encounter.c08_arena";
        private const string F10RoomGuardianBossId = "boss.custodian_of_the_oaks";
        private const string F10RoomGuardianSpawnId = "boss.custodian";
        private const float F10RoomMarkerTolerance = 0.001f;

        private enum F10TechnicalRoomPaymentKind
        {
            Combat,
            Exploration,
            Guardian
        }

        /// <summary>
        /// Private, immutable capability minted only after an exact F10 room observation is checked. It carries
        /// the event and policy context, never caller-provided amounts, grant IDs, route targets, or callbacks.
        /// </summary>
        private sealed class F10TechnicalRoomPayment
        {
            internal F10TechnicalRoomPayment(F10TechnicalRoomPaymentKind kind,
                ExpeditionGameplayComposition owner, ExpeditionRunConfiguration run,
                ExpeditionSaveData saveAtCapture, string saveJson, long expectedRevision,
                string expectedInventoryJson, ExpeditionRoomTransitionController controller,
                RoomEncounterRuntimeContext context, ExpeditionRouteNode sourceNode,
                string targetNodeId, string resultId, string resultJson,
                ExpeditionEncounterRewardRequest rewardRequest, RoomEncounterRuntime runtime,
                RoomEncounterClearObservation clearObservation, F10ObjectiveDriver2D driver,
                IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation exitObservation)
            {
                Kind = kind;
                Owner = owner;
                Run = run;
                SaveJson = saveJson;
                ExpectedRevision = expectedRevision;
                ExpectedInventoryJson = expectedInventoryJson;
                Controller = controller;
                Context = context;
                SourceNode = sourceNode;
                SourceRoomId = context.RoomInstanceId;
                SourceNodeId = sourceNode.NodeId;
                TargetNodeId = targetNodeId;
                ResultId = resultId;
                ResultJson = resultJson;
                RewardRequest = rewardRequest;
                Runtime = runtime;
                ClearObservation = clearObservation;
                GuardianCoordinator = kind == F10TechnicalRoomPaymentKind.Guardian && context != null && context.Scope != null
                    ? context.Scope.GetComponent<F10GuardianRuntimeCoordinator>()
                    : null;
                Driver = driver;
                Handoff = handoff;
                ExitObservation = exitObservation;
            }

            internal F10TechnicalRoomPaymentKind Kind { get; }
            internal ExpeditionGameplayComposition Owner { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal string SaveJson { get; }
            internal long ExpectedRevision { get; }
            internal string ExpectedInventoryJson { get; }
            internal ExpeditionRoomTransitionController Controller { get; }
            internal RoomEncounterRuntimeContext Context { get; }
            internal ExpeditionRouteNode SourceNode { get; }
            internal RoomInstanceId SourceRoomId { get; }
            internal string SourceNodeId { get; }
            internal string TargetNodeId { get; }
            internal string ResultId { get; }
            internal string ResultJson { get; }
            internal ExpeditionEncounterRewardRequest RewardRequest { get; }
            internal RoomEncounterRuntime Runtime { get; }
            internal RoomEncounterClearObservation ClearObservation { get; }
            internal F10GuardianRuntimeCoordinator GuardianCoordinator { get; }
            internal F10ObjectiveDriver2D Driver { get; }
            internal IF10ObjectiveObservationHandoff Handoff { get; }
            internal F10ObjectiveObservation ExitObservation { get; }
        }

        /// <summary>Advances the exact F10 C1 clear to E1 and pays its deterministic room/enemy gold and Renown.</summary>
        internal Task<RoomAdvanceCommitResult> CompleteAndAdvanceF10CombatAsync(
            ExpeditionGameplayComposition owner, RoomEncounterRuntime runtime,
            RoomEncounterClearObservation clearObservation)
        {
            return StartF10TechnicalRoomAdvance(owner, F10TechnicalRoomPaymentKind.Combat,
                runtime, clearObservation, null, null, null);
        }

        /// <summary>Advances the exact E1 exit observation to the Guardian and pays only the room Renown.</summary>
        internal Task<RoomAdvanceCommitResult> CompleteAndAdvanceF10ExplorationAsync(
            ExpeditionGameplayComposition owner, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation exitObservation)
        {
            return StartF10TechnicalRoomAdvance(owner, F10TechnicalRoomPaymentKind.Exploration,
                null, null, driver, handoff, exitObservation);
        }

        /// <summary>Advances the exact physical F10 Custodian clear to safe extraction and pays its policy rewards.</summary>
        internal Task<RoomAdvanceCommitResult> CompleteAndAdvanceF10GuardianAsync(
            ExpeditionGameplayComposition owner, RoomEncounterRuntime runtime,
            RoomEncounterClearObservation clearObservation)
        {
            return StartF10TechnicalRoomAdvance(owner, F10TechnicalRoomPaymentKind.Guardian,
                runtime, clearObservation, null, null, null);
        }

        private Task<RoomAdvanceCommitResult> StartF10TechnicalRoomAdvance(
            ExpeditionGameplayComposition owner, F10TechnicalRoomPaymentKind kind,
            RoomEncounterRuntime runtime, RoomEncounterClearObservation clearObservation,
            F10ObjectiveDriver2D driver, IF10ObjectiveObservationHandoff handoff,
            F10ObjectiveObservation exitObservation)
        {
            if (!TryCaptureF10RoomAdvanceContext(owner, kind, runtime, clearObservation,
                    driver, handoff, exitObservation, out ExpeditionRunConfiguration run,
                    out ExpeditionSaveData save, out ExpeditionRoomTransitionController controller,
                    out RoomEncounterRuntimeContext context, out ExpeditionRouteNode sourceNode,
                    out string targetNodeId, out ExpeditionEncounterRewardRequest request,
                    out string error))
                return Task.FromResult(RoomAdvanceCommitResult.Failure(false, error));

            if (!TryAcquireRoomAdvanceSimulationPauseLease(out IDisposable pauseLease, out string pauseError))
                return Task.FromResult(RoomAdvanceCommitResult.Failure(false, pauseError));

            try
            {
                // Recheck the same witness after the real pause lease; the core rechecks it again under its gate.
                if (!TryCaptureF10RoomAdvanceContext(owner, kind, runtime, clearObservation,
                        driver, handoff, exitObservation, out ExpeditionRunConfiguration pausedRun,
                        out ExpeditionSaveData pausedSave, out ExpeditionRoomTransitionController pausedController,
                        out RoomEncounterRuntimeContext pausedContext, out ExpeditionRouteNode pausedNode,
                        out string pausedTarget, out ExpeditionEncounterRewardRequest pausedRequest,
                        out error) || !ReferenceEquals(run, pausedRun) || !ReferenceEquals(controller, pausedController) ||
                    !ReferenceEquals(context, pausedContext) || !ReferenceEquals(sourceNode, pausedNode) ||
                    !string.Equals(targetNodeId, pausedTarget, StringComparison.Ordinal) ||
                    !RewardRequestsMatch(request, pausedRequest) ||
                    !string.Equals(JsonUtility.ToJson(save), JsonUtility.ToJson(pausedSave), StringComparison.Ordinal))
                {
                    pauseLease.Dispose();
                    return Task.FromResult(RoomAdvanceCommitResult.Failure(false,
                        string.IsNullOrEmpty(error) ? "The F10 room witness changed while acquiring its pause lease." : error));
                }

                save = pausedSave;
                request = pausedRequest;

                long expectedRevision = ActiveExpeditionRevision;
                ExpeditionInventory currentInventory = ActiveRun == null ? null : ActiveRun.Inventory;
                if (currentInventory == null)
                {
                    pauseLease.Dispose();
                    return Task.FromResult(RoomAdvanceCommitResult.Failure(false,
                        "The F10 technical run has no active expedition inventory."));
                }
                string expectedInventoryJson = JsonUtility.ToJson(currentInventory.CreateSnapshot());
                string resultId = "room-result.v1:" + context.RoomInstanceId;
                string resultJson = SerializeF10RoomResult(context.RoomInstanceId,
                    sourceNode.NodeId, targetNodeId);
                var payment = new F10TechnicalRoomPayment(kind, owner, run, save,
                    JsonUtility.ToJson(save), expectedRevision, expectedInventoryJson,
                    controller, context, sourceNode, targetNodeId, resultId, resultJson,
                    request, runtime, clearObservation, driver, handoff, exitObservation);
                ExpeditionInventory candidateInventory = ExpeditionInventory.Restore(
                    currentInventory.Catalog, currentInventory.CreateSnapshot());

                return TrackRoomAdvanceInFlight(() => CompleteAndAdvanceRoomCoreAsync(
                    controller, context.RoomInstanceId, targetNodeId, resultId, resultJson,
                    candidateInventory, expectedInventoryJson, expectedRevision,
                    CancellationToken.None, pauseLease, payment));
            }
            catch
            {
                pauseLease?.Dispose();
                throw;
            }
        }

        private bool TryCaptureF10RoomAdvanceContext(ExpeditionGameplayComposition owner,
            F10TechnicalRoomPaymentKind kind, RoomEncounterRuntime runtime,
            RoomEncounterClearObservation clearObservation, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation exitObservation,
            out ExpeditionRunConfiguration run, out ExpeditionSaveData save,
            out ExpeditionRoomTransitionController controller, out RoomEncounterRuntimeContext context,
            out ExpeditionRouteNode sourceNode, out string targetNodeId,
            out ExpeditionEncounterRewardRequest rewardRequest, out string error)
        {
            run = null;
            save = null;
            controller = null;
            context = null;
            sourceNode = null;
            targetNodeId = null;
            rewardRequest = null;
            error = string.Empty;

            if (!TryValidateF10TechnicalOwner(owner, out ExpeditionReadinessCompositionView view,
                    out ExpeditionRoomActivationRegistration activation, out error)) return false;
            run = ActiveRun;
            save = ActiveExpedition;
            controller = owner.RoomTransitions;
            context = activation.Context;
            if (!TryValidateF10RunAndRoute(run, save, context, controller,
                    out sourceNode, out targetNodeId, out error)) return false;

            if (kind == F10TechnicalRoomPaymentKind.Combat)
            {
                if (runtime == null || clearObservation == null ||
                    !ReferenceEquals(runtime.LastClearObservation, clearObservation) ||
                    !TryValidateF10CombatClear(run, context, runtime, clearObservation, out error))
                    return FailF10RoomAdvance("The C1 completion requires this runtime's exact complete physical clear observation.", out error);
                if (!TryBuildF10CombatRewardRequest(run, save, sourceNode, context,
                        runtime, clearObservation, out rewardRequest, out error)) return false;
            }
            else if (kind == F10TechnicalRoomPaymentKind.Guardian)
            {
                F10GuardianRuntimeCoordinator guardianCoordinator = context.Scope == null
                    ? null
                    : context.Scope.GetComponent<F10GuardianRuntimeCoordinator>();
                if (!TryValidateF10GuardianClear(run, context, runtime, clearObservation,
                        guardianCoordinator, out error))
                    return FailF10RoomAdvance("Guardian completion requires the exact current physical Custodian clear and wall witness.", out error);
                if (!TryBuildF10GuardianRewardRequest(run, save, sourceNode, context,
                        clearObservation, out rewardRequest, out error)) return false;
            }
            else
            {
                if (driver == null || handoff == null || exitObservation == null ||
                    !driver.IsDeliveringTo(handoff, exitObservation) ||
                    !TryValidateF10ExplorationExit(run, context, driver, handoff, exitObservation, out error))
                    return FailF10RoomAdvance("E1 completion requires its exact exit observation while being delivered to the bound handoff.", out error);
                if (!TryValidateF10ExplorationRoomContent(context.Scope, out string cacheError))
                    return FailF10RoomAdvance(cacheError, out error);
                if (!TryBuildF10ExplorationRewardRequest(run, save, sourceNode,
                        out rewardRequest, out error)) return false;
            }

            return true;
        }

        private bool TryValidateF10TechnicalOwner(ExpeditionGameplayComposition owner,
            out ExpeditionReadinessCompositionView view,
            out ExpeditionRoomActivationRegistration activation, out string error)
        {
            view = null;
            activation = null;
            error = string.Empty;
            ExpeditionRunConfiguration run = ActiveRun;
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, this) ||
                owner == null || !owner.isActiveAndEnabled || !owner.IsReady || !OwnsF10DiagnosticRun(run) ||
                !ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, owner) ||
                !ReferenceEquals(_expeditionSessionMutationPublicationOwner, owner) ||
                _expeditionSessionStateCapture == null || _expeditionSessionMutationPreparer == null ||
                _expeditionSimulationPauseLeaseProvider == null || !CanContinueExpedition ||
                HasPendingExpeditionWrite || HasPendingSettlement || HasPendingContractProgression ||
                HasPendingCraftingWrite || HasPendingEconomyMutation || HasPendingPermanentUpgradePurchase ||
                HasPendingRoomAdvance)
                return FailF10RoomAdvance("Room payment requires the exact ready owner of the isolated F10 run and a clear profile mutation lane.", out error);

            view = owner.CaptureReadinessCompositionView();
            ExpeditionRoomTransitionController controller = owner.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = view == null ? null : view.ReadinessRegistration;
            activation = registration == null ? null : registration.CurrentActivation;
            if (view == null || !view.IsReady || !ReferenceEquals(view.Owner, owner) ||
                !ReferenceEquals(view.Application, this) || !ReferenceEquals(view.Run, run) ||
                view.PlayerMotor == null || !ReferenceEquals(view.PlayerMotor, owner.PlayerMotor) ||
                view.PlayerObject == null || !ReferenceEquals(view.PlayerObject, view.PlayerMotor.gameObject) ||
                controller == null || !ReferenceEquals(view.RoomTransitions, controller) ||
                controller.IsDisposed || activation == null || !registration.IsCurrentActivation(activation) ||
                activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Controller, controller) ||
                activation.BoundRun == null || activation.Services == null ||
                !ReferenceEquals(activation.BoundRun, activation.Services.Run) ||
                activation.BoundRun.RunId != run.RunId || activation.BoundRun.Seed != run.Seed ||
                activation.BoundRun.Route == null ||
                !string.Equals(activation.BoundRun.Route.CanonicalForm, run.Route.CanonicalForm, StringComparison.Ordinal) ||
                !ReferenceEquals(activation.PlayerMotor, view.PlayerMotor) ||
                activation.Context == null || activation.Source == null ||
                !ReferenceEquals(activation.Scope, controller.ActiveScope) ||
                !activation.Context.IsCurrentRoomScope())
                return FailF10RoomAdvance("The current F10 readiness owner, actor, room activation, or controller binding is stale.", out error);

            return true;
        }

        private static bool TryValidateF10RunAndRoute(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, RoomEncounterRuntimeContext context,
            ExpeditionRoomTransitionController controller, out ExpeditionRouteNode sourceNode,
            out string targetNodeId, out string error)
        {
            sourceNode = null;
            targetNodeId = null;
            error = string.Empty;
            if (run == null || save == null || context == null || controller == null || run.Route == null ||
                run.Route.GenerationVersion != 2 || run.Route.GenerationVersion != context.RouteGenerationVersion ||
                run.Seed != run.Route.Seed || !string.Equals(save.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                save.seed != run.Seed || save.generationVersion != run.Route.GenerationVersion ||
                !string.Equals(save.routeSnapshotJson, run.Route.CanonicalForm, StringComparison.Ordinal) ||
                save.pactIds == null || save.claimedRewardIds == null || save.completedRoomIds == null ||
                save.visitedNodeIds == null || save.pactIds.Any(string.IsNullOrWhiteSpace) ||
                save.claimedRewardIds.Any(string.IsNullOrWhiteSpace) ||
                save.claimedRewardIds.Distinct(StringComparer.Ordinal).Count() != save.claimedRewardIds.Length ||
                save.pactIds.Distinct(StringComparer.Ordinal).Count() != save.pactIds.Length ||
                save.pactIds.Any(pactId => !PactIds.IsKnown(pactId)) || save.accumulatedRenown < 0)
                return FailF10RoomAdvance("The F10 run or saved route/pact/reward context is invalid.", out error);

            string expectedTarget;
            string expectedTemplate;
            ExpeditionRouteNodeKind expectedKind;
            int expectedPathIndex;
            if (string.Equals(save.currentNodeId, F10TechnicalEncounterPlanProvider.C1NodeId, StringComparison.Ordinal))
            {
                expectedTarget = F10RoomExplorationNodeId;
                expectedTemplate = F10TechnicalEncounterPlanProvider.C1TemplateId;
                expectedKind = ExpeditionRouteNodeKind.Combat;
                expectedPathIndex = 1;
            }
            else if (string.Equals(save.currentNodeId, F10RoomExplorationNodeId, StringComparison.Ordinal))
            {
                expectedTarget = F10TechnicalEncounterPlanProvider.GuardianNodeId;
                expectedTemplate = F10RoomExplorationTemplateId;
                expectedKind = ExpeditionRouteNodeKind.Exploration;
                expectedPathIndex = 2;
            }
            else if (string.Equals(save.currentNodeId, F10TechnicalEncounterPlanProvider.GuardianNodeId, StringComparison.Ordinal))
            {
                expectedTarget = F10RoomExtractionNodeId;
                expectedTemplate = F10TechnicalEncounterPlanProvider.GuardianTemplateId;
                expectedKind = ExpeditionRouteNodeKind.Guardian;
                expectedPathIndex = 3;
            }
            else return FailF10RoomAdvance("The F10 room-payment API only handles Patio C1, E1, or Guardian.", out error);

            ExpeditionRouteNode[] sources = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, save.currentNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteNode[] targets = run.Route.Nodes.Where(node => node != null &&
                string.Equals(node.NodeId, expectedTarget, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(edge => edge != null &&
                string.Equals(edge.FromNodeId, save.currentNodeId, StringComparison.Ordinal)).ToArray();
            if (sources.Length != 1 || targets.Length != 1 || outgoing.Length != 1 ||
                outgoing[0].IsOptionalBranch || !string.Equals(outgoing[0].ToNodeId, expectedTarget, StringComparison.Ordinal))
                return FailF10RoomAdvance("The saved F10 route must have exactly one non-optional C1→E1, E1→Guardian, or Guardian→extraction edge.", out error);

            sourceNode = sources[0];
            ExpeditionRouteNode target = targets[0];
            ExpeditionRouteNodeKind targetKind = expectedTarget == F10RoomExplorationNodeId
                ? ExpeditionRouteNodeKind.Exploration
                : expectedTarget == F10TechnicalEncounterPlanProvider.GuardianNodeId
                    ? ExpeditionRouteNodeKind.Guardian
                    : ExpeditionRouteNodeKind.SafeExtraction;
            string targetTemplate = expectedTarget == F10RoomExplorationNodeId
                ? F10RoomExplorationTemplateId
                : expectedTarget == F10TechnicalEncounterPlanProvider.GuardianNodeId
                    ? F10TechnicalEncounterPlanProvider.GuardianTemplateId
                    : F10RoomExtractionTemplateId;
            int targetPathIndex = expectedTarget == F10RoomExplorationNodeId ? 2
                : expectedTarget == F10TechnicalEncounterPlanProvider.GuardianNodeId ? 3 : 4;
            if (sourceNode.Kind != expectedKind || !sourceNode.IsMandatory || sourceNode.MainPathIndex != expectedPathIndex ||
                !string.Equals(sourceNode.TemplateId, expectedTemplate, StringComparison.Ordinal) ||
                !string.Equals(sourceNode.SectorId, "patio", StringComparison.Ordinal) ||
                target.Kind != targetKind || !target.IsMandatory || target.MainPathIndex != targetPathIndex ||
                !string.Equals(target.TemplateId, targetTemplate, StringComparison.Ordinal) ||
                !string.Equals(target.SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(context.NodeId, sourceNode.NodeId, StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, sourceNode.TemplateId, StringComparison.Ordinal) ||
                context.RoomInstanceId != ExpeditionRoomIdentity.ForNode(run.RunId, sourceNode.NodeId) ||
                context.Scope == null || context.Scope.RoomInstanceId != context.RoomInstanceId ||
                !string.Equals(context.Scope.TemplateId, context.TemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(context.Controller, controller) || !ReferenceEquals(controller.ActiveScope, context.Scope) ||
                !ReferenceEquals(controller.ActiveRoomRoot, context.Scope.gameObject) ||
                controller.CurrentRoomId != context.RoomInstanceId ||
                !string.Equals(controller.CurrentNodeId, sourceNode.NodeId, StringComparison.Ordinal) ||
                !string.Equals(save.currentNodeId, sourceNode.NodeId, StringComparison.Ordinal) ||
                !string.Equals(context.RunId.ToString(), run.RunId.ToString(), StringComparison.Ordinal) ||
                save.visitedNodeIds.Length == 0 ||
                !string.Equals(save.visitedNodeIds[save.visitedNodeIds.Length - 1], sourceNode.NodeId, StringComparison.Ordinal) ||
                save.completedRoomIds.Contains(sourceNode.NodeId, StringComparer.Ordinal))
                return FailF10RoomAdvance("The active and saved route cursor must identify the exact current F10 source and its fixed next node.", out error);

            targetNodeId = expectedTarget;
            return true;
        }

        private static bool TryValidateF10CombatClear(ExpeditionRunConfiguration run,
            RoomEncounterRuntimeContext context, RoomEncounterRuntime runtime,
            RoomEncounterClearObservation observation, out string error)
        {
            error = string.Empty;
            if (run == null || context == null || runtime == null || observation == null ||
                runtime.IsDisposed || runtime.Status != RoomEncounterRuntimeStatus.Cleared ||
                !runtime.ClearNotificationIssued || !ReferenceEquals(runtime.LastClearObservation, observation) ||
                !ReferenceEquals(observation.Scope, context.Scope) || observation.RunId != run.RunId ||
                observation.RoomInstanceId != context.RoomInstanceId ||
                observation.ActivationGeneration != context.ActivationGeneration ||
                !string.Equals(observation.NodeId, context.NodeId, StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, context.TemplateId, StringComparison.Ordinal) ||
                !context.IsCurrentRoomScope() || context.Plan == null || !context.Plan.HasOnlySupportedActors ||
                context.Plan.Roster == null || context.Plan.Roster.Waves.Count != 2 ||
                runtime.CompletedWaveCount != 2 || runtime.CurrentWaveNumber != 0 ||
                observation.Actors.Count != 4 || runtime.RegisteredBindings.Count != 4)
                return FailF10RoomAdvance("The C1 runtime did not publish a complete clear for its current physical roster.", out error);

            string[][] expectedSpawnIds =
            {
                new[] { "spawn.slime.01", "spawn.slime.02" },
                new[] { "spawn.huesoguardia.01", "spawn.huesoguardia.02" }
            };
            var bindings = runtime.RegisteredBindings.ToDictionary(binding => binding.SpawnKey, StringComparer.Ordinal);
            for (int waveIndex = 0; waveIndex < expectedSpawnIds.Length; waveIndex++)
            {
                ExpeditionEncounterWavePlan wave = context.Plan.Roster.Waves[waveIndex];
                if (wave == null || wave.WaveNumber != waveIndex + 1 || wave.SpawnKeys.Count != 2)
                    return FailF10RoomAdvance("The C1 roster is not the frozen two-wave C08 physical roster.", out error);

                for (int actorIndex = 0; actorIndex < expectedSpawnIds[waveIndex].Length; actorIndex++)
                {
                    string spawnId = expectedSpawnIds[waveIndex][actorIndex];
                    string expectedKey;
                    try
                    {
                        expectedKey = EncounterSpawnIdentityV1.Create(run.RunId,
                            checked((uint)run.Route.GenerationVersion), F10TechnicalEncounterPlanProvider.C1NodeId,
                            context.RoomInstanceId, F10RoomC08EncounterId, spawnId).Key;
                    }
                    catch (Exception exception)
                    {
                        return FailF10RoomAdvance("The C1 spawn identity could not be derived: " + exception.GetType().Name + ".", out error);
                    }
                    if (!string.Equals(wave.SpawnKeys[actorIndex], expectedKey, StringComparison.Ordinal) ||
                        !context.Plan.TryGetActor(expectedKey, out RoomEncounterActorDefinition actorDefinition) ||
                        actorDefinition == null || !actorDefinition.SupportsConcreteActorAdapter ||
                        !bindings.TryGetValue(expectedKey, out RoomEncounterActorBinding binding) ||
                        binding == null || !binding.IsDefeatAccepted || !binding.PhysicalDeathObserved ||
                        binding.Phase != RoomEncounterActorBindingPhase.DefeatAccepted ||
                        !binding.ActorIsDead || binding.ActorCurrentHealth > 0 ||
                        !ReferenceEquals(binding.Scope, context.Scope) ||
                        binding.Generation != context.ActivationGeneration ||
                        !ActorTypeMatchesF10C1Spawn(actorDefinition, binding, waveIndex))
                        return FailF10RoomAdvance("A planned C1 spawn is not the exact physical defeated actor owned by this room.", out error);

                    RoomEncounterDefeatedActorObservation[] matches = observation.Actors.Where(actor =>
                        string.Equals(actor.SpawnKey, expectedKey, StringComparison.Ordinal)).ToArray();
                    if (matches.Length != 1 || matches[0].WaveNumber != waveIndex + 1 ||
                        matches[0].ActorId != binding.ActorId || !matches[0].ActorId.IsValid ||
                        matches[0].CapturedSequence <= 0 || matches[0].ProcessedDrainSequence <= matches[0].CapturedSequence)
                        return FailF10RoomAdvance("The clear observation does not contain one accepted physical defeat for every C1 spawn.", out error);
                }
            }

            return true;
        }

        private static bool TryValidateF10GuardianClear(ExpeditionRunConfiguration run,
            RoomEncounterRuntimeContext context, RoomEncounterRuntime runtime,
            RoomEncounterClearObservation observation, F10GuardianRuntimeCoordinator coordinator,
            out string error)
        {
            error = string.Empty;
            if (run == null || context == null || runtime == null || observation == null || coordinator == null ||
                run.Route == null || !coordinator.isActiveAndEnabled ||
                runtime.IsDisposed || runtime.Status != RoomEncounterRuntimeStatus.Cleared ||
                !runtime.ClearNotificationIssued || !ReferenceEquals(runtime.LastClearObservation, observation) ||
                coordinator.IsDisposed || coordinator.IsSetupFailed ||
                coordinator.RuntimeStatus != RoomEncounterRuntimeStatus.Cleared ||
                !coordinator.HasPhysicalClearObservation ||
                !ReferenceEquals(coordinator.Runtime, runtime) ||
                !ReferenceEquals(coordinator.PhysicalClearObservation, observation) ||
                !coordinator.HasCurrentPhysicalBoundaryWitness ||
                !ReferenceEquals(coordinator, context.Scope == null ? null : context.Scope.GetComponent<F10GuardianRuntimeCoordinator>()) ||
                !string.Equals(context.NodeId, F10TechnicalEncounterPlanProvider.GuardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(context.TemplateId, F10TechnicalEncounterPlanProvider.GuardianTemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(observation.Scope, context.Scope) || observation.RunId != run.RunId ||
                observation.RoomInstanceId != context.RoomInstanceId ||
                observation.ActivationGeneration != context.ActivationGeneration ||
                !string.Equals(observation.NodeId, context.NodeId, StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, context.TemplateId, StringComparison.Ordinal) ||
                !context.IsCurrentRoomScope() || context.Plan == null || !context.Plan.HasOnlySupportedActors ||
                context.Plan.Roster == null || context.Plan.Roster.Waves.Count != 1 ||
                context.Plan.Roster.Waves[0] == null || context.Plan.Roster.Waves[0].WaveNumber != 1 ||
                context.Plan.Roster.Waves[0].SpawnKeys.Count != 1 || observation.Actors == null ||
                observation.Actors.Count != 1 || runtime.RegisteredBindings == null || runtime.RegisteredBindings.Count != 1)
                return FailF10RoomAdvance("The Guardian runtime, physical wall witness, or single-Custodian clear is stale or incomplete.", out error);

            string expectedKey;
            try
            {
                expectedKey = EncounterSpawnIdentityV1.Create(run.RunId,
                    checked((uint)run.Route.GenerationVersion), F10TechnicalEncounterPlanProvider.GuardianNodeId,
                    context.RoomInstanceId, F10RoomGuardianBossId, F10RoomGuardianSpawnId).Key;
            }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The deterministic Custodian spawn identity could not be derived: " + exception.GetType().Name + ".", out error);
            }

            if (!string.Equals(context.Plan.Roster.Waves[0].SpawnKeys[0], expectedKey, StringComparison.Ordinal) ||
                !context.Plan.TryGetActor(expectedKey, out RoomEncounterActorDefinition actorDefinition) ||
                actorDefinition == null || !actorDefinition.SupportsConcreteActorAdapter ||
                actorDefinition.ActorPrefab == null || actorDefinition.ActorPrefab.GetComponent<CustodianBoss2D>() == null ||
                actorDefinition.ActorPrefab.GetComponent<Slime2D>() != null ||
                actorDefinition.ActorPrefab.GetComponent<Huesoguardia2D>() != null)
                return FailF10RoomAdvance("Guardian's planned actor is not the one frozen Custodian spawn.", out error);

            RoomEncounterActorBinding binding = runtime.RegisteredBindings[0];
            RoomEncounterDefeatedActorObservation actor = observation.Actors[0];
            if (binding == null || !string.Equals(binding.SpawnKey, expectedKey, StringComparison.Ordinal) ||
                binding.WaveNumber != 1 || binding.CustodianBoss == null || binding.Slime != null ||
                binding.Huesoguardia != null || !binding.IsDefeatAccepted || !binding.PhysicalDeathObserved ||
                binding.Phase != RoomEncounterActorBindingPhase.DefeatAccepted || !binding.ActorIsDead ||
                binding.ActorCurrentHealth > 0 || !ReferenceEquals(binding.Scope, context.Scope) ||
                binding.Generation != context.ActivationGeneration || !binding.ActorId.IsValid ||
                !string.Equals(actor.SpawnKey, expectedKey, StringComparison.Ordinal) ||
                actor.WaveNumber != 1 || actor.ActorId != binding.ActorId || !actor.ActorId.IsValid ||
                actor.CapturedSequence <= 0 || actor.ProcessedDrainSequence <= actor.CapturedSequence)
                return FailF10RoomAdvance("The exact Custodian binding was not physically defeated and accepted in Guardian's current scope.", out error);

            return true;
        }

        private static bool ActorTypeMatchesF10C1Spawn(RoomEncounterActorDefinition actorDefinition,
            RoomEncounterActorBinding binding, int waveIndex)
        {
            if (waveIndex == 0)
                return binding.Slime != null && binding.Huesoguardia == null && binding.CustodianBoss == null &&
                    actorDefinition.ActorPrefab.GetComponent<Slime2D>() != null &&
                    actorDefinition.ActorPrefab.GetComponent<Huesoguardia2D>() == null;
            return binding.Huesoguardia != null && binding.Slime == null && binding.CustodianBoss == null &&
                actorDefinition.ActorPrefab.GetComponent<Huesoguardia2D>() != null &&
                actorDefinition.ActorPrefab.GetComponent<Slime2D>() == null;
        }

        private static bool TryValidateF10ExplorationExit(ExpeditionRunConfiguration run,
            RoomEncounterRuntimeContext context, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation,
            out string error)
        {
            error = string.Empty;
            if (run == null || context == null || driver == null || handoff == null || observation == null ||
                !driver.isActiveAndEnabled || !driver.IsDeliveringTo(handoff, observation) ||
                observation.Kind != F10ObjectiveObservationKind.ExplorationExitTouched ||
                !ReferenceEquals(observation.Scope, context.Scope) ||
                !ReferenceEquals(observation.Controller, context.Controller) ||
                !ReferenceEquals(observation.Player, context.Player) ||
                observation.RunId != run.RunId || observation.RoomInstanceId != context.RoomInstanceId ||
                observation.ActivationGeneration != context.ActivationGeneration ||
                observation.ActorId != context.Player.ActorId || !observation.ActorId.IsValid ||
                context.Plan != null || !context.IsCurrentRoomScope() ||
                context.Player == null || !context.Player.isActiveAndEnabled || context.Player.IsDead ||
                context.Player.CurrentHealth <= 0)
                return FailF10RoomAdvance("The E1 exit observation no longer belongs to the current F10 actor and room activation.", out error);

            return true;
        }

        private static bool TryBuildF10CombatRewardRequest(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, ExpeditionRouteNode node, RoomEncounterRuntimeContext context,
            RoomEncounterRuntime runtime, RoomEncounterClearObservation observation,
            out ExpeditionEncounterRewardRequest request, out string error)
        {
            request = null;
            error = string.Empty;
            if (!TryGetF10AvariceState(save, out bool avariceActive, out error)) return false;
            var spawns = new List<ExpeditionEncounterRewardSpawn>(4);
            foreach (RoomEncounterDefeatedActorObservation actor in observation.Actors)
                spawns.Add(new ExpeditionEncounterRewardSpawn(actor.SpawnKey,
                    ExpeditionEncounterRewardEnemyKind.Normal));
            try
            {
                request = new ExpeditionEncounterRewardRequest(run.RunId, run.Seed,
                    run.Route.GenerationVersion, node.NodeId, node.TemplateId, node.SectorId,
                    node.Kind, spawns, avaricePactActive: avariceActive,
                    vinculoPactActive: false, hasExplorationCache: false);
                return true;
            }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The validated C1 roster could not form a deterministic reward request: " + exception.Message, out error);
            }
        }

        private static bool TryBuildF10GuardianRewardRequest(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, ExpeditionRouteNode node, RoomEncounterRuntimeContext context,
            RoomEncounterClearObservation observation,
            out ExpeditionEncounterRewardRequest request, out string error)
        {
            request = null;
            error = string.Empty;
            if (!TryGetF10AvariceState(save, out bool avariceActive, out error)) return false;
            string expectedKey;
            try
            {
                expectedKey = EncounterSpawnIdentityV1.Create(run.RunId,
                    checked((uint)run.Route.GenerationVersion), F10TechnicalEncounterPlanProvider.GuardianNodeId,
                    context.RoomInstanceId, F10RoomGuardianBossId, F10RoomGuardianSpawnId).Key;
                if (observation == null || observation.Actors == null || observation.Actors.Count != 1 ||
                    !string.Equals(observation.Actors[0].SpawnKey, expectedKey, StringComparison.Ordinal))
                    return FailF10RoomAdvance("The Guardian reward request must use its fixed physical Custodian spawn key.", out error);

                request = new ExpeditionEncounterRewardRequest(run.RunId, run.Seed,
                    run.Route.GenerationVersion, node.NodeId, node.TemplateId, node.SectorId,
                    node.Kind, new[] { new ExpeditionEncounterRewardSpawn(expectedKey,
                        ExpeditionEncounterRewardEnemyKind.Guardian) }, avaricePactActive: avariceActive,
                    vinculoPactActive: false,
                    hasExplorationCache: false);
                return true;
            }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The validated Guardian Custodian could not form its deterministic reward request: " + exception.Message, out error);
            }
        }

        private static bool TryBuildF10ExplorationRewardRequest(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, ExpeditionRouteNode node,
            out ExpeditionEncounterRewardRequest request, out string error)
        {
            request = null;
            error = string.Empty;
            if (!TryGetF10AvariceState(save, out bool avariceActive, out error)) return false;
            try
            {
                request = new ExpeditionEncounterRewardRequest(run.RunId, run.Seed,
                    run.Route.GenerationVersion, node.NodeId, node.TemplateId, node.SectorId,
                    node.Kind, Array.Empty<ExpeditionEncounterRewardSpawn>(), avaricePactActive: avariceActive,
                    vinculoPactActive: false, hasExplorationCache: true,
                    explorationCacheKey: F10CacheRoomMarkerId);
                return true;
            }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The validated E1 source could not form a deterministic room payout request: " + exception.Message, out error);
            }
        }

        private static bool TryGetF10AvariceState(ExpeditionSaveData save, out bool avariceActive, out string error)
        {
            avariceActive = false;
            error = string.Empty;
            if (save == null || save.pactIds == null || save.pactIds.Any(string.IsNullOrWhiteSpace) ||
                save.pactIds.Distinct(StringComparer.Ordinal).Count() != save.pactIds.Length ||
                save.pactIds.Any(pactId => !PactIds.IsKnown(pactId)))
                return FailF10RoomAdvance("The saved pact context contains an unknown or duplicate pact ID.", out error);
            avariceActive = save.pactIds.Contains(PactIds.Avarice, StringComparer.Ordinal);
            return true;
        }

        private static bool TryValidateF10ExplorationRoomContent(RoomLifetimeScope scope, out string error)
        {
            error = string.Empty;
            if (scope == null || !scope.isActiveAndEnabled || scope.IsDisposed)
                return FailF10RoomAdvance("E1 payout requires its active physical room scope.", out error);

            TextAsset canonical = Resources.Load<TextAsset>(F10CacheRoomDefinitionResource);
            RoomTemplatePrefab2D[] rooms = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (canonical == null || rooms.Length != 1 || rooms[0] == null || !rooms[0].isActiveAndEnabled ||
                rooms[0].SourceDefinition == null ||
                !string.Equals(rooms[0].SourceDefinition.text, canonical.text, StringComparison.Ordinal))
                return FailF10RoomAdvance("The active E1 room must use its canonical F10 template source.", out error);

            RoomTemplateData data;
            try { data = RoomTemplateJsonLoader.Load(rooms[0].SourceDefinition.text); }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The canonical E1 template could not be parsed: " + exception.GetType().Name + ".", out error);
            }
            RoomPositionMarkerData[] cacheDefinitions = (data.markers ?? Array.Empty<RoomPositionMarkerData>())
                .Where(marker => marker != null && string.Equals(marker.id, F10CacheRoomMarkerId, StringComparison.Ordinal))
                .ToArray();
            RoomPositionMarker2D[] markers = scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(marker => marker != null && string.Equals(marker.MarkerId, F10CacheRoomMarkerId, StringComparison.Ordinal))
                .ToArray();
            ExplorationGoldCachePickup2D[] pickups = scope.GetComponentsInChildren<ExplorationGoldCachePickup2D>(true);
            if (!string.Equals(data.templateId, F10RoomExplorationTemplateId, StringComparison.Ordinal) ||
                cacheDefinitions.Length != 1 || !string.Equals(cacheDefinitions[0].kind, "treasure", StringComparison.Ordinal) ||
                cacheDefinitions[0].tileX != 21 || cacheDefinitions[0].tileY != 8 || data.tileSize <= 0 ||
                markers.Length != 1 || pickups.Length != 1 || pickups[0] == null || !markers[0].isActiveAndEnabled ||
                !ReferenceEquals(pickups[0].transform.parent, scope.transform))
                return FailF10RoomAdvance("E1 must contain the unique canonical physical cache marker and its separate pickup.", out error);

            Vector3 expected = rooms[0].transform.TransformPoint(new Vector3(
                (cacheDefinitions[0].tileX + 0.5f) * data.tileSize,
                cacheDefinitions[0].tileY * data.tileSize, 0f));
            if (!string.Equals(markers[0].Kind, "treasure", StringComparison.Ordinal) ||
                markers[0].TilePosition != new Vector2Int(cacheDefinitions[0].tileX, cacheDefinitions[0].tileY) ||
                !(ReferenceEquals(markers[0].transform, rooms[0].transform) || markers[0].transform.IsChildOf(rooms[0].transform)) ||
                (markers[0].transform.position - expected).sqrMagnitude > F10RoomMarkerTolerance * F10RoomMarkerTolerance ||
                (pickups[0].transform.position - expected).sqrMagnitude > F10RoomMarkerTolerance * F10RoomMarkerTolerance)
                return FailF10RoomAdvance("The E1 cache marker and pickup must retain their JSON-derived physical pose.", out error);

            return true;
        }

        private bool TryApplyF10TechnicalPayment(F10TechnicalRoomPayment payment,
            ExpeditionRunConfiguration currentRun, ExpeditionSaveData currentSave,
            ExpeditionSaveData candidateSave, ExpeditionInventory candidateInventory,
            ExpeditionRoomTransitionController controller, RoomInstanceId sourceRoomId,
            string targetNodeId, string resultId, string resultJson, long expectedRevision,
            out string error)
        {
            error = string.Empty;
            if (payment == null || !ReferenceEquals(payment.Owner, _expeditionSessionMutationPublicationOwner) ||
                !ReferenceEquals(payment.Run, currentRun) || !ReferenceEquals(currentRun, ActiveRun) ||
                currentSave == null || candidateSave == null || candidateInventory == null ||
                !string.Equals(JsonUtility.ToJson(currentSave), payment.SaveJson, StringComparison.Ordinal) ||
                !string.Equals(currentSave.runId, currentRun.RunId.ToString(), StringComparison.Ordinal) ||
                expectedRevision != payment.ExpectedRevision || expectedRevision != ActiveExpeditionRevision ||
                !string.Equals(JsonUtility.ToJson(candidateInventory.CreateSnapshot()), payment.ExpectedInventoryJson, StringComparison.Ordinal) ||
                !string.Equals(payment.ExpectedInventoryJson, JsonUtility.ToJson(currentRun.Inventory.CreateSnapshot()), StringComparison.Ordinal) ||
                !ReferenceEquals(candidateInventory.Catalog, currentRun.Inventory.Catalog) ||
                !string.Equals(candidateInventory.ClassId, currentRun.ClassId, StringComparison.Ordinal) ||
                !ReferenceEquals(controller, payment.Controller) || sourceRoomId != payment.SourceRoomId ||
                !string.Equals(targetNodeId, payment.TargetNodeId, StringComparison.Ordinal) ||
                !string.Equals(resultId, payment.ResultId, StringComparison.Ordinal) ||
                !string.Equals(resultJson, payment.ResultJson, StringComparison.Ordinal) ||
                !string.Equals(payment.SourceNodeId, currentSave.currentNodeId, StringComparison.Ordinal) ||
                !IsSameF10RoomRewardSourceState(currentSave, candidateSave))
                return FailF10RoomAdvance("The F10 room-payment certificate no longer matches the gated route, save, inventory, or result payload.", out error);

            if (!TryValidateF10TechnicalOwner(payment.Owner, out _,
                    out ExpeditionRoomActivationRegistration activation, out error) ||
                !ReferenceEquals(activation.Context, payment.Context) ||
                !TryValidateF10RunAndRoute(currentRun, currentSave, payment.Context, controller,
                    out ExpeditionRouteNode currentNode, out string currentTarget, out error) ||
                !ReferenceEquals(currentNode, payment.SourceNode) ||
                !string.Equals(currentTarget, payment.TargetNodeId, StringComparison.Ordinal)) return false;

            if (payment.Kind == F10TechnicalRoomPaymentKind.Combat)
            {
                if (!ReferenceEquals(payment.Runtime.LastClearObservation, payment.ClearObservation) ||
                    !TryValidateF10CombatClear(currentRun, payment.Context, payment.Runtime,
                        payment.ClearObservation, out error) ||
                    !TryBuildF10CombatRewardRequest(currentRun, currentSave, currentNode,
                        payment.Context, payment.Runtime, payment.ClearObservation,
                        out ExpeditionEncounterRewardRequest currentRequest, out error) ||
                    !RewardRequestsMatch(payment.RewardRequest, currentRequest))
                    return FailF10RoomAdvance("The exact C1 clear/roster or its saved reward context changed before payment.", out error);
            }
            else if (payment.Kind == F10TechnicalRoomPaymentKind.Guardian)
            {
                if (!ReferenceEquals(payment.Runtime.LastClearObservation, payment.ClearObservation) ||
                    !TryValidateF10GuardianClear(currentRun, payment.Context, payment.Runtime,
                        payment.ClearObservation, payment.GuardianCoordinator, out error) ||
                    !TryBuildF10GuardianRewardRequest(currentRun, currentSave, currentNode,
                        payment.Context, payment.ClearObservation,
                        out ExpeditionEncounterRewardRequest currentRequest, out error) ||
                    !RewardRequestsMatch(payment.RewardRequest, currentRequest))
                    return FailF10RoomAdvance("The exact Guardian Custodian clear, boundary witness, or saved reward context changed before payment.", out error);
            }
            else if (!payment.Driver.IsDeliveringTo(payment.Handoff, payment.ExitObservation) ||
                !TryValidateF10ExplorationExit(currentRun, payment.Context, payment.Driver,
                    payment.Handoff, payment.ExitObservation, out error) ||
                !TryValidateF10ExplorationRoomContent(payment.Context.Scope, out error) ||
                !TryBuildF10ExplorationRewardRequest(currentRun, currentSave, currentNode,
                    out ExpeditionEncounterRewardRequest currentRequest, out error) ||
                !RewardRequestsMatch(payment.RewardRequest, currentRequest))
                return FailF10RoomAdvance("The E1 exit handoff or its saved room/cache policy changed before payment.", out error);

            ExpeditionEncounterRewardResolution resolution;
            try { resolution = ExpeditionEncounterRewardPolicy.Resolve(payment.RewardRequest); }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The deterministic F10 room policy rejected its saved context: " + exception.Message, out error);
            }

            if (resolution == null || resolution.RoomPayout == null || resolution.OfferRequirement != null ||
                (payment.Kind == F10TechnicalRoomPaymentKind.Combat && resolution.ExplorationCacheReward != null) ||
                (payment.Kind == F10TechnicalRoomPaymentKind.Exploration &&
                    (resolution.ExplorationCacheReward == null || resolution.RoomPayout.Gold != 0 ||
                     resolution.EnemyOutcomes.Count != 0)) ||
                (payment.Kind == F10TechnicalRoomPaymentKind.Guardian && resolution.ExplorationCacheReward != null))
                return FailF10RoomAdvance("The F10 policy returned rewards outside the one-room payment contract.", out error);

            if (payment.Kind == F10TechnicalRoomPaymentKind.Exploration &&
                !TryValidateF10E1CachePaymentState(currentRun, currentSave, payment.Context.Scope,
                    resolution.ExplorationCacheReward, out error)) return false;

            // Keep the established Guardian transaction path separate. C1/E1 policy rewards
            // share this exact applier with the V7 combat candidate below.
            if (payment.Kind != F10TechnicalRoomPaymentKind.Guardian)
                return TryApplyF10PolicyRoomPayment(currentSave, candidateSave,
                    candidateInventory, resolution,
                    payment.Kind == F10TechnicalRoomPaymentKind.Combat, out error);

            string guardianGrantId = null;
            int totalGold;
            int renown;
            string[] claimIds;
            bool valuesValid = payment.Kind == F10TechnicalRoomPaymentKind.Guardian
                ? TryCollectF10GuardianPaymentValues(resolution, out totalGold, out renown,
                    out guardianGrantId, out claimIds, out error)
                : TryCollectF10TechnicalPaymentValues(payment.Kind == F10TechnicalRoomPaymentKind.Combat,
                    resolution, out totalGold, out renown, out claimIds, out error);
            if (!valuesValid) return false;
            ExpeditionRoomCompletionPayout payout = resolution.RoomPayout;
            if (candidateSave.claimedRewardIds == null ||
                candidateSave.claimedRewardIds.Distinct(StringComparer.Ordinal).Count() != candidateSave.claimedRewardIds.Length)
                return FailF10RoomAdvance("The candidate save contains duplicate room reward claims.", out error);

            ExpeditionInventorySnapshot inventorySnapshot = candidateInventory.CreateSnapshot();
            TransactionId transactionId = CreateF10TechnicalRoomTransactionId(resolution.ResolutionId, claimIds);
            bool transactionIdExists = HasF10RoomTransactionId(inventorySnapshot, transactionId);
            bool exactGoldTransaction = totalGold > 0 && HasSuccessfulF10RoomGoldTransaction(
                inventorySnapshot, transactionId, totalGold);
            bool guardianGrantPersisted = false;
            FortuneOfferBook guardianBook = null;
            if (payment.Kind == F10TechnicalRoomPaymentKind.Guardian)
            {
                if (!TryRestoreF10GuardianBook(currentSave.fortuneOfferBookSnapshot, currentRun,
                        out guardianBook, out error)) return false;
                guardianGrantPersisted = currentSave.fortuneOfferBookSnapshot.processedGuardianIds
                    .Contains(guardianGrantId, StringComparer.Ordinal);
            }

            bool alreadyPaid;
            bool classificationValid = payment.Kind == F10TechnicalRoomPaymentKind.Guardian
                ? TryClassifyF10GuardianRewardState(claimIds, currentSave.claimedRewardIds,
                    transactionIdExists, exactGoldTransaction, guardianGrantPersisted, out alreadyPaid)
                : TryClassifyF10RoomClaimState(claimIds, currentSave.claimedRewardIds,
                    transactionIdExists, totalGold > 0, exactGoldTransaction, out alreadyPaid);
            if (!classificationValid)
                return FailF10RoomAdvance("A partial room claim or inconsistent deterministic transaction is present; no reward was applied.", out error);
            if (alreadyPaid) return true;

            if (totalGold > 0)
            {
                int goldBefore = candidateInventory.Gold;
                int expectedGold;
                try { expectedGold = checked(goldBefore + totalGold); }
                catch (OverflowException) { return FailF10RoomAdvance("The room gold payout exceeds inventory capacity.", out error); }
                InventoryOperationOutcome outcome = candidateInventory.TryAddGold(totalGold, transactionId);
                if (outcome == null || !outcome.Succeeded || outcome.WasReplay || candidateInventory.Gold != expectedGold)
                    return FailF10RoomAdvance("The deterministic room gold transaction was rejected or replayed unexpectedly.", out error);
            }

            if (payment.Kind == F10TechnicalRoomPaymentKind.Guardian)
            {
                int chargesBefore = guardianBook.CurrentCharges;
                FortuneChargeResult grant = guardianBook.GrantGuardianCharge(guardianGrantId);
                if (grant == null ||
                    (grant.Status == FortuneOperationStatus.Succeeded &&
                        (chargesBefore >= FortuneOfferBook.MaximumCharges || grant.CurrentCharges != chargesBefore + 1)) ||
                    (grant.Status == FortuneOperationStatus.RejectedAtCapacity &&
                        (chargesBefore != FortuneOfferBook.MaximumCharges || grant.CurrentCharges != chargesBefore)) ||
                    (grant.Status != FortuneOperationStatus.Succeeded &&
                        grant.Status != FortuneOperationStatus.RejectedAtCapacity))
                    return FailF10RoomAdvance("The Fortune book rejected the exact Guardian grant or changed outside the three-charge cap.", out error);
                candidateSave.fortuneOfferBookSnapshot = guardianBook.CreateSnapshot();
            }

            try { candidateSave.accumulatedRenown = checked(candidateSave.accumulatedRenown + payout.Renown); }
            catch (OverflowException) { return FailF10RoomAdvance("The room Renown payout exceeds the saved expedition balance.", out error); }
            candidateSave.claimedRewardIds = candidateSave.claimedRewardIds.Concat(claimIds)
                .OrderBy(id => id, StringComparer.Ordinal).ToArray();
            return true;
        }

        /// <summary>
        /// Applies the existing policy-owned C1/E1 room payment to detached candidates. Amounts,
        /// stable claims, replay classification, and transaction identity are all derived here;
        /// callers supply neither amounts nor claim IDs.
        /// </summary>
        private static bool TryApplyF10PolicyRoomPayment(ExpeditionSaveData currentSave,
            ExpeditionSaveData candidateSave, ExpeditionInventory candidateInventory,
            ExpeditionEncounterRewardResolution resolution, bool combat, out string error)
        {
            error = string.Empty;
            if (currentSave == null || candidateSave == null || candidateInventory == null ||
                currentSave.claimedRewardIds == null || candidateSave.claimedRewardIds == null ||
                candidateSave.claimedRewardIds.Distinct(StringComparer.Ordinal).Count() != candidateSave.claimedRewardIds.Length)
                return FailF10RoomAdvance("The detached room-payment candidates or their claim state are invalid.", out error);

            if (!TryCollectF10TechnicalPaymentValues(combat, resolution,
                    out int totalGold, out int renown, out string[] claimIds, out error)) return false;

            ExpeditionInventorySnapshot inventorySnapshot = candidateInventory.CreateSnapshot();
            TransactionId transactionId = CreateF10TechnicalRoomTransactionId(resolution.ResolutionId, claimIds);
            bool transactionIdExists = HasF10RoomTransactionId(inventorySnapshot, transactionId);
            bool exactGoldTransaction = totalGold > 0 && HasSuccessfulF10RoomGoldTransaction(
                inventorySnapshot, transactionId, totalGold);
            if (!TryClassifyF10RoomClaimState(claimIds, currentSave.claimedRewardIds,
                    transactionIdExists, totalGold > 0, exactGoldTransaction, out bool alreadyPaid))
                return FailF10RoomAdvance("A partial room claim or inconsistent deterministic transaction is present; no reward was applied.", out error);
            if (alreadyPaid) return true;

            if (totalGold > 0)
            {
                int goldBefore = candidateInventory.Gold;
                int expectedGold;
                try { expectedGold = checked(goldBefore + totalGold); }
                catch (OverflowException) { return FailF10RoomAdvance("The room gold payout exceeds inventory capacity.", out error); }
                InventoryOperationOutcome outcome = candidateInventory.TryAddGold(totalGold, transactionId);
                if (outcome == null || !outcome.Succeeded || outcome.WasReplay || candidateInventory.Gold != expectedGold)
                    return FailF10RoomAdvance("The deterministic room gold transaction was rejected or replayed unexpectedly.", out error);
            }

            try { candidateSave.accumulatedRenown = checked(candidateSave.accumulatedRenown + renown); }
            catch (OverflowException) { return FailF10RoomAdvance("The room Renown payout exceeds the saved expedition balance.", out error); }
            candidateSave.claimedRewardIds = candidateSave.claimedRewardIds.Concat(claimIds)
                .OrderBy(id => id, StringComparer.Ordinal).ToArray();
            return true;
        }

        private bool TryValidateF10E1CachePaymentState(ExpeditionRunConfiguration run,
            ExpeditionSaveData save, RoomLifetimeScope scope, ExpeditionExplorationCacheReward cacheReward,
            out string error)
        {
            error = string.Empty;
            if (run == null || run.Inventory == null || save == null || save.claimedRewardIds == null ||
                cacheReward == null || !string.Equals(cacheReward.CacheKey, F10CacheRoomMarkerId, StringComparison.Ordinal) ||
                cacheReward.Gold <= 0 || string.IsNullOrWhiteSpace(cacheReward.GoldGrantId) ||
                !TryValidateF10ExplorationRoomContent(scope, out error))
                return FailF10RoomAdvance("The E1 cache reward or physical pickup binding is not canonical.", out error);

            ExplorationGoldCachePickup2D[] pickups = scope.GetComponentsInChildren<ExplorationGoldCachePickup2D>(true);
            if (pickups.Length != 1 || pickups[0] == null)
                return FailF10RoomAdvance("E1 must retain exactly one physical cache pickup.", out error);

            ExpeditionInventorySnapshot inventory = run.Inventory.CreateSnapshot();
            TransactionId cacheTransactionId = CreateF10CacheTransactionId(cacheReward.GoldGrantId);
            bool claimPersisted = save.claimedRewardIds.Contains(cacheReward.GoldGrantId, StringComparer.Ordinal);
            bool anyCacheTransaction = HasF10RoomTransactionId(inventory, cacheTransactionId);
            bool matchingCacheTransaction = HasSuccessfulF10CacheTransaction(inventory,
                cacheTransactionId, cacheReward.Gold);
            if (!IsF10E1CacheActorStateCoherent(pickups[0].isActiveAndEnabled,
                    pickups[0].gameObject.activeSelf, claimPersisted, matchingCacheTransaction,
                    anyCacheTransaction))
                return FailF10RoomAdvance("The optional E1 cache must be active while unclaimed, or have its exact durable claim and pickup transaction after collection.", out error);

            return true;
        }

        private static bool HasF10RoomTransactionId(ExpeditionInventorySnapshot snapshot,
            TransactionId transactionId)
        {
            return snapshot != null && snapshot.transactions != null && transactionId.IsValid &&
                snapshot.transactions.Any(transaction => transaction != null &&
                    string.Equals(transaction.transactionId, transactionId.ToString(), StringComparison.Ordinal));
        }

        internal static bool IsF10E1CacheActorStateCoherent(bool pickupIsActiveAndEnabled,
            bool pickupActiveSelf, bool claimPersisted, bool matchingTransaction, bool anyCacheTransaction)
        {
            if (claimPersisted) return anyCacheTransaction && matchingTransaction;
            return pickupIsActiveAndEnabled && pickupActiveSelf && !anyCacheTransaction && !matchingTransaction;
        }

        internal static bool TryClassifyF10RoomClaimState(IEnumerable<string> requiredClaimIds,
            IEnumerable<string> persistedClaimIds, bool transactionIdExists,
            bool transactionExpected, bool exactTransactionExists, out bool alreadyPaid)
        {
            alreadyPaid = false;
            string[] required = requiredClaimIds == null ? Array.Empty<string>() : requiredClaimIds.ToArray();
            string[] persisted = persistedClaimIds == null ? Array.Empty<string>() : persistedClaimIds.ToArray();
            if (required.Length == 0 || required.Any(string.IsNullOrWhiteSpace) ||
                required.Distinct(StringComparer.Ordinal).Count() != required.Length ||
                persisted.Any(string.IsNullOrWhiteSpace) ||
                persisted.Distinct(StringComparer.Ordinal).Count() != persisted.Length ||
                exactTransactionExists && (!transactionIdExists || !transactionExpected) ||
                transactionIdExists && (!transactionExpected || !exactTransactionExists)) return false;

            int claimedCount = required.Count(id => persisted.Contains(id, StringComparer.Ordinal));
            if (claimedCount != 0 && claimedCount != required.Length) return false;
            if (claimedCount == required.Length)
            {
                if (transactionExpected != exactTransactionExists) return false;
                alreadyPaid = true;
                return true;
            }

            return !transactionIdExists && !exactTransactionExists;
        }

        internal static bool TryClassifyF10GuardianRewardState(IEnumerable<string> requiredClaimIds,
            IEnumerable<string> persistedClaimIds, bool transactionIdExists,
            bool exactGoldTransactionExists, bool guardianGrantPersisted, out bool alreadyPaid)
        {
            if (!TryClassifyF10RoomClaimState(requiredClaimIds, persistedClaimIds,
                    transactionIdExists, true, exactGoldTransactionExists, out alreadyPaid)) return false;
            return alreadyPaid == guardianGrantPersisted;
        }

        private static bool TryRestoreF10GuardianBook(FortuneOfferBookSnapshot snapshot,
            ExpeditionRunConfiguration run, out FortuneOfferBook book, out string error)
        {
            book = null;
            error = string.Empty;
            if (snapshot == null || run == null || run.Route == null ||
                snapshot.processedGuardianIds == null ||
                snapshot.processedGuardianIds.Any(string.IsNullOrWhiteSpace) ||
                snapshot.processedGuardianIds.Distinct(StringComparer.Ordinal).Count() != snapshot.processedGuardianIds.Length)
                return FailF10RoomAdvance("The saved Fortune book or processed Guardian identities are invalid.", out error);

            try { book = FortuneOfferBook.Restore(snapshot); }
            catch (Exception exception)
            {
                return FailF10RoomAdvance("The saved Fortune book could not be restored: " + exception.GetType().Name + ".", out error);
            }
            if (book.GenerationVersion != run.Route.GenerationVersion || book.Seed != run.Seed ||
                !string.Equals(book.RaceId, run.RaceId, StringComparison.Ordinal))
                return FailF10RoomAdvance("The saved Fortune book does not belong to the current Guardian run.", out error);
            return true;
        }

        private static bool IsSameF10RoomRewardSourceState(ExpeditionSaveData currentSave,
            ExpeditionSaveData candidateSave)
        {
            return currentSave != null && candidateSave != null &&
                string.Equals(currentSave.runId, candidateSave.runId, StringComparison.Ordinal) &&
                currentSave.seed == candidateSave.seed && currentSave.generationVersion == candidateSave.generationVersion &&
                string.Equals(currentSave.routeSnapshotJson, candidateSave.routeSnapshotJson, StringComparison.Ordinal) &&
                string.Equals(currentSave.currentNodeId, candidateSave.currentNodeId, StringComparison.Ordinal) &&
                currentSave.accumulatedRenown == candidateSave.accumulatedRenown &&
                currentSave.pactIds.SequenceEqual(candidateSave.pactIds, StringComparer.Ordinal) &&
                currentSave.claimedRewardIds.SequenceEqual(candidateSave.claimedRewardIds, StringComparer.Ordinal) &&
                (currentSave.fortuneOfferBookSnapshot == null
                    ? candidateSave.fortuneOfferBookSnapshot == null
                    : candidateSave.fortuneOfferBookSnapshot != null &&
                        string.Equals(JsonUtility.ToJson(currentSave.fortuneOfferBookSnapshot),
                            JsonUtility.ToJson(candidateSave.fortuneOfferBookSnapshot), StringComparison.Ordinal));
        }

        private static bool RewardRequestsMatch(ExpeditionEncounterRewardRequest left,
            ExpeditionEncounterRewardRequest right)
        {
            if (left == null || right == null || left.RunId != right.RunId || left.Seed != right.Seed ||
                left.GenerationVersion != right.GenerationVersion || left.NodeId != right.NodeId ||
                left.TemplateId != right.TemplateId || left.SectorId != right.SectorId ||
                left.NodeKind != right.NodeKind || left.AvaricePactActive != right.AvaricePactActive ||
                left.VinculoPactActive != right.VinculoPactActive || left.HasExplorationCache != right.HasExplorationCache ||
                !string.Equals(left.ExplorationCacheKey, right.ExplorationCacheKey, StringComparison.Ordinal) ||
                left.Spawns.Count != right.Spawns.Count) return false;
            for (int index = 0; index < left.Spawns.Count; index++)
            {
                ExpeditionEncounterRewardSpawn a = left.Spawns[index];
                ExpeditionEncounterRewardSpawn b = right.Spawns[index];
                if (!string.Equals(a.SpawnKey, b.SpawnKey, StringComparison.Ordinal) ||
                    a.EnemyKind != b.EnemyKind || a.VinculoSequenceOrdinal != b.VinculoSequenceOrdinal) return false;
            }
            return true;
        }

        internal static TransactionId CreateF10TechnicalRoomTransactionId(string resolutionId,
            IEnumerable<string> grantIds)
        {
            string[] sortedIds = grantIds == null ? Array.Empty<string>() : grantIds.OrderBy(id => id, StringComparer.Ordinal).ToArray();
            var canonical = new StringBuilder("luckbound-f10-room-transaction-v1|");
            AppendF10LengthPrefixed(canonical, resolutionId ?? string.Empty);
            foreach (string grantId in sortedIds) AppendF10LengthPrefixed(canonical, grantId ?? string.Empty);
            byte[] digest;
            using (SHA256 sha256 = SHA256.Create()) digest = sha256.ComputeHash(Encoding.UTF8.GetBytes(canonical.ToString()));
            var hex = new StringBuilder(32);
            for (int index = 0; index < 16; index++) hex.Append(digest[index].ToString("x2", CultureInfo.InvariantCulture));
            Guid value = Guid.ParseExact(hex.ToString(), "N");
            if (value == Guid.Empty) value = Guid.ParseExact("00000000000000000000000000000001", "N");
            return new TransactionId(value);
        }

        private static void AppendF10LengthPrefixed(StringBuilder builder, string value)
        {
            builder.Append(value.Length.ToString(CultureInfo.InvariantCulture)).Append(':').Append(value).Append('|');
        }

        internal static bool HasSuccessfulF10RoomGoldTransaction(ExpeditionInventorySnapshot snapshot,
            TransactionId transactionId, int amount)
        {
            if (snapshot == null || snapshot.transactions == null || !transactionId.IsValid || amount <= 0) return false;
            string signature = "gold|" + amount.ToString(CultureInfo.InvariantCulture);
            return snapshot.transactions.Any(transaction => transaction != null &&
                string.Equals(transaction.transactionId, transactionId.ToString(), StringComparison.Ordinal) &&
                transaction.status == (int)InventoryOperationStatus.Succeeded &&
                string.Equals(transaction.signature, signature, StringComparison.Ordinal) &&
                string.Equals(transaction.itemId, "currency.gold", StringComparison.Ordinal) &&
                transaction.craftingStatus == (int)CraftingOperationStatus.Unknown && transaction.economyStatus == 0);
        }

        internal static bool TryCollectF10GuardianPaymentValues(
            ExpeditionEncounterRewardResolution resolution, out int totalGold,
            out int renown, out string fortuneChargeGrantId, out string[] claimIds,
            out string error)
        {
            totalGold = 0;
            renown = 0;
            fortuneChargeGrantId = null;
            claimIds = Array.Empty<string>();
            error = string.Empty;
            if (resolution == null || resolution.RoomPayout == null ||
                resolution.ExplorationCacheReward != null || resolution.OfferRequirement != null ||
                resolution.EnemyOutcomes.Count != 1)
                return FailF10RoomAdvance("Guardian policy must return one Custodian outcome and no cache or offer.", out error);

            ExpeditionEnemyRewardOutcome guardian = resolution.EnemyOutcomes[0];
            ExpeditionRoomCompletionPayout payout = resolution.RoomPayout;
            if (guardian.EnemyKind != ExpeditionEncounterRewardEnemyKind.Guardian ||
                guardian.VinculoSequenceOrdinal != 0 || guardian.TotalGold <= 0 ||
                guardian.FortuneCharges != 1 || guardian.RelicOfferId != null ||
                guardian.BaseMaterialGrants.Count != 0 || guardian.VinculoMaterialGrants.Count != 0 ||
                string.IsNullOrWhiteSpace(guardian.GoldGrantId) ||
                string.IsNullOrWhiteSpace(guardian.FortuneChargeGrantId) ||
                payout.Gold != 0 || payout.GoldGrantId != null || payout.Renown <= 0 ||
                string.IsNullOrWhiteSpace(payout.RenownGrantId))
                return FailF10RoomAdvance("Guardian reward policy must return only Custodian gold, room Renown, and its single charge grant.", out error);

            totalGold = guardian.TotalGold;
            renown = payout.Renown;

            string[] claims =
            {
                guardian.GoldGrantId,
                payout.RenownGrantId,
                guardian.FortuneChargeGrantId
            };
            if (claims.Any(string.IsNullOrWhiteSpace) ||
                claims.Distinct(StringComparer.Ordinal).Count() != claims.Length)
                return FailF10RoomAdvance("Guardian reward claims must all be present and unique.", out error);

            fortuneChargeGrantId = guardian.FortuneChargeGrantId;
            claimIds = claims.OrderBy(id => id, StringComparer.Ordinal).ToArray();
            return true;
        }

        /// <summary>Extracts only durable room/enemy claims; exploration-cache gold and physical materials stay unclaimed.</summary>
        internal static bool TryCollectF10TechnicalPaymentValues(bool combat,
            ExpeditionEncounterRewardResolution resolution, out int totalGold,
            out int renown, out string[] claimIds, out string error)
        {
            totalGold = 0;
            renown = 0;
            claimIds = Array.Empty<string>();
            error = string.Empty;
            if (resolution == null || resolution.RoomPayout == null || resolution.OfferRequirement != null ||
                (combat && resolution.ExplorationCacheReward != null) ||
                (!combat && (resolution.ExplorationCacheReward == null || resolution.RoomPayout.Gold != 0 ||
                    resolution.EnemyOutcomes.Count != 0)))
                return FailF10RoomAdvance("The F10 policy returned rewards outside the one-room payment contract.", out error);

            try
            {
                var claims = new List<string>();
                if (combat)
                {
                    foreach (ExpeditionEnemyRewardOutcome enemy in resolution.EnemyOutcomes)
                    {
                        if (enemy.TotalGold < 0 || enemy.FortuneCharges != 0 || enemy.RelicOfferId != null)
                            return FailF10RoomAdvance("C1 may pay deterministic enemy gold only; physical materials and offers remain separate.", out error);
                        if (enemy.TotalGold > 0)
                        {
                            if (string.IsNullOrWhiteSpace(enemy.GoldGrantId))
                                return FailF10RoomAdvance("A positive C1 enemy payment is missing its stable claim ID.", out error);
                            totalGold = checked(totalGold + enemy.TotalGold);
                            claims.Add(enemy.GoldGrantId);
                        }
                        else if (enemy.GoldGrantId != null)
                            return FailF10RoomAdvance("A zero C1 enemy payment cannot have a gold grant ID.", out error);
                    }
                }

                ExpeditionRoomCompletionPayout payout = resolution.RoomPayout;
                if (payout.Gold < 0 || payout.Renown < 0)
                    return FailF10RoomAdvance("The F10 room payout contains a negative amount.", out error);
                if (payout.Gold > 0)
                {
                    if (!combat || string.IsNullOrWhiteSpace(payout.GoldGrantId))
                        return FailF10RoomAdvance("Only C1 may include its positive room gold payout.", out error);
                    totalGold = checked(totalGold + payout.Gold);
                    claims.Add(payout.GoldGrantId);
                }
                else if (payout.GoldGrantId != null)
                    return FailF10RoomAdvance("A zero room gold payout cannot have a gold grant ID.", out error);
                if (payout.Renown > 0)
                {
                    if (string.IsNullOrWhiteSpace(payout.RenownGrantId))
                        return FailF10RoomAdvance("A positive F10 Renown payout is missing its stable claim ID.", out error);
                    claims.Add(payout.RenownGrantId);
                }
                else if (payout.RenownGrantId != null)
                    return FailF10RoomAdvance("A zero Renown payout cannot have a claim ID.", out error);

                if (claims.Count == 0 || claims.Any(string.IsNullOrWhiteSpace) ||
                    claims.Distinct(StringComparer.Ordinal).Count() != claims.Count)
                    return FailF10RoomAdvance("The room policy must produce a non-empty set of unique durable reward claims.", out error);
                renown = payout.Renown;
                claimIds = claims.OrderBy(id => id, StringComparer.Ordinal).ToArray();
                return true;
            }
            catch (OverflowException)
            {
                return FailF10RoomAdvance("The F10 room payment exceeds the supported gold range.", out error);
            }
        }

        private static string SerializeF10RoomResult(RoomInstanceId roomId, string sourceNodeId, string targetNodeId)
        {
            return "{\"schema\":1,\"outcome\":\"cleared\",\"roomInstanceId\":" +
                QuoteF10Json(roomId.ToString()) + ",\"sourceNodeId\":" + QuoteF10Json(sourceNodeId) +
                ",\"targetNodeId\":" + QuoteF10Json(targetNodeId) + ",\"technicalPayment\":\"f10-room.v1\"}";
        }

        private static string QuoteF10Json(string value)
        {
            var builder = new StringBuilder((value ?? string.Empty).Length + 2).Append('"');
            foreach (char character in value ?? string.Empty)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\b': builder.Append("\\b"); break;
                    case '\f': builder.Append("\\f"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < 0x20) builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        else builder.Append(character);
                        break;
                }
            }
            return builder.Append('"').ToString();
        }

        private static bool FailF10RoomAdvance(string message, out string error)
        {
            error = message;
            return false;
        }
    }
}
#endif
