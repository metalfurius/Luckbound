#if UNITY_EDITOR
using System;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;

namespace Luckbound.App
{
    public sealed partial class SaveRepository
    {
        /// <summary>
        /// Staging-only admission for an active V7 session. The App must hold its own
        /// mutation gate and block V6 writes if an incompatible store was observed.
        /// This method does not publish gameplay or authorize an outcome.
        /// </summary>
        internal async Task<F10V7SafeOpenResult> TryOpenActiveV7ForPreproductionAsync(
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry)
        {
            await _gate.WaitAsync();
            try
            {
                if (_pendingProfile != null || _v7ExtractedSettlementOwner != null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.WritePending,
                        "An existing profile operation owns the repository.");
                if (_v7ProfileProtocolLatched)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.ProtocolConflict,
                        "An existing V7 protocol session already owns the repository.");
                if (_f10V7SessionHandle != null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.ProtocolConflict,
                        "The repository already retains its one V7 admission capability.");
                if (itemCatalog == null || exactRegistry == null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.CatalogRevisionUnavailable,
                        "The exact item catalog and encounter registry are required.");

                // This monotonic barrier is deliberately independent of the V7 latch and does not
                // alter the V6 caches. It must precede the first profile read, including failures.
                ArmV7V6ProfileWriteAdmissionBarrierUnderLock();
                SaveStorageSnapshot storage;
                try { storage = await _store.ReadAsync(SaveDocument.Profile); }
                catch (Exception)
                {
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.Corrupted,
                        "The profile store could not be read; existing state was preserved.");
                }
                if (storage == null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.Corrupted,
                        "The profile store returned no snapshot.");

                SaveV7LoadView primary = DecodeV7Storage(storage.PrimaryJson, SaveLoadStatus.LoadedPrimary);
                SaveV7LoadView selected;
                bool validPrimary;
                if (IsV7Usable(primary) || primary.Status == SaveLoadStatus.Incompatible)
                {
                    selected = primary;
                    validPrimary = IsV7Usable(primary);
                }
                else
                {
                    selected = DecodeV7Storage(storage.BackupJson, SaveLoadStatus.RecoveredBackup);
                    validPrimary = false;
                }

                if (selected.Status == SaveLoadStatus.Incompatible)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.Incompatible,
                        "The selected profile uses an incompatible version.");
                if (!IsV7Usable(selected))
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.Corrupted,
                        "No authenticated active V7 profile was found.");
                if (selected.SourceContentVersion != 7 || selected.Access != SaveDataAccess.ReadWrite)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.ProtocolConflict,
                        "The selected profile is not a writable V7 profile.");

                ProfileSaveEnvelopeV7 envelope = selected.Envelope;
                if (envelope == null || !envelope.hasActiveExpedition || envelope.activeExpedition == null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.InvalidData,
                        "The selected V7 profile does not contain an active expedition.");
                if (!SaveV7CandidateMapper.TryRestore(envelope, itemCatalog, exactRegistry,
                    out ExpeditionRunConfiguration run, out ExpeditionSaveDataV7 state,
                    out ResolvedEncounterPlanV1 plan, out SaveV7Error error))
                    return F10V7SafeOpenResult.Rejected(this, error);
                if (run == null || state == null || plan == null)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.PlanMismatch,
                        "The pinned expedition could not be restored completely.");
                if (string.IsNullOrWhiteSpace(selected.OriginalJson) ||
                    !RunId.TryParse(state.runId, out RunId restoredRunId) || restoredRunId != run.RunId)
                    return F10V7SafeOpenResult.Rejected(this, SaveV7ErrorCode.PlanMismatch,
                        "The restored baseline, run identity, and exact opening JSON are required.");

                // The one capability is minted only after authenticated restore under this gate.
                // Its JSON is the exact opening snapshot; later commits own their confirmed bytes.
                F10V7SessionHandle sessionHandle = new F10V7SessionHandle(
                    F10V7SessionHandleFactoryKey, this, selected.OriginalJson, run.RunId,
                    itemCatalog, exactRegistry, state);
                F10V7SafeOpenResult result = F10V7SafeOpenResult.Accepted(this, selected, sessionHandle);
                // Prepare the result first; there is no await across latch, selection, or retention.
                LatchV7UnderLock();
                SelectV7UnderLock(selected, validPrimary);
                _f10V7SessionHandle = sessionHandle;
                return result;
            }
            finally { _gate.Release(); }
        }
    }

    internal sealed class F10V7SafeOpenResult
    {
        private F10V7SafeOpenResult(SaveRepository repository, SaveV7LoadView view,
            SaveRepository.F10V7SessionHandle sessionHandle, SaveV7Error error)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            if ((view == null) != (sessionHandle == null))
                throw new ArgumentException("An opened view and its session capability must be supplied together.");
            View = view;
            SessionHandle = sessionHandle;
            Error = error;
            AdmissionArmed = repository.V7V6ProfileWriteAdmissionBarrierArmedSnapshot;
        }

        internal bool Opened => View != null;
        internal SaveV7LoadView View { get; }
        internal SaveRepository.F10V7SessionHandle SessionHandle { get; }
        internal SaveV7Error Error { get; }
        internal bool AdmissionArmed { get; }

        internal static F10V7SafeOpenResult Accepted(SaveRepository repository, SaveV7LoadView view,
            SaveRepository.F10V7SessionHandle sessionHandle) =>
            new F10V7SafeOpenResult(repository, view, sessionHandle, default(SaveV7Error));
        internal static F10V7SafeOpenResult Rejected(SaveRepository repository, SaveV7Error error) =>
            new F10V7SafeOpenResult(repository, null, null, error);
        internal static F10V7SafeOpenResult Rejected(SaveRepository repository, SaveV7ErrorCode code, string message) =>
            Rejected(repository, new SaveV7Error(code, "profile", message));
    }
}
#endif
