#if UNITY_EDITOR
using System;
using System.Linq;
using System.Text;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Builds only the rewardless authenticated V7 Tutorial-to-C1 candidate. This helper does
    /// not establish a physical victory; its caller must supply the exact ConfirmedJson returned
    /// by the handle-bound repository operation and the live resolver's captured receipt.
    /// </summary>
    internal static class F10V7TutorialAdvanceCandidate
    {
        internal const string TutorialNodeId = "sample.tutorial";
        internal const string TutorialTemplateId = "room.sample.tutorial";
        internal const string C1NodeId = "sample.patio.combat";
        internal const string C1TemplateId = "room.patio.c1";

        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        /// <summary>
        /// Builds a temporary common projection for the real actor binder. The projection is
        /// read-only input; the returned object is a detached Tutorial-to-C1 candidate. The App
        /// composition must capture actor state into this candidate before TryCreate persists it.
        /// </summary>
        internal static bool TryCreateCommonCandidate(F10V7ExpeditionReadProjection currentProjection,
            ExpeditionRunConfiguration exactRun, RoomInstanceId sourceRoomId, string resultId,
            string resultJson, out ExpeditionSaveData candidate, out string error)
        {
            candidate = null;
            error = string.Empty;
            if (currentProjection == null || exactRun == null || exactRun.Route == null)
                return Fail("An authenticated current V7 projection and exact run are required.", out error);
            ExpeditionSaveDataV7 prior = currentProjection.SourceStateV7;
            if (!ValidateReceiptAndRoute(prior, exactRun, sourceRoomId, resultId, resultJson, out error)) return false;

            ExpeditionSaveData common = currentProjection.CompositionReadOnlyView;
            if (common == null || !string.Equals(common.currentNodeId, TutorialNodeId, StringComparison.Ordinal))
                return Fail("The current composition projection is not at the authenticated Tutorial cursor.", out error);
            common.completedRoomIds = (common.completedRoomIds ?? Array.Empty<string>())
                .Concat(new[] { TutorialNodeId }).ToArray();
            common.completedRoomResults = (common.completedRoomResults ?? Array.Empty<ExpeditionRoomCompletionSaveData>())
                .Concat(new[] { new ExpeditionRoomCompletionSaveData
                {
                    roomNodeId = TutorialNodeId,
                    resultId = resultId,
                    resultJson = resultJson
                }}).ToArray();
            common.visitedNodeIds = (common.visitedNodeIds ?? Array.Empty<string>())
                .Concat(new[] { C1NodeId }).ToArray();
            common.currentNodeId = C1NodeId;
            common.roomEntryCheckpointJson = null;
            candidate = common;
            return true;
        }

        /// <summary>
        /// Applies only the live binder's common health/inventory capture to a full V7 clone,
        /// preserving the complete profile and all V7-only receipts, counters, pin, and checkpoint
        /// authority. The caller must pass ConfirmedJson from the repository's exact readback.
        /// </summary>
        internal static bool TryCreate(string confirmedJson,
            F10V7ExpeditionReadProjection currentProjection, ExpeditionRunConfiguration exactRun,
            EncounterCatalogRegistryV1 exactRegistry, RoomInstanceId sourceRoomId, string resultId,
            string resultJson, ExpeditionInventory candidateInventory,
            string expectedBaseInventorySnapshotJson, ExpeditionSaveData capturedCommonCandidate,
            out PinnedProfileCandidateV7 candidate, out string error)
        {
            candidate = null;
            error = string.Empty;
            if (string.IsNullOrWhiteSpace(confirmedJson) || currentProjection == null || exactRun == null ||
                exactRun.Route == null || exactRun.Inventory == null || exactRegistry == null ||
                candidateInventory == null || capturedCommonCandidate == null)
                return Fail("Exact confirmed JSON, current projection, run/catalog, actor capture, and inventory are required.", out error);

            ProfileSaveEnvelopeV7 confirmedEnvelope;
            try
            {
                if (!SaveV7JsonCodec.TryDecodeProfile(StrictUtf8.GetBytes(confirmedJson),
                        out confirmedEnvelope, out SaveV7Error decodeError))
                    return Fail(decodeError.Code + ": " + decodeError.Message, out error);
            }
            catch (EncoderFallbackException exception)
            { return Fail("ConfirmedJson is not strict UTF-8: " + exception.Message, out error); }

            if (confirmedEnvelope == null || confirmedEnvelope.profile == null ||
                confirmedEnvelope.activeExpedition == null || confirmedEnvelope.contentVersion != 7 ||
                !SameV7State(confirmedEnvelope.activeExpedition, currentProjection.SourceStateV7))
                return Fail("The read projection is not derived from the exact supplied ConfirmedJson.", out error);

            ExpeditionSaveDataV7 prior = confirmedEnvelope.activeExpedition;
            if (!ValidateReceiptAndRoute(prior, exactRun, sourceRoomId, resultId, resultJson, out error)) return false;
            if (currentProjection.CompositionReadOnlyView == null ||
                !ReferenceEquals(exactRun.Inventory.Catalog, candidateInventory.Catalog) ||
                !string.Equals(exactRun.Inventory.ClassId, candidateInventory.ClassId, StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(expectedBaseInventorySnapshotJson) ||
                !string.Equals(expectedBaseInventorySnapshotJson,
                    JsonUtility.ToJson(candidateInventory.CreateSnapshot()), StringComparison.Ordinal) ||
                !string.Equals(expectedBaseInventorySnapshotJson, capturedCommonCandidate.inventorySnapshotJson,
                    StringComparison.Ordinal))
                return Fail("The rewardless candidate must retain the exact live resolver and actor-captured inventory snapshot.", out error);

            if (!TryBuildExpectedCommonCandidate(currentProjection, exactRun, sourceRoomId, resultId,
                    resultJson, out ExpeditionSaveData expectedCommon, out error)) return false;
            expectedCommon.inventorySnapshotJson = capturedCommonCandidate.inventorySnapshotJson;
            expectedCommon.maximumHealth = capturedCommonCandidate.maximumHealth;
            expectedCommon.currentHealth = capturedCommonCandidate.currentHealth;
            expectedCommon.maximumEnergy = capturedCommonCandidate.maximumEnergy;
            expectedCommon.currentEnergy = capturedCommonCandidate.currentEnergy;
            expectedCommon.healthPotionCharges = capturedCommonCandidate.healthPotionCharges;
            if (!StatesEqual(expectedCommon, capturedCommonCandidate))
                return Fail("The prepared actor publication changed fields outside its allowed live resource snapshot.", out error);

            if (!SaveV7CandidateMapper.TryToDomainPin(prior.encounterPlanPin,
                    out EncounterPlanPinV1 existingPin, out SaveV7Error pinError))
                return Fail(pinError.Code + ": " + pinError.Message, out error);
            if (existingPin.RunId != exactRun.RunId || existingPin.Entry == null ||
                !string.Equals(existingPin.Entry.NodeId, TutorialNodeId, StringComparison.Ordinal) ||
                !exactRegistry.TryGetExact(existingPin.CatalogId, existingPin.CatalogRevision,
                    existingPin.CatalogSha256, out EncounterCatalogManifest manifest,
                    out EncounterCatalogError catalogError))
                return Fail("The exact pinned encounter catalog is unavailable for the Tutorial candidate.", out error);
            if (!EncounterPlanResolverV1.TryResolve(manifest, exactRun, C1NodeId, prior.pactIds,
                    out ResolvedEncounterPlanV1 c1Plan, out EncounterPlanResolutionErrorV1 planError))
                return Fail(planError.Code + ": " + planError.Message, out error);

            EncounterPlanPinV1 nextPin;
            try { nextPin = EncounterPlanPinV1.Append(existingPin, c1Plan, C1NodeId); }
            catch (Exception exception) when (exception is ArgumentException || exception is InvalidOperationException)
            { return Fail("Could not append the exact C1 plan to the admitted pin: " + exception.Message, out error); }

            ExpeditionSaveDataV7 next = SaveV7Clone.Clone(prior);
            next.completedRoomIds = prior.completedRoomIds.Concat(new[] { TutorialNodeId }).ToArray();
            next.completedRoomResults = prior.completedRoomResults.Concat(new[]
            {
                new ExpeditionRoomCompletionSaveDataV7
                {
                    roomNodeId = TutorialNodeId,
                    resultId = resultId,
                    resultJson = resultJson
                }
            }).ToArray();
            next.visitedNodeIds = prior.visitedNodeIds.Concat(new[] { C1NodeId }).ToArray();
            next.currentNodeId = C1NodeId;
            next.inventorySnapshotJson = capturedCommonCandidate.inventorySnapshotJson;
            next.maximumHealth = capturedCommonCandidate.maximumHealth;
            next.currentHealth = capturedCommonCandidate.currentHealth;
            next.maximumEnergy = capturedCommonCandidate.maximumEnergy;
            next.currentEnergy = capturedCommonCandidate.currentEnergy;
            next.healthPotionCharges = capturedCommonCandidate.healthPotionCharges;
            next.encounterPlanPin = SaveV7CandidateMapper.ToPinDto(nextPin);
            // Prepare writes the exact C1 checkpoint after the real actor snapshot has been captured.
            next.roomEntryCheckpointJson = null;

            try
            {
                PinnedProfileCandidateV7 preparedCandidate = SaveV7CandidateMapper.Prepare(
                    confirmedEnvelope.profile, next, nextPin);
                ProfileSaveEnvelopeV7 candidateEnvelope = preparedCandidate.CreateEnvelope(
                    checked(confirmedEnvelope.generation + 1), checked(confirmedEnvelope.sequence + 1),
                    DateTime.UtcNow.ToString("O", System.Globalization.CultureInfo.InvariantCulture));
                if (!SaveV7CandidateMapper.TryValidateCommit(candidateEnvelope, exactRun, exactRegistry,
                        out SaveV7Error validationError) ||
                    !SaveV7CandidateMapper.TryValidateTransition(confirmedEnvelope, null, candidateEnvelope,
                        out validationError))
                    return Fail(validationError.Code + ": " + validationError.Message, out error);
                if (!SaveV7CandidateMapper.HasSameProfilePayload(confirmedEnvelope.profile, candidateEnvelope.profile))
                    return Fail("The Tutorial candidate changed permanent profile data.", out error);

                byte[] encoded = SaveV7JsonCodec.EncodeProfile(candidateEnvelope);
                if (!SaveV7JsonCodec.TryDecodeProfile(encoded, out ProfileSaveEnvelopeV7 roundTrip,
                        out validationError) ||
                    !SaveV7CandidateMapper.TryValidateCommit(roundTrip, exactRun, exactRegistry,
                        out validationError) ||
                    !SaveV7CandidateMapper.TryValidateTransition(confirmedEnvelope, null, roundTrip,
                        out validationError))
                    return Fail(validationError.Code + ": " + validationError.Message, out error);
                if (!SaveV7CandidateMapper.HasSameProfilePayload(confirmedEnvelope.profile, roundTrip.profile) ||
                    !string.Equals(roundTrip.activeExpedition.currentNodeId, C1NodeId, StringComparison.Ordinal) ||
                    roundTrip.activeExpedition.encounterPlanPin.entry == null ||
                    !string.Equals(roundTrip.activeExpedition.encounterPlanPin.entry.nodeId, C1NodeId,
                        StringComparison.Ordinal) ||
                    string.IsNullOrWhiteSpace(roundTrip.activeExpedition.roomEntryCheckpointJson))
                    return Fail("The encoded candidate has no exact preserved profile, C1 pin entry, or rollback checkpoint.", out error);

                candidate = preparedCandidate;
            }
            catch (Exception exception) when (exception is ArgumentException || exception is FormatException ||
                exception is OverflowException || exception is InvalidOperationException ||
                exception is SaveV7ValidationException)
            {
                return Fail("The authenticated Tutorial-to-C1 candidate is invalid: " + exception.Message, out error);
            }

            return true;
        }

        private static bool ValidateReceiptAndRoute(ExpeditionSaveDataV7 prior,
            ExpeditionRunConfiguration exactRun, RoomInstanceId sourceRoomId, string resultId,
            string resultJson, out string error)
        {
            error = string.Empty;
            if (prior == null || !RunId.TryParse(prior.runId, out RunId runId) ||
                runId != exactRun.RunId || sourceRoomId != ExpeditionRoomIdentity.ForNode(runId, TutorialNodeId) ||
                !string.Equals(prior.currentNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                !string.Equals(resultId, "room-result.v1:" + sourceRoomId, StringComparison.Ordinal) ||
                !string.Equals(resultJson, ExpectedCompletionJson(sourceRoomId), StringComparison.Ordinal))
                return Fail("The candidate is not bound to this exact rewardless Tutorial-to-C1 completion receipt.", out error);

            ExpeditionRouteNode tutorial = exactRun.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, TutorialNodeId, StringComparison.Ordinal));
            ExpeditionRouteNode c1 = exactRun.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, C1NodeId, StringComparison.Ordinal));
            ExpeditionRouteConnection[] outgoing = exactRun.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, TutorialNodeId, StringComparison.Ordinal)).ToArray();
            if (tutorial == null || tutorial.Kind != ExpeditionRouteNodeKind.Tutorial ||
                !string.Equals(tutorial.TemplateId, TutorialTemplateId, StringComparison.Ordinal) ||
                c1 == null || c1.Kind != ExpeditionRouteNodeKind.Combat ||
                !string.Equals(c1.TemplateId, C1TemplateId, StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, C1NodeId, StringComparison.Ordinal))
                return Fail("The exact run route does not contain the sole Tutorial-to-C1 edge.", out error);

            if (prior.completedRoomIds == null || prior.completedRoomIds.Contains(TutorialNodeId, StringComparer.Ordinal) ||
                prior.completedRoomResults == null || prior.completedRoomResults.Any(result => result != null &&
                    string.Equals(result.roomNodeId, TutorialNodeId, StringComparison.Ordinal)) ||
                prior.visitedNodeIds == null || prior.visitedNodeIds.Length == 0 ||
                !string.Equals(prior.visitedNodeIds[prior.visitedNodeIds.Length - 1], TutorialNodeId, StringComparison.Ordinal))
                return Fail("The authenticated Tutorial state is already completed or has inconsistent route history.", out error);
            return true;
        }

        private static bool TryBuildExpectedCommonCandidate(F10V7ExpeditionReadProjection currentProjection,
            ExpeditionRunConfiguration exactRun, RoomInstanceId sourceRoomId, string resultId,
            string resultJson, out ExpeditionSaveData candidate, out string error)
        {
            candidate = null;
            error = string.Empty;
            if (!TryCreateCommonCandidate(currentProjection, exactRun, sourceRoomId, resultId,
                    resultJson, out candidate, out error)) return false;
            return true;
        }

        private static bool SameV7State(ExpeditionSaveDataV7 left, ExpeditionSaveDataV7 right)
        {
            return left != null && right != null &&
                string.Equals(JsonUtility.ToJson(left), JsonUtility.ToJson(right), StringComparison.Ordinal);
        }

        private static bool StatesEqual(ExpeditionSaveData left, ExpeditionSaveData right)
        {
            return left != null && right != null &&
                string.Equals(JsonUtility.ToJson(left), JsonUtility.ToJson(right), StringComparison.Ordinal);
        }

        private static string ExpectedCompletionJson(RoomInstanceId sourceRoomId)
        {
            return "{\"schema\":1,\"outcome\":\"cleared\",\"roomInstanceId\":\"" +
                sourceRoomId + "\",\"sourceNodeId\":\"sample.tutorial\",\"targetNodeId\":\"sample.patio.combat\",\"rewardIds\":[]}";
        }

        private static bool Fail(string message, out string error)
        {
            error = message ?? "The V7 tutorial candidate is invalid.";
            return false;
        }
    }
}
#endif
