#if UNITY_EDITOR
using System;
using System.Text;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Fortune;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// A read-only composition adapter. The V7 source and selected restored/current states remain
    /// attached so V7-only authority is not discarded when a V6-shaped consumer view is requested.
    /// </summary>
    internal sealed class F10V7ExpeditionReadProjection
    {
        private readonly ExpeditionSaveDataV7 _sourceState;
        private readonly ExpeditionSaveDataV7 _restoredState;
        private readonly ExpeditionRoomCheckpointSaveDataV7 _checkpointAuthority;
        private readonly ExpeditionSaveData _compositionReadOnlyView;

        internal F10V7ExpeditionReadProjection(ExpeditionSaveDataV7 sourceState,
            ExpeditionSaveDataV7 restoredState, ExpeditionRoomCheckpointSaveDataV7 checkpointAuthority,
            ExpeditionSaveData compositionReadOnlyView)
        {
            _sourceState = SaveV7Clone.Clone(sourceState);
            _restoredState = SaveV7Clone.Clone(restoredState);
            _checkpointAuthority = SaveV7Clone.Clone(checkpointAuthority);
            _compositionReadOnlyView = compositionReadOnlyView == null ? null : compositionReadOnlyView.Clone();
        }

        /// <summary>The authenticated V7 state before the composition rollback view was calculated.</summary>
        internal ExpeditionSaveDataV7 SourceStateV7 => SaveV7Clone.Clone(_sourceState);

        /// <summary>The selected V7 state: entry rollback on resume or current authenticated state after commit.</summary>
        internal ExpeditionSaveDataV7 RestoredStateV7 => SaveV7Clone.Clone(_restoredState);

        /// <summary>Exact typed checkpoint authority, including the V7-only encounter entry.</summary>
        internal ExpeditionRoomCheckpointSaveDataV7 CheckpointAuthorityV7 =>
            SaveV7Clone.Clone(_checkpointAuthority);

        /// <summary>Detached V6-shaped data for composition reads only; never persist this value.</summary>
        internal ExpeditionSaveData CompositionReadOnlyView =>
            _compositionReadOnlyView == null ? null : _compositionReadOnlyView.Clone();
    }

    /// <summary>V7-to-V6-shaped, read-only composition projection. It has no save or mutation API.</summary>
    internal static class F10V7ExpeditionReadProjector
    {
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        internal static bool TryCreate(ProfileSaveEnvelopeV7 envelope, ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 exactRegistry, out F10V7ExpeditionReadProjection projection,
            out SaveV7Error error)
        {
            return TryCreateCore(envelope, itemCatalog, exactRegistry, restoreEntry: true,
                out projection, out error);
        }

        /// <summary>
        /// Projects the authenticated current durable state after a confirmed session commit.
        /// It does not roll back the current room or authorize a physical outcome.
        /// </summary>
        internal static bool TryCreateCurrent(ProfileSaveEnvelopeV7 envelope, ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 exactRegistry, out F10V7ExpeditionReadProjection projection,
            out SaveV7Error error)
        {
            return TryCreateCore(envelope, itemCatalog, exactRegistry, restoreEntry: false,
                out projection, out error);
        }

        private static bool TryCreateCore(ProfileSaveEnvelopeV7 envelope, ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 exactRegistry, bool restoreEntry,
            out F10V7ExpeditionReadProjection projection, out SaveV7Error error)
        {
            projection = null;
            ProfileSaveEnvelopeV7 stableEnvelope = SaveV7Clone.Clone(envelope);
            ExpeditionRunConfiguration run;
            ExpeditionSaveDataV7 restoredState;
            ResolvedEncounterPlanV1 resolvedPlan;
            bool restored = restoreEntry
                ? SaveV7CandidateMapper.TryRestore(stableEnvelope, itemCatalog, exactRegistry,
                    out run, out restoredState, out resolvedPlan, out error)
                : SaveV7CandidateMapper.TryRestoreCurrentForSettlement(stableEnvelope, itemCatalog, exactRegistry,
                    out run, out restoredState, out resolvedPlan, out error);
            if (!restored) return false;
            if (stableEnvelope == null || stableEnvelope.activeExpedition == null || run == null ||
                restoredState == null || resolvedPlan == null)
                return Fail("activeExpedition", "An authenticated active V7 state and its typed plan are required.",
                    out projection, out error);
            if (restoredState.fortuneOfferBookSnapshot == null)
                return Fail("activeExpedition.fortuneOfferBookSnapshot",
                    "The V7 fortune book has no exact V6-shaped projection.", out projection, out error);

            if (!TryProjectCheckpoint(restoredState.roomEntryCheckpointJson,
                out string v6CheckpointJson, out ExpeditionRoomCheckpointSaveDataV7 checkpointAuthority,
                out error)) return false;

            ExpeditionSaveData compositionView;
            try
            {
                compositionView = new ExpeditionSaveData
                {
                    runId = restoredState.runId,
                    seed = restoredState.seed,
                    generationVersion = restoredState.generationVersion,
                    contentVersion = restoredState.contentVersion,
                    classId = restoredState.classId,
                    raceId = restoredState.raceId,
                    selectedSkillIds = Copy(restoredState.selectedSkillIds),
                    startingEquipmentInstanceIds = Copy(restoredState.startingEquipmentInstanceIds),
                    routeSnapshotJson = restoredState.routeSnapshotJson,
                    currentNodeId = restoredState.currentNodeId,
                    visitedNodeIds = Copy(restoredState.visitedNodeIds),
                    completedRoomIds = Copy(restoredState.completedRoomIds),
                    completedRoomResults = ProjectCompletions(restoredState.completedRoomResults),
                    roomEntryCheckpointJson = v6CheckpointJson,
                    inventorySnapshotJson = restoredState.inventorySnapshotJson,
                    maximumHealth = restoredState.maximumHealth,
                    currentHealth = restoredState.currentHealth,
                    maximumEnergy = restoredState.maximumEnergy,
                    currentEnergy = restoredState.currentEnergy,
                    healthPotionCharges = restoredState.healthPotionCharges,
                    frozenPermanentUpgrades = ProjectUpgrades(restoredState.frozenPermanentUpgrades),
                    hasFrozenPermanentUpgrades = restoredState.hasFrozenPermanentUpgrades,
                    accumulatedRenown = restoredState.accumulatedRenown,
                    pactIds = Copy(restoredState.pactIds),
                    fortuneOfferBookSnapshot = ProjectFortuneBook(restoredState.fortuneOfferBookSnapshot),
                    collectedItemIds = Copy(restoredState.collectedItemIds),
                    claimedRewardIds = Copy(restoredState.claimedRewardIds)
                };
            }
            catch (Exception exception)
            {
                return Fail("activeExpedition", "A V6-shaped read view could not be built: " + exception.Message,
                    out projection, out error);
            }

            projection = new F10V7ExpeditionReadProjection(stableEnvelope.activeExpedition,
                restoredState, checkpointAuthority, compositionView);
            error = default(SaveV7Error);
            return true;
        }

        private static bool TryProjectCheckpoint(string v7Json, out string v6Json,
            out ExpeditionRoomCheckpointSaveDataV7 authority, out SaveV7Error error)
        {
            v6Json = v7Json;
            authority = null;
            error = default(SaveV7Error);
            if (string.IsNullOrWhiteSpace(v7Json)) return true;

            ExpeditionRoomCheckpointSaveDataV7 v7Checkpoint;
            try
            {
                if (!SaveV7JsonCodec.TryDecodeCheckpoint(StrictUtf8.GetBytes(v7Json),
                    out v7Checkpoint, out error)) return false;
            }
            catch (Exception exception)
            {
                error = new SaveV7Error(SaveV7ErrorCode.InvalidData,
                    "activeExpedition.roomEntryCheckpointJson", exception.Message);
                return false;
            }

            // V6 has no encounterEntry field. Keep the exact V7 checkpoint and pin attached to
            // the projection; only the common resource fields are serialized into the transient
            // V6-shaped view. TryRestore has already validated this checkpoint against the pin.
            var v6Checkpoint = new ExpeditionRoomCheckpointSaveData
            {
                roomNodeId = v7Checkpoint.roomNodeId,
                inventorySnapshotJson = v7Checkpoint.inventorySnapshotJson,
                maximumHealth = v7Checkpoint.maximumHealth,
                currentHealth = v7Checkpoint.currentHealth,
                maximumEnergy = v7Checkpoint.maximumEnergy,
                currentEnergy = v7Checkpoint.currentEnergy,
                healthPotionCharges = v7Checkpoint.healthPotionCharges,
                accumulatedRenown = v7Checkpoint.accumulatedRenown,
                fortuneOfferBookSnapshot = ProjectFortuneBook(v7Checkpoint.fortuneOfferBookSnapshot),
                pactIds = Copy(v7Checkpoint.pactIds),
                collectedItemIds = Copy(v7Checkpoint.collectedItemIds),
                claimedRewardIds = Copy(v7Checkpoint.claimedRewardIds)
            };
            try
            {
                v6Json = JsonUtility.ToJson(v6Checkpoint);
                if (string.IsNullOrWhiteSpace(v6Json))
                {
                    error = new SaveV7Error(SaveV7ErrorCode.InvalidData,
                        "activeExpedition.roomEntryCheckpointJson", "Unity did not serialize the V6-shaped read checkpoint.");
                    return false;
                }
            }
            catch (Exception exception)
            {
                error = new SaveV7Error(SaveV7ErrorCode.InvalidData,
                    "activeExpedition.roomEntryCheckpointJson", exception.Message);
                return false;
            }

            authority = SaveV7Clone.Clone(v7Checkpoint);
            error = default(SaveV7Error);
            return true;
        }

        private static ExpeditionRoomCompletionSaveData[] ProjectCompletions(
            ExpeditionRoomCompletionSaveDataV7[] source)
        {
            if (source == null) return null;
            var result = new ExpeditionRoomCompletionSaveData[source.Length];
            for (int index = 0; index < source.Length; index++)
            {
                ExpeditionRoomCompletionSaveDataV7 item = source[index];
                result[index] = item == null ? null : new ExpeditionRoomCompletionSaveData
                {
                    roomNodeId = item.roomNodeId,
                    resultId = item.resultId,
                    resultJson = item.resultJson
                };
            }
            return result;
        }

        private static ExpeditionPermanentUpgradeSnapshotSaveData ProjectUpgrades(
            ExpeditionPermanentUpgradeSnapshotSaveDataV7 source)
        {
            return source == null ? null : new ExpeditionPermanentUpgradeSnapshotSaveData
            {
                healthUpgradeLevel = source.healthUpgradeLevel,
                energyUpgradeLevel = source.energyUpgradeLevel,
                additionalPotionUpgradeLevel = source.additionalPotionUpgradeLevel
            };
        }

        private static FortuneOfferBookSnapshot ProjectFortuneBook(FortuneOfferBookSnapshotV7 source)
        {
            if (source == null) return null;
            var result = new FortuneOfferBookSnapshot
            {
                snapshotVersion = source.snapshotVersion,
                generationVersion = source.generationVersion,
                seed = source.seed,
                raceId = source.raceId,
                charges = source.charges,
                processedGuardianIds = Copy(source.processedGuardianIds),
                offers = source.offers == null ? null : new FortuneOfferSnapshot[source.offers.Length],
                rerollReceipts = source.rerollReceipts == null
                    ? null : new FortuneRerollReceiptSnapshot[source.rerollReceipts.Length],
                fortuneBrewReceipts = source.fortuneBrewReceipts == null
                    ? null : new FortuneBrewReceiptSnapshot[source.fortuneBrewReceipts.Length]
            };
            if (source.offers != null)
                for (int i = 0; i < source.offers.Length; i++)
                {
                    FortuneOfferSnapshotV7 offer = source.offers[i];
                    result.offers[i] = offer == null ? null : new FortuneOfferSnapshot
                    {
                        offerId = offer.offerId,
                        contextId = offer.contextId,
                        eligibleOptionIds = Copy(offer.eligibleOptionIds),
                        selectedOptionId = offer.selectedOptionId,
                        claimed = offer.claimed,
                        history = offer.history == null ? null : new FortuneOfferHistorySnapshot[offer.history.Length]
                    };
                    if (offer != null && offer.history != null)
                        for (int h = 0; h < offer.history.Length; h++)
                            result.offers[i].history[h] = offer.history[h] == null ? null :
                                new FortuneOfferHistorySnapshot { optionIds = Copy(offer.history[h].optionIds) };
                }
            if (source.rerollReceipts != null)
                for (int i = 0; i < source.rerollReceipts.Length; i++)
                {
                    FortuneRerollReceiptSnapshotV7 receipt = source.rerollReceipts[i];
                    result.rerollReceipts[i] = receipt == null ? null : new FortuneRerollReceiptSnapshot
                    {
                        transactionId = receipt.transactionId,
                        offerId = receipt.offerId,
                        status = receipt.status,
                        contextId = receipt.contextId,
                        optionIds = Copy(receipt.optionIds),
                        selectedOptionId = receipt.selectedOptionId,
                        rerollCount = receipt.rerollCount,
                        claimed = receipt.claimed,
                        remainingCharges = receipt.remainingCharges,
                        hasOffer = receipt.hasOffer
                    };
                }
            if (source.fortuneBrewReceipts != null)
                for (int i = 0; i < source.fortuneBrewReceipts.Length; i++)
                {
                    FortuneBrewReceiptSnapshotV7 receipt = source.fortuneBrewReceipts[i];
                    result.fortuneBrewReceipts[i] = receipt == null ? null : new FortuneBrewReceiptSnapshot
                    {
                        transactionId = receipt.transactionId,
                        itemInstanceId = receipt.itemInstanceId,
                        status = receipt.status,
                        currentCharges = receipt.currentCharges
                    };
                }
            return result;
        }

        private static string[] Copy(string[] source) => source == null ? null : (string[])source.Clone();

        private static bool Fail(string path, string message,
            out F10V7ExpeditionReadProjection projection, out SaveV7Error error)
        {
            projection = null;
            error = new SaveV7Error(SaveV7ErrorCode.InvalidData, path, message);
            return false;
        }
    }
}
#endif
