#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;

namespace Luckbound.App
{
    [Serializable]
    public sealed class F10DiagnosticMaterializationReceipt
    {
        public int schemaVersion;
        public string status;
        public string copyRoot;
        public string copyCertificateSha256;
        public F10DiagnosticMaterializedOutput[] outputs;
        public F10DiagnosticGeneratorFile[] generatorFiles;
        public F10DiagnosticDependencyClosure[] dependencies;
        public F10DiagnosticPackageDependencyEvidence[] packageDependencies;
        public string[] createdDirectories;
    }

    [Serializable]
    public sealed class F10DiagnosticMaterializedOutput
    {
        public string path;
        public string sha256;
        public long length;
        public string identity;
        public uint linkCount;
    }

    [Serializable]
    public sealed class F10DiagnosticGeneratorFile
    {
        public string path;
        public string sha256;
    }

    [Serializable]
    public sealed class F10DiagnosticDependencyClosure
    {
        public string assetPath;
        public string[] dependencyPaths;
    }

    /// <summary>
    /// Re-measures the certified F10 diagnostic copy and its imported dependency closures in the Editor.
    /// This file is excluded from player builds and contains no caller-supplied authority delegate.
    /// </summary>
    public static class F10DiagnosticMaterializationReceiptValidator
    {
        public const string CertificateRelativePath = "Logs/F10DisposableArt-20261116/copy-certificate.json";
        public const string PreflightRelativePath = "Logs/F10V6Resume-20261120/copy-preflight-receipt.json";
        public const string ReceiptRelativePath = "Logs/F10V6Resume-20261120/materialization-receipt.json";
        private const string ApprovedCopiesRootRelativePath = "Logs/F10DisposableArt-20261116/copies";
        private const string OverlayBuilderRunRootRelativePath = "Logs/F10V6OverlayBuilderFix-20261120/runs";
        private const string OverlayBuilderChainReceiptRelativePath = "Logs/F10V6OverlayBuilderFix-20261120/receipts/03-final-copy-verified.json";
        private const string FixtureImporterProjectPath = "Assets/Luckbound/Editor/Diagnostic/F10DisposableArtReferenceImporter.cs";
        private const string FixtureImporterMetaProjectPath = FixtureImporterProjectPath + ".meta";
        private const string FixtureSourceRootRelativePath = "docs/technical-f10/disposable-unity/art-fixture/";
        private const string ExpectedUnityVersion = "6000.6.10f1";
        private const string PackagesLockRelativePath = "Packages/packages-lock.json";
        private const string EmbeddedCorePackageName = "com.unity.render-pipelines.core";
        private const string EmbeddedCoreAssetRoot = "Packages/" + EmbeddedCorePackageName;
        private const StringComparison WindowsPathComparison = StringComparison.OrdinalIgnoreCase;
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);
        private static readonly string[] InventoryRoots = { "Assets", "Packages", "ProjectSettings" };
        private static readonly string[] CertifiedExternalFiles =
        {
            "docs/art/F01_bellator_32x48.png",
            "docs/art/F01_master_reference.md",
            "docs/art/records/ART-F01-BELLATOR-32X48.v1.json"
        };
        private static readonly string[] RequiredAssetPaths =
        {
            "Assets/Luckbound/Editor/Diagnostic/F10Diagnostic.unity",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10TutorialDiagnostic.prefab",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioCombatC1Diagnostic.prefab",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioExplorationE1Diagnostic.prefab",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioGuardianDiagnostic.prefab",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10SafeExtractionDiagnostic.prefab",
            "Assets/Luckbound/Editor/Diagnostic/Shared/StonePrototypeDiagnosticTile.asset",
            "Assets/Luckbound/Editor/Diagnostic/F10TechnicalDiagnosticPlayer.prefab",
            "Assets/Luckbound/Editor/Diagnostic/F10GoldCache/F10ExplorationGoldCacheDiagnostic.prefab"
        };
        private static readonly string[] GeneratorSourcePaths =
        {
            "Assets/Luckbound/Editor/F10DiagnosticSceneGenerator.cs",
            "Assets/Luckbound/Editor/F10TechnicalDiagnosticPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10RoomTemplatePrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10TechnicalDiagnosticPlayerPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10PhysicalGoldCacheDiagnosticPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10DiagnosticMaterializationReceiptExporter.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticMaterializationReceiptValidator.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticPackageDependencyEvidence.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticSceneRunner.cs",
            "Assets/Luckbound/Scripts/App/ApplicationBootstrapper.F10Diagnostic.cs"
        };
        private static readonly HashSet<string> F02BlockPaths = new HashSet<string>(StringComparer.Ordinal)
        {
            "Assets/Luckbound/Editor/F02ImportStaging",
            "Assets/Luckbound/Editor/F02ImportStaging.meta",
            "ProjectSettings/Luckbound/F02ImportRecovery/pending",
            "Library/Luckbound/F02/Transactions"
        };

        /// <summary>Called by the F10 Editor-only bootstrapper before it creates or resumes a run.</summary>
        public static void ValidateForRuntime(string projectRoot)
        {
            string root = CanonicalPath(projectRoot);
            F10DiagnosticCopyCertificate certificate = ReadCertificate(root);
            MaterializationPreflightReceipt preflight = ReadPreflight(root);
            F10DiagnosticMaterializationReceipt receipt = ReadReceipt(root);
            ValidateCopyContext(root, certificate, preflight, requireFreshPreflight: false);
            ValidateMaterialization(root, certificate, receipt);
        }

        /// <summary>Entry gate for the Editor generator; requires a fresh external preflight and an empty allowlist.</summary>
        public static void VerifyCertifiedBaseBeforeMaterialization(string projectRoot)
        {
            string root = CanonicalPath(projectRoot);
            F10DiagnosticCopyCertificate certificate = ReadCertificate(root);
            MaterializationPreflightReceipt preflight = ReadPreflight(root);
            ValidateCopyContext(root, certificate, preflight, requireFreshPreflight: true);
            VerifyBaseInventory(root, certificate, outputPaths: Array.Empty<string>(), createdDirectories: Array.Empty<string>());

            if (ExistsAsAnyEntry(AbsolutePath(root, ReceiptRelativePath)))
                throw new IOException("A materialization receipt already exists; existing evidence was preserved.");
            foreach (string path in BuildRequiredOutputFiles())
            {
                if (ExistsAsAnyEntry(AbsolutePath(root, path)) ||
                    AssetDatabase.LoadMainAssetAtPath(path) != null)
                    throw new IOException("An F10 output destination is occupied; existing content was preserved: " + path);
            }

            foreach (string path in GeneratorSourcePaths)
            {
                F10DiagnosticCopyCertificateFile row = FindCertificateFile(certificate, path);
                if (row == null || !IsSha256(row.sha256))
                    throw new InvalidDataException("A generator or Editor source is not part of the immutable base certificate: " + path);
                VerifyBaseFile(root, row);
            }
        }

        /// <summary>Re-measures a prospective receipt before a create-only write.</summary>
        public static void ValidateMeasuredReceipt(string projectRoot, F10DiagnosticMaterializationReceipt receipt)
        {
            string root = CanonicalPath(projectRoot);
            F10DiagnosticCopyCertificate certificate = ReadCertificate(root);
            MaterializationPreflightReceipt preflight = ReadPreflight(root);
            ValidateCopyContext(root, certificate, preflight, requireFreshPreflight: true);
            ValidateMaterialization(root, certificate, receipt);
        }

        /// <summary>
        /// Captures the live AssetDatabase dependency closures and their uncovered package evidence.
        /// The certificate and fresh external preflight are revalidated before querying packages.
        /// </summary>
        public static F10DiagnosticDependencyClosure[] CaptureMeasuredDependencies(string projectRoot,
            IEnumerable<string> createdOutputDirectories,
            out F10DiagnosticPackageDependencyEvidence[] packageDependencies)
        {
            string root = CanonicalPath(projectRoot);
            F10DiagnosticCopyCertificate certificate = ReadCertificate(root);
            MaterializationPreflightReceipt preflight = ReadPreflight(root);
            ValidateCopyContext(root, certificate, preflight, requireFreshPreflight: true);
            Dictionary<string, F10DiagnosticCopyCertificateFile> certificateRows = BuildCertificateMap(certificate);
            var allowedOutputSet = new HashSet<string>(BuildRequiredOutputFiles(), StringComparer.Ordinal);
            if (createdOutputDirectories == null)
                throw new InvalidDataException("Created output directories must be measured before dependency capture.");
            foreach (string directory in createdOutputDirectories)
                allowedOutputSet.Add(NormalizeRelativePath(directory) + ".meta");
            F10DiagnosticDependencyClosure[] closures = CaptureLiveDependencyClosures(root, certificateRows,
                allowedOutputSet, out string[] packageAssetPaths);
            string lockSha256 = GetCertifiedPackagesLockSha256(root, certificateRows);
            packageDependencies = F10DiagnosticPackageDependencyEvidenceReader.Capture(root,
                packageAssetPaths, lockSha256);
            ValidatePackageDependencyEvidenceShape(packageDependencies, packageAssetPaths);
            return closures;
        }

        private static void ValidateMaterialization(string root, F10DiagnosticCopyCertificate certificate,
            F10DiagnosticMaterializationReceipt receipt)
        {
            if (receipt == null || receipt.schemaVersion != 2 ||
                !string.Equals(receipt.status, "measured", StringComparison.Ordinal) ||
                !PathEquals(receipt.copyRoot, root) || !IsSha256(receipt.copyCertificateSha256) ||
                !string.Equals(receipt.copyCertificateSha256, HashFile(AbsolutePath(root, CertificateRelativePath)), StringComparison.Ordinal))
                throw new InvalidDataException("The measured receipt is missing, malformed, or bound to another copy certificate/root.");

            var certificateRows = BuildCertificateMap(certificate);
            string[] allowedOutputs = ValidateAndGetOutputPaths(root, certificateRows, receipt);
            VerifyBaseInventory(root, certificate, allowedOutputs, receipt.createdDirectories);
            VerifyGeneratorFiles(root, certificateRows, receipt);
            VerifyDependencyClosures(root, certificateRows, receipt);
        }

        private static void VerifyGeneratorFiles(string root,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows,
            F10DiagnosticMaterializationReceipt receipt)
        {
            if (receipt.generatorFiles == null || receipt.generatorFiles.Length != GeneratorSourcePaths.Length)
                throw new InvalidDataException("The measured receipt must bind every F10 materializer and Editor receiver source.");

            var rows = new Dictionary<string, F10DiagnosticGeneratorFile>(StringComparer.Ordinal);
            foreach (F10DiagnosticGeneratorFile row in receipt.generatorFiles)
            {
                string path = NormalizeRelativePath(row == null ? null : row.path);
                if (row == null || !IsSha256(row.sha256) || rows.ContainsKey(path))
                    throw new InvalidDataException("The generator source inventory contains an invalid or duplicate row.");
                rows.Add(path, row);
            }

            foreach (string path in GeneratorSourcePaths)
            {
                if (!rows.TryGetValue(path, out F10DiagnosticGeneratorFile measured) ||
                    !certificateRows.TryGetValue(path, out F10DiagnosticCopyCertificateFile certified) ||
                    !string.Equals(measured.sha256, certified.sha256, StringComparison.Ordinal))
                    throw new InvalidDataException("Generator or Editor source bytes do not match the immutable certificate: " + path);
                VerifyBaseFile(root, certified);
            }
        }

        private static void VerifyDependencyClosures(string root,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows,
            F10DiagnosticMaterializationReceipt receipt)
        {
            if (receipt.dependencies == null || receipt.dependencies.Length != RequiredAssetPaths.Length)
                throw new InvalidDataException("The receipt must contain one real AssetDatabase dependency closure per F10 root asset.");

            var rows = new Dictionary<string, F10DiagnosticDependencyClosure>(StringComparer.Ordinal);
            foreach (F10DiagnosticDependencyClosure row in receipt.dependencies)
            {
                string path = NormalizeRelativePath(row == null ? null : row.assetPath);
                if (row == null || rows.ContainsKey(path) || row.dependencyPaths == null)
                    throw new InvalidDataException("The dependency inventory contains a missing, malformed, or duplicate root.");
                rows.Add(path, row);
            }

            var allowedOutputSet = new HashSet<string>(BuildRequiredOutputFiles(), StringComparer.Ordinal);
            foreach (F10DiagnosticMaterializedOutput output in receipt.outputs)
                allowedOutputSet.Add(NormalizeRelativePath(output.path));
            if (receipt.createdDirectories == null)
                throw new InvalidDataException("The measured output directory inventory is missing.");
            foreach (string directory in receipt.createdDirectories)
                allowedOutputSet.Add(NormalizeRelativePath(directory) + ".meta");

            string[] packageAssetPaths;
            F10DiagnosticDependencyClosure[] current = CaptureLiveDependencyClosures(root, certificateRows,
                allowedOutputSet, out packageAssetPaths);
            foreach (F10DiagnosticDependencyClosure actual in current)
            {
                if (!rows.TryGetValue(actual.assetPath, out F10DiagnosticDependencyClosure measured))
                    throw new InvalidDataException("A required F10 AssetDatabase closure is missing: " + actual.assetPath);
                string[] recorded = measured.dependencyPaths.Select(NormalizeRelativePath)
                    .Distinct(StringComparer.Ordinal).OrderBy(path => path, StringComparer.Ordinal).ToArray();
                if (!actual.dependencyPaths.SequenceEqual(recorded, StringComparer.Ordinal))
                    throw new InvalidDataException("AssetDatabase dependency closure changed from the measured receipt: " + actual.assetPath);
            }

            ValidatePackageDependencyEvidenceShape(receipt.packageDependencies, packageAssetPaths);
            string lockSha256 = GetCertifiedPackagesLockSha256(root, certificateRows);
            F10DiagnosticPackageDependencyEvidenceReader.ValidateRecorded(root, receipt.packageDependencies,
                packageAssetPaths, lockSha256);
        }

        private static F10DiagnosticDependencyClosure[] CaptureLiveDependencyClosures(string root,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows,
            ISet<string> allowedOutputSet, out string[] packageAssetPaths)
        {
            var packagePaths = new SortedSet<string>(StringComparer.Ordinal);
            var result = new List<F10DiagnosticDependencyClosure>(RequiredAssetPaths.Length);
            foreach (string rootAssetPath in RequiredAssetPaths.OrderBy(path => path, StringComparer.Ordinal))
            {
                UnityEngine.Object rootAsset = AssetDatabase.LoadMainAssetAtPath(rootAssetPath);
                if (rootAsset == null || !AssetDatabase.Contains(rootAsset) ||
                    !string.Equals(AssetDatabase.GetAssetPath(rootAsset), rootAssetPath, StringComparison.Ordinal))
                    throw new InvalidDataException("The F10 dependency root is not the exact imported AssetDatabase asset: " + rootAssetPath);

                string[] actual = AssetDatabase.GetDependencies(rootAssetPath, true)
                    .Select(NormalizeRelativePath).Distinct(StringComparer.Ordinal)
                    .Concat(new[] { rootAssetPath }).Distinct(StringComparer.Ordinal)
                    .OrderBy(path => path, StringComparer.Ordinal).ToArray();
                result.Add(new F10DiagnosticDependencyClosure { assetPath = rootAssetPath, dependencyPaths = actual });

                foreach (string dependencyPath in actual)
                {
                    if (allowedOutputSet.Contains(dependencyPath))
                        continue;

                    string classification = ClassifyDependencyPath(dependencyPath,
                        certificateRows.ContainsKey(dependencyPath));
                    if (classification == "embedded-core-candidate")
                    {
                        VerifyEmbeddedCoreDependency(root, dependencyPath, certificateRows);
                        continue;
                    }
                    if (classification == "certified-base")
                    {
                        VerifyBaseFile(root, certificateRows[dependencyPath]);
                        continue;
                    }
                    if (classification == "package-helper")
                    {
                        packagePaths.Add(dependencyPath);
                        continue;
                    }
                    if (classification == "unrepresentable-package")
                        throw new InvalidDataException("AssetDatabase returned a package-cache path without its exact Packages/ asset path: " + dependencyPath);
                    throw new InvalidDataException("A real AssetDatabase dependency is neither certified base nor an allowed output: " + dependencyPath);
                }
            }

            packageAssetPaths = packagePaths.ToArray();
            return result.ToArray();
        }

        /// <summary>Pure path classifier. Core is only a candidate until PackageInfo and certificate checks pass.</summary>
        internal static string ClassifyDependencyPath(string rawPath, bool certificateCoversPath)
        {
            string path = NormalizeRelativePath(rawPath);
            if (string.Equals(path, EmbeddedCoreAssetRoot, StringComparison.Ordinal) ||
                path.StartsWith(EmbeddedCoreAssetRoot + "/", StringComparison.Ordinal))
                return "embedded-core-candidate";
            if (certificateCoversPath) return "certified-base";
            if (path.StartsWith("Packages/", StringComparison.Ordinal)) return "package-helper";
            if (path.StartsWith("Library/PackageCache/", StringComparison.Ordinal) ||
                path.StartsWith("Library/PackageManager/", StringComparison.Ordinal))
                return "unrepresentable-package";
            return "uncovered";
        }

        /// <summary>Rejects receipts that omit, duplicate, or broaden the exact live helper package subset.</summary>
        internal static void ValidatePackageDependencyEvidenceShape(
            F10DiagnosticPackageDependencyEvidence[] recorded, IEnumerable<string> actualPackageAssetPaths)
        {
            if (recorded == null || actualPackageAssetPaths == null)
                throw new InvalidDataException("The exact live package subset and its evidence inventory are required.");

            var actual = new SortedSet<string>(StringComparer.Ordinal);
            foreach (string rawPath in actualPackageAssetPaths)
            {
                string path = NormalizeRelativePath(rawPath);
                if (!path.StartsWith("Packages/", StringComparison.Ordinal) || !actual.Add(path))
                    throw new InvalidDataException("The live package subset contains an unsupported or duplicate AssetDatabase path: " + path);
            }

            var recordedPaths = new HashSet<string>(StringComparer.Ordinal);
            foreach (F10DiagnosticPackageDependencyEvidence row in recorded)
            {
                if (row == null || row.schemaVersion != 2 || string.IsNullOrWhiteSpace(row.packageName) ||
                    string.IsNullOrWhiteSpace(row.resolvedRootRelativePath) || row.dependencyAssetPaths == null || row.files == null)
                    throw new InvalidDataException("A package dependency evidence row is incomplete.");
                foreach (string rawPath in row.dependencyAssetPaths)
                {
                    string path = NormalizeRelativePath(rawPath);
                    if (!path.StartsWith("Packages/", StringComparison.Ordinal) || !recordedPaths.Add(path))
                        throw new InvalidDataException("The package evidence paths contain an unsupported or duplicate dependency: " + path);
                }
            }

            if (!actual.SetEquals(recordedPaths))
                throw new InvalidDataException("The package receipt does not cover the exact live, certificate-uncovered package dependency set.");
        }

        private static void VerifyEmbeddedCoreDependency(string root, string dependencyPath,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows)
        {
            if (!certificateRows.TryGetValue(dependencyPath, out F10DiagnosticCopyCertificateFile certifiedDependency))
                throw new InvalidDataException("Embedded Core dependency bytes are not covered by the copy certificate: " + dependencyPath);
            string sidecarPath = dependencyPath + ".meta";
            if (!certificateRows.TryGetValue(sidecarPath, out F10DiagnosticCopyCertificateFile certifiedSidecar))
                throw new InvalidDataException("Embedded Core dependency metadata is not covered by the copy certificate: " + sidecarPath);
            VerifyBaseFile(root, certifiedDependency);
            VerifyBaseFile(root, certifiedSidecar);

            PackageInfo byAssetPath = PackageInfo.FindForAssetPath(dependencyPath);
            PackageInfo byName = PackageInfo.FindForPackageName(EmbeddedCorePackageName);
            if (byAssetPath == null || byName == null ||
                byAssetPath.source != PackageSource.Embedded || byName.source != PackageSource.Embedded ||
                !string.Equals(byAssetPath.name, EmbeddedCorePackageName, StringComparison.Ordinal) ||
                !string.Equals(byName.name, EmbeddedCorePackageName, StringComparison.Ordinal) ||
                !string.Equals(byAssetPath.assetPath, EmbeddedCoreAssetRoot, StringComparison.Ordinal) ||
                !string.Equals(byName.assetPath, EmbeddedCoreAssetRoot, StringComparison.Ordinal) ||
                !string.Equals(byAssetPath.version, byName.version, StringComparison.Ordinal) ||
                !string.Equals(byAssetPath.packageId, byName.packageId, StringComparison.Ordinal) ||
                !PathEquals(byAssetPath.resolvedPath, byName.resolvedPath) ||
                !string.Equals(byAssetPath.assetPath, byName.assetPath, StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(byAssetPath.version) ||
                !(string.Equals(dependencyPath, EmbeddedCoreAssetRoot, StringComparison.Ordinal) ||
                  dependencyPath.StartsWith(EmbeddedCoreAssetRoot + "/", StringComparison.Ordinal)))
                throw new InvalidDataException("Embedded Core PackageInfo does not identify the exact certified copy package for " + dependencyPath);

            string expectedRoot = AbsolutePath(root, EmbeddedCoreAssetRoot);
            EnsurePlainPath(expectedRoot);
            if (!Directory.Exists(expectedRoot) || !PathEquals(byAssetPath.resolvedPath, expectedRoot))
                throw new InvalidDataException("Embedded Core must resolve physically inside its certified Packages directory.");
        }

        private static string GetCertifiedPackagesLockSha256(string root,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows)
        {
            if (!certificateRows.TryGetValue(PackagesLockRelativePath, out F10DiagnosticCopyCertificateFile lockRow) ||
                lockRow == null || !IsSha256(lockRow.sha256))
                throw new InvalidDataException("packages-lock.json must have one valid row in the verified copy certificate.");
            VerifyBaseFile(root, lockRow);
            return lockRow.sha256;
        }

        private static string[] ValidateAndGetOutputPaths(string root,
            IDictionary<string, F10DiagnosticCopyCertificateFile> certificateRows,
            F10DiagnosticMaterializationReceipt receipt)
        {
            if (receipt.outputs == null || receipt.outputs.Length == 0 || receipt.createdDirectories == null)
                throw new InvalidDataException("The receipt has no complete measured output inventory.");

            string[] knownDirectories = PotentialOutputDirectories();
            var created = new HashSet<string>(StringComparer.Ordinal);
            foreach (string rawPath in receipt.createdDirectories)
            {
                string path = NormalizeRelativePath(rawPath);
                if (!knownDirectories.Contains(path, StringComparer.Ordinal) || !created.Add(path) ||
                    certificateRows.Values.Any(row => string.Equals(NormalizeRelativePath(row.path), path + ".meta", StringComparison.Ordinal)))
                    throw new InvalidDataException("The receipt reports an unapproved or pre-existing output directory: " + path);
                string absolute = AbsolutePath(root, path);
                if (!Directory.Exists(absolute) || IsReparsePoint(absolute))
                    throw new InvalidDataException("A measured output directory is absent or a reparse point: " + path);
            }

            string[] expected = BuildRequiredOutputFiles().Concat(created.Select(path => path + ".meta"))
                .Distinct(StringComparer.Ordinal).OrderBy(path => path, StringComparer.Ordinal).ToArray();
            var outputRows = new Dictionary<string, F10DiagnosticMaterializedOutput>(StringComparer.Ordinal);
            var identities = new HashSet<string>(StringComparer.Ordinal);
            foreach (F10DiagnosticMaterializedOutput row in receipt.outputs)
            {
                string path = NormalizeRelativePath(row == null ? null : row.path);
                if (row == null || outputRows.ContainsKey(path) || !expected.Contains(path, StringComparer.Ordinal) ||
                    !IsSha256(row.sha256) || row.length < 0 || row.linkCount != 1 || string.IsNullOrWhiteSpace(row.identity))
                    throw new InvalidDataException("The measured output inventory contains a duplicate, unapproved, or invalid physical record.");

                string absolute = AbsolutePath(root, path);
                if (!File.Exists(absolute) || IsReparsePoint(absolute))
                    throw new FileNotFoundException("A measured output file is missing or a reparse point.", absolute);
                byte[] bytes = File.ReadAllBytes(absolute);
                PhysicalFileInformation physical = ReadPhysicalFileInformation(absolute);
                string normalizedIdentity = NormalizeIdentity(physical.Identity);
                if (bytes.LongLength != row.length || !string.Equals(Sha256Hex(bytes), row.sha256, StringComparison.Ordinal) ||
                    !string.Equals(physical.Identity, row.identity, StringComparison.Ordinal) ||
                    physical.LinkCount != row.linkCount || !identities.Add(normalizedIdentity))
                    throw new InvalidDataException("Measured output bytes or physical identity changed: " + path);
                outputRows.Add(path, row);
            }
            if (!outputRows.Keys.OrderBy(path => path, StringComparer.Ordinal)
                .SequenceEqual(expected, StringComparer.Ordinal))
                throw new InvalidDataException("The output receipt is not a complete exact inventory of F10 assets, metadata, and created folder metadata.");

            foreach (string output in expected)
            {
                if (certificateRows.ContainsKey(output))
                    throw new InvalidDataException("A new output path collides with immutable base content: " + output);
            }
            return expected;
        }

        private static void VerifyBaseInventory(string root, F10DiagnosticCopyCertificate certificate,
            IEnumerable<string> outputPaths, IEnumerable<string> createdDirectories)
        {
            Dictionary<string, F10DiagnosticCopyCertificateFile> certificateRows = BuildCertificateMap(certificate);
            var expectedFiles = new HashSet<string>(certificateRows.Keys, StringComparer.Ordinal);
            foreach (string path in outputPaths ?? Array.Empty<string>())
                if (!expectedFiles.Add(NormalizeRelativePath(path)))
                    throw new InvalidDataException("Output path overlaps the immutable copy certificate: " + path);

            Dictionary<string, FileSnapshot> actualFiles = CaptureInventoryFiles(root);
            if (!actualFiles.Keys.OrderBy(path => path, StringComparer.Ordinal)
                .SequenceEqual(expectedFiles.OrderBy(path => path, StringComparer.Ordinal), StringComparer.Ordinal))
            {
                string extra = actualFiles.Keys.Except(expectedFiles, StringComparer.Ordinal).FirstOrDefault();
                string missing = expectedFiles.Except(actualFiles.Keys, StringComparer.Ordinal).FirstOrDefault();
                throw new InvalidDataException("Unexpected Assets/Packages/ProjectSettings delta; extra=" + (extra ?? "<none>") +
                    ", missing=" + (missing ?? "<none>") + ".");
            }

            foreach (F10DiagnosticCopyCertificateFile row in certificateRows.Values)
                VerifyBaseFile(root, row);

            var expectedDirectories = BuildCertifiedDirectorySet(root, certificateRows.Keys);
            foreach (string path in createdDirectories ?? Array.Empty<string>())
            {
                string normalized = NormalizeRelativePath(path);
                if (!expectedDirectories.Add(normalized))
                    throw new InvalidDataException("A newly reported directory is already part of the certified base: " + normalized);
            }
            string[] actualDirectories = CaptureInventoryDirectories(root).OrderBy(path => path, StringComparer.Ordinal).ToArray();
            if (!actualDirectories.SequenceEqual(expectedDirectories.OrderBy(path => path, StringComparer.Ordinal), StringComparer.Ordinal))
                throw new InvalidDataException("The Assets/Packages/ProjectSettings directory inventory differs from base certificate plus measured created directories.");

            var allIdentities = new HashSet<string>(StringComparer.Ordinal);
            foreach (FileSnapshot snapshot in actualFiles.Values)
            {
                PhysicalFileInformation physical = ReadPhysicalFileInformation(snapshot.AbsolutePath);
                if (physical.LinkCount != 1 || !allIdentities.Add(NormalizeIdentity(physical.Identity)))
                    throw new InvalidDataException("A project inventory file has a hard link or shares an identity with another path: " + snapshot.RelativePath);
            }
        }

        private static void VerifyBaseFile(string root, F10DiagnosticCopyCertificateFile row)
        {
            if (row == null || !IsSafeRelativePath(row.path) || !IsSha256(row.sha256) ||
                string.IsNullOrWhiteSpace(row.copyFileId) || string.IsNullOrWhiteSpace(row.sourceFileId))
                throw new InvalidDataException("The base certificate contains an invalid file record.");
            string path = NormalizeRelativePath(row.path);
            string absolute = AbsolutePath(root, path);
            if (!File.Exists(absolute) || IsReparsePoint(absolute))
                throw new FileNotFoundException("Certified base file is missing or a reparse point.", absolute);
            if (!string.Equals(HashFile(absolute), row.sha256, StringComparison.Ordinal))
                throw new InvalidDataException("Certified base bytes changed after preflight: " + path);
            PhysicalFileInformation physical = ReadPhysicalFileInformation(absolute);
            if (physical.LinkCount != 1 || !IdentityEquals(physical.Identity, row.copyFileId))
                throw new InvalidDataException("Certified base physical identity changed or has a hard link: " + path);
        }

        private static void VerifyMirrorSourceFile(string mirrorRoot, F10DiagnosticCopyCertificateFile row)
        {
            string path = NormalizeRelativePath(row.path);
            string absolute = AbsolutePath(mirrorRoot, path);
            EnsurePlainPath(absolute);
            if (!File.Exists(absolute) || IsReparsePoint(absolute) ||
                !string.Equals(HashFile(absolute), row.sha256, StringComparison.Ordinal))
                throw new InvalidDataException("The final certificate's mirror-source bytes are absent or changed: " + path);
            PhysicalFileInformation physical = ReadPhysicalFileInformation(absolute);
            if (physical.LinkCount != 1 || !IdentityEquals(physical.Identity, row.sourceFileId))
                throw new InvalidDataException("The final certificate's mirror-source identity changed or has a hard link: " + path);
        }

        private static void VerifyFixtureSourceFile(string originalRoot, string mirrorRoot,
            F10DiagnosticCopyCertificateFile row, string sourceRelativePath)
        {
            string mirrorDiagnosticDirectory = AbsolutePath(mirrorRoot, "Assets/Luckbound/Editor/Diagnostic");
            string mirrorDestination = AbsolutePath(mirrorRoot, row.path);
            if (Directory.Exists(mirrorDiagnosticDirectory) || ExistsAsAnyEntry(mirrorDestination))
                throw new InvalidDataException("The fixed Editor fixture must come from docs and remain absent from mirror-base: " + row.path);

            string sourcePath = AbsolutePath(originalRoot, sourceRelativePath);
            EnsurePlainPath(sourcePath);
            if (!File.Exists(sourcePath) || IsReparsePoint(sourcePath) ||
                !string.Equals(HashFile(sourcePath), row.sha256, StringComparison.Ordinal))
                throw new InvalidDataException("The fixed docs fixture bytes do not match the final-copy certificate: " + sourceRelativePath);
            PhysicalFileInformation physical = ReadPhysicalFileInformation(sourcePath);
            if (physical.LinkCount != 1 || !IdentityEquals(physical.Identity, row.sourceFileId))
                throw new InvalidDataException("The fixed docs fixture source identity changed or has a hard link: " + sourceRelativePath);
        }

        private static bool TryGetFixtureSourceRelativePath(string projectPath, out string sourceRelativePath)
        {
            if (string.Equals(projectPath, FixtureImporterProjectPath, StringComparison.Ordinal) ||
                string.Equals(projectPath, FixtureImporterMetaProjectPath, StringComparison.Ordinal))
            {
                sourceRelativePath = FixtureSourceRootRelativePath + projectPath;
                return true;
            }
            sourceRelativePath = null;
            return false;
        }

        private static string ValidateAcceptedBuilderChain(string mirrorRoot, string finalRoot,
            string certificateSha256, string builderChainReceiptSha256)
        {
            if (!IsSha256(builderChainReceiptSha256))
                throw new InvalidDataException("External preflight must bind the accepted original→mirror→final builder receipt SHA-256.");

            string runRoot = CanonicalPath(Directory.GetParent(mirrorRoot).FullName);
            string runsRoot = CanonicalPath(Directory.GetParent(runRoot).FullName);
            string builderRoot = CanonicalPath(Directory.GetParent(runsRoot).FullName);
            string logsRoot = CanonicalPath(Directory.GetParent(builderRoot).FullName);
            string originalRoot = CanonicalPath(Directory.GetParent(logsRoot).FullName);
            string expectedRunsRoot = CanonicalPath(Path.Combine(originalRoot,
                OverlayBuilderRunRootRelativePath.Replace('/', Path.DirectorySeparatorChar)));
            string runName = Path.GetFileName(runRoot);
            string expectedMirror = CanonicalPath(Path.Combine(expectedRunsRoot,
                runName, "mirror-base"));

            if (!PathEquals(runsRoot, expectedRunsRoot) ||
                !string.Equals(Path.GetFileName(builderRoot), "F10V6OverlayBuilderFix-20261120", StringComparison.Ordinal) ||
                !string.Equals(Path.GetFileName(mirrorRoot), "mirror-base", StringComparison.Ordinal) ||
                !IsApprovedOverlayRunName(runName) || !PathEquals(expectedMirror, mirrorRoot) ||
                !PathEquals(Path.GetDirectoryName(finalRoot), Path.Combine(mirrorRoot,
                    ApprovedCopiesRootRelativePath.Replace('/', Path.DirectorySeparatorChar))))
                throw new InvalidDataException("The certificate source/copy roots do not form the accepted overlay-builder run → mirror-base → final-copy hierarchy.");

            EnsurePlainPath(originalRoot);
            string gitMarker = Path.Combine(originalRoot, ".git");
            EnsurePlainPath(gitMarker);
            if (!(File.Exists(gitMarker) || Directory.Exists(gitMarker)) ||
                File.Exists(Path.Combine(mirrorRoot, ".git")) || Directory.Exists(Path.Combine(mirrorRoot, ".git")))
                throw new InvalidDataException("The overlay chain must lead to a real Git checkout and a mirror that excludes Git metadata.");

            string chainPath = AbsolutePath(mirrorRoot, OverlayBuilderChainReceiptRelativePath);
            EnsurePlainPath(chainPath);
            if (!File.Exists(chainPath) ||
                !string.Equals(HashFile(chainPath), builderChainReceiptSha256, StringComparison.Ordinal))
                throw new InvalidDataException("The fixed builder chain receipt is missing or differs from its external preflight SHA-256.");
            PhysicalFileInformation chainPhysical = ReadPhysicalFileInformation(chainPath);
            if (chainPhysical.LinkCount != 1)
                throw new InvalidDataException("The accepted builder chain receipt must have one physical link.");

            OverlayBuilderFinalReceipt chain;
            try { chain = JsonUtility.FromJson<OverlayBuilderFinalReceipt>(StrictUtf8.GetString(File.ReadAllBytes(chainPath))); }
            catch (Exception exception) { throw new FormatException("The accepted overlay-builder chain receipt is invalid JSON.", exception); }

            string actualCertificatePath = AbsolutePath(finalRoot, CertificateRelativePath);
            if (chain == null || chain.schemaVersion != 1 ||
                !string.Equals(chain.status, "verified-chain", StringComparison.Ordinal) ||
                !PathEquals(chain.originalRoot, originalRoot) || !PathEquals(chain.mirrorBaseRoot, mirrorRoot) ||
                !PathEquals(chain.mirrorTransformedRoot, mirrorRoot) || !PathEquals(chain.finalCopyRoot, finalRoot) ||
                !PathEquals(chain.executionRoot, finalRoot) || chain.unityStarted || !chain.writersPausedAttested ||
                chain.osLockClaim || !chain.singleFilesystemLinkPerMeasuredFile || !chain.f01OutsideAssets ||
                !string.Equals(chain.physicalIndependence, "verified-for-original-mirror-final-files", StringComparison.Ordinal) ||
                !string.Equals(chain.f02Guards, "passed", StringComparison.Ordinal) || chain.finalCertificate == null ||
                !PathEquals(chain.finalCertificate.path, actualCertificatePath) ||
                !string.Equals(chain.finalCertificate.sha256, certificateSha256, StringComparison.Ordinal) ||
                !PathEquals(chain.finalCertificate.sourceRoot, mirrorRoot) ||
                !PathEquals(chain.finalCertificate.copyRoot, finalRoot) || !chain.finalCertificate.identifiesTransformedMirror)
                throw new InvalidDataException("The builder chain receipt does not link the original checkout, transformed mirror, final copy, and exact certificate.");

            return originalRoot;
        }

        private static void ValidateCopyContext(string root, F10DiagnosticCopyCertificate certificate,
            MaterializationPreflightReceipt preflight, bool requireFreshPreflight)
        {
            EnsureWindows();
            EnsurePlainPath(root);
            string sourceRoot = CanonicalPath(Path.GetFullPath(Path.Combine(root, "..", "..", "..", "..")));
            string expectedCopiesRoot = CanonicalPath(Path.Combine(sourceRoot, ApprovedCopiesRootRelativePath.Replace('/', Path.DirectorySeparatorChar)));
            if (!Directory.Exists(root) || !PathEquals(Path.GetDirectoryName(root), expectedCopiesRoot) ||
                !IsApprovedCopyName(Path.GetFileName(root)) ||
                File.Exists(Path.Combine(root, ".git")) || Directory.Exists(Path.Combine(root, ".git")))
                throw new InvalidOperationException("F10 materialization is restricted to a direct named final copy below the certificate source mirror's approved Logs root.");
            if (certificate == null || certificate.schemaVersion != 1 ||
                !string.Equals(certificate.status, "verified", StringComparison.Ordinal) ||
                !PathEquals(certificate.sourceRoot, sourceRoot) || !PathEquals(certificate.copyRoot, root) ||
                !certificate.reparsePointsRejected || !certificate.fileIdentityChecksPassed ||
                !certificate.f02ImportStagingAbsent || certificate.files == null || certificate.files.Length == 0)
                throw new InvalidDataException("The immutable base certificate is absent or does not identify this exact verified copy.");

            string unityVersionPath = AbsolutePath(root, "ProjectSettings/ProjectVersion.txt");
            string projectVersion = ReadProjectUnityVersion(unityVersionPath);
            if (!string.Equals(projectVersion, ExpectedUnityVersion, StringComparison.Ordinal) ||
                !string.Equals(Application.unityVersion, ExpectedUnityVersion, StringComparison.Ordinal))
                throw new InvalidOperationException("Measured F10 materialization requires Unity " + ExpectedUnityVersion + ".");

            string certificateHash = HashFile(AbsolutePath(root, CertificateRelativePath));
            if (preflight == null || preflight.schemaVersion != 1 ||
                !string.Equals(preflight.status, "verified-at-launch", StringComparison.Ordinal) ||
                !PathEquals(preflight.sourceRoot, sourceRoot) || !PathEquals(preflight.copyRoot, root) ||
                !string.Equals(preflight.certificateSha256, certificateHash, StringComparison.Ordinal) ||
                !string.Equals(preflight.measuredCertificateSha256, certificateHash, StringComparison.Ordinal) ||
                preflight.fileCount != certificate.files.Length || !preflight.externalPreflightVerified || !preflight.writersExcluded ||
                !preflight.writersPausedAttested || preflight.osLockClaim ||
                !string.Equals(preflight.builderChainReceiptPath, OverlayBuilderChainReceiptRelativePath, StringComparison.Ordinal) ||
                (requireFreshPreflight && !IsRecentPreflight(preflight.issuedAtUtc)))
                throw new InvalidDataException("A matching external full-copy preflight receipt is required; stale or synthetic receipts are rejected.");

            string originalRoot = ValidateAcceptedBuilderChain(sourceRoot, root, certificateHash,
                preflight.builderChainReceiptSha256);
            if (!PathEquals(preflight.originalRoot, originalRoot) ||
                !PathEquals(preflight.mirrorBaseRoot, sourceRoot) ||
                !PathEquals(preflight.mirrorTransformedRoot, sourceRoot))
                throw new InvalidDataException("The external preflight roots do not bind the accepted original → mirror → final-copy chain.");

            var sourceIds = new HashSet<string>(StringComparer.Ordinal);
            var copyIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (F10DiagnosticCopyCertificateFile row in certificate.files)
            {
                string path = row == null ? null : NormalizeRelativePath(row.path);
                if (row == null || !IsSafeRelativePath(row.path) || !IsAllowedCertifiedPath(path) ||
                    !IsSha256(row.sha256) || string.IsNullOrWhiteSpace(row.sourceFileId) ||
                    string.IsNullOrWhiteSpace(row.copyFileId) || !sourceIds.Add(NormalizeIdentity(row.sourceFileId)) ||
                    !copyIds.Add(NormalizeIdentity(row.copyFileId)) || IdentityEquals(row.sourceFileId, row.copyFileId))
                    throw new InvalidDataException("The base certificate has an invalid, duplicate, or shared source/copy identity.");
                VerifyBaseFile(root, row);
                if (TryGetFixtureSourceRelativePath(path, out string fixtureSourcePath))
                    VerifyFixtureSourceFile(originalRoot, sourceRoot, row, fixtureSourcePath);
                else
                    VerifyMirrorSourceFile(sourceRoot, row);
            }
            var certifiedPaths = new HashSet<string>(certificate.files.Select(row => NormalizeRelativePath(row.path)), StringComparer.Ordinal);
            if (CertifiedExternalFiles.Any(path => !certifiedPaths.Contains(path)))
                throw new InvalidDataException("The immutable base certificate must contain exactly the three fixed F01 provenance files outside Unity roots.");
            if (!certifiedPaths.Contains(FixtureImporterProjectPath) || !certifiedPaths.Contains(FixtureImporterMetaProjectPath))
                throw new InvalidDataException("The immutable final-copy certificate must include both fixed diagnostic fixture source rows.");
            if (sourceIds.Overlaps(copyIds))
                throw new InvalidDataException("The immutable certificate records physical identity shared by source and copy.");

            if (!Directory.Exists(originalRoot) || !(File.Exists(Path.Combine(originalRoot, ".git")) ||
                Directory.Exists(Path.Combine(originalRoot, ".git"))))
                throw new InvalidDataException("The builder's original checkout root is not a real Git checkout.");

            foreach (string path in F02BlockPaths)
                if (ExistsAsAnyEntry(AbsolutePath(root, path)))
                    throw new InvalidOperationException("F02 recovery/import staging or sentinel state blocks this diagnostic copy: " + path);
        }

        private static F10DiagnosticCopyCertificate ReadCertificate(string root)
        {
            string path = AbsolutePath(root, CertificateRelativePath);
            EnsurePlainPath(path);
            if (!File.Exists(path)) throw new FileNotFoundException("The immutable disposable-copy certificate is required.", path);
            try { return JsonUtility.FromJson<F10DiagnosticCopyCertificate>(StrictUtf8.GetString(File.ReadAllBytes(path))); }
            catch (Exception exception) { throw new FormatException("The disposable-copy certificate JSON is invalid.", exception); }
        }

        private static MaterializationPreflightReceipt ReadPreflight(string root)
        {
            string path = AbsolutePath(root, PreflightRelativePath);
            EnsurePlainPath(path);
            if (!File.Exists(path)) throw new FileNotFoundException("External preflight must be measured before the first Unity process.", path);
            try { return JsonUtility.FromJson<MaterializationPreflightReceipt>(StrictUtf8.GetString(File.ReadAllBytes(path))); }
            catch (Exception exception) { throw new FormatException("The external copy preflight JSON is invalid.", exception); }
        }

        private static F10DiagnosticMaterializationReceipt ReadReceipt(string root)
        {
            string path = AbsolutePath(root, ReceiptRelativePath);
            EnsurePlainPath(path);
            if (!File.Exists(path))
                throw new FileNotFoundException("No Unity-measured F10 materialization receipt exists; it is never synthesized by runtime code.", path);
            string json = StrictUtf8.GetString(File.ReadAllBytes(path));
            F10DiagnosticMaterializationReceipt receipt;
            try { receipt = JsonUtility.FromJson<F10DiagnosticMaterializationReceipt>(json); }
            catch (Exception exception) { throw new FormatException("The measured materialization receipt JSON is invalid.", exception); }
            if (receipt == null || !string.Equals(JsonUtility.ToJson(receipt, false), json, StringComparison.Ordinal))
                throw new InvalidDataException("The measured receipt is not the exact JsonUtility serialization emitted by the Editor entrypoint.");
            return receipt;
        }

        private static Dictionary<string, F10DiagnosticCopyCertificateFile> BuildCertificateMap(F10DiagnosticCopyCertificate certificate)
        {
            if (certificate == null || certificate.files == null) throw new InvalidDataException("The base certificate inventory is missing.");
            var result = new Dictionary<string, F10DiagnosticCopyCertificateFile>(StringComparer.Ordinal);
            foreach (F10DiagnosticCopyCertificateFile row in certificate.files)
            {
                string path = NormalizeRelativePath(row == null ? null : row.path);
                if (row == null || !IsSafeRelativePath(row.path) || !IsAllowedCertifiedPath(path) || !result.TryAdd(path, row))
                    throw new InvalidDataException("The base certificate has a duplicate or malformed project path.");
            }
            return result;
        }

        private static F10DiagnosticCopyCertificateFile FindCertificateFile(F10DiagnosticCopyCertificate certificate, string path)
        {
            if (certificate == null || certificate.files == null) return null;
            return certificate.files.FirstOrDefault(row => row != null &&
                string.Equals(NormalizeRelativePath(row.path), path, StringComparison.Ordinal));
        }

        private static string[] BuildRequiredOutputFiles()
        {
            return RequiredAssetPaths.SelectMany(path => new[] { path, path + ".meta" })
                .OrderBy(path => path, StringComparer.Ordinal).ToArray();
        }

        private static string[] PotentialOutputDirectories()
        {
            return RequiredAssetPaths.Select(path => path.Substring(0, path.LastIndexOf('/')))
                .SelectMany(DirectoryAncestors)
                .Where(path => path.StartsWith("Assets/Luckbound/Editor/Diagnostic", StringComparison.Ordinal))
                .Distinct(StringComparer.Ordinal).OrderBy(path => path, StringComparer.Ordinal).ToArray();
        }

        private static IEnumerable<string> DirectoryAncestors(string path)
        {
            string current = path;
            while (!string.IsNullOrEmpty(current) && current != "Assets")
            {
                yield return current;
                int separator = current.LastIndexOf('/');
                if (separator < 0) yield break;
                current = current.Substring(0, separator);
            }
        }

        private static HashSet<string> BuildCertifiedDirectorySet(string root, IEnumerable<string> certificatePaths)
        {
            var directories = new HashSet<string>(StringComparer.Ordinal);
            foreach (string path in certificatePaths)
            {
                string current = path;
                int separator = current.LastIndexOf('/');
                while (separator > 0)
                {
                    current = current.Substring(0, separator);
                    if (IsInInventoryRoot(current)) directories.Add(current);
                    separator = current.LastIndexOf('/');
                }
                if (path.EndsWith(".meta", StringComparison.Ordinal))
                {
                    string representedDirectory = path.Substring(0, path.Length - ".meta".Length);
                    if (IsInInventoryRoot(representedDirectory) && Directory.Exists(AbsolutePath(root, representedDirectory)))
                        directories.Add(representedDirectory);
                }
            }
            foreach (string inventoryRoot in InventoryRoots) directories.Add(inventoryRoot);
            return directories;
        }

        private static Dictionary<string, FileSnapshot> CaptureInventoryFiles(string root)
        {
            var result = new Dictionary<string, FileSnapshot>(StringComparer.Ordinal);
            foreach (string inventoryRoot in InventoryRoots)
            {
                string absoluteRoot = AbsolutePath(root, inventoryRoot);
                if (!Directory.Exists(absoluteRoot)) throw new DirectoryNotFoundException("Required project inventory root is missing: " + absoluteRoot);
                var pending = new Stack<string>();
                pending.Push(absoluteRoot);
                while (pending.Count > 0)
                {
                    string directory = pending.Pop();
                    EnsurePlainPath(directory);
                    foreach (string entry in Directory.EnumerateFileSystemEntries(directory))
                    {
                        if (IsReparsePoint(entry)) throw new IOException("Project inventory rejects reparse points: " + entry);
                        if (Directory.Exists(entry)) { pending.Push(entry); continue; }
                        string relative = ToRelativePath(root, entry);
                        if (!result.TryAdd(relative, new FileSnapshot(relative, entry)))
                            throw new InvalidDataException("Project inventory contains a duplicate path: " + relative);
                    }
                }
            }
            foreach (string relative in CertifiedExternalFiles)
            {
                string absolute = AbsolutePath(root, relative);
                EnsurePlainPath(absolute);
                if (!File.Exists(absolute))
                    throw new FileNotFoundException("An exact certified F01 provenance file is missing.", absolute);
                if (!result.TryAdd(relative, new FileSnapshot(relative, absolute)))
                    throw new InvalidDataException("An exact F01 provenance path overlaps another inventory entry: " + relative);
            }
            return result;
        }

        private static HashSet<string> CaptureInventoryDirectories(string root)
        {
            var result = new HashSet<string>(StringComparer.Ordinal);
            foreach (string inventoryRoot in InventoryRoots)
            {
                string absoluteRoot = AbsolutePath(root, inventoryRoot);
                if (!Directory.Exists(absoluteRoot)) throw new DirectoryNotFoundException("Required project inventory root is missing: " + absoluteRoot);
                var pending = new Stack<string>();
                pending.Push(absoluteRoot);
                while (pending.Count > 0)
                {
                    string directory = pending.Pop();
                    EnsurePlainPath(directory);
                    result.Add(ToRelativePath(root, directory));
                    foreach (string entry in Directory.EnumerateDirectories(directory))
                    {
                        if (IsReparsePoint(entry)) throw new IOException("Project inventory rejects reparse directories: " + entry);
                        pending.Push(entry);
                    }
                }
            }
            return result;
        }

        private static void EnsureWindows()
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || Path.DirectorySeparatorChar != '\\')
                throw new PlatformNotSupportedException("F10 physical materialization identity has only been implemented for Windows; it fails closed elsewhere.");
        }

        private static PhysicalFileInformation ReadPhysicalFileInformation(string path)
        {
            using (SafeFileHandle handle = CreateFile(path, 0, FileShare.ReadWrite | FileShare.Delete,
                IntPtr.Zero, FileMode.Open, 0x02000000 | 0x00200000, IntPtr.Zero))
            {
                if (handle.IsInvalid || !GetFileInformationByHandle(handle, out ByHandleFileInformation info))
                    throw new IOException("Could not read actual Windows file identity: " + path,
                        Marshal.GetExceptionForHR(Marshal.GetHRForLastWin32Error()));
                byte[] fileIdInfo = new byte[24];
                if (!GetFileInformationByHandleEx(handle, 18, fileIdInfo, (uint)fileIdInfo.Length))
                    throw new IOException("Could not read 64-bit FileIdInfo required to match the certificate's Python st_dev: " + path,
                        Marshal.GetExceptionForHR(Marshal.GetHRForLastWin32Error()));
                ulong volumeId = BitConverter.ToUInt64(fileIdInfo, 0);
                ulong fileIdLow = BitConverter.ToUInt64(fileIdInfo, 8);
                ulong fileIdHigh = BitConverter.ToUInt64(fileIdInfo, 16);
                ulong legacyFileIndex = ((ulong)info.FileIndexHigh << 32) | info.FileIndexLow;
                if (fileIdHigh != 0 || fileIdLow != legacyFileIndex || volumeId == 0)
                    throw new IOException("This filesystem's 128-bit file ID cannot be represented exactly by the certified Python device/inode pair: " + path);
                string identity = volumeId.ToString("X16", CultureInfo.InvariantCulture) + ":" +
                    fileIdLow.ToString("X16", CultureInfo.InvariantCulture);
                return new PhysicalFileInformation(identity, info.LinkCount);
            }
        }

        private static bool IdentityEquals(string left, string right)
        {
            return string.Equals(NormalizeIdentity(left), NormalizeIdentity(right), StringComparison.Ordinal);
        }

        private static string NormalizeIdentity(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new InvalidDataException("A physical file identity is required.");
            string[] parts = value.Split(':');
            if (parts.Length != 2 || !ulong.TryParse(parts[0], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong volume) ||
                !ulong.TryParse(parts[1], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong file))
                throw new InvalidDataException("Physical file identity has an unsupported Windows volume/file-index form.");
            return volume.ToString("X16", CultureInfo.InvariantCulture) + ":" + file.ToString("X16", CultureInfo.InvariantCulture);
        }

        private static string HashFile(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                return ToLowerHex(sha.ComputeHash(stream));
        }

        public static string Sha256Hex(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create()) return ToLowerHex(sha.ComputeHash(bytes));
        }

        public static string ToLowerHex(byte[] bytes)
        {
            return string.Concat(bytes.Select(value => value.ToString("x2", CultureInfo.InvariantCulture)));
        }

        private static bool IsSha256(string value)
        {
            return value != null && value.Length == 64 && value.All(character =>
                character >= '0' && character <= '9' || character >= 'a' && character <= 'f');
        }

        private static bool IsRecentPreflight(string timestamp)
        {
            if (!DateTime.TryParse(timestamp, CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind, out DateTime issued)) return false;
            TimeSpan age = DateTime.UtcNow - issued.ToUniversalTime();
            return age >= TimeSpan.FromSeconds(-30) && age <= TimeSpan.FromMinutes(30);
        }

        private static string ReadProjectUnityVersion(string path)
        {
            string text = StrictUtf8.GetString(File.ReadAllBytes(path));
            const string prefix = "m_EditorVersion: ";
            string line = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .FirstOrDefault(value => value.StartsWith(prefix, StringComparison.Ordinal));
            if (line == null) throw new InvalidDataException("ProjectVersion.txt does not declare m_EditorVersion.");
            return line.Substring(prefix.Length).Trim();
        }

        private static bool IsApprovedCopyName(string name)
        {
            if (string.IsNullOrEmpty(name) || name.Length != 34 || !name.StartsWith("copy-", StringComparison.Ordinal) ||
                name[13] != 'T' || name[20] != 'Z' || name[21] != '-') return false;
            for (int index = 5; index < 13; index++) if (!char.IsDigit(name[index])) return false;
            for (int index = 14; index < 20; index++) if (!char.IsDigit(name[index])) return false;
            for (int index = 22; index < 34; index++) if (!Uri.IsHexDigit(name[index])) return false;
            return true;
        }

        private static bool IsApprovedOverlayRunName(string name)
        {
            if (string.IsNullOrEmpty(name) || name.Length != 31 || !name.StartsWith("run-", StringComparison.Ordinal) ||
                name[12] != 'T' || name[19] != 'Z' || name[20] != '-') return false;
            for (int index = 4; index < 12; index++) if (!char.IsDigit(name[index])) return false;
            for (int index = 13; index < 19; index++) if (!char.IsDigit(name[index])) return false;
            for (int index = 21; index < 31; index++) if (!Uri.IsHexDigit(name[index])) return false;
            return true;
        }

        private static bool IsInInventoryRoot(string path)
        {
            return InventoryRoots.Any(root => string.Equals(path, root, StringComparison.Ordinal) ||
                path.StartsWith(root + "/", StringComparison.Ordinal));
        }

        private static bool IsAllowedCertifiedPath(string path)
        {
            return IsInInventoryRoot(path) || CertifiedExternalFiles.Contains(path, StringComparer.Ordinal);
        }

        private static bool IsSafeRelativePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || Path.IsPathRooted(path) || path.IndexOf(':') >= 0) return false;
            string normalized = path.Replace('\\', '/');
            return !normalized.StartsWith("/", StringComparison.Ordinal) &&
                normalized.Split('/').All(segment => segment.Length > 0 && segment != "." && segment != "..");
        }

        private static string NormalizeRelativePath(string path)
        {
            if (!IsSafeRelativePath(path)) throw new InvalidDataException("Unsafe project-relative path: " + (path ?? "<null>"));
            return path.Replace('\\', '/');
        }

        private static string ToRelativePath(string root, string path)
        {
            string prefix = CanonicalPath(root) + Path.DirectorySeparatorChar;
            string full = CanonicalPath(path);
            if (!full.StartsWith(prefix, WindowsPathComparison))
                throw new InvalidOperationException("Inventory path escaped the disposable copy root: " + path);
            return full.Substring(prefix.Length).Replace('\\', '/');
        }

        private static string AbsolutePath(string root, string relative)
        {
            if (!IsSafeRelativePath(relative)) throw new InvalidDataException("Unsafe project-relative path: " + (relative ?? "<null>"));
            return Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
        }

        private static bool ExistsAsAnyEntry(string path) => File.Exists(path) || Directory.Exists(path);

        private static bool IsReparsePoint(string path)
        {
            if (!ExistsAsAnyEntry(path)) return false;
            return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;
        }

        private static void EnsurePlainPath(string path)
        {
            string full = Path.GetFullPath(path);
            string volumeRoot = Path.GetPathRoot(full);
            string relative = full.Substring(volumeRoot.Length);
            string current = volumeRoot;
            if (ExistsAsAnyEntry(current) && IsReparsePoint(current)) throw new IOException("Reparse point in path: " + current);
            foreach (string segment in relative.Split(new[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar },
                StringSplitOptions.RemoveEmptyEntries))
            {
                current = Path.Combine(current, segment);
                if (!ExistsAsAnyEntry(current)) continue;
                if (IsReparsePoint(current)) throw new IOException("Reparse point in path: " + current);
            }
        }

        private static bool PathEquals(string left, string right)
        {
            if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right)) return false;
            return string.Equals(CanonicalPath(left), CanonicalPath(right), WindowsPathComparison);
        }

        private static string CanonicalPath(string path)
        {
            string full = Path.GetFullPath(path ?? throw new ArgumentNullException(nameof(path)));
            string root = Path.GetPathRoot(full) ?? string.Empty;
            while (full.Length > root.Length &&
                (full[full.Length - 1] == Path.DirectorySeparatorChar || full[full.Length - 1] == Path.AltDirectorySeparatorChar))
                full = full.Substring(0, full.Length - 1);
            return full;
        }

        [Serializable]
        private sealed class FileSnapshot
        {
            internal FileSnapshot(string relativePath, string absolutePath) { RelativePath = relativePath; AbsolutePath = absolutePath; }
            internal string RelativePath { get; }
            internal string AbsolutePath { get; }
        }

        private sealed class PhysicalFileInformation
        {
            internal PhysicalFileInformation(string identity, uint linkCount) { Identity = identity; LinkCount = linkCount; }
            internal string Identity { get; }
            internal uint LinkCount { get; }
        }

        [Serializable]
        private sealed class MaterializationPreflightReceipt
        {
            public int schemaVersion;
            public string status;
            public string sourceRoot;
            public string copyRoot;
            public string certificateSha256;
            public string measuredCertificateSha256;
            public int fileCount;
            public bool externalPreflightVerified;
            public bool writersExcluded;
            public bool writersPausedAttested;
            public bool osLockClaim;
            public string issuedAtUtc;
            public string originalRoot;
            public string mirrorBaseRoot;
            public string mirrorTransformedRoot;
            public string builderChainReceiptPath;
            public string builderChainReceiptSha256;
        }

        [Serializable]
        private sealed class OverlayBuilderFinalReceipt
        {
            public int schemaVersion;
            public string status;
            public string originalRoot;
            public string mirrorBaseRoot;
            public string mirrorTransformedRoot;
            public string finalCopyRoot;
            public bool writersPausedAttested;
            public bool osLockClaim;
            public bool singleFilesystemLinkPerMeasuredFile;
            public bool f01OutsideAssets;
            public string physicalIndependence;
            public string f02Guards;
            public bool unityStarted;
            public string executionRoot;
            public OverlayBuilderFinalCertificate finalCertificate;
        }

        [Serializable]
        private sealed class OverlayBuilderFinalCertificate
        {
            public string path;
            public string sha256;
            public string sourceRoot;
            public string copyRoot;
            public bool identifiesTransformedMirror;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct ByHandleFileInformation
        {
            internal uint FileAttributes;
            internal System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            internal uint VolumeSerialNumber;
            internal uint FileSizeHigh;
            internal uint FileSizeLow;
            internal uint LinkCount;
            internal uint FileIndexHigh;
            internal uint FileIndexLow;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFile(string fileName, uint desiredAccess, FileShare shareMode,
            IntPtr securityAttributes, FileMode creationDisposition, uint flagsAndAttributes, IntPtr templateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out ByHandleFileInformation information);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandleEx(SafeFileHandle handle, int fileInformationClass,
            [Out] byte[] information, uint bufferSize);
    }
}
#endif
