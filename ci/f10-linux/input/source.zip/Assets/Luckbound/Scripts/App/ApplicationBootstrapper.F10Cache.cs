#if UNITY_EDITOR
using System;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Crafting;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Pacts;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Rooms;
using UnityEditor;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// F10 technical-demo cache settlement. This Editor-only path accepts a physical contact witness, derives
    /// the grant from the saved route context, and uses the existing serialized expedition write pipeline.
    /// </summary>
    public sealed partial class ApplicationBootstrapper
    {
        private const string F10CacheNodeId = "sample.patio.exploration";
        private const string F10CacheTemplateId = "room.patio.e1";
        private const string F10CacheRoomMarkerId = "cache.exploration";
        private const string F10CacheRoomDefinitionResource = "Luckbound/Data/Rooms/F10PatioExplorationE1Room";
        private const float F10CachePoseTolerance = 0.001f;
        private PendingF10CacheClaim _pendingF10CacheClaim;

        /// <summary>
        /// Commits the one physical cache contact in the isolated F10 Editor demo. A non-pending rejection
        /// releases the sensor witness so a later physical Stay may be considered again.
        /// </summary>
        internal async Task<ExpeditionMutationCommitResult<InventoryOperationOutcome>> CollectF10ExplorationCacheAsync(
            ExpeditionGameplayComposition owner, ExplorationGoldCacheContact contact)
        {
            await _profileMutationGate.WaitAsync();
            IDisposable sessionPauseLease = null;
            bool retainContact = false;
            InventoryOperationOutcome outcome = null;
            try
            {
                if (_pendingF10CacheClaim != null)
                {
                    if (!ReferenceEquals(_pendingF10CacheClaim.Owner, owner) ||
                        !ReferenceEquals(_pendingF10CacheClaim.Contact, contact))
                        return RejectF10CacheContact(contact,
                            "A different F10 cache contact is waiting for its exact expedition write.");

                    PendingF10CacheClaim pending = _pendingF10CacheClaim;
                    outcome = pending.Outcome;
                    if (!HasPendingExpeditionWrite && IsF10CacheClaimDurable(pending))
                    {
                        CompletePendingF10CacheClaim(pending, pausedPublication: false);
                        return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, true, false,
                            "The exploration cache reward was already committed and its exact pickup was reconciled.");
                    }

                    SaveWriteResult retry;
                    try { retry = await RetryPendingExpeditionWriteUnderGateAsync(); }
                    catch (Exception exception)
                    {
                        bool ownPendingWrite = HasPendingF10CacheOperation(pending);
                        if (!ownPendingWrite && ReferenceEquals(_pendingF10CacheClaim, pending))
                            _pendingF10CacheClaim = null;
                        retainContact = ownPendingWrite;
                        return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, false,
                            ownPendingWrite, "The pending cache reward could not be retried: " + exception.Message);
                    }

                    if (retry.Succeeded && IsF10CacheClaimDurable(pending))
                    {
                        if (ReferenceEquals(_pendingF10CacheClaim, pending))
                            CompletePendingF10CacheClaim(pending, pausedPublication: false);
                        return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, true, false,
                            retry.Message);
                    }

                    bool operationPending = HasPendingF10CacheOperation(pending);
                    if (!operationPending && ReferenceEquals(_pendingF10CacheClaim, pending))
                        _pendingF10CacheClaim = null;
                    retainContact = operationPending;
                    return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, false,
                        operationPending, retry.Message);
                }

                if (!CanWriteProfile)
                    return RejectF10CacheContact(contact, ProfileWriteBlockReason);
                if (_pendingEconomyMutation != null || HasPendingExpeditionWrite ||
                    _pendingContractProgression != null || HasPendingSettlement || HasPendingRoomAdvance ||
                    IsRoomAdvanceInFlight)
                    return RejectF10CacheContact(contact,
                        "Resolve the existing expedition write before collecting the exploration cache.");
                if (!CanContinueExpedition || ActiveRun == null || _activeExpedition == null)
                    return RejectF10CacheContact(contact,
                        "There is no safely resumable active expedition for this cache contact.");
                if (!HasF10CacheSessionBindings(owner))
                    return RejectF10CacheContact(contact,
                        "The isolated F10 Editor session does not own this expedition and room.");
                ExpeditionRunConfiguration sessionRun = ActiveRun;
                ExpeditionSaveData savedExpedition = _activeExpedition;
                if (!TryResolveF10CacheReward(sessionRun, savedExpedition, contact,
                        out ExpeditionExplorationCacheReward reward, out string contextError))
                    return RejectF10CacheContact(contact, contextError);

                TransactionId transactionId = CreateF10CacheTransactionId(reward.GoldGrantId);
                ExpeditionInventory replayCheckInventory = ExpeditionInventory.Restore(
                    sessionRun.Inventory.Catalog, sessionRun.Inventory.CreateSnapshot());
                int goldBefore = replayCheckInventory.Gold;
                InventoryOperationOutcome replayCheck = replayCheckInventory.TryAddGold(reward.Gold, transactionId);
                bool alreadyClaimed = savedExpedition.claimedRewardIds.Contains(reward.GoldGrantId,
                    StringComparer.Ordinal);
                if (alreadyClaimed)
                {
                    if (!replayCheck.Succeeded || replayCheckInventory.Gold != goldBefore ||
                        !HasSuccessfulF10CacheTransaction(sessionRun.Inventory.CreateSnapshot(), transactionId,
                            reward.Gold))
                        return RejectF10CacheContact(contact,
                            "The saved cache claim and its inventory transaction do not agree; no reward was changed.");
                    outcome = replayCheck;
                    ConsumeF10CachePickupAfterCommittedClaim(owner, contact, ActiveRun.RunId,
                        ActiveRun, contact.Scope.RoomInstanceId, reward.GoldGrantId, reward.Gold,
                        pausedPublication: false);
                    return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, true, false,
                        "This physical cache reward was already committed.");
                }
                if (!replayCheck.Succeeded)
                    return RejectF10CacheContact(contact,
                        "The cache reward could not be added to the expedition inventory.", replayCheck);
                if (replayCheckInventory.Gold != checked(goldBefore + reward.Gold))
                    return RejectF10CacheContact(contact,
                        "The inventory already contains this cache transaction without its saved claim; no reward was changed.",
                        replayCheck);

                if (!TryAcquireExpeditionSimulationPauseLease(out sessionPauseLease, out string pauseError))
                    return RejectF10CacheContact(contact, pauseError);

                ExpeditionRunConfiguration witnessedRun = sessionRun;
                if (!ReferenceEquals(ActiveRun, witnessedRun))
                    return RejectF10CacheContact(contact,
                        "The F10 session changed while acquiring the simulation pause lease.");
                if (!TryValidateF10CachePhysicalContext(witnessedRun, _activeExpedition, contact,
                    requireCurrentContact: false, out string postPauseError))
                    return RejectF10CacheContact(contact,
                        "The F10 cache source or pose changed while acquiring the simulation pause lease: " + postPauseError);
                ExpeditionSaveData candidateSave = _activeExpedition.Clone();
                try
                {
                    if (_expeditionSessionStateCapture == null ||
                        !ReferenceEquals(_expeditionSessionMutationPublicationOwner, owner) ||
                        !ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, owner))
                        return RejectF10CacheContact(contact,
                            "The active F10 session cannot capture and publish a durable cache reward.");

                    _expeditionSessionStateCapture(witnessedRun, candidateSave);
                }
                catch (Exception exception)
                {
                    return RejectF10CacheContact(contact,
                        "The live expedition state could not be captured before the cache save: " + exception.Message);
                }

                if (!IsSameF10CacheRewardContext(_activeExpedition, candidateSave, witnessedRun, contact))
                    return RejectF10CacheContact(contact,
                        "The active route or pact context changed while preparing the cache reward.");

                ExpeditionInventory candidateInventory = ExpeditionInventory.Restore(
                    witnessedRun.Inventory.Catalog, witnessedRun.Inventory.CreateSnapshot());
                outcome = candidateInventory.TryAddGold(reward.Gold, transactionId);
                if (!outcome.Succeeded || outcome.WasReplay)
                    return RejectF10CacheContact(contact,
                        "The cache gold transaction was rejected while building its candidate.", outcome);

                candidateSave.claimedRewardIds = candidateSave.claimedRewardIds
                    .Concat(new[] { reward.GoldGrantId }).ToArray();
                candidateSave.inventorySnapshotJson = JsonUtility.ToJson(candidateInventory.CreateSnapshot());
                candidateSave.healthPotionCharges = ExpeditionSaveMapper.GetHealthPotionCharges(candidateInventory);
                ExpeditionRunConfiguration candidateRun = witnessedRun.WithInventory(candidateInventory);
                RoomInstanceId sourceRoomId = contact.Scope.RoomInstanceId;
                PendingF10CacheClaim pendingClaim = new PendingF10CacheClaim(owner, contact, witnessedRun.RunId,
                    sourceRoomId, candidateRun, reward.GoldGrantId, reward.Gold, outcome);
                _pendingF10CacheClaim = pendingClaim;

                Task<SaveWriteResult> saveTask = SaveExpeditionCandidateUnderGateAsync(candidateSave,
                    _activeExpeditionRevision, candidateRun, sessionPauseLease,
                    sessionStateCaptured: true);
                sessionPauseLease = null;
                SaveWriteResult save;
                try { save = await saveTask; }
                catch (Exception exception)
                {
                    if (HasPendingF10CacheOperation(pendingClaim))
                    {
                        TryAttachF10CacheClaimToPendingPublication(pendingClaim);
                        retainContact = true;
                        return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, false, true,
                            "The cache reward remains pending its exact save retry: " + exception.Message);
                    }
                    if (ReferenceEquals(_pendingF10CacheClaim, pendingClaim)) _pendingF10CacheClaim = null;
                    return RejectF10CacheContact(contact,
                        "The cache reward save failed without a pending expedition write: " + exception.Message, outcome);
                }

                if (save.Succeeded && IsF10CacheClaimDurable(pendingClaim))
                {
                    CompletePendingF10CacheClaim(pendingClaim, pausedPublication: false);
                    return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, true, false,
                        save.Message);
                }

                if (HasPendingF10CacheOperation(pendingClaim))
                {
                    TryAttachF10CacheClaimToPendingPublication(pendingClaim);
                    retainContact = true;
                    return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(outcome, false, true,
                        save.Message);
                }

                if (ReferenceEquals(_pendingF10CacheClaim, pendingClaim)) _pendingF10CacheClaim = null;
                return RejectF10CacheContact(contact, save.Message, outcome);
            }
            catch (Exception exception)
            {
                PendingF10CacheClaim pending = _pendingF10CacheClaim;
                if (pending != null && ReferenceEquals(pending.Contact, contact) &&
                    HasPendingF10CacheOperation(pending))
                {
                    TryAttachF10CacheClaimToPendingPublication(pending);
                    retainContact = true;
                    return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(
                        pending.Outcome, false, true,
                        "The cache reward remains pending its exact save retry: " + exception.Message);
                }
                if (pending != null && ReferenceEquals(pending.Contact, contact))
                    _pendingF10CacheClaim = null;
                return RejectF10CacheContact(contact,
                    "The cache contact could not be committed: " + exception.Message, outcome);
            }
            finally
            {
                try { sessionPauseLease?.Dispose(); }
                finally
                {
                    try
                    {
                        if (!retainContact && contact != null && contact.Pickup != null)
                            contact.Pickup.ReleaseRejectedContact(contact);
                    }
                    finally
                    {
                        try { _profileMutationGate.Release(); }
                        finally { ScheduleGameplayProgressEventDrain(); }
                    }
                }
            }
        }

        private bool HasF10CacheSessionBindings(ExpeditionGameplayComposition owner)
        {
            return owner != null && owner.IsReady && ActiveRun != null && _activeExpedition != null &&
                OwnsF10DiagnosticRun(ActiveRun) &&
                ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, owner) &&
                ReferenceEquals(_expeditionSessionMutationPublicationOwner, owner) &&
                _expeditionSessionStateCapture != null && _expeditionSessionMutationPreparer != null &&
                _expeditionSimulationPauseLeaseProvider != null;
        }

        private bool TryResolveF10CacheReward(ExpeditionRunConfiguration run, ExpeditionSaveData checkpoint,
            ExplorationGoldCacheContact contact, out ExpeditionExplorationCacheReward reward, out string error)
        {
            reward = null;
            error = string.Empty;
            if (!TryValidateF10CachePhysicalContext(run, checkpoint, contact, requireCurrentContact: true, out error))
                return false;

            ExpeditionRouteNode[] matchingNodes = run.Route.Nodes.Where(node =>
                string.Equals(node.NodeId, F10CacheNodeId, StringComparison.Ordinal)).ToArray();
            try
            {
                reward = ResolveF10CacheRewardFromSavedContext(run, checkpoint, matchingNodes[0], contact.CacheId);
            }
            catch (Exception exception)
            {
                return FailF10CacheContext("The saved Patio E1 reward context is invalid: " + exception.Message, out error);
            }

            if (reward == null || reward.Gold <= 0 || string.IsNullOrWhiteSpace(reward.GoldGrantId))
                return FailF10CacheContext("The cache policy produced no valid physical gold reward.", out error);
            return true;
        }

        private bool TryValidateF10CachePhysicalContext(ExpeditionRunConfiguration run,
            ExpeditionSaveData checkpoint, ExplorationGoldCacheContact contact, bool requireCurrentContact,
            out string error)
        {
            error = string.Empty;
            if (run == null || checkpoint == null || contact == null || contact.Pickup == null ||
                contact.Scope == null || contact.Marker == null || contact.Player == null)
                return FailF10CacheContext("The physical cache contact is incomplete.", out error);
            if (!HasF10CacheSessionBindingsFor(run, contact) ||
                (requireCurrentContact
                    ? !contact.Pickup.IsPendingContactCurrent(contact)
                    : !contact.Pickup.HasPendingContact))
                return FailF10CacheContext(
                    "The cache contact is no longer current for the active F10 player and room.", out error);
            if (!string.Equals(checkpoint.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                checkpoint.seed != run.Seed || checkpoint.generationVersion != run.Route.GenerationVersion ||
                !string.Equals(checkpoint.currentNodeId, F10CacheNodeId, StringComparison.Ordinal))
                return FailF10CacheContext("The saved run is not at the F10 Patio E1 cache node.", out error);

            ExpeditionRouteNode[] matchingNodes = run.Route.Nodes.Where(node =>
                string.Equals(node.NodeId, F10CacheNodeId, StringComparison.Ordinal)).ToArray();
            if (matchingNodes.Length != 1 || matchingNodes[0].Kind != ExpeditionRouteNodeKind.Exploration ||
                !string.Equals(matchingNodes[0].TemplateId, F10CacheTemplateId, StringComparison.Ordinal) ||
                !string.Equals(matchingNodes[0].SectorId, "patio", StringComparison.Ordinal) ||
                !string.Equals(contact.Scope.TemplateId, F10CacheTemplateId, StringComparison.Ordinal) ||
                !string.Equals(contact.CacheId, F10CacheRoomMarkerId, StringComparison.Ordinal) ||
                !string.Equals(contact.Marker.MarkerId, F10CacheRoomMarkerId, StringComparison.Ordinal) ||
                !string.Equals(contact.Marker.Kind, "treasure", StringComparison.Ordinal))
                return FailF10CacheContext("The contact does not match the unique cache marker in Patio E1.", out error);

            RoomTemplatePrefab2D[] roomPrefabs = contact.Scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            TextAsset canonicalDefinition = Resources.Load<TextAsset>(F10CacheRoomDefinitionResource);
            if (roomPrefabs.Length != 1 || roomPrefabs[0] == null || !roomPrefabs[0].isActiveAndEnabled ||
                EditorUtility.IsPersistent(roomPrefabs[0].gameObject) || canonicalDefinition == null ||
                roomPrefabs[0].SourceDefinition == null ||
                !string.Equals(roomPrefabs[0].SourceDefinition.text, canonicalDefinition.text, StringComparison.Ordinal) ||
                !(ReferenceEquals(roomPrefabs[0].transform, contact.Scope.transform) ||
                    roomPrefabs[0].transform.IsChildOf(contact.Scope.transform)))
                return FailF10CacheContext("The active E1 scope must own one live room prefab with its canonical JSON source.", out error);

            RoomTemplatePrefab2D roomPrefab = roomPrefabs[0];
            RoomTemplateData roomData;
            try { roomData = RoomTemplateJsonLoader.Load(roomPrefab.SourceDefinition.text); }
            catch (Exception exception)
            {
                return FailF10CacheContext("The active E1 room JSON could not be parsed: " + exception.Message, out error);
            }
            if (roomData == null || !string.Equals(roomData.templateId, F10CacheTemplateId, StringComparison.Ordinal) ||
                roomData.markers == null)
                return FailF10CacheContext("The active room source is not the Patio E1 JSON definition.", out error);

            RoomPositionMarkerData[] cacheDefinitions = roomData.markers.Where(marker => marker != null &&
                string.Equals(marker.id, F10CacheRoomMarkerId, StringComparison.Ordinal)).ToArray();
            if (cacheDefinitions.Length != 1 || !string.Equals(cacheDefinitions[0].kind, "treasure", StringComparison.Ordinal) ||
                cacheDefinitions[0].tileX != 21 || cacheDefinitions[0].tileY != 8 || roomData.tileSize <= 0)
                return FailF10CacheContext("The E1 JSON must define one treasure cache at tile (21, 8).", out error);

            RoomPositionMarker2D[] matchingMarkers = contact.Scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(marker => marker != null && string.Equals(marker.MarkerId, F10CacheRoomMarkerId,
                    StringComparison.Ordinal)).ToArray();
            ExplorationGoldCachePickup2D[] matchingPickups = contact.Scope
                .GetComponentsInChildren<ExplorationGoldCachePickup2D>(true);
            if (matchingMarkers.Length != 1 || !ReferenceEquals(matchingMarkers[0], contact.Marker) ||
                matchingPickups.Length != 1 || !ReferenceEquals(matchingPickups[0], contact.Pickup))
                return FailF10CacheContext("Patio E1 must own exactly this one cache marker and pickup.", out error);

            RoomPositionMarkerData cacheDefinition = cacheDefinitions[0];
            Vector3 expectedPose = roomPrefab.transform.TransformPoint(new Vector3(
                (cacheDefinition.tileX + 0.5f) * roomData.tileSize, cacheDefinition.tileY * roomData.tileSize, 0f));
            RoomPositionMarker2D marker = matchingMarkers[0];
            ExplorationGoldCachePickup2D pickup = matchingPickups[0];
            if (!marker.isActiveAndEnabled || !marker.gameObject.activeInHierarchy ||
                marker.TilePosition != new Vector2Int(cacheDefinition.tileX, cacheDefinition.tileY) ||
                !(ReferenceEquals(marker.transform, roomPrefab.transform) || marker.transform.IsChildOf(roomPrefab.transform)) ||
                !IsNearF10CachePose(marker.transform.position, expectedPose) ||
                Quaternion.Angle(marker.transform.rotation, roomPrefab.transform.rotation) > F10CachePoseTolerance ||
                !IsNearF10CachePose(marker.transform.lossyScale, roomPrefab.transform.lossyScale) ||
                !pickup.isActiveAndEnabled || !pickup.gameObject.activeInHierarchy || !pickup.HasPendingContact ||
                !ReferenceEquals(pickup.transform.parent, contact.Scope.transform) ||
                !IsNearF10CachePose(pickup.transform.position, expectedPose) ||
                Quaternion.Angle(pickup.transform.rotation, roomPrefab.transform.rotation) > F10CachePoseTolerance ||
                !IsNearF10CachePose(pickup.transform.lossyScale, roomPrefab.transform.lossyScale))
                return FailF10CacheContext("The unique live cache marker and pickup must match the JSON-derived E1 pose.", out error);

            return true;
        }

        private static bool IsNearF10CachePose(Vector3 actual, Vector3 expected)
        {
            return (actual - expected).sqrMagnitude <= F10CachePoseTolerance * F10CachePoseTolerance;
        }

        /// <summary>Resolves the cache policy from the exact saved route, seed, and pact context.</summary>
        internal static ExpeditionExplorationCacheReward ResolveF10CacheRewardFromSavedContext(
            ExpeditionRunConfiguration run, ExpeditionSaveData checkpoint, ExpeditionRouteNode node, string cacheKey)
        {
            if (run == null) throw new ArgumentNullException(nameof(run));
            if (checkpoint == null) throw new ArgumentNullException(nameof(checkpoint));
            if (node == null) throw new ArgumentNullException(nameof(node));
            if (!string.Equals(checkpoint.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                checkpoint.seed != run.Seed || checkpoint.generationVersion != run.Route.GenerationVersion ||
                !string.Equals(checkpoint.currentNodeId, F10CacheNodeId, StringComparison.Ordinal) ||
                !string.Equals(node.NodeId, F10CacheNodeId, StringComparison.Ordinal) ||
                !string.Equals(node.TemplateId, F10CacheTemplateId, StringComparison.Ordinal) ||
                !string.Equals(node.SectorId, "patio", StringComparison.Ordinal) ||
                node.Kind != ExpeditionRouteNodeKind.Exploration ||
                !string.Equals(cacheKey, F10CacheRoomMarkerId, StringComparison.Ordinal))
                throw new InvalidOperationException("The saved run and route must identify the exact F10 Patio E1 cache.");
            if (checkpoint.pactIds == null || checkpoint.claimedRewardIds == null ||
                checkpoint.pactIds.Any(string.IsNullOrWhiteSpace) || checkpoint.claimedRewardIds.Any(string.IsNullOrWhiteSpace) ||
                checkpoint.claimedRewardIds.Distinct(StringComparer.Ordinal).Count() != checkpoint.claimedRewardIds.Length)
                throw new InvalidOperationException("The saved pact or claimed-reward context is invalid.");

            bool avariceActive = checkpoint.pactIds.Contains(PactIds.Avarice, StringComparer.Ordinal);
            var request = new ExpeditionEncounterRewardRequest(RunId.Parse(checkpoint.runId), checkpoint.seed,
                checkpoint.generationVersion, node.NodeId, node.TemplateId, node.SectorId, node.Kind,
                Array.Empty<ExpeditionEncounterRewardSpawn>(), avaricePactActive: avariceActive,
                vinculoPactActive: false, hasExplorationCache: true, explorationCacheKey: cacheKey);
            return ExpeditionEncounterRewardPolicy.Resolve(request).ExplorationCacheReward;
        }

        private bool HasF10CacheSessionBindingsFor(ExpeditionRunConfiguration run,
            ExplorationGoldCacheContact contact)
        {
            ExpeditionGameplayComposition owner = contact == null ? null :
                _expeditionSessionMutationPublicationOwner as ExpeditionGameplayComposition;
            ExpeditionRoomTransitionController transitions = owner == null ? null : owner.RoomTransitions;
            GameObject activeRoomRoot = transitions == null ? null : transitions.ActiveRoomRoot;
            return run != null && HasF10CacheSessionBindings(owner) &&
                ReferenceEquals(ActiveRun, run) &&
                ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, owner) &&
                ReferenceEquals(contact.Player, owner.PlayerMotor) &&
                owner.PlayerObject == contact.Player.gameObject &&
                transitions != null && !transitions.IsDisposed &&
                ReferenceEquals(transitions.ActiveScope, contact.Scope) &&
                ReferenceEquals(activeRoomRoot, contact.Scope.gameObject) && activeRoomRoot.activeInHierarchy &&
                transitions.IsCurrentRoom(contact.RoomInstanceId) && transitions.CurrentRoomId == contact.RoomInstanceId &&
                contact.Scope.RoomInstanceId == contact.RoomInstanceId && !contact.Scope.IsDisposed &&
                contact.Scope.isActiveAndEnabled &&
                contact.RoomInstanceId == ActiveRoomInstanceId &&
                string.Equals(transitions.CurrentNodeId, F10CacheNodeId, StringComparison.Ordinal) &&
                string.Equals(_activeExpedition.currentNodeId, F10CacheNodeId, StringComparison.Ordinal);
        }

        private static bool IsSameF10CacheRewardContext(ExpeditionSaveData before, ExpeditionSaveData after,
            ExpeditionRunConfiguration run, ExplorationGoldCacheContact contact)
        {
            return before != null && after != null && run != null && contact != null &&
                string.Equals(before.runId, after.runId, StringComparison.Ordinal) &&
                string.Equals(before.runId, run.RunId.ToString(), StringComparison.Ordinal) &&
                before.seed == after.seed && before.seed == run.Seed &&
                before.generationVersion == after.generationVersion &&
                before.generationVersion == run.Route.GenerationVersion &&
                string.Equals(before.currentNodeId, after.currentNodeId, StringComparison.Ordinal) &&
                string.Equals(before.currentNodeId, F10CacheNodeId, StringComparison.Ordinal) &&
                before.pactIds.SequenceEqual(after.pactIds, StringComparer.Ordinal) &&
                before.claimedRewardIds.SequenceEqual(after.claimedRewardIds, StringComparer.Ordinal) &&
                contact.RoomInstanceId.IsValid;
        }

        private void AttachF10CacheClaimToPendingPublication(PendingF10CacheClaim pending)
        {
            if (_pendingExpeditionSessionPublication == null)
                throw new InvalidOperationException("The exact pending cache candidate has no session publication to complete it.");
            if (_pendingF10CacheClaim != null && !ReferenceEquals(_pendingF10CacheClaim, pending))
                throw new InvalidOperationException("Another physical cache contact already owns the pending publication.");
            if (pending.PublicationAttached) return;

            Action publishSession = _pendingExpeditionSessionPublication;
            _pendingF10CacheClaim = pending;
            _pendingExpeditionSessionPublication = () =>
            {
                publishSession();
                CompletePendingF10CacheClaim(pending, pausedPublication: true);
            };
            pending.PublicationAttached = true;
        }

        private bool HasPendingF10CacheOperation(PendingF10CacheClaim pending)
        {
            return pending != null && ReferenceEquals(_pendingF10CacheClaim, pending) &&
                (HasPendingExpeditionWrite || _pendingExpeditionSessionPublication != null);
        }

        /// <summary>Read-only identity check for the exact cache contact retained by this application instance.</summary>
        internal bool OwnsPendingF10CacheContact(ExpeditionGameplayComposition owner,
            ExplorationGoldCacheContact contact)
        {
            PendingF10CacheClaim pending = _pendingF10CacheClaim;
            return pending != null && ReferenceEquals(pending.Owner, owner) &&
                ReferenceEquals(pending.Contact, contact);
        }

        private bool TryAttachF10CacheClaimToPendingPublication(PendingF10CacheClaim pending)
        {
            if (!HasPendingF10CacheOperation(pending)) return false;
            if (pending.PublicationAttached) return true;
            try
            {
                AttachF10CacheClaimToPendingPublication(pending);
                return true;
            }
            catch
            {
                // Keep the exact claim/contact retained so explicit retry can reconcile it after the save.
                return false;
            }
        }

        private void CompletePendingF10CacheClaim(PendingF10CacheClaim pending, bool pausedPublication)
        {
            if (pending == null || !IsF10CacheClaimDurable(pending))
                throw new InvalidOperationException("A physical cache cannot be consumed before its gold and claim are durable.");
            ConsumeF10CachePickupAfterCommittedClaim(pending.Owner, pending.Contact, pending.RunId,
                pending.CommittedRun, pending.RoomInstanceId, pending.GoldGrantId, pending.GoldAmount,
                pausedPublication);
            if (ReferenceEquals(_pendingF10CacheClaim, pending)) _pendingF10CacheClaim = null;
        }

        private bool IsF10CacheClaimDurable(PendingF10CacheClaim pending)
        {
            return pending != null && _activeExpedition != null && ActiveRun != null &&
                string.Equals(_activeExpedition.runId, pending.RunId.ToString(), StringComparison.Ordinal) &&
                ActiveRun.RunId == pending.RunId && pending.CommittedRun != null &&
                pending.CommittedRun.RunId == pending.RunId &&
                _activeExpedition.claimedRewardIds != null &&
                _activeExpedition.claimedRewardIds.Contains(pending.GoldGrantId, StringComparer.Ordinal) &&
                ReferenceEquals(ActiveRun, pending.CommittedRun) && ActiveRun.Inventory != null &&
                HasSuccessfulF10CacheTransaction(ActiveRun.Inventory.CreateSnapshot(),
                    CreateF10CacheTransactionId(pending.GoldGrantId), pending.GoldAmount);
        }

        private void ConsumeF10CachePickupAfterCommittedClaim(ExpeditionGameplayComposition owner,
            ExplorationGoldCacheContact contact, RunId runId, ExpeditionRunConfiguration committedRun,
            RoomInstanceId roomInstanceId, string goldGrantId, int goldAmount, bool pausedPublication)
        {
            if (!IsF10CacheClaimDurable(new PendingF10CacheClaim(owner, contact, runId,
                    roomInstanceId, committedRun, goldGrantId, goldAmount, null)))
                throw new InvalidOperationException("The cache grant is not present in the committed expedition.");

            bool exactOwnerAndScope = owner != null && contact != null && contact.Player != null &&
                contact.Scope != null && owner.IsReady && OwnsF10DiagnosticRun(ActiveRun) &&
                ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, owner) &&
                ReferenceEquals(_expeditionSessionMutationPublicationOwner, owner) &&
                ReferenceEquals(owner.PlayerMotor, contact.Player) && owner.PlayerObject == contact.Player.gameObject &&
                owner.RoomTransitions != null && !owner.RoomTransitions.IsDisposed &&
                ReferenceEquals(owner.RoomTransitions.ActiveScope, contact.Scope) &&
                owner.RoomTransitions.IsCurrentRoom(roomInstanceId) &&
                owner.RoomTransitions.CurrentRoomId == roomInstanceId &&
                ReferenceEquals(owner.RoomTransitions.ActiveRoomRoot, contact.Scope.gameObject) &&
                contact.Scope != null && !contact.Scope.IsDisposed &&
                contact.Scope.RoomInstanceId == roomInstanceId &&
                contact.CacheId == F10CacheRoomMarkerId && contact.Marker != null &&
                contact.Marker.MarkerId == F10CacheRoomMarkerId && contact.Marker.Kind == "treasure" &&
                contact.Pickup != null && contact.Pickup.isActiveAndEnabled &&
                contact.Pickup.HasPendingContact && ReferenceEquals(contact.Pickup.transform.parent, contact.Scope.transform);
            if (exactOwnerAndScope && (pausedPublication || contact.Pickup.IsPendingContactCurrent(contact)))
            {
                try
                {
                    contact.Pickup.gameObject.SetActive(false);
                    return;
                }
                catch (Exception)
                {
                    // The durable claim and inventory transaction are already authoritative. A later Stay
                    // will be recognized as a replay if this scene actor cannot be hidden immediately.
                }
            }

            if (contact != null && contact.Pickup != null)
                contact.Pickup.ReleaseRejectedContact(contact);
        }

        private ExpeditionMutationCommitResult<InventoryOperationOutcome> RejectF10CacheContact(
            ExplorationGoldCacheContact contact, string message, InventoryOperationOutcome rejectedOutcome = null)
        {
            contact?.Pickup?.ReleaseRejectedContact(contact);
            return new ExpeditionMutationCommitResult<InventoryOperationOutcome>(rejectedOutcome, false, false, message);
        }

        private static bool FailF10CacheContext(string message, out string error)
        {
            error = message;
            return false;
        }

        internal static TransactionId CreateF10CacheTransactionId(string goldGrantId)
        {
            if (string.IsNullOrWhiteSpace(goldGrantId))
                throw new ArgumentException("A stable gold grant ID is required.", nameof(goldGrantId));
            byte[] digest;
            using (SHA256 sha256 = SHA256.Create())
                digest = sha256.ComputeHash(Encoding.UTF8.GetBytes("luckbound-f10-cache-transaction-v1|" + goldGrantId));
            var canonical = new StringBuilder(32);
            for (int index = 0; index < 16; index++) canonical.Append(digest[index].ToString("x2"));
            Guid value = Guid.ParseExact(canonical.ToString(), "N");
            if (value == Guid.Empty) value = Guid.ParseExact("00000000000000000000000000000001", "N");
            return new TransactionId(value);
        }

        private static bool HasSuccessfulF10CacheTransaction(ExpeditionInventorySnapshot snapshot,
            TransactionId transactionId, int goldAmount)
        {
            if (snapshot == null || snapshot.transactions == null || !transactionId.IsValid || goldAmount <= 0)
                return false;
            string expectedSignature = "gold|" + goldAmount.ToString(CultureInfo.InvariantCulture);
            return snapshot.transactions.Any(transaction => transaction != null &&
                string.Equals(transaction.transactionId, transactionId.ToString(), StringComparison.Ordinal) &&
                transaction.status == (int)InventoryOperationStatus.Succeeded &&
                string.Equals(transaction.signature, expectedSignature, StringComparison.Ordinal) &&
                string.Equals(transaction.itemId, "currency.gold", StringComparison.Ordinal) &&
                transaction.craftingStatus == (int)CraftingOperationStatus.Unknown &&
                transaction.economyStatus == 0);
        }

        private sealed class PendingF10CacheClaim
        {
            internal PendingF10CacheClaim(ExpeditionGameplayComposition owner, ExplorationGoldCacheContact contact,
                RunId runId, RoomInstanceId roomInstanceId, ExpeditionRunConfiguration committedRun,
                string goldGrantId, int goldAmount, InventoryOperationOutcome outcome)
            {
                Owner = owner;
                Contact = contact;
                RunId = runId;
                RoomInstanceId = roomInstanceId;
                CommittedRun = committedRun;
                GoldGrantId = goldGrantId;
                GoldAmount = goldAmount;
                Outcome = outcome;
            }

            internal ExpeditionGameplayComposition Owner { get; }
            internal ExplorationGoldCacheContact Contact { get; }
            internal RunId RunId { get; }
            internal RoomInstanceId RoomInstanceId { get; }
            internal ExpeditionRunConfiguration CommittedRun { get; }
            internal string GoldGrantId { get; }
            internal int GoldAmount { get; }
            internal InventoryOperationOutcome Outcome { get; }
            internal bool PublicationAttached { get; set; }
        }
    }
}
#endif
