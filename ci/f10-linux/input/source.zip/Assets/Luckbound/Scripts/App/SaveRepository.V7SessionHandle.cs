#if UNITY_EDITOR
using System;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves.V7;

namespace Luckbound.App
{
    public sealed partial class SaveRepository
    {
        // Only SafeOpen can supply this reference: it is never serialized, exposed, or caller-selected.
        private static readonly object F10V7SessionHandleFactoryKey = new object();
        private F10V7SessionHandle _f10V7SessionHandle;

        /// <summary>
        /// Checks the exact capability retained by this repository. The opening JSON is a historical
        /// admission snapshot, not the current confirmed JSON after any future commit.
        /// </summary>
        internal bool IsRetainedF10V7SessionHandle(F10V7SessionHandle handle,
            string exactOpeningJson, RunId runId, ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 registry)
        {
            return handle != null && ReferenceEquals(_f10V7SessionHandle, handle) &&
                handle.IsBoundTo(this, exactOpeningJson, runId, itemCatalog, registry);
        }

        /// <summary>
        /// Single non-fabricable capability minted by authenticated V7 SafeOpen under _gate.
        /// It retains the complete post-restore baseline for a future owner; it grants no gameplay
        /// or physical outcome authority and does not reserve/consume rollback by itself.
        /// </summary>
        internal sealed class F10V7SessionHandle
        {
            private readonly SaveRepository _repository;
            private readonly string _exactOpeningJson;
            private readonly RunId _runId;
            private readonly ItemCatalog _itemCatalog;
            private readonly EncounterCatalogRegistryV1 _registry;
            private readonly ExpeditionSaveDataV7 _baselineState;

            internal F10V7SessionHandle(object factoryKey, SaveRepository repository,
                string exactOpeningJson, RunId runId, ItemCatalog itemCatalog,
                EncounterCatalogRegistryV1 registry, ExpeditionSaveDataV7 baselineState)
            {
                if (!ReferenceEquals(factoryKey, F10V7SessionHandleFactoryKey))
                    throw new InvalidOperationException("Only authenticated V7 SafeOpen may mint this capability.");
                if (repository == null) throw new ArgumentNullException(nameof(repository));
                if (string.IsNullOrWhiteSpace(exactOpeningJson))
                    throw new ArgumentException("The exact opening JSON is required.", nameof(exactOpeningJson));
                if (!runId.IsValid) throw new ArgumentException("A valid RunId is required.", nameof(runId));
                if (itemCatalog == null) throw new ArgumentNullException(nameof(itemCatalog));
                if (registry == null) throw new ArgumentNullException(nameof(registry));
                if (baselineState == null) throw new ArgumentNullException(nameof(baselineState));
                if (!RunId.TryParse(baselineState.runId, out RunId baselineRunId) || baselineRunId != runId)
                    throw new ArgumentException("The restored baseline must match the admitted RunId.", nameof(baselineState));

                _repository = repository;
                _exactOpeningJson = exactOpeningJson;
                _runId = runId;
                _itemCatalog = itemCatalog;
                _registry = registry;
                _baselineState = SaveV7Clone.Clone(baselineState);
                if (_baselineState == null)
                    throw new ArgumentException("The restored baseline could not be cloned.", nameof(baselineState));
            }

            internal SaveRepository Repository => _repository;

            /// <summary>The exact JSON authenticated at admission; future commits must track newer bytes separately.</summary>
            internal string ExactJson => _exactOpeningJson;

            internal RunId RunId => _runId;
            internal ItemCatalog ItemCatalog => _itemCatalog;
            internal EncounterCatalogRegistryV1 Registry => _registry;

            /// <summary>Returns a complete deep clone so callers cannot mutate the retained opening baseline.</summary>
            internal ExpeditionSaveDataV7 BaselineState => SaveV7Clone.Clone(_baselineState);

            /// <summary>
            /// Tests identity against the opening admission snapshot only. It does not assert that
            /// ExactJson remains the repository's confirmed JSON after later commits.
            /// </summary>
            internal bool IsBoundTo(SaveRepository repository, string exactOpeningJson,
                RunId runId, ItemCatalog itemCatalog, EncounterCatalogRegistryV1 registry)
            {
                return ReferenceEquals(_repository, repository) &&
                    string.Equals(_exactOpeningJson, exactOpeningJson, StringComparison.Ordinal) &&
                    _runId == runId && ReferenceEquals(_itemCatalog, itemCatalog) &&
                    ReferenceEquals(_registry, registry);
            }
        }
    }
}
#endif
