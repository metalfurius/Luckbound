#if UNITY_EDITOR
using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>App-owned V7 Tutorial-to-C1 commit lane; never enters the V6 profile writer.</summary>
    public sealed partial class ApplicationBootstrapper
    {
        private static readonly UTF8Encoding StrictF10V7TutorialUtf8 = new UTF8Encoding(false, true);
        private PendingF10V7TutorialAdvance _pendingF10V7TutorialAdvance;

        internal async Task<ExpeditionEncounterAdvanceOutcome> CommitAdmittedV7TutorialAdvanceAsync(
            ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
            F10V7SessionInitializationBinding binding, ExpeditionEncounterResolutionScope scope,
            ExpeditionInventory candidateInventory, string expectedBaseInventorySnapshotJson,
            long expectedExpeditionRevision)
        {
            bool acquiredMutationGate = false;
            bool operationClaimed = false;
            object operationToken = null;
            PendingF10V7TutorialAdvance pending = _pendingF10V7TutorialAdvance;
            try
            {
                if (pending == null)
                {
                    await _profileMutationGate.WaitAsync();
                    acquiredMutationGate = true;
                    if (_pendingF10V7TutorialAdvance != null)
                        return PendingF10V7TutorialOutcome(_pendingF10V7TutorialAdvance,
                            "A V7 tutorial advance was retained while this call waited for the App gate.");
                    if (!TryPreparePendingF10V7TutorialAdvance(composition, registration, binding, scope,
                            candidateInventory, expectedBaseInventorySnapshotJson,
                            expectedExpeditionRevision, out pending, out string prepareError))
                    {
                        if (pending != null && pending.MutationGateRetained &&
                            ReferenceEquals(_pendingF10V7TutorialAdvance, pending))
                            acquiredMutationGate = false;
                        if (pending != null && pending.MutationGateRetained)
                            return PendingF10V7TutorialOutcome(pending, prepareError);
                        return ExpeditionEncounterAdvanceOutcome.Failure(false, prepareError);
                    }
                    if (!TryAcquirePendingF10V7TutorialAdvanceOperation(pending, out operationToken))
                        return PendingF10V7TutorialOutcome(pending,
                            "The exact V7 tutorial operation is already running.");
                    operationClaimed = true;
                    pending.MutationGateRetained = true;
                    _pendingF10V7TutorialAdvance = pending;
                    acquiredMutationGate = false; // This exact pending operation owns the gate until resolved.
                }
                else if (!pending.MutationGateRetained ||
                    !MatchesPendingF10V7TutorialAdvance(pending, composition, registration, binding,
                        scope, candidateInventory, expectedBaseInventorySnapshotJson,
                        expectedExpeditionRevision))
                {
                    return PendingF10V7TutorialOutcome(pending,
                        "Only the exact retained V7 tutorial scope, candidate, owner, and retry may continue.");
                }
                else
                {
                    if (pending.UnwrittenCleanupFailed)
                        return PendingF10V7TutorialOutcome(pending,
                            "The retained pre-write cleanup failed; the owner remains locked and no repository operation may start.");
                    if (!TryAcquirePendingF10V7TutorialAdvanceOperation(pending, out operationToken))
                        return PendingF10V7TutorialOutcome(pending,
                            "The exact V7 tutorial operation is already running; no overlapping commit or retry was started.");
                    operationClaimed = true;
                }

                if (!IsCurrentV7TutorialAdvanceOwner(composition, registration, binding))
                    return PendingF10V7TutorialOutcome(pending,
                        "The exact App V7 tutorial owner changed; the retained transaction remains locked.");

                F10V7SessionCommitResult commit;
                try
                {
                    commit = pending.RepositoryPending || pending.RepositoryConfirmed
                        ? await _saveRepository.RetryF10V7SessionForPreproductionAsync(binding.SessionHandle)
                        : await _saveRepository.CommitF10V7SessionForPreproductionAsync(binding.SessionHandle,
                            pending.Candidate);
                    // Preserve the repository's exact return before any post-await identity or revision check.
                    // The DTO is not an authority; only this private pending operation may retain it.
                    pending.CaptureRepositoryCommitResult(commit);
                    if (commit == null || commit.Pending)
                        pending.RepositoryPending = true;
                    else if (commit.Persisted)
                    {
                        if (string.IsNullOrWhiteSpace(commit.ConfirmedJson))
                            pending.RepositoryPending = true;
                        else if (pending.ConfirmedJson == null || string.Equals(pending.ConfirmedJson,
                                     commit.ConfirmedJson, StringComparison.Ordinal))
                        {
                            pending.ConfirmedJson = commit.ConfirmedJson;
                            pending.RepositoryConfirmed = true;
                            pending.RepositoryPending = false;
                        }
                        else pending.RepositoryPending = true;
                    }
                    else pending.RepositoryPending = pending.RepositoryConfirmed;
                }
                catch (Exception exception)
                {
                    pending.RepositoryPending = true;
                    return PendingF10V7TutorialOutcome(pending,
                        "The exact V7 write/readback outcome is uncertain; retain this candidate for retry. " + exception.Message);
                }

                if (!ReferenceEquals(_pendingF10V7TutorialAdvance, pending) || !pending.MutationGateRetained ||
                    !ReferenceEquals(pending.ActiveOperationToken, operationToken) ||
                    pending.OperationInFlight != 1 ||
                    !IsCurrentV7TutorialAdvanceOwner(composition, registration, binding) ||
                    !IsExactCurrentOrPartialF10V7TutorialPublication(pending))
                    return PendingF10V7TutorialOutcome(pending,
                        "The repository result was retained, but the App owner or revision changed while awaiting it; publication is blocked.");

                if (commit == null)
                {
                    pending.RepositoryPending = true;
                    return PendingF10V7TutorialOutcome(pending,
                        "The repository returned no V7 commit result; the exact candidate remains retained.");
                }

                if (!commit.Persisted)
                {
                    pending.RepositoryPending = commit.Pending || pending.RepositoryConfirmed;
                    if (pending.RepositoryConfirmed || commit.Pending)
                        return PendingF10V7TutorialOutcome(pending, commit.Message);
                    DiscardUnwrittenPendingF10V7TutorialAdvance(pending);
                    return ExpeditionEncounterAdvanceOutcome.Failure(false, commit.Message);
                }
                if (string.IsNullOrWhiteSpace(commit.ConfirmedJson))
                {
                    pending.RepositoryPending = true;
                    return PendingF10V7TutorialOutcome(pending,
                        "The repository reported persistence without exact authenticated readback JSON.");
                }
                bool retainProjectionForExactJson = pending.ConfirmedProjection != null &&
                    string.Equals(pending.ConfirmedJson, commit.ConfirmedJson, StringComparison.Ordinal);
                if (pending.ConfirmedJson != null && !string.Equals(pending.ConfirmedJson,
                        commit.ConfirmedJson, StringComparison.Ordinal))
                    return PendingF10V7TutorialOutcome(pending,
                        "The repository retry returned bytes different from the retained ConfirmedJson.");

                pending.ConfirmedJson = commit.ConfirmedJson;
                pending.RepositoryConfirmed = true;
                pending.RepositoryPending = false;
                if (!TryValidateConfirmedF10V7TutorialCandidate(pending, retainProjectionForExactJson,
                        out string confirmedError))
                    return PendingF10V7TutorialOutcome(pending, confirmedError);

                if (!pending.ReceiptRegistered)
                {
                    if (!RegisterPendingAdmittedV7Publication(binding, registration, pending.Publication,
                            pending.ExpectedExpeditionRevision, out string registrationError))
                        return PendingF10V7TutorialOutcome(pending,
                            "The confirmed V7 publication receipt could not be registered: " + registrationError);
                    pending.ReceiptRegistered = true;
                }
                if (!pending.Promoted)
                {
                    if (!PromoteConfirmedAdmittedV7Publication(binding, registration, pending.Publication,
                            out string promotionError))
                        return PendingF10V7TutorialOutcome(pending,
                            "The authenticated V7 tutorial state could not be promoted: " + promotionError);
                    pending.ConfirmedRevision = _activeExpeditionRevision;
                    pending.Promoted = true;
                }

                if (!pending.PublicationPublished)
                {
                    try
                    {
                        pending.Publication.PublishConfirmed();
                        pending.PublicationPublished = true;
                    }
                    catch (Exception exception)
                    {
                        return PendingF10V7TutorialOutcome(pending,
                            "The durable V7 candidate is retained while its real actor publication is retried. " + exception.Message);
                    }
                }

                bool activated = IsF10V7TutorialC1Activated(pending);
                if (!activated && IsAtF10V7C1Route(pending))
                    return PendingF10V7TutorialOutcome(pending,
                        HasExactF10V7C1Activation(pending)
                            ? "C1 is already active but its confirmed App snapshot is not reconciled; the consumed room transition will not be replayed."
                            : "C1 is active without the exact V7 actor/scope witness; the consumed room transition will not be replayed.");
                if (!activated)
                {
                    if (pending.PreparedTransition == null || !pending.PreparedTransition.IsPending)
                        return PendingF10V7TutorialOutcome(pending,
                            "The retained prepared transition has already been consumed; it will not be invoked again.");
                    try { activated = pending.TransitionController.TryCommitPreparedTransition(pending.PreparedTransition); }
                    catch (Exception exception)
                    {
                        activated = IsF10V7TutorialC1Activated(pending);
                        if (!activated)
                            return PendingF10V7TutorialOutcome(pending,
                                "The durable candidate and actor publication are retained while C1 activation is retried. " + exception.Message);
                    }
                }
                if (!activated || !IsF10V7TutorialC1Activated(pending))
                    return PendingF10V7TutorialOutcome(pending,
                        "The V7 C1 state is durable, but its exact prepared room/actor activation is not yet confirmed.");

                CompletePendingF10V7TutorialAdvance(pending);
                return new ExpeditionEncounterAdvanceOutcome(true, false, false, true,
                    "The rewardless V7 Tutorial completion is read back, published, and bound to C1.");
            }
            catch (Exception exception)
            {
                return PendingF10V7TutorialOutcome(pending,
                    "V7 Tutorial-to-C1 failed closed: " + exception.Message);
            }
            finally
            {
                if (operationClaimed && pending != null)
                    ReleasePendingF10V7TutorialAdvanceOperation(pending, operationToken);
                if (acquiredMutationGate) _profileMutationGate.Release();
            }
        }

        private bool TryPreparePendingF10V7TutorialAdvance(
            ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
            F10V7SessionInitializationBinding binding, ExpeditionEncounterResolutionScope scope,
            ExpeditionInventory candidateInventory, string expectedBaseInventorySnapshotJson,
            long expectedExpeditionRevision, out PendingF10V7TutorialAdvance pending, out string error)
        {
            pending = null;
            error = string.Empty;
            IDisposable pauseLease = null;
            ExpeditionRoomTransitionController.PreparedRoomTransition preparedTransition = null;
            try
            {
                if (!TryGetExactAcceptedV7TutorialCoordinator(composition, out F10TutorialAdvanceCoordinator coordinator) ||
                    !coordinator.OwnsAcceptedV7TutorialResolution(this, composition, registration, binding, scope))
                    return Fail("No unique V7 Tutorial coordinator owns the synchronously accepted observation and exact resolver scope.", out error);

                if (!IsCurrentV7TutorialAdvanceOwner(composition, registration, binding) ||
                    !IsCurrentV7PublishedSession(binding, registration, binding.PublishedRevision) ||
                    _activeExpeditionRevision != expectedExpeditionRevision ||
                    expectedExpeditionRevision != binding.PublishedRevision || ActiveExpedition == null ||
                    !string.Equals(ActiveExpedition.currentNodeId,
                        F10V7TutorialAdvanceCandidate.TutorialNodeId, StringComparison.Ordinal) ||
                    _pendingF10V7TutorialAdvance != null || HasOtherPendingSessionMutationForV7TutorialAdvance() ||
                    scope == null || !scope.HasCompletion ||
                    !ReferenceEquals(scope.CandidateInventory, candidateInventory) ||
                    scope.ExpectedExpeditionRevision != expectedExpeditionRevision ||
                    !string.Equals(scope.ExpectedBaseInventorySnapshotJson,
                        expectedBaseInventorySnapshotJson, StringComparison.Ordinal) ||
                    string.IsNullOrWhiteSpace(expectedBaseInventorySnapshotJson) ||
                    scope.SourceRoomId != ExpeditionRoomIdentity.ForNode(binding.Run.RunId,
                        F10V7TutorialAdvanceCandidate.TutorialNodeId) ||
                    !string.Equals(scope.SourceNodeId, F10V7TutorialAdvanceCandidate.TutorialNodeId,
                        StringComparison.Ordinal) ||
                    !string.Equals(scope.TargetNodeId, F10V7TutorialAdvanceCandidate.C1NodeId,
                        StringComparison.Ordinal) ||
                    !string.Equals(scope.ResultId, "room-result.v1:" + scope.SourceRoomId,
                        StringComparison.Ordinal) ||
                    !string.Equals(scope.ResultJson, ExpectedF10V7TutorialCompletionJson(scope.SourceRoomId),
                        StringComparison.Ordinal))
                    return Fail("The live V7 owner, source revision, rewardless Tutorial receipt, or captured inventory changed.", out error);

                ExpeditionReadinessCompositionView view = composition.CaptureReadinessCompositionView();
                ExpeditionReadinessTransitionView transition = composition.RoomTransitions == null
                    ? null
                    : composition.RoomTransitions.CaptureReadinessTransitionView();
                ExpeditionRoomActivationRegistration activation = registration.CurrentActivation;
                if (view == null || !view.IsReady || !ReferenceEquals(view.ReadinessRegistration, registration) ||
                    !ReferenceEquals(view.Run, binding.Run) || view.PlayerMotor == null || view.ItemCollector == null ||
                    !ReferenceEquals(view.PlayerMotor, composition.PlayerMotor) ||
                    !ReferenceEquals(view.ItemCollector.Inventory, binding.Run.Inventory) ||
                    transition == null || transition.IsDisposed || transition.IsTransitioning ||
                    transition.HasPreparedTransition || !string.Equals(transition.ActiveNodeId,
                        F10V7TutorialAdvanceCandidate.TutorialNodeId, StringComparison.Ordinal) ||
                    !ReferenceEquals(transition.ActiveScope, scope.RoomScopeToken) ||
                    activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                    !ReferenceEquals(activation.Scope, transition.ActiveScope) ||
                    !ReferenceEquals(activation.PlayerMotor, view.PlayerMotor) ||
                    !ReferenceEquals(activation.ItemCollector, view.ItemCollector))
                    return Fail("The current bound Tutorial actor, scope, or readiness registration is not exact.", out error);

                if (!TryAcquireAdmittedV7TutorialPauseLease(composition, registration, binding,
                        out pauseLease, out error)) return false;
                if (!composition.RoomTransitions.TryPrepareTransition(scope.SourceRoomId,
                        F10V7TutorialAdvanceCandidate.C1NodeId, out preparedTransition))
                    return Fail("Could not retain a prepared C1 room transition: " +
                        composition.RoomTransitions.LastTransitionError, out error);

                if (!SaveV7JsonCodec.TryDecodeProfile(StrictF10V7TutorialUtf8.GetBytes(binding.AdmittedJson),
                        out ProfileSaveEnvelopeV7 openingEnvelope, out SaveV7Error decodeError))
                    return Fail(decodeError.Code + ": " + decodeError.Message, out error);
                if (openingEnvelope == null || openingEnvelope.activeExpedition == null ||
                    !string.Equals(openingEnvelope.activeExpedition.currentNodeId,
                        F10V7TutorialAdvanceCandidate.TutorialNodeId, StringComparison.Ordinal) ||
                    !F10V7ExpeditionReadProjector.TryCreateCurrent(openingEnvelope,
                        binding.AdmissionItemCatalog, binding.AdmissionRegistry,
                        out F10V7ExpeditionReadProjection currentProjection, out decodeError))
                    return Fail(decodeError.Code == SaveV7ErrorCode.None
                        ? "The exact opening JSON is not the active authenticated Tutorial state."
                        : decodeError.Code + ": " + decodeError.Message, out error);
                if (!string.Equals(JsonUtility.ToJson(currentProjection.SourceStateV7),
                        JsonUtility.ToJson(binding.Projection.SourceStateV7), StringComparison.Ordinal) ||
                    !StatesEqual(currentProjection.CompositionReadOnlyView, ActiveExpedition))
                    return Fail("The current projection diverged from the exact authenticated V7 opening state.", out error);

                if (!F10V7TutorialAdvanceCandidate.TryCreateCommonCandidate(currentProjection,
                        binding.Run, scope.SourceRoomId, scope.ResultId, scope.ResultJson,
                        out ExpeditionSaveData commonCandidate, out error)) return false;
                if (!composition.TryPrepareAdmittedV7Publication(binding, commonCandidate,
                        expectedExpeditionRevision, out ExpeditionReadinessPreparedPublication publication,
                        out ExpeditionSaveData capturedCommonCandidate, out error)) return false;
                if (publication == null || capturedCommonCandidate == null ||
                    !ReferenceEquals(publication.Registration, registration) ||
                    !ReferenceEquals(publication.Activation, activation) ||
                    !ReferenceEquals(publication.CandidateSave, capturedCommonCandidate) ||
                    publication.PreparedAtRevision != expectedExpeditionRevision ||
                    _activeExpeditionRevision != expectedExpeditionRevision ||
                    !ReferenceEquals(ActiveRun, binding.Run))
                    return Fail("The actor publication did not retain the exact current V7 Tutorial binder and revision.", out error);

                if (!F10V7TutorialAdvanceCandidate.TryCreate(binding.AdmittedJson, currentProjection,
                        binding.Run, binding.AdmissionRegistry, scope.SourceRoomId, scope.ResultId,
                        scope.ResultJson, candidateInventory, expectedBaseInventorySnapshotJson,
                        capturedCommonCandidate, out PinnedProfileCandidateV7 candidate, out error))
                    return false;

                pending = new PendingF10V7TutorialAdvance
                {
                    Binding = binding,
                    Composition = composition,
                    Registration = registration,
                    TransitionController = composition.RoomTransitions,
                    ResolutionScope = scope,
                    SourceRoomId = scope.SourceRoomId,
                    TargetNodeId = scope.TargetNodeId,
                    ResultId = scope.ResultId,
                    ResultJson = scope.ResultJson,
                    CandidateInventory = candidateInventory,
                    CandidateInventorySnapshotJson = JsonUtility.ToJson(candidateInventory.CreateSnapshot()),
                    ExpectedBaseInventorySnapshotJson = expectedBaseInventorySnapshotJson,
                    ExpectedExpeditionRevision = expectedExpeditionRevision,
                    PreparedTransition = preparedTransition,
                    Publication = publication,
                    Candidate = candidate,
                    ConfirmedProjection = null,
                    SimulationPauseLease = pauseLease,
                    ResolutionAuthorityAccepted = true
                };
                preparedTransition = null;
                pauseLease = null;
                return true;
            }
            catch (Exception exception)
            {
                return Fail("Could not capture one exact V7 Tutorial-to-C1 candidate: " + exception.Message, out error);
            }
            finally
            {
                Exception cleanupError = null;
                if (preparedTransition != null)
                {
                    try
                    {
                        if (preparedTransition.IsPending) preparedTransition.Dispose();
                        preparedTransition = null;
                    }
                    catch (Exception exception) { cleanupError = exception; }
                }
                if (pauseLease != null)
                {
                    try
                    {
                        pauseLease.Dispose();
                        pauseLease = null;
                    }
                    catch (Exception exception) { cleanupError = cleanupError ?? exception; }
                }
                if (cleanupError != null)
                {
                    PendingF10V7TutorialAdvance cleanupOwner = pending ?? new PendingF10V7TutorialAdvance
                    {
                        Composition = composition,
                        Registration = registration,
                        Binding = binding,
                        ResolutionScope = scope,
                        SourceRoomId = scope == null ? default : scope.SourceRoomId,
                        TargetNodeId = scope == null ? null : scope.TargetNodeId,
                        ResultId = scope == null ? null : scope.ResultId,
                        ResultJson = scope == null ? null : scope.ResultJson,
                        CandidateInventory = candidateInventory,
                        ExpectedBaseInventorySnapshotJson = expectedBaseInventorySnapshotJson,
                        ExpectedExpeditionRevision = expectedExpeditionRevision
                    };
                    cleanupOwner.PreparedTransition = preparedTransition;
                    cleanupOwner.SimulationPauseLease = pauseLease;
                    cleanupOwner.UnwrittenCleanupFailed = true;
                    cleanupOwner.MutationGateRetained = true;
                    pending = cleanupOwner;
                    _pendingF10V7TutorialAdvance = cleanupOwner;
                    error = string.IsNullOrEmpty(error)
                        ? "Pre-write cleanup failed; the exact owner and App gate remain retained. " + cleanupError.Message
                        : error + " Pre-write cleanup also failed; the exact owner and App gate remain retained. " + cleanupError.Message;
                }
            }
        }

        private bool MatchesPendingF10V7TutorialAdvance(PendingF10V7TutorialAdvance pending,
            ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
            F10V7SessionInitializationBinding binding, ExpeditionEncounterResolutionScope scope,
            ExpeditionInventory candidateInventory, string expectedBaseInventorySnapshotJson,
            long expectedExpeditionRevision)
        {
            if (pending == null || !pending.ResolutionAuthorityAccepted || scope == null || candidateInventory == null ||
                !ReferenceEquals(pending.Composition, composition) ||
                !ReferenceEquals(pending.Registration, registration) || !ReferenceEquals(pending.Binding, binding) ||
                !ReferenceEquals(pending.ResolutionScope, scope) ||
                !ReferenceEquals(pending.CandidateInventory, candidateInventory) ||
                pending.ExpectedExpeditionRevision != expectedExpeditionRevision ||
                !string.Equals(pending.ExpectedBaseInventorySnapshotJson, expectedBaseInventorySnapshotJson,
                    StringComparison.Ordinal) || !string.Equals(pending.ResultId, scope.ResultId, StringComparison.Ordinal) ||
                !string.Equals(pending.ResultJson, scope.ResultJson, StringComparison.Ordinal) ||
                pending.SourceRoomId != scope.SourceRoomId ||
                !string.Equals(pending.TargetNodeId, scope.TargetNodeId, StringComparison.Ordinal)) return false;
            try
            {
                return string.Equals(pending.CandidateInventorySnapshotJson,
                    JsonUtility.ToJson(candidateInventory.CreateSnapshot()), StringComparison.Ordinal);
            }
            catch (Exception) { return false; }
        }

        private bool TryValidateConfirmedF10V7TutorialCandidate(PendingF10V7TutorialAdvance pending,
            bool retainProjectionForExactJson, out string error)
        {
            error = string.Empty;
            if (pending == null || !pending.RepositoryConfirmed || pending.CommitResult == null ||
                !pending.CommitResult.Persisted || pending.CommitResult.Pending ||
                !string.Equals(pending.CommitResult.ConfirmedJson, pending.ConfirmedJson, StringComparison.Ordinal))
                return Fail("No exact repository-emitted V7 ConfirmedJson is retained for publication.", out error);
            try
            {
                if (!SaveV7JsonCodec.TryDecodeProfile(StrictF10V7TutorialUtf8.GetBytes(pending.Binding.AdmittedJson),
                        out ProfileSaveEnvelopeV7 prior, out SaveV7Error validationError) ||
                    !SaveV7JsonCodec.TryDecodeProfile(StrictF10V7TutorialUtf8.GetBytes(pending.ConfirmedJson),
                        out ProfileSaveEnvelopeV7 confirmed, out validationError))
                    return Fail(validationError.Code + ": " + validationError.Message, out error);
                if (confirmed == null || prior == null || confirmed.activeExpedition == null ||
                    confirmed.generation != checked(prior.generation + 1) ||
                    confirmed.sequence != checked(prior.sequence + 1) ||
                    !SaveV7CandidateMapper.TryValidateCommit(confirmed, pending.Binding.Run,
                        pending.Binding.AdmissionRegistry, out validationError) ||
                    !SaveV7CandidateMapper.TryValidateTransition(prior, null, confirmed, out validationError))
                    return Fail(validationError.Code == SaveV7ErrorCode.None
                        ? "The exact ConfirmedJson is not the single validated candidate transition."
                        : validationError.Code + ": " + validationError.Message, out error);

                ProfileSaveEnvelopeV7 candidateEnvelope = pending.Candidate.CreateEnvelope(
                    confirmed.generation, confirmed.sequence, confirmed.savedAtUtc);
                if (!SaveV7CandidateMapper.HasSameProfilePayload(candidateEnvelope.profile, confirmed.profile) ||
                    !string.Equals(JsonUtility.ToJson(candidateEnvelope.activeExpedition),
                        JsonUtility.ToJson(confirmed.activeExpedition), StringComparison.Ordinal))
                    return Fail("ConfirmedJson does not contain the exact full-profile and C1 candidate retained before IO.", out error);

                if (!F10V7ExpeditionReadProjector.TryCreateCurrent(confirmed,
                        pending.Binding.AdmissionItemCatalog, pending.Binding.AdmissionRegistry,
                        out F10V7ExpeditionReadProjection projection, out validationError))
                    return Fail(validationError.Code + ": " + validationError.Message, out error);
                if (projection == null || projection.CheckpointAuthorityV7 == null ||
                    !string.Equals(projection.SourceStateV7.currentNodeId,
                        F10V7TutorialAdvanceCandidate.C1NodeId, StringComparison.Ordinal) ||
                    !string.Equals(projection.CheckpointAuthorityV7.roomNodeId,
                        F10V7TutorialAdvanceCandidate.C1NodeId, StringComparison.Ordinal) ||
                    projection.SourceStateV7.encounterPlanPin?.entry == null ||
                    !string.Equals(projection.SourceStateV7.encounterPlanPin.entry.nodeId,
                        F10V7TutorialAdvanceCandidate.C1NodeId, StringComparison.Ordinal))
                    return Fail("The authenticated current projection lost its exact C1 checkpoint or plan pin.", out error);

                if (retainProjectionForExactJson)
                {
                    if (!V7ProjectionsEqual(pending.ConfirmedProjection, projection))
                        return Fail("The same ConfirmedJson produced a different current V7 projection during retry.", out error);
                }
                else pending.ConfirmedProjection = projection;
                return true;
            }
            catch (Exception exception) when (exception is EncoderFallbackException || exception is OverflowException ||
                exception is InvalidOperationException || exception is ArgumentException)
            { return Fail("Confirmed V7 tutorial candidate validation failed: " + exception.Message, out error); }
        }

        private bool IsF10V7TutorialC1Activated(PendingF10V7TutorialAdvance pending)
        {
            if (pending == null || pending.ConfirmedProjection == null || !pending.Promoted ||
                !pending.PublicationPublished || pending.ConfirmedRevision <= pending.ExpectedExpeditionRevision ||
                _activeExpeditionRevision != pending.ConfirmedRevision || ActiveExpedition == null ||
                !StatesEqual(ActiveExpedition, pending.ConfirmedProjection.CompositionReadOnlyView) ||
                ActiveRun == null || ActiveRun.RunId != pending.Binding.Run.RunId ||
                ActiveRun.Inventory == null || !string.Equals(
                    JsonUtility.ToJson(ActiveRun.Inventory.CreateSnapshot()),
                    pending.ConfirmedProjection.SourceStateV7.inventorySnapshotJson, StringComparison.Ordinal)) return false;
            return HasExactF10V7C1Activation(pending);
        }

        private bool IsAtF10V7C1Route(PendingF10V7TutorialAdvance pending)
        {
            if (pending == null || pending.Composition == null || ActiveRun == null ||
                ActiveRun.RunId != pending.Binding.Run.RunId) return false;
            ExpeditionRoomTransitionController transitions = pending.Composition.RoomTransitions;
            return transitions != null &&
                string.Equals(transitions.CurrentNodeId, F10V7TutorialAdvanceCandidate.C1NodeId,
                    StringComparison.Ordinal) &&
                transitions.CurrentRoomId == ExpeditionRoomIdentity.ForNode(ActiveRun.RunId,
                    F10V7TutorialAdvanceCandidate.C1NodeId) &&
                ActiveRoomInstanceId == transitions.CurrentRoomId;
        }

        private bool HasExactF10V7C1Activation(PendingF10V7TutorialAdvance pending)
        {
            if (pending == null || pending.Composition == null || pending.Registration == null ||
                pending.Binding == null || _f10V7PublishedSession == null ||
                !ReferenceEquals(_f10V7PublishedSession.Binding, pending.Binding)) return false;
            ExpeditionReadinessCompositionView view = pending.Composition.CaptureReadinessCompositionView();
            ExpeditionRoomTransitionController transitions = view == null ? null : view.RoomTransitions;
            ExpeditionRoomActivationRegistration activation = pending.Registration.CurrentActivation;
            return IsAtF10V7C1Route(pending) && pending.Composition.IsReady && view != null && view.IsReady &&
                ReferenceEquals(view.Application, this) && ReferenceEquals(view.Owner, pending.Composition) &&
                ReferenceEquals(view.ReadinessRegistration, pending.Registration) &&
                ReferenceEquals(view.Run, ActiveRun) && transitions != null &&
                activation != null &&
                activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Scope, transitions.ActiveScope) &&
                string.Equals(activation.NodeId, F10V7TutorialAdvanceCandidate.C1NodeId, StringComparison.Ordinal) &&
                string.Equals(activation.TemplateId, F10V7TutorialAdvanceCandidate.C1TemplateId,
                    StringComparison.Ordinal) &&
                pending.Registration.IsCurrentV7PublishedBinding(_f10V7PublishedSession);
        }

        internal bool TryReconcileAdmittedV7TutorialAdvance(
            ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
            F10V7SessionInitializationBinding binding, ExpeditionEncounterResolutionScope scope,
            out ExpeditionEncounterAdvanceOutcome outcome)
        {
            outcome = null;
            PendingF10V7TutorialAdvance pending = _pendingF10V7TutorialAdvance;
            if (pending == null) return false;
            if (!ReferenceEquals(pending.Composition, composition) || !ReferenceEquals(pending.Registration, registration) ||
                !ReferenceEquals(pending.Binding, binding) || !ReferenceEquals(pending.ResolutionScope, scope))
            {
                outcome = ExpeditionEncounterAdvanceOutcome.Failure(true,
                    "A different App-owned V7 Tutorial pending blocks reconciliation and retry.");
                return true;
            }
            if (!pending.MutationGateRetained || !IsAtF10V7C1Route(pending)) return false;
            if (!HasExactF10V7C1Activation(pending))
            {
                outcome = PendingF10V7TutorialOutcome(pending,
                    "C1 is active without the exact confirmed V7 actor/scope witness; no room transition will be replayed.");
                return true;
            }
            if (!TryAcquirePendingF10V7TutorialAdvanceOperation(pending, out object operationToken))
            {
                outcome = PendingF10V7TutorialOutcome(pending,
                    "The exact V7 pending is still reconciling; no overlapping retry was started.");
                return true;
            }
            try
            {
                if (!IsCurrentV7TutorialAdvanceOwner(composition, registration, binding) ||
                    !pending.RepositoryConfirmed || !pending.Promoted || !pending.PublicationPublished ||
                    !IsF10V7TutorialC1Activated(pending))
                {
                    outcome = PendingF10V7TutorialOutcome(pending,
                        "The active C1 room cannot yet be matched to the exact durable V7 publication.");
                    return true;
                }
                CompletePendingF10V7TutorialAdvance(pending);
                outcome = new ExpeditionEncounterAdvanceOutcome(true, false, false, true,
                    "The already active C1 room was reconciled to the exact confirmed V7 checkpoint.");
                return true;
            }
            catch (Exception exception)
            {
                outcome = PendingF10V7TutorialOutcome(pending,
                    "The exact durable C1 activation remains retained for reconciliation: " + exception.Message);
                return true;
            }
            finally { ReleasePendingF10V7TutorialAdvanceOperation(pending, operationToken); }
        }

        private void DiscardUnwrittenPendingF10V7TutorialAdvance(PendingF10V7TutorialAdvance pending)
        {
            if (pending == null || pending.RepositoryConfirmed || pending.RepositoryPending) return;
            try
            {
                if (pending.PreparedTransition != null && pending.PreparedTransition.IsPending)
                    pending.PreparedTransition.Dispose();
                pending.PreparedTransition = null;
                pending.SimulationPauseLease?.Dispose();
                pending.SimulationPauseLease = null;
            }
            catch
            {
                pending.UnwrittenCleanupFailed = true;
                throw;
            }
            if (ReferenceEquals(_pendingF10V7TutorialAdvance, pending)) _pendingF10V7TutorialAdvance = null;
            if (pending.MutationGateRetained)
            {
                pending.MutationGateRetained = false;
                _profileMutationGate.Release();
            }
        }

        private bool HasOtherPendingSessionMutationForV7TutorialAdvance()
        {
            // The profile gate is already held by this first-attempt lane. Exclude only that
            // self-observation and preserve every independent App pending/in-flight guard.
            return IsRoomAdvanceInFlight || HasPendingExpeditionWrite || HasPendingRoomAdvance ||
                HasPendingSettlement || HasPendingContractProgression || HasPendingCraftingWrite ||
                HasPendingEconomyMutation || HasPendingPermanentUpgradePurchase;
        }

        private static bool TryGetExactAcceptedV7TutorialCoordinator(ExpeditionGameplayComposition composition,
            out F10TutorialAdvanceCoordinator coordinator)
        {
            coordinator = null;
            if (composition == null) return false;
            F10TutorialAdvanceCoordinator[] coordinators = composition.GetComponents<F10TutorialAdvanceCoordinator>();
            if (coordinators == null || coordinators.Length != 1 || coordinators[0] == null) return false;
            coordinator = coordinators[0];
            return true;
        }

        private static ExpeditionEncounterAdvanceOutcome PendingF10V7TutorialOutcome(
            PendingF10V7TutorialAdvance pending, string message)
        {
            bool exactConfirmed = pending != null && pending.RepositoryConfirmed &&
                pending.ConfirmedCommitResult != null && pending.ConfirmedCommitResult.Persisted &&
                !pending.ConfirmedCommitResult.Pending &&
                !string.IsNullOrWhiteSpace(pending.ConfirmedJson) &&
                string.Equals(pending.ConfirmedCommitResult.ConfirmedJson, pending.ConfirmedJson, StringComparison.Ordinal);
            return new ExpeditionEncounterAdvanceOutcome(exactConfirmed, true, false, false, message);
        }

        private static bool TryAcquirePendingF10V7TutorialAdvanceOperation(
            PendingF10V7TutorialAdvance pending, out object operationToken)
        {
            operationToken = null;
            return pending != null && pending.TryAcquireOperation(out operationToken);
        }

        private static void ReleasePendingF10V7TutorialAdvanceOperation(
            PendingF10V7TutorialAdvance pending, object operationToken)
        {
            pending?.ReleaseOperation(operationToken);
        }

        private void CompletePendingF10V7TutorialAdvance(PendingF10V7TutorialAdvance pending)
        {
            if (!ReferenceEquals(_pendingF10V7TutorialAdvance, pending) || !pending.RepositoryConfirmed ||
                !pending.Promoted || !pending.PublicationPublished)
                throw new InvalidOperationException("Only the exact confirmed and published V7 C1 transition can release its owner.");
            // A lease-disposal failure must leave the exact pending owner and mutation gate in
            // place so that the durable transition remains reconcilable.
            pending.SimulationPauseLease?.Dispose();
            pending.SimulationPauseLease = null;
            _pendingF10V7TutorialAdvance = null;
            if (pending.MutationGateRetained)
            {
                pending.MutationGateRetained = false;
                _profileMutationGate.Release();
            }
        }

        private static string ExpectedF10V7TutorialCompletionJson(RoomInstanceId sourceRoomId)
        {
            return "{\"schema\":1,\"outcome\":\"cleared\",\"roomInstanceId\":\"" +
                sourceRoomId + "\",\"sourceNodeId\":\"sample.tutorial\",\"targetNodeId\":\"sample.patio.combat\",\"rewardIds\":[]}";
        }

        private static bool Fail(string message, out string error)
        {
            error = message ?? "The admitted V7 Tutorial advance is invalid.";
            return false;
        }

        internal bool TryAcquireAdmittedV7TutorialPauseLease(
            ExpeditionGameplayComposition composition,
            ExpeditionSessionReadinessRegistration registration,
            F10V7SessionInitializationBinding binding,
            out IDisposable lease, out string error)
        {
            lease = null;
            error = string.Empty;
            if (!IsCurrentV7TutorialAdvanceOwner(composition, registration, binding))
            {
                error = "The exact admitted V7 tutorial owner is not current.";
                return false;
            }
            if (!ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, composition) ||
                _expeditionSimulationPauseLeaseProvider == null)
            {
                error = "The admitted V7 composition does not own its simulation pause lease provider.";
                return false;
            }

            try { lease = _expeditionSimulationPauseLeaseProvider(); }
            catch (Exception exception)
            {
                error = "The admitted V7 simulation could not be paused: " + exception.Message;
                return false;
            }
            if (lease != null) return true;
            error = "The admitted V7 simulation pause provider returned no lease.";
            return false;
        }

        internal bool IsCurrentV7TutorialAdvanceOwner(ExpeditionGameplayComposition composition,
            ExpeditionSessionReadinessRegistration registration, F10V7SessionInitializationBinding binding)
        {
            if (composition == null || registration == null || binding == null ||
                !ReferenceEquals(_instance, this) || !ReferenceEquals(binding.Bootstrapper, this) ||
                !ReferenceEquals(binding.Composition, composition) || !ReferenceEquals(registration.Owner, composition) ||
                !ReferenceEquals(registration.Application, this) ||
                !ReferenceEquals(registration.V7InitializationBinding, binding) ||
                !ReferenceEquals(_saveRepository, binding.AdmissionRepository) ||
                !ReferenceEquals(_expeditionSimulationPauseLeaseProviderOwner, composition) ||
                !ReferenceEquals(ActiveRun, binding.Run) || !composition.isActiveAndEnabled ||
                registration.IsDisposed || !registration.IsOwnerActive || !binding.IsCurrentFor(this, composition))
                return false;

            if (IsCurrentV7PublishedSession(binding, registration, binding.PublishedRevision)) return true;
            PendingF10V7TutorialAdvance pending = _pendingF10V7TutorialAdvance;
            return pending != null && ReferenceEquals(pending.Binding, binding) &&
                ReferenceEquals(pending.Composition, composition) && ReferenceEquals(pending.Registration, registration) &&
                pending.RepositoryConfirmed && IsExactCurrentOrPartialF10V7TutorialPublication(pending);
        }

        private bool IsExactCurrentOrPartialF10V7TutorialPublication(PendingF10V7TutorialAdvance pending)
        {
            F10V7SessionInitializationBinding binding = pending?.Binding;
            ExpeditionSessionReadinessRegistration registration = pending?.Registration;
            F10V7PublishedSession published = _f10V7PublishedSession;
            if (pending == null || binding == null || registration == null ||
                !ReferenceEquals(_pendingF10V7TutorialAdvance, pending) || !pending.MutationGateRetained ||
                !ReferenceEquals(_instance, this) || !ReferenceEquals(pending.Composition, binding.Composition) ||
                !ReferenceEquals(registration.Application, this) || !ReferenceEquals(registration.Owner, pending.Composition) ||
                !ReferenceEquals(registration.V7InitializationBinding, binding) ||
                !ReferenceEquals(_saveRepository, binding.AdmissionRepository) ||
                !_f10V7AdmissionProfileWriteBlock || !binding.IsCurrentFor(this, pending.Composition) ||
                !ReferenceEquals(ActiveRun, binding.Run) || published == null ||
                !ReferenceEquals(published.Binding, binding) ||
                !_saveRepository.IsRetainedF10V7SessionHandle(binding.SessionHandle,
                    binding.AdmittedJson, binding.Run.RunId,
                    binding.AdmissionItemCatalog, binding.AdmissionRegistry)) return false;

            long expected = pending.ExpectedExpeditionRevision;
            if (expected != binding.PublishedRevision || expected == long.MaxValue) return false;
            bool appIsBase = _activeExpeditionRevision == expected &&
                StatesEqual(ActiveExpedition, binding.Projection.CompositionReadOnlyView);
            bool publicationIsBase = published.Revision == expected &&
                string.Equals(published.ConfirmedJson, binding.AdmittedJson, StringComparison.Ordinal) &&
                V7ProjectionsEqual(published.Projection, binding.Projection);
            if (publicationIsBase && appIsBase) return true;

            if (pending.ConfirmedProjection == null || pending.ConfirmedCommitResult == null ||
                !pending.ConfirmedCommitResult.Persisted || pending.ConfirmedCommitResult.Pending ||
                string.IsNullOrWhiteSpace(pending.ConfirmedJson) ||
                !string.Equals(pending.ConfirmedCommitResult.ConfirmedJson, pending.ConfirmedJson, StringComparison.Ordinal))
                return false;
            bool publicationIsTarget = published.Revision == expected + 1 &&
                string.Equals(published.ConfirmedJson, pending.ConfirmedJson, StringComparison.Ordinal) &&
                V7ProjectionsEqual(published.Projection, pending.ConfirmedProjection);
            bool appIsTarget = _activeExpeditionRevision == expected + 1 &&
                StatesEqual(ActiveExpedition, pending.ConfirmedProjection.CompositionReadOnlyView);
            return publicationIsBase && appIsBase || publicationIsTarget && (appIsBase || appIsTarget);
        }

        private sealed class PendingF10V7TutorialAdvance
        {
            internal ApplicationBootstrapper.F10V7SessionInitializationBinding Binding;
            internal ExpeditionGameplayComposition Composition;
            internal ExpeditionSessionReadinessRegistration Registration;
            internal ExpeditionRoomTransitionController TransitionController;
            internal ExpeditionEncounterResolutionScope ResolutionScope;
            internal RoomInstanceId SourceRoomId;
            internal string TargetNodeId;
            internal string ResultId;
            internal string ResultJson;
            internal ExpeditionInventory CandidateInventory;
            internal string CandidateInventorySnapshotJson;
            internal string ExpectedBaseInventorySnapshotJson;
            internal long ExpectedExpeditionRevision;
            internal ExpeditionRoomTransitionController.PreparedRoomTransition PreparedTransition;
            internal ExpeditionReadinessPreparedPublication Publication;
            internal PinnedProfileCandidateV7 Candidate;
            private F10V7SessionCommitResult _commitResult;
            private F10V7SessionCommitResult _confirmedCommitResult;
            private object _activeOperationToken;
            private int _operationInFlight;

            internal F10V7SessionCommitResult CommitResult => _commitResult;
            internal F10V7SessionCommitResult ConfirmedCommitResult => _confirmedCommitResult;
            internal object ActiveOperationToken => _activeOperationToken;
            internal int OperationInFlight => Volatile.Read(ref _operationInFlight);

            internal void CaptureRepositoryCommitResult(F10V7SessionCommitResult result)
            {
                _commitResult = result;
                // A transient retry failure does not undo the earlier durable readback. Keep
                // that proof separate; publication still checks the CURRENT attempt result.
                if (_confirmedCommitResult == null && result != null && result.Persisted &&
                    !result.Pending && !string.IsNullOrWhiteSpace(result.ConfirmedJson))
                    _confirmedCommitResult = result;
            }

            internal bool TryAcquireOperation(out object operationToken)
            {
                operationToken = null;
                if (Interlocked.CompareExchange(ref _operationInFlight, 1, 0) != 0) return false;
                object token = new object();
                _commitResult = null;
                _activeOperationToken = token;
                operationToken = token;
                return true;
            }

            internal void ReleaseOperation(object operationToken)
            {
                if (operationToken == null || !ReferenceEquals(_activeOperationToken, operationToken)) return;
                _activeOperationToken = null;
                Interlocked.Exchange(ref _operationInFlight, 0);
            }
            internal F10V7ExpeditionReadProjection ConfirmedProjection;
            internal string ConfirmedJson;
            internal long ConfirmedRevision;
            internal bool RepositoryConfirmed;
            internal bool RepositoryPending;
            internal bool ReceiptRegistered;
            internal bool Promoted;
            internal bool PublicationPublished;
            internal IDisposable SimulationPauseLease;
            internal bool MutationGateRetained;
            internal bool ResolutionAuthorityAccepted;
            internal bool UnwrittenCleanupFailed;
        }
    }
}
#endif
