#if UNITY_EDITOR
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Saves;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Luckbound.App
{
    /// <summary>
    /// App-owned empty-store bootstrap and exact-primary admission checks for the staged F10 V7
    /// opening. The V6 profile surface is fenced before SaveDataReady can become true.
    /// </summary>
    public sealed partial class ApplicationBootstrapper
    {
        private const string F10V7DiagnosticStoreRootRelativePath = "Logs/F10V7DiagnosticOpening-20261120/stores";
        private const string F10V7DiagnosticFenceMessage =
            "The disposable F10 V7 diagnostic bootstrap is fenced from all V6 profile writes.";

        internal static async Task<F10V7DiagnosticBootstrapResult> BootstrapF10V7DiagnosticAsync(
            FileSaveStore exactStore, string storeDirectory)
        {
            if (!Application.isPlaying)
                throw new InvalidOperationException("The F10 V7 diagnostic bootstrap requires Editor Play Mode.");
            if (string.Equals(SceneManager.GetActiveScene().name, "Bootstrap", StringComparison.Ordinal))
                throw new InvalidOperationException("The diagnostic bootstrap cannot start in the product Bootstrap scene.");
            if (exactStore == null) throw new ArgumentNullException(nameof(exactStore));
            if (_instance != null)
                throw new InvalidOperationException("An ApplicationBootstrapper already owns this Editor process.");
            if (EditorSaveStoreFactoryForTests != null)
                throw new InvalidOperationException("Another Editor save-store factory is already installed.");

            string projectRoot = Path.GetFullPath(Directory.GetParent(Application.dataPath).FullName);
            string expectedStoreRoot = Path.GetFullPath(Path.Combine(projectRoot,
                F10V7DiagnosticStoreRootRelativePath.Replace('/', Path.DirectorySeparatorChar)));
            string normalizedStore = Path.GetFullPath(storeDirectory ?? string.Empty);
            string persistent = Path.GetFullPath(Application.persistentDataPath);
            if (!IsPathEqualOrWithin(normalizedStore, expectedStoreRoot) || PathsOverlap(normalizedStore, persistent))
                throw new InvalidDataException("The diagnostic App store must remain under the project Logs store root and disjoint from persistentDataPath.");
            EnsureNoReparsePoints(normalizedStore, expectedStoreRoot);

            string profilePath = Path.GetFullPath(exactStore.GetPrimaryPath(SaveDocument.Profile));
            string settingsPath = Path.GetFullPath(exactStore.GetPrimaryPath(SaveDocument.Settings));
            if (!PathEquals(Path.GetDirectoryName(profilePath), normalizedStore) ||
                !PathEquals(Path.GetDirectoryName(settingsPath), normalizedStore))
                throw new InvalidDataException("The App FileSaveStore primary files do not share the exact reserved directory.");
            if (Directory.GetFileSystemEntries(normalizedStore).Length != 0)
                throw new IOException("The reserved diagnostic FileSaveStore directory is not empty; its contents were preserved.");

            int factoryCalls = 0;
            Func<ISaveStore> factory = () =>
            {
                if (Interlocked.Increment(ref factoryCalls) != 1)
                    throw new InvalidOperationException("The diagnostic App may receive the exact FileSaveStore only once.");
                return exactStore;
            };
            GameObject owner = null;
            ApplicationBootstrapper app = null;
            Exception creationFailure = null;
            try
            {
                EditorSaveStoreFactoryForTests = factory;
                owner = new GameObject("ApplicationBootstrapper (F10 V7 Diagnostic)");
                app = owner.AddComponent<ApplicationBootstrapper>();
            }
            catch (Exception exception)
            {
                creationFailure = exception;
            }
            finally
            {
                if (ReferenceEquals(EditorSaveStoreFactoryForTests, factory))
                    EditorSaveStoreFactoryForTests = null;
            }

            if (app == null)
            {
                if (owner != null && _instance == null) UnityEngine.Object.Destroy(owner);
                throw new InvalidOperationException("Unity did not create the diagnostic ApplicationBootstrapper.", creationFailure);
            }

            bool storeWasEmpty = false;
            string failure = null;
            try
            {
                if (factoryCalls != 1 || !ReferenceEquals(_instance, app))
                    throw new InvalidOperationException("The App did not retain the unique expected FileSaveStore owner.");
                if (creationFailure != null)
                    throw new InvalidOperationException("The App component setup raised an exception.", creationFailure);
                if (EditorSaveStoreFactoryForTests != null)
                    throw new InvalidOperationException("The borrowed Editor store factory was not cleared.");

                // In this non-Bootstrap technical scene Start does not run the product loader.
                // Invoke the App's actual loader, then inspect both loaded status and raw store bytes.
                await app.LoadSaveDataAsync();
                SaveStorageSnapshot profile = await exactStore.ReadAsync(SaveDocument.Profile);
                SaveStorageSnapshot settings = await exactStore.ReadAsync(SaveDocument.Settings);
                bool noUnexpectedStoreEntries = Directory.GetFileSystemEntries(normalizedStore).Length == 0;
                storeWasEmpty = IsEmptyF10V7DiagnosticV6BootstrapState(
                    app.ProfileLoadStatus, app.SettingsLoadStatus, app.ProfileAccess,
                    profile, settings, app._saveRepository?.ExportLoadedProfileJson(),
                    app.ActiveRun, app.HasActiveExpedition, factoryCalls,
                    ReferenceEquals(_instance, app), noUnexpectedStoreEntries);
                if (!storeWasEmpty)
                    failure = "The App loader or exact store did not confirm an empty V6 profile/settings pair; bytes were preserved.";
            }
            catch (Exception exception)
            {
                failure = "The App-owned empty-store preflight failed; bytes were preserved. " + exception.Message;
            }
            finally
            {
                // This order is intentional. Even rejected or contaminated stores become
                // non-writable before Ready is published, and the profile status independently
                // protects the V6 surface if V7 admission releases its temporary App block.
                app.ArmF10V7DiagnosticV6WriteFence();
            }

            bool fenceArmed = app.IsF10V7DiagnosticV6WriteFenceArmed;
            if (!fenceArmed)
                failure = string.IsNullOrEmpty(failure)
                    ? "The App could not arm its V6 write fence before readiness."
                    : failure + " The V6 write fence postcondition also failed.";
            return new F10V7DiagnosticBootstrapResult(app, owner, storeWasEmpty && fenceArmed, failure);
        }

        internal static bool IsEmptyF10V7DiagnosticV6BootstrapState(SaveLoadStatus profileStatus,
            SaveLoadStatus settingsStatus, SaveDataAccess profileAccess,
            SaveStorageSnapshot profile, SaveStorageSnapshot settings, string loadedProfileJson,
            ExpeditionRunConfiguration activeRun, bool hasActiveExpedition, int factoryCalls,
            bool isCurrentOwner, bool noUnexpectedStoreEntries)
        {
            return profileStatus == SaveLoadStatus.Missing && settingsStatus == SaveLoadStatus.Missing &&
                profileAccess == SaveDataAccess.ReadWrite && profile != null && settings != null &&
                profile.PrimaryJson == null && profile.BackupJson == null &&
                settings.PrimaryJson == null && settings.BackupJson == null &&
                loadedProfileJson == null && activeRun == null && !hasActiveExpedition &&
                factoryCalls == 1 && isCurrentOwner && noUnexpectedStoreEntries;
        }

        internal static bool IsExactF10V7PrimarySnapshot(string committedJson, string primaryJson) =>
            !string.IsNullOrEmpty(committedJson) && !string.IsNullOrEmpty(primaryJson) &&
            string.Equals(committedJson, primaryJson, StringComparison.Ordinal);

        internal void ArmF10V7DiagnosticV6WriteFence()
        {
            _f10V7AdmissionProfileWriteBlock = true;
            ProfileLoadStatus = SaveLoadStatus.Incompatible;
            ProfileLoadMessage = F10V7DiagnosticFenceMessage;
            SaveDataReady = true;
        }

        internal bool IsF10V7DiagnosticV6WriteFenceArmed => IsF10V7DiagnosticV6WriteFenceState(
            SaveDataReady, _f10V7AdmissionProfileWriteBlock, ProfileLoadStatus, CanWriteProfile);

        internal static bool IsF10V7DiagnosticV6WriteFenceState(bool saveDataReady,
            bool profileWriteBlocked, SaveLoadStatus profileStatus, bool canWriteProfile) =>
            saveDataReady && profileWriteBlocked && profileStatus == SaveLoadStatus.Incompatible &&
            !canWriteProfile;

        internal void ReassertF10V7DiagnosticV6WriteFence()
        {
            if (!ReferenceEquals(_instance, this) || !SaveDataReady)
                return;
            _f10V7AdmissionProfileWriteBlock = true;
            ProfileLoadStatus = SaveLoadStatus.Incompatible;
            ProfileLoadMessage = F10V7DiagnosticFenceMessage;
        }

        /// <summary>
        /// Checks an Editor receipt against App-private authenticated admission context and the
        /// repository-retained, non-fabricable handle. The caller supplies only bytes to compare.
        /// </summary>
        internal bool OwnsExactF10V7AdmissionPrimaryJson(string primaryJson)
        {
            F10V7AdmissionContext context = _f10V7AdmissionContext;
            if (context == null || string.IsNullOrEmpty(primaryJson) ||
                !ReferenceEquals(_instance, this) || !ReferenceEquals(context.Bootstrapper, this) ||
                !ReferenceEquals(context.Repository, _saveRepository) || context.SessionHandle == null ||
                !IsF10V7DiagnosticV6WriteFenceArmed ||
                !IsExactF10V7PrimarySnapshot(context.ConfirmedJson, primaryJson) ||
                !IsExactF10V7PrimarySnapshot(context.SessionHandle.ExactJson, primaryJson) ||
                !IsExactF10V7PrimarySnapshot(context.Repository.ExportLoadedProfileJson(), primaryJson))
                return false;

            return context.Repository.IsRetainedF10V7SessionHandle(context.SessionHandle,
                primaryJson, context.SessionHandle.RunId, context.ItemCatalog, context.Registry);
        }

        private static void EnsureNoReparsePoints(string target, string stopAt)
        {
            string root = Path.GetFullPath(stopAt);
            string current = Path.GetFullPath(target);
            if (!IsPathEqualOrWithin(current, root))
                throw new InvalidDataException("The App diagnostic store is outside its approved project root.");
            while (IsPathEqualOrWithin(current, root))
            {
                if (!Directory.Exists(current))
                    throw new DirectoryNotFoundException("A diagnostic store path component is missing: " + current);
                if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Reparse points are forbidden in the App diagnostic store path: " + current);
                if (PathEquals(current, root)) return;
                current = Path.GetDirectoryName(current);
                if (string.IsNullOrEmpty(current)) break;
            }
            throw new InvalidDataException("The App diagnostic store root could not be verified.");
        }
    }

    internal sealed class F10V7DiagnosticBootstrapResult
    {
        internal F10V7DiagnosticBootstrapResult(ApplicationBootstrapper app, GameObject owner,
            bool readyForV7Opening, string message)
        { App = app; Owner = owner; ReadyForV7Opening = readyForV7Opening; Message = message ?? string.Empty; }
        internal ApplicationBootstrapper App { get; }
        internal GameObject Owner { get; }
        internal bool ReadyForV7Opening { get; }
        internal string Message { get; }
    }
}
#endif
