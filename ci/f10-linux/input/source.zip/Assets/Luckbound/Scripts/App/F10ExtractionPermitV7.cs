#if UNITY_EDITOR
using System;
using System.Linq;
using System.Text;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves.V7;

namespace Luckbound.App
{
    /// <summary>
    /// One-shot authority captured only while the exact F10 extraction observation is being
    /// delivered by its room driver. This capability carries no caller-selected outcome or amount.
    /// </summary>
    internal sealed class F10ExtractionPermitV7
    {
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        private readonly object _bindGate = new object();
        private readonly ApplicationBootstrapper _application;
        private readonly ExpeditionGameplayComposition _composition;
        private readonly F10ObjectiveDriver2D _driver;
        private readonly IF10ObjectiveObservationHandoff _handoff;
        private readonly F10ObjectiveObservation _observation;
        private readonly string _observationId;
        private readonly object _appSettlementOperationOwner;
        private readonly IDisposable _simulationLease;
        private readonly ExpeditionSessionReadinessRegistration _readinessRegistration;
        private readonly ItemCatalog _itemCatalog;
        private readonly EncounterCatalogRegistryV1 _exactRegistry;

        private bool _bound;
        private SaveRepository _repository;
        private string _sourceProfileJson;
        private RunId _sourceRunId;
        private SaveV7ExtractedSettlementCandidate.Candidate _candidate;

        private F10ExtractionPermitV7(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation,
            object appSettlementOperationOwner, IDisposable simulationLease,
            ExpeditionSessionReadinessRegistration readinessRegistration,
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry)
        {
            _application = application;
            _composition = composition;
            _driver = driver;
            _handoff = handoff;
            _observation = observation;
            _observationId = observation.ObservationId;
            _appSettlementOperationOwner = appSettlementOperationOwner;
            _simulationLease = simulationLease;
            _readinessRegistration = readinessRegistration;
            _itemCatalog = itemCatalog;
            _exactRegistry = exactRegistry;
        }

        /// <summary>
        /// App-only issuance seam. It rejects unless called synchronously from the exact driver's
        /// callback and the App proves that the supplied opaque owner, pause lease, readiness
        /// registration, composition, actor and extraction activation are its current operation.
        /// </summary>
        internal static bool TryIssueFromAppHandoff(
            ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition,
            F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff,
            F10ObjectiveObservation observation,
            object appSettlementOperationOwner,
            IDisposable simulationLease,
            ExpeditionSessionReadinessRegistration readinessRegistration,
            ItemCatalog itemCatalog,
            EncounterCatalogRegistryV1 exactRegistry,
            out F10ExtractionPermitV7 permit,
            out string error)
        {
            permit = null;
            error = string.Empty;

            // Keep this check synchronous and first. The driver clears this delivery witness as
            // soon as the handoff callback returns, so no later await can manufacture a permit.
            if (driver == null || handoff == null || observation == null ||
                !driver.IsDeliveringTo(handoff, observation))
                return Fail("PhysicalDeliveryRequired: the exact extraction fact is not being delivered.", out error);

            if (application == null || composition == null || appSettlementOperationOwner == null ||
                simulationLease == null || readinessRegistration == null || itemCatalog == null || exactRegistry == null)
                return Fail("AppOwnerRequired: the App operation, held simulation lease, readiness registration, and exact catalogs are required.", out error);

            if (!application.TryValidateF10ExtractionPermitV7Owner(composition, driver, handoff,
                observation, appSettlementOperationOwner, simulationLease, readinessRegistration,
                itemCatalog, requireDriverDelivery: true, out error))
                return false;

            permit = new F10ExtractionPermitV7(application, composition, driver, handoff,
                observation, appSettlementOperationOwner, simulationLease,
                readinessRegistration, itemCatalog, exactRegistry);
            error = string.Empty;
            return true;
        }

        /// <summary>
        /// Repository calls this only after its awaited profile gate and fresh durable read. It
        /// binds the one captured physical fact to the exact authenticated source bytes and the
        /// exact terminal candidate. Delivery is intentionally not re-required after the await;
        /// the App owner, lease and Bound activation must still be current.
        /// </summary>
        internal bool TryBindExactProfileAndCandidate(SaveRepository repository,
            string exactSourceProfileJson, ProfileSaveEnvelopeV7 sourceEnvelope,
            SaveV7ExtractedSettlementCandidate.Candidate candidate,
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry,
            out string error)
        {
            lock (_bindGate)
            {
                if (_bound)
                    return Fail("PhysicalPermitConsumed: this extraction permit has already been bound.", out error);
                if (repository == null || candidate == null || itemCatalog == null || exactRegistry == null)
                    return Fail("PhysicalPermitInputRequired: repository, candidate, and exact catalogs are required.", out error);
                if (!ReferenceEquals(itemCatalog, _itemCatalog) || !ReferenceEquals(exactRegistry, _exactRegistry))
                    return Fail("PhysicalPermitCatalogMismatch: settlement must use the exact catalogs captured at issuance.", out error);
                if (!TryValidateSourceAndCandidate(exactSourceProfileJson, sourceEnvelope, candidate,
                    out RunId sourceRunId, out error)) return false;
                if (sourceRunId != _observation.RunId)
                    return Fail("PhysicalPermitRunMismatch: the durable source RunId differs from the delivered extraction fact.", out error);

                // This is post-await validation. It checks the same private App operation and
                // retained lease/registration without asking the room driver to still be inside
                // the callback or the observation to remain at the queue head.
                if (!_application.TryValidateF10ExtractionPermitV7Owner(_composition, _driver,
                    _handoff, _observation, _appSettlementOperationOwner, _simulationLease,
                    _readinessRegistration, _itemCatalog, requireDriverDelivery: false, out error))
                    return false;

                _repository = repository;
                _sourceProfileJson = exactSourceProfileJson;
                _sourceRunId = sourceRunId;
                _candidate = candidate;
                _bound = true;
                error = string.Empty;
                return true;
            }
        }

        /// <summary>Allows the App publisher to verify the repository retained this exact binding.</summary>
        internal bool IsBoundTo(SaveRepository repository, string exactSourceProfileJson,
            SaveV7ExtractedSettlementCandidate.Candidate candidate,
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry)
        {
            lock (_bindGate)
            {
                return _bound && ReferenceEquals(_repository, repository) &&
                    ReferenceEquals(_candidate, candidate) && ReferenceEquals(_itemCatalog, itemCatalog) &&
                    ReferenceEquals(_exactRegistry, exactRegistry) &&
                    string.Equals(_sourceProfileJson, exactSourceProfileJson, StringComparison.Ordinal) &&
                    _sourceRunId == _observation.RunId &&
                    candidate != null && candidate.Receipt != null &&
                    candidate.Receipt.RunId == _sourceRunId &&
                    candidate.Receipt.Outcome == ExpeditionOutcome.Extracted &&
                    !candidate.Receipt.AlreadyProcessed;
            }
        }

        private static bool TryValidateSourceAndCandidate(string exactSourceProfileJson,
            ProfileSaveEnvelopeV7 sourceEnvelope,
            SaveV7ExtractedSettlementCandidate.Candidate candidate,
            out RunId sourceRunId, out string error)
        {
            sourceRunId = default(RunId);
            error = string.Empty;
            if (string.IsNullOrWhiteSpace(exactSourceProfileJson) || sourceEnvelope == null || candidate == null ||
                candidate.Receipt == null || string.IsNullOrWhiteSpace(candidate.EncodedJson))
                return Fail("PhysicalPermitDataRequired: authenticated source bytes and terminal candidate are required.", out error);

            try
            {
                byte[] sourceBytes = StrictUtf8.GetBytes(exactSourceProfileJson);
                if (!SaveV7JsonCodec.TryDecodeProfile(sourceBytes,
                    out ProfileSaveEnvelopeV7 decodedSource, out SaveV7Error sourceError) ||
                    !SaveV7JsonCodec.TryAuthenticateProfile(sourceEnvelope, out sourceError) ||
                    !SaveV7JsonCodec.TryAuthenticateProfile(decodedSource, out sourceError))
                    return Fail("PhysicalPermitSourceRejected: " + sourceError.Code + ": " + sourceError.Message, out error);

                byte[] suppliedEnvelopeBytes = SaveV7JsonCodec.EncodeProfile(sourceEnvelope);
                byte[] decodedEnvelopeBytes = SaveV7JsonCodec.EncodeProfile(decodedSource);
                if (!BytesEqual(suppliedEnvelopeBytes, decodedEnvelopeBytes) ||
                    sourceEnvelope.contentVersion != 7 || !sourceEnvelope.hasActiveExpedition ||
                    sourceEnvelope.activeExpedition == null || sourceEnvelope.profile == null ||
                    !RunId.TryParse(sourceEnvelope.activeExpedition.runId, out sourceRunId))
                    return Fail("PhysicalPermitSourceMismatch: the exact bytes do not authenticate the supplied active V7 envelope.", out error);

                ExpeditionSettlementReceipt receipt = candidate.Receipt;
                if (receipt.Outcome != ExpeditionOutcome.Extracted || receipt.AlreadyProcessed ||
                    receipt.RunId != sourceRunId || !sourceEnvelope.hasActiveExpedition ||
                    !RunId.TryParse(decodedSource.activeExpedition.runId, out RunId decodedRunId) ||
                    decodedRunId != sourceRunId)
                    return Fail("PhysicalPermitReceiptMismatch: the receipt is not one new extraction of this source RunId.", out error);

                byte[] candidateBytes = StrictUtf8.GetBytes(candidate.EncodedJson);
                if (!SaveV7JsonCodec.TryDecodeProfile(candidateBytes,
                    out ProfileSaveEnvelopeV7 decodedCandidate, out SaveV7Error candidateError) ||
                    !SaveV7JsonCodec.TryAuthenticateProfile(decodedCandidate, out candidateError))
                    return Fail("PhysicalPermitCandidateRejected: " + candidateError.Code + ": " + candidateError.Message, out error);

                ProfileSaveEnvelopeV7 retainedCandidate = candidate.Envelope;
                if (retainedCandidate == null || retainedCandidate.profile == null ||
                    !SaveV7JsonCodec.TryAuthenticateProfile(retainedCandidate, out candidateError) ||
                    !BytesEqual(candidateBytes, SaveV7JsonCodec.EncodeProfile(retainedCandidate)) ||
                    decodedCandidate.contentVersion != 7 || decodedCandidate.hasActiveExpedition ||
                    decodedCandidate.activeExpedition != null ||
                    sourceEnvelope.generation == int.MaxValue || sourceEnvelope.sequence == long.MaxValue ||
                    decodedCandidate.generation != sourceEnvelope.generation + 1 ||
                    decodedCandidate.sequence != sourceEnvelope.sequence + 1 ||
                    decodedCandidate.profile.availableRenown != receipt.BalanceAfter ||
                    !HasExactProcessedRunAppend(sourceEnvelope.profile.processedSettlementRunIds,
                        decodedCandidate.profile.processedSettlementRunIds, sourceRunId))
                    return Fail("PhysicalPermitCandidateMismatch: terminal bytes are not the exact next profile for this extraction receipt.", out error);

                error = string.Empty;
                return true;
            }
            catch (Exception exception) when (exception is ArgumentException ||
                exception is OverflowException || exception is InvalidOperationException ||
                exception is SaveV7ValidationException)
            {
                return Fail("PhysicalPermitDataRejected: " + exception.Message, out error);
            }
        }

        private static bool HasExactProcessedRunAppend(string[] previous, string[] next, RunId runId)
        {
            previous = previous ?? Array.Empty<string>();
            next = next ?? Array.Empty<string>();
            string runText = runId.ToString();
            if (previous.Contains(runText, StringComparer.Ordinal) || next.Length != previous.Length + 1 ||
                !string.Equals(next[next.Length - 1], runText, StringComparison.Ordinal)) return false;
            for (int index = 0; index < previous.Length; index++)
                if (!string.Equals(previous[index], next[index], StringComparison.Ordinal)) return false;
            return true;
        }

        private static bool BytesEqual(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;
            for (int index = 0; index < left.Length; index++)
                if (left[index] != right[index]) return false;
            return true;
        }

        private static bool Fail(string message, out string error)
        {
            error = message;
            return false;
        }
    }
}
#endif
