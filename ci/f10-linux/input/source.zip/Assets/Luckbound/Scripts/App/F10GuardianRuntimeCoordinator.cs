#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Editor-only Guardian bridge. It installs scope-owned physical room walls, prepares the real single-Custodian
    /// encounter, and retains only the runtime's exact physical clear observation. It never pays, saves, or advances.
    /// </summary>
    [DisallowMultipleComponent]
    internal sealed class F10GuardianRuntimeCoordinator : MonoBehaviour, IRoomEncounterClearObserver, IDisposable
    {
        private const string GuardianNodeId = F10TechnicalEncounterPlanProvider.GuardianNodeId;
        private const string GuardianTemplateId = F10TechnicalEncounterPlanProvider.GuardianTemplateId;
        private const string GuardianSpawnId = "boss.custodian";

        private ApplicationBootstrapper _application;
        private ExpeditionGameplayComposition _composition;
        private F10TechnicalEncounterPlanProvider _provider;
        private ExpeditionSessionReadinessRegistration _registration;
        private ExpeditionRoomActivationRegistration _activation;
        private ExpeditionRunConfiguration _run;
        private RoomLifetimeScope _scope;
        private RoomTemplatePrefab2D _room;
        private F10GuardianPhysicalBoundaryInstaller.InstallationWitness _boundaryWitness;
        private RoomEncounterRuntimeContext _context;
        private ExpeditionEncounterSessionSnapshotSource _snapshotSource;
        private RoomEncounterRuntimePlan _plan;
        private RoomEncounterRuntime _runtime;
        private RoomEncounterClearObservation _clearObservation;
        private string _setupFailure = string.Empty;
        private bool _clearAccepted;
        private bool _disposed;

        internal RoomEncounterRuntimeStatus RuntimeStatus => _runtime == null
            ? RoomEncounterRuntimeStatus.NotReady
            : _runtime.Status;

        internal RoomEncounterRuntime Runtime => _runtime;
        internal bool HasCurrentPhysicalBoundaryWitness =>
            F10GuardianPhysicalBoundaryInstaller.IsCurrent(_boundaryWitness, _run, _scope, _room);
        internal bool IsSetupFailed => !string.IsNullOrEmpty(_setupFailure);
        internal bool IsDisposed => _disposed;
        internal bool HasPhysicalClearObservation => _clearAccepted && _clearObservation != null;
        internal RoomEncounterClearObservation PhysicalClearObservation =>
            HasPhysicalClearObservation ? _clearObservation : null;

        internal string StatusMessage
        {
            get
            {
                if (!string.IsNullOrEmpty(_setupFailure)) return _setupFailure;
                if (HasPhysicalClearObservation)
                    return "Guardian physical Custodian clear observed. No reward, save, or route advancement was issued.";
                if (_disposed && _runtime == null)
                    return "Guardian coordinator was disposed with its room scope before runtime preparation.";
                if (_disposed) return "Guardian coordinator was disposed with its room scope.";
                if (_runtime == null) return "Guardian encounter runtime has not been prepared.";

                switch (_runtime.Status)
                {
                    case RoomEncounterRuntimeStatus.WaitingForSession:
                        return "Guardian is waiting for real session readiness; the runtime retries only while its physical witness remains current.";
                    case RoomEncounterRuntimeStatus.Armed:
                        return "Guardian Custodian encounter is armed.";
                    case RoomEncounterRuntimeStatus.Cleared:
                        return "Guardian runtime cleared without a retained physical observation.";
                    case RoomEncounterRuntimeStatus.Faulted:
                        return "Guardian encounter faulted: " + _runtime.FaultReason;
                    case RoomEncounterRuntimeStatus.SessionEnded:
                        return "Guardian session ended; encounter progression is inhibited.";
                    case RoomEncounterRuntimeStatus.Disposed:
                        return "Guardian encounter runtime was disposed with its room scope.";
                    default:
                        return "Guardian encounter runtime is not ready.";
                }
            }
        }

        /// <summary>Attaches only to the exact active Guardian activation of the isolated F10 diagnostic run.</summary>
        internal static F10GuardianRuntimeCoordinator Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, F10TechnicalEncounterPlanProvider provider)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            if (provider == null) throw new ArgumentNullException(nameof(provider));

            RoomLifetimeScope candidateScope = composition.RoomTransitions == null
                ? null
                : composition.RoomTransitions.ActiveScope;
            F10GuardianRuntimeCoordinator existing = candidateScope == null
                ? null
                : candidateScope.GetComponent<F10GuardianRuntimeCoordinator>();
            if (existing != null)
            {
                AttachmentView existingAttachment = ValidateAttachment(application, composition,
                    requireFreshEncounterContext: false);
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition) &&
                    ReferenceEquals(existing._provider, provider) &&
                    ReferenceEquals(existing._scope, existingAttachment.Scope) &&
                    ReferenceEquals(existing._activation, existingAttachment.Activation) &&
                    (existing._context == null || ReferenceEquals(existing._activation.Context, existing._context)) &&
                    (existing._snapshotSource == null || ReferenceEquals(existing._activation.Source, existing._snapshotSource)))
                    return existing;
                throw new InvalidOperationException("The active Guardian room scope already owns another F10 runtime coordinator.");
            }

            AttachmentView attachment = ValidateAttachment(application, composition,
                requireFreshEncounterContext: true);
            F10GuardianRuntimeCoordinator coordinator = attachment.Scope.gameObject.AddComponent<F10GuardianRuntimeCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._provider = provider;
            coordinator._registration = attachment.Registration;
            coordinator._activation = attachment.Activation;
            coordinator._run = attachment.Run;
            coordinator._scope = attachment.Scope;
            coordinator._room = attachment.Room;

            try
            {
                F10GuardianRuntimeCoordinator owned = attachment.Scope.OwnResource(coordinator);
                if (!ReferenceEquals(owned, coordinator))
                    throw new InvalidOperationException("The active Guardian room scope did not retain the exact F10 coordinator.");
                coordinator.PrepareEncounter();
            }
            catch (Exception exception)
            {
                coordinator.FailSetup("Guardian encounter setup failed closed: " + exception.Message);
            }

            return coordinator;
        }

        private static AttachmentView ValidateAttachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, bool requireFreshEncounterContext)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun))
                throw new InvalidOperationException("Guardian runtime requires the exact isolated F10 diagnostic run in Play Mode.");

            ExpeditionReadinessCompositionView readiness = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = readiness == null ? null : readiness.Run;
            ExpeditionRoomTransitionController transitions = readiness == null ? null : readiness.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = readiness == null ? null : readiness.ReadinessRegistration;
            if (!composition.isActiveAndEnabled || !composition.IsReady || readiness == null || !readiness.IsReady ||
                !ReferenceEquals(readiness.Owner, composition) || !ReferenceEquals(readiness.Application, application) ||
                !ReferenceEquals(run, application.ActiveRun) || run == null || run.Route == null ||
                run.Route.GenerationVersion != 2 || transitions == null ||
                !ReferenceEquals(transitions, composition.RoomTransitions) || registration == null ||
                registration.IsDisposed || !registration.IsOwnerActive ||
                !ReferenceEquals(registration.Owner, composition) ||
                registration.RouteGenerationVersion != run.Route.GenerationVersion)
                throw new InvalidOperationException("Guardian runtime requires the ready composition and its live real-session readiness registration.");

            ExpeditionSaveData activeSave = application.ActiveExpedition;
            if (activeSave == null || !string.Equals(activeSave.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                !string.Equals(activeSave.currentNodeId, GuardianNodeId, StringComparison.Ordinal) ||
                activeSave.visitedNodeIds == null || activeSave.visitedNodeIds.Length == 0 ||
                !string.Equals(activeSave.visitedNodeIds[activeSave.visitedNodeIds.Length - 1], GuardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(transitions.CurrentNodeId, GuardianNodeId, StringComparison.Ordinal) ||
                application.HasPendingSessionMutation || application.HasPendingRoomAdvance)
                throw new InvalidOperationException("The saved and active F10 route cursor must be settled on sample.patio.guardian.");

            ExpeditionReadinessTransitionView transition = transitions.CaptureReadinessTransitionView();
            RoomLifetimeScope scope = transition == null ? null : transition.ActiveScope;
            RoomInstanceId expectedRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, GuardianNodeId);
            if (transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !string.Equals(transition.ActiveNodeId, GuardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(transition.ActiveTemplateId, GuardianTemplateId, StringComparison.Ordinal) ||
                scope == null || !ReferenceEquals(scope, transitions.ActiveScope) ||
                !ReferenceEquals(transition.ActiveRoomRoot, scope.gameObject) || scope.IsDisposed ||
                !scope.isActiveAndEnabled || scope.RoomInstanceId != expectedRoomId ||
                !string.Equals(scope.TemplateId, GuardianTemplateId, StringComparison.Ordinal) ||
                !transitions.IsCurrentRoom(expectedRoomId) || transitions.CurrentRoomId != application.ActiveRoomInstanceId)
                throw new InvalidOperationException("Guardian runtime requires the exact active sample.patio.guardian scope and settled route activation.");

            ExpeditionRoomActivationRegistration activation = registration.CurrentActivation;
            if (activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, scope) || !ReferenceEquals(activation.Controller, transitions) ||
                activation.RunId != run.RunId || !ReferenceEquals(activation.BoundRun, run) ||
                !string.Equals(activation.NodeId, GuardianNodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, GuardianTemplateId, StringComparison.Ordinal) ||
                (requireFreshEncounterContext && (activation.Context != null || activation.Source != null)))
                throw new InvalidOperationException("Guardian readiness must own one bound activation with no prior encounter context or snapshot source.");

            if (readiness.PlayerMotor == null || !readiness.PlayerMotor.isActiveAndEnabled ||
                !readiness.PlayerMotor.ActorId.IsValid || readiness.PlayerObject == null ||
                !ReferenceEquals(readiness.PlayerMotor.gameObject, readiness.PlayerObject) ||
                readiness.PlayerObject.GetComponent<Collider2D>() == null)
                throw new InvalidOperationException("Guardian runtime requires the bound live player actor and its real collider.");

            RoomTemplatePrefab2D[] roomComponents = transition.ActiveRoomRoot.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            RoomTemplatePrefab2D room = roomComponents.Length == 1 ? roomComponents[0] : null;
            if (room == null || !room.isActiveAndEnabled || !room.gameObject.activeInHierarchy ||
                !room.transform.IsChildOf(scope.transform))
                throw new InvalidOperationException("Guardian runtime requires exactly one active RoomTemplatePrefab2D under the active room scope.");

            return new AttachmentView(registration, activation, run, transitions, scope, room);
        }

        private void PrepareEncounter()
        {
            if (!F10GuardianPhysicalBoundaryInstaller.TryInstall(_run, _scope, _room,
                    out _boundaryWitness, out string boundaryError))
            {
                FailSetup("Guardian physical boundary installation failed closed: " + boundaryError);
                return;
            }
            if (!F10GuardianPhysicalBoundaryInstaller.IsCurrent(_boundaryWitness, _run, _scope, _room))
            {
                FailSetup("Guardian physical boundary witness was stale immediately after installation.");
                return;
            }
            if (!_provider.TryBuildGuardian(_run, _scope, _room, _boundaryWitness,
                    out RoomEncounterRuntimePlan plan, out string planError))
            {
                FailSetup("Guardian plan provider refused the active room: " + planError);
                return;
            }
            _plan = plan;

            _context = RoomEncounterRuntimeContext.Create(_run.RunId, GuardianNodeId, GuardianTemplateId,
                _activation.RoomInstanceId, _scope, _activation.Controller,
                _composition.PlayerMotor, _plan, _run.Route.GenerationVersion);
            _snapshotSource = _registration.CreateSnapshotSource(_context);
            if (_snapshotSource == null || !ReferenceEquals(_activation.Context, _context) ||
                !ReferenceEquals(_activation.Source, _snapshotSource))
                throw new InvalidOperationException("The real readiness registration did not retain this exact Guardian context and snapshot source.");

            _runtime = RoomEncounterRuntime.Prepare(_context, _snapshotSource, this);
            TryArmOnlyWhileWaiting();
        }

        private void Update()
        {
            if (_disposed || _clearAccepted || _runtime == null) return;
            if (!F10GuardianPhysicalBoundaryInstaller.IsCurrent(_boundaryWitness, _run, _scope, _room))
            {
                InhibitForLostBoundary();
                return;
            }
            TryArmOnlyWhileWaiting();
        }

        private void TryArmOnlyWhileWaiting()
        {
            if (_runtime == null || _runtime.Status != RoomEncounterRuntimeStatus.WaitingForSession) return;
            if (!F10GuardianPhysicalBoundaryInstaller.IsCurrent(_boundaryWitness, _run, _scope, _room))
            {
                InhibitForLostBoundary();
                return;
            }
            _runtime.ConfirmSessionReadyForScope();
        }

        void IRoomEncounterClearObserver.OnRoomEncounterCleared(RoomEncounterClearObservation observation)
        {
            if (_disposed || !isActiveAndEnabled || _runtime == null || _context == null || _plan == null || observation == null ||
                !_runtime.ClearNotificationIssued || !ReferenceEquals(_runtime.LastClearObservation, observation) ||
                _runtime.Status != RoomEncounterRuntimeStatus.Armed ||
                observation.RunId != _context.RunId || observation.RoomInstanceId != _context.RoomInstanceId ||
                observation.ActivationGeneration != _context.ActivationGeneration ||
                !string.Equals(observation.NodeId, _context.NodeId, StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, _context.TemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(observation.Scope, _context.Scope) ||
                !_registration.IsCurrentActivation(_activation) ||
                !F10GuardianPhysicalBoundaryInstaller.IsCurrent(_boundaryWitness, _run, _scope, _room) ||
                !HasExactPlannedRoster(observation, _plan))
            {
                _setupFailure = "Guardian clear callback did not match the exact physical Custodian, activation, and current boundary witness.";
                throw new InvalidOperationException(_setupFailure);
            }

            if (_clearAccepted)
            {
                _setupFailure = "Guardian runtime attempted to publish more than one physical clear observation.";
                throw new InvalidOperationException(_setupFailure);
            }
            _clearObservation = observation;
            _clearAccepted = true;
        }

        private static bool HasExactPlannedRoster(RoomEncounterClearObservation observation,
            RoomEncounterRuntimePlan plan)
        {
            if (observation == null || plan == null || plan.Roster == null || observation.Actors == null)
                return false;
            var expected = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (ExpeditionEncounterWavePlan wave in plan.Roster.Waves)
            {
                foreach (string spawnKey in wave.SpawnKeys)
                {
                    if (string.IsNullOrEmpty(spawnKey) || expected.ContainsKey(spawnKey)) return false;
                    expected.Add(spawnKey, wave.WaveNumber);
                }
            }
            if (expected.Count != 1 || observation.Actors.Count != expected.Count) return false;
            foreach (RoomEncounterDefeatedActorObservation actor in observation.Actors)
            {
                if (!expected.TryGetValue(actor.SpawnKey, out int waveNumber) ||
                    waveNumber != actor.WaveNumber || !actor.ActorId.IsValid)
                    return false;
                expected.Remove(actor.SpawnKey);
            }
            return expected.Count == 0;
        }

        private void InhibitForLostBoundary()
        {
            const string message = "Guardian physical boundary witness became stale; the encounter was inhibited before clear publication.";
            if (string.IsNullOrEmpty(_setupFailure)) _setupFailure = message;
            _runtime?.InhibitForOwnerIntegrityFailure(message);
        }

        private void FailSetup(string message)
        {
            _setupFailure = string.IsNullOrWhiteSpace(message) ? "Guardian encounter setup failed closed." : message;
            _runtime?.InhibitForOwnerIntegrityFailure(_setupFailure);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _runtime?.InhibitForOwnerIntegrityFailure(
                "Guardian boundary coordinator was disabled or disposed before encounter completion.");
        }

        private void OnDisable() => Dispose();

        private void OnDestroy()
        {
            Dispose();
        }

        private sealed class AttachmentView
        {
            internal AttachmentView(ExpeditionSessionReadinessRegistration registration,
                ExpeditionRoomActivationRegistration activation, ExpeditionRunConfiguration run,
                ExpeditionRoomTransitionController transitions, RoomLifetimeScope scope,
                RoomTemplatePrefab2D room)
            {
                Registration = registration;
                Activation = activation;
                Run = run;
                Transitions = transitions;
                Scope = scope;
                Room = room;
            }

            internal ExpeditionSessionReadinessRegistration Registration { get; }
            internal ExpeditionRoomActivationRegistration Activation { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal ExpeditionRoomTransitionController Transitions { get; }
            internal RoomLifetimeScope Scope { get; }
            internal RoomTemplatePrefab2D Room { get; }
        }
    }
}
#endif
