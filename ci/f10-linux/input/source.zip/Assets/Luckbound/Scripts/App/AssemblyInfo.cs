using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Luckbound.PlayMode.Tests")]
[assembly: InternalsVisibleTo("Luckbound.Editor")]
