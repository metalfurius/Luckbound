#if UNITY_EDITOR
using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Luckbound.App
{
    /// <summary>
    /// Canonical diagnostic fingerprint only. This does not verify a bundle, choose descriptor
    /// paths, or authorize physical assets; callers must derive paths from the fixed table and
    /// independently verify the exact manifest, payload, and measured dependency closure.
    /// </summary>
    internal static class F10PhysicalDescriptorFingerprintV1
    {
        internal const string Domain = "luckbound.f10.physical-descriptor.v1";
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        internal static bool TryCompute(string descriptorId, string kind, int revision,
            string rootAssetPath, string sourceDefinitionAssetPath,
            string physicalDescriptorPayloadSha256, string bundleManifestSha256,
            out string fingerprint)
        {
            fingerprint = null;
            if (!IsStableId(descriptorId) ||
                (kind != "room" && kind != "enemy" && kind != "cache") || revision <= 0 ||
                !IsCanonicalAssetPath(rootAssetPath) || sourceDefinitionAssetPath == null ||
                (sourceDefinitionAssetPath.Length != 0 && !IsCanonicalAssetPath(sourceDefinitionAssetPath)) ||
                (kind == "room" && sourceDefinitionAssetPath.Length == 0) ||
                !IsLowerSha256(physicalDescriptorPayloadSha256) || !IsLowerSha256(bundleManifestSha256))
                return false;

            string[] fields =
            {
                Domain, descriptorId, kind, revision.ToString(CultureInfo.InvariantCulture),
                rootAssetPath, sourceDefinitionAssetPath, physicalDescriptorPayloadSha256,
                bundleManifestSha256
            };
            try
            {
                using (var bytes = new MemoryStream())
                {
                    foreach (string field in fields)
                    {
                        byte[] utf8 = StrictUtf8.GetBytes(field);
                        uint length = checked((uint)utf8.Length);
                        bytes.WriteByte((byte)(length >> 24));
                        bytes.WriteByte((byte)(length >> 16));
                        bytes.WriteByte((byte)(length >> 8));
                        bytes.WriteByte((byte)length);
                        bytes.Write(utf8, 0, utf8.Length);
                    }
                    using (SHA256 hash = SHA256.Create())
                    {
                        byte[] digest = hash.ComputeHash(bytes.ToArray());
                        var text = new StringBuilder(digest.Length * 2);
                        foreach (byte value in digest)
                            text.Append(value.ToString("x2", CultureInfo.InvariantCulture));
                        fingerprint = text.ToString();
                    }
                }
                return true;
            }
            catch (EncoderFallbackException) { return false; }
            catch (OverflowException) { return false; }
        }

        private static bool IsStableId(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || !string.Equals(value, value.Trim(), StringComparison.Ordinal))
                return false;
            foreach (char character in value)
                if (char.IsControl(character)) return false;
            return true;
        }

        private static bool IsCanonicalAssetPath(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || !value.StartsWith("Assets/", StringComparison.Ordinal) ||
                value.EndsWith("/", StringComparison.Ordinal) || value.IndexOf('\\') >= 0 ||
                value.IndexOf(':') >= 0 || value.IndexOf("//", StringComparison.Ordinal) >= 0)
                return false;
            foreach (string segment in value.Split('/'))
            {
                if (segment.Length == 0 || segment == "." || segment == "..") return false;
                foreach (char character in segment)
                    if (char.IsControl(character)) return false;
            }
            return true;
        }

        private static bool IsLowerSha256(string value)
        {
            if (value == null || value.Length != 64) return false;
            foreach (char character in value)
                if (!(character >= '0' && character <= '9') && !(character >= 'a' && character <= 'f'))
                    return false;
            return true;
        }
    }
}
#endif
