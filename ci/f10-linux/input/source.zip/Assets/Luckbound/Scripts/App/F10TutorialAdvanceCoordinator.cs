#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    internal enum F10TutorialAdvanceState
    {
        WaitingForTutorial,
        SetupFailed,
        Resolving,
        PendingRetry,
        Failed,
        Completed
    }

    /// <summary>Connects only the isolated F10 tutorial observation to its saved C1 route edge.</summary>
    [DisallowMultipleComponent]
    internal sealed class F10TutorialAdvanceCoordinator : MonoBehaviour, IF10ObjectiveObservationHandoff
    {
        private const string TutorialNodeId = "sample.tutorial";
        private const string TutorialTemplateId = "room.sample.tutorial";
        private const string C1NodeId = "sample.patio.combat";
        private const string C1TemplateId = "room.patio.c1";

        private ApplicationBootstrapper _application;
        private ExpeditionGameplayComposition _composition;
        private ExpeditionSessionReadinessRegistration _registration;
        private RoomEncounterRuntimeContext _context;
        private ExpeditionEncounterSessionSnapshotSource _snapshotSource;
        private F10ObjectiveDriver2D _objectiveDriver;
        private ExpeditionEncounterResolver _resolver;
        private ExpeditionEncounterResolutionScope _resolutionScope;
        private Task _attemptTask;
        private RunId _runId;
        private string _targetNodeId;
        private string _acceptedObservationId;
        private F10ObjectiveObservation _acceptedObservation;
        private ExpeditionEncounterAdvanceOutcome _lastOutcome;
        private F10TutorialAdvanceState _state = F10TutorialAdvanceState.SetupFailed;
        private string _error = string.Empty;
        private bool _observationAccepted;
        private bool _attemptInProgress;
        private bool _persistedConfirmed;
        private bool _activatedConfirmed;
        private ApplicationBootstrapper.F10V7SessionInitializationBinding _v7Binding;
        private F10V7TutorialAdvanceGateway _v7Gateway;

        internal F10TutorialAdvanceState State => _state;
        internal string Error => _error;
        internal bool Persisted => _persistedConfirmed;
        internal bool Activated => _activatedConfirmed;
        internal string TargetNodeId => _targetNodeId ?? string.Empty;
        internal ExpeditionEncounterAdvanceOutcome LastOutcome => _lastOutcome;

        /// <summary>
        /// Attaches only to the owning isolated F10 run while its exact tutorial activation is ready.
        /// Precondition failures throw; objective-driver setup failures remain inspectable and retryable here.
        /// </summary>
        internal static F10TutorialAdvanceCoordinator Attach(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            F10TutorialAdvanceCoordinator existing = composition.GetComponent<F10TutorialAdvanceCoordinator>();
            if (existing != null)
            {
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition)) return existing;
                throw new InvalidOperationException("This composition already owns another tutorial advance coordinator.");
            }

            AttachmentView attachment = ValidateAttachment(application, composition);
            F10TutorialAdvanceCoordinator coordinator =
                composition.gameObject.AddComponent<F10TutorialAdvanceCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._registration = attachment.Registration;
            coordinator._runId = attachment.Run.RunId;
            coordinator._targetNodeId = attachment.TargetNodeId;
            coordinator._resolver = new ExpeditionEncounterResolver(application, attachment.Transitions);
            coordinator.TryAttachObjectiveDriver();
            return coordinator;
        }

        /// <summary>
        /// Attaches to the exact already-published V7 tutorial session. This is a separate entry
        /// point because the legacy F10 scene runner is still V6-gated and must not mint V7 ownership.
        /// </summary>
        internal static F10TutorialAdvanceCoordinator AttachV7(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (application == null) throw new ArgumentNullException(nameof(application));
            if (composition == null) throw new ArgumentNullException(nameof(composition));
            F10TutorialAdvanceCoordinator existing = composition.GetComponent<F10TutorialAdvanceCoordinator>();
            if (existing != null)
            {
                if (ReferenceEquals(existing._application, application) &&
                    ReferenceEquals(existing._composition, composition) && existing._v7Binding != null)
                    return existing;
                throw new InvalidOperationException("This composition already owns another tutorial advance coordinator.");
            }

            AttachmentView attachment = ValidateV7Attachment(application, composition);
            F10TutorialAdvanceCoordinator coordinator =
                composition.gameObject.AddComponent<F10TutorialAdvanceCoordinator>();
            coordinator._application = application;
            coordinator._composition = composition;
            coordinator._registration = attachment.Registration;
            coordinator._runId = attachment.Run.RunId;
            coordinator._targetNodeId = attachment.TargetNodeId;
            coordinator._v7Binding = attachment.V7Binding;
            coordinator._v7Gateway = new F10V7TutorialAdvanceGateway(application, composition,
                attachment.Registration, attachment.V7Binding, attachment.Transitions, attachment.Run);
            coordinator._resolver = new ExpeditionEncounterResolver(coordinator._v7Gateway);
            coordinator.TryAttachObjectiveDriver();
            return coordinator;
        }

        /// <summary>Accepts one exact local tutorial fact and starts a rewardless durable room completion.</summary>
        public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
        {
            if (_objectiveDriver == null || !_objectiveDriver.IsDeliveringTo(this, observation) ||
                !IsExactTutorialObservationForContext(_context, observation) || !IsCurrentTutorialActivation())
                return F10ObjectiveHandoffResult.RetryLater;

            if (_acceptedObservationId != null)
                return string.Equals(_acceptedObservationId, observation.ObservationId, StringComparison.Ordinal)
                    ? F10ObjectiveHandoffResult.AcceptedLocalObservation
                    : F10ObjectiveHandoffResult.RetryLater;
            if (_snapshotSource == null || _registration.CurrentActivation.Source != _snapshotSource ||
                _objectiveDriver == null || _state != F10TutorialAdvanceState.WaitingForTutorial)
                return F10ObjectiveHandoffResult.RetryLater;

            _acceptedObservationId = observation.ObservationId;
            _acceptedObservation = observation;
            _observationAccepted = true;
            StartAttempt();
            return F10ObjectiveHandoffResult.AcceptedLocalObservation;
        }

        /// <summary>Retries the retained resolver scope and completion payload; it never manufactures input.</summary>
        internal Task RetryAsync()
        {
            if (_state == F10TutorialAdvanceState.Completed) return Task.CompletedTask;
            if (_attemptInProgress) return _attemptTask ?? Task.CompletedTask;
            if (TryReconcileSavedActivation()) return Task.CompletedTask;

            if (_objectiveDriver == null)
            {
                TryAttachObjectiveDriver();
                if (_objectiveDriver == null) return Task.CompletedTask;
            }
            if (!_observationAccepted) return Task.CompletedTask;
            return StartAttempt();
        }

        private static AttachmentView ValidateAttachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application) ||
                !application.OwnsF10DiagnosticRun(application.ActiveRun))
                throw new InvalidOperationException("Tutorial advance requires the exact owned F10 diagnostic run in Play Mode.");

            ExpeditionReadinessCompositionView readiness = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = readiness == null ? null : readiness.Run;
            ExpeditionRoomTransitionController transitions = readiness == null ? null : readiness.RoomTransitions;
            if (!composition.isActiveAndEnabled || !composition.IsReady || readiness == null || !readiness.IsReady ||
                !ReferenceEquals(readiness.Owner, composition) || !ReferenceEquals(readiness.Application, application) ||
                !ReferenceEquals(run, application.ActiveRun) || run == null || run.Route == null ||
                run.Route.GenerationVersion != 2 || transitions == null || !ReferenceEquals(transitions, composition.RoomTransitions))
                throw new InvalidOperationException("The F10 composition must be ready for its exact active run.");

            ExpeditionSaveData activeSave = application.ActiveExpedition;
            if (activeSave == null || !string.Equals(activeSave.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                !string.Equals(activeSave.currentNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                activeSave.visitedNodeIds == null || activeSave.visitedNodeIds.Length == 0 ||
                !string.Equals(activeSave.visitedNodeIds[activeSave.visitedNodeIds.Length - 1], TutorialNodeId, StringComparison.Ordinal) ||
                !string.Equals(transitions.CurrentNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                transitions.CurrentRoomId != application.ActiveRoomInstanceId ||
                application.HasPendingSessionMutation || application.HasPendingRoomAdvance)
                throw new InvalidOperationException("The saved and active route cursor must still be the F10 tutorial.");

            ExpeditionRouteNode tutorial = run.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, TutorialNodeId, StringComparison.Ordinal));
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, TutorialNodeId, StringComparison.Ordinal)).ToArray();
            ExpeditionRouteNode c1 = run.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, C1NodeId, StringComparison.Ordinal));
            if (tutorial == null || !string.Equals(tutorial.TemplateId, TutorialTemplateId, StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, C1NodeId, StringComparison.Ordinal) ||
                c1 == null || !string.Equals(c1.TemplateId, C1TemplateId, StringComparison.Ordinal))
                throw new InvalidOperationException("The tutorial must have exactly one real outgoing edge to F10 C1.");

            ExpeditionReadinessTransitionView transition = transitions.CaptureReadinessTransitionView();
            ExpeditionSessionReadinessRegistration registration = readiness.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null ? null : registration.CurrentActivation;
            if (transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !string.Equals(transition.ActiveNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                transition.ActiveScope == null || !ReferenceEquals(transition.ActiveScope, transitions.ActiveScope) ||
                registration.IsDisposed ||
                !registration.IsOwnerActive || !ReferenceEquals(registration.Owner, composition) ||
                activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, transition.ActiveScope) ||
                !string.Equals(activation.NodeId, TutorialNodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, TutorialTemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(activation.BoundRun, run) && activation.BoundRun?.RunId != run.RunId ||
                readiness.PlayerMotor == null || !ReferenceEquals(readiness.PlayerMotor, composition.PlayerMotor) ||
                readiness.PlayerObject == null || !ReferenceEquals(readiness.PlayerObject, readiness.PlayerMotor.gameObject) ||
                readiness.PlayerObject.GetComponent<Collider2D>() == null)
                throw new InvalidOperationException("Readiness does not own the exact bound tutorial actor and scope.");

            return new AttachmentView(registration, transitions, run, outgoing[0].ToNodeId,
                transition.ActiveScope, readiness.PlayerMotor, readiness.PlayerObject.GetComponent<Collider2D>(), null);
        }

        private static AttachmentView ValidateV7Attachment(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition)
        {
            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, application))
                throw new InvalidOperationException("V7 tutorial advance requires the active App during Play Mode.");

            ExpeditionReadinessCompositionView readiness = composition.CaptureReadinessCompositionView();
            ExpeditionRunConfiguration run = readiness == null ? null : readiness.Run;
            ExpeditionRoomTransitionController transitions = readiness == null ? null : readiness.RoomTransitions;
            ExpeditionSessionReadinessRegistration registration = readiness?.ReadinessRegistration;
            ApplicationBootstrapper.F10V7SessionInitializationBinding binding =
                registration?.V7InitializationBinding;
            if (!composition.isActiveAndEnabled || !composition.IsReady || readiness == null || !readiness.IsReady ||
                !ReferenceEquals(readiness.Owner, composition) || !ReferenceEquals(readiness.Application, application) ||
                !ReferenceEquals(readiness.ReadinessRegistration, registration) || run == null ||
                !ReferenceEquals(run, application.ActiveRun) || transitions == null ||
                !ReferenceEquals(transitions, composition.RoomTransitions) || binding == null ||
                !ReferenceEquals(binding.Composition, composition) || !ReferenceEquals(binding.Run, run) ||
                !binding.IsCurrentFor(application, composition) ||
                !application.IsCurrentV7PublishedSession(binding, registration, binding.PublishedRevision) ||
                application.HasPendingRoomAdvance || application.HasPendingSessionMutation)
                throw new InvalidOperationException("The exact admitted V7 session is not currently published and ready.");

            ExpeditionSaveData activeSave = application.ActiveExpedition;
            if (activeSave == null || !string.Equals(activeSave.runId, run.RunId.ToString(), StringComparison.Ordinal) ||
                !string.Equals(activeSave.currentNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                activeSave.visitedNodeIds == null || activeSave.visitedNodeIds.Length == 0 ||
                !string.Equals(activeSave.visitedNodeIds[activeSave.visitedNodeIds.Length - 1], TutorialNodeId,
                    StringComparison.Ordinal) || !string.Equals(transitions.CurrentNodeId, TutorialNodeId,
                    StringComparison.Ordinal) || transitions.CurrentRoomId != application.ActiveRoomInstanceId)
                throw new InvalidOperationException("The App and live route must still identify the admitted Tutorial room.");

            ExpeditionRouteNode tutorial = run.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, TutorialNodeId, StringComparison.Ordinal));
            ExpeditionRouteNode c1 = run.Route.Nodes.SingleOrDefault(node =>
                string.Equals(node.NodeId, C1NodeId, StringComparison.Ordinal));
            ExpeditionRouteConnection[] outgoing = run.Route.Connections.Where(connection => connection != null &&
                string.Equals(connection.FromNodeId, TutorialNodeId, StringComparison.Ordinal)).ToArray();
            if (tutorial == null || !string.Equals(tutorial.TemplateId, TutorialTemplateId, StringComparison.Ordinal) ||
                c1 == null || !string.Equals(c1.TemplateId, C1TemplateId, StringComparison.Ordinal) ||
                outgoing.Length != 1 || outgoing[0].IsOptionalBranch ||
                !string.Equals(outgoing[0].ToNodeId, C1NodeId, StringComparison.Ordinal))
                throw new InvalidOperationException("The admitted V7 route must have exactly one Tutorial-to-C1 edge.");

            ExpeditionReadinessTransitionView transition = transitions.CaptureReadinessTransitionView();
            ExpeditionRoomActivationRegistration activation = registration.CurrentActivation;
            if (transition == null || !transition.IsInitialized || transition.IsDisposed || transition.IsTransitioning ||
                transition.HasPreparedTransition || !string.Equals(transition.ActiveNodeId, TutorialNodeId, StringComparison.Ordinal) ||
                transition.ActiveScope == null || !ReferenceEquals(transition.ActiveScope, transitions.ActiveScope) ||
                registration.IsDisposed || !registration.IsOwnerActive || !ReferenceEquals(registration.Owner, composition) ||
                activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, transition.ActiveScope) ||
                !string.Equals(activation.NodeId, TutorialNodeId, StringComparison.Ordinal) ||
                !string.Equals(activation.TemplateId, TutorialTemplateId, StringComparison.Ordinal) ||
                !ReferenceEquals(activation.BoundRun, run) && activation.BoundRun?.RunId != run.RunId ||
                readiness.PlayerMotor == null || !ReferenceEquals(readiness.PlayerMotor, composition.PlayerMotor) ||
                readiness.PlayerObject == null || !ReferenceEquals(readiness.PlayerObject, readiness.PlayerMotor.gameObject) ||
                readiness.PlayerObject.GetComponent<Collider2D>() == null)
                throw new InvalidOperationException("Readiness does not own the exact bound V7 Tutorial actor and scope.");

            return new AttachmentView(registration, transitions, run, outgoing[0].ToNodeId,
                transition.ActiveScope, readiness.PlayerMotor, readiness.PlayerObject.GetComponent<Collider2D>(), binding);
        }

        private void TryAttachObjectiveDriver()
        {
            try
            {
                ExpeditionReadinessCompositionView readiness = _composition.CaptureReadinessCompositionView();
                if (readiness == null || !readiness.IsReady || !ReferenceEquals(readiness.ReadinessRegistration, _registration) ||
                    readiness.PlayerMotor == null || !ReferenceEquals(readiness.PlayerMotor.gameObject,
                        readiness.PlayerObject) || !readiness.PlayerMotor.ActorId.IsValid)
                    throw new InvalidOperationException("The exact ready F10 tutorial actor is no longer available.");

                EnsureSingleContextAndSource(readiness, _registration.CurrentActivation);
                if (!_context.IsCurrentRoomScope() ||
                    !string.Equals(_context.NodeId, TutorialNodeId, StringComparison.Ordinal))
                    throw new InvalidOperationException("The retained tutorial activation is no longer current.");

                _objectiveDriver = F10ObjectiveSetupDemo.Attach(_context, _snapshotSource,
                    readiness.PlayerObject.GetComponent<Collider2D>(), this);
                _state = F10TutorialAdvanceState.WaitingForTutorial;
                _error = string.Empty;
            }
            catch (Exception exception)
            {
                _state = F10TutorialAdvanceState.SetupFailed;
                _error = exception.Message;
            }
        }

        private void EnsureSingleContextAndSource(ExpeditionReadinessCompositionView readiness,
            ExpeditionRoomActivationRegistration activation)
        {
            if (activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation.Scope, _composition.RoomTransitions.ActiveScope))
                throw new InvalidOperationException("The tutorial activation registration is no longer bound.");

            if (_context == null)
            {
                RoomEncounterRuntimeContext registeredContext = activation.Context;
                if (registeredContext != null)
                {
                    if (registeredContext.Plan != null || !IsExactTutorialContext(registeredContext,
                        activation, readiness, _application))
                        throw new InvalidOperationException("This activation already owns a different encounter context.");
                    _context = registeredContext;
                }
                else
                {
                    if (activation.Source != null)
                        throw new InvalidOperationException("The activation has a source without its exact context.");
                    _context = RoomEncounterRuntimeContext.Create(_runId, TutorialNodeId,
                        TutorialTemplateId, activation.RoomInstanceId, activation.Scope,
                        activation.Controller, readiness.PlayerMotor, plan: null,
                        routeGenerationVersion: _registration.RouteGenerationVersion);
                }
            }

            if (!IsExactTutorialContext(_context, activation, readiness, _application) || _context.Plan != null)
                throw new InvalidOperationException("The one tutorial context must match the exact activation and use Plan == null.");
            _snapshotSource = _registration.CreateSnapshotSource(_context);
            if (_snapshotSource == null || !ReferenceEquals(activation.Context, _context) ||
                !ReferenceEquals(activation.Source, _snapshotSource))
                throw new InvalidOperationException("The registration did not return its exact activation-owned snapshot source.");
        }

        private Task StartAttempt()
        {
            if (_attemptInProgress) return _attemptTask ?? Task.CompletedTask;
            if (_state == F10TutorialAdvanceState.Completed) return Task.CompletedTask;
            _attemptInProgress = true;
            _state = F10TutorialAdvanceState.Resolving;
            _error = string.Empty;
            _attemptTask = ResolveRetainedCompletionAsync();
            return _attemptTask;
        }

        private async Task ResolveRetainedCompletionAsync()
        {
            try
            {
                if (_resolver == null || !_observationAccepted || string.IsNullOrEmpty(_acceptedObservationId))
                    throw new InvalidOperationException("No accepted tutorial observation is retained for resolution.");
                if (_resolutionScope == null)
                {
                    _resolutionScope = _resolver.ActivateCurrentRoom(_targetNodeId);
                    _v7Gateway?.RetainResolutionScope(_resolutionScope);
                }

                ExpeditionEncounterAdvanceOutcome outcome = _resolutionScope.HasCompletion
                    ? await _resolver.RetryCapturedCompletionAsync(_resolutionScope)
                    : await _resolver.ResolveVictoryAsync(_resolutionScope, Array.Empty<string>());
                _lastOutcome = outcome;
                _persistedConfirmed = outcome != null && outcome.Persisted;
                _activatedConfirmed = outcome != null && outcome.Activated;

                if (_activatedConfirmed)
                {
                    _state = F10TutorialAdvanceState.Completed;
                    _error = string.Empty;
                    return;
                }

                if (TryReconcileSavedActivation()) return;
                if (outcome == null)
                    throw new InvalidOperationException("The room resolver returned no durable completion outcome.");

                _error = outcome.Message;
                _state = outcome.Pending ? F10TutorialAdvanceState.PendingRetry : F10TutorialAdvanceState.Failed;
            }
            catch (Exception exception)
            {
                _state = F10TutorialAdvanceState.Failed;
                _error = exception.Message;
            }
            finally
            {
                _attemptInProgress = false;
            }
        }

        private bool TryReconcileSavedActivation()
        {
            if (_resolutionScope == null || !_resolutionScope.HasCompletion ||
                _application == null || _composition == null) return false;

            if (_v7Gateway != null)
            {
                if (_attemptInProgress) return false;
                if (_v7Gateway.TryReconcileAlreadyActivated(_resolutionScope,
                        out ExpeditionEncounterAdvanceOutcome v7Reconciliation))
                {
                    _lastOutcome = v7Reconciliation;
                    _persistedConfirmed = v7Reconciliation != null && v7Reconciliation.Persisted;
                    _activatedConfirmed = v7Reconciliation != null && v7Reconciliation.Activated;
                    if (_activatedConfirmed)
                    {
                        _state = F10TutorialAdvanceState.Completed;
                        _error = string.Empty;
                        return true;
                    }
                    _state = F10TutorialAdvanceState.PendingRetry;
                    _error = v7Reconciliation == null
                        ? "The exact V7 C1 publication remains pending reconciliation."
                        : v7Reconciliation.Message;
                    return false;
                }
            }

            ExpeditionRunConfiguration activeRun = _application.ActiveRun;
            ExpeditionSaveData saved = _application.ActiveExpedition;
            ExpeditionRoomTransitionController transitions = _composition.RoomTransitions;
            ExpeditionReadinessCompositionView readiness = _composition.CaptureReadinessCompositionView();
            ExpeditionSessionReadinessRegistration registration = readiness == null ? null : readiness.ReadinessRegistration;
            ExpeditionRoomActivationRegistration activation = registration == null ? null : registration.CurrentActivation;
            bool exactSavedResult = saved != null && saved.completedRoomResults != null &&
                saved.completedRoomResults.Any(result => result != null &&
                    string.Equals(result.roomNodeId, TutorialNodeId, StringComparison.Ordinal) &&
                    string.Equals(result.resultId, _resolutionScope.ResultId, StringComparison.Ordinal) &&
                    string.Equals(result.resultJson, _resolutionScope.ResultJson, StringComparison.Ordinal));
            bool exactActiveC1 = activeRun != null && activeRun.RunId == _runId && saved != null &&
                string.Equals(saved.currentNodeId, _targetNodeId, StringComparison.Ordinal) &&
                transitions != null && string.Equals(transitions.CurrentNodeId, _targetNodeId, StringComparison.Ordinal) &&
                transitions.CurrentRoomId == ExpeditionRoomIdentity.ForNode(_runId, _targetNodeId) &&
                _application.ActiveRoomInstanceId == transitions.CurrentRoomId &&
                readiness != null && readiness.IsReady && _composition.IsReady &&
                activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Scope, transitions.ActiveScope) &&
                string.Equals(activation.NodeId, _targetNodeId, StringComparison.Ordinal) &&
                string.Equals(activation.TemplateId, C1TemplateId, StringComparison.Ordinal);

            if (!exactSavedResult || !exactActiveC1 || _application.HasPendingRoomAdvance ||
                _application.IsRoomAdvanceInFlight) return false;
            _persistedConfirmed = true;
            _activatedConfirmed = true;
            _state = F10TutorialAdvanceState.Completed;
            _error = string.Empty;
            return true;
        }

        private bool IsCurrentTutorialActivation()
        {
            if (_application == null || _composition == null || _registration == null || _context == null ||
                _snapshotSource == null || !compositionReadyForSource()) return false;
            ExpeditionRoomActivationRegistration activation = _registration.CurrentActivation;
            return activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                ReferenceEquals(activation.Context, _context) && ReferenceEquals(activation.Source, _snapshotSource) &&
                ReferenceEquals(activation.Scope, _context.Scope) && _context.IsCurrentRoomScope() &&
                string.Equals(_application.ActiveExpedition?.currentNodeId, TutorialNodeId, StringComparison.Ordinal) &&
                _application.ActiveRun != null && _application.ActiveRun.RunId == _runId;
        }

        /// <summary>
        /// Proves the initial V7 mutation belongs to this coordinator's private synchronous
        /// observation acceptance and the exact resolver scope created from that acceptance.
        /// It does not re-run IsDeliveringTo after the callback has returned.
        /// </summary>
        internal bool OwnsAcceptedV7TutorialResolution(ApplicationBootstrapper application,
            ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
            ApplicationBootstrapper.F10V7SessionInitializationBinding binding,
            ExpeditionEncounterResolutionScope scope)
        {
            if (application == null || composition == null || registration == null || binding == null || scope == null ||
                !ReferenceEquals(_application, application) || !ReferenceEquals(_composition, composition) ||
                !ReferenceEquals(_registration, registration) || !ReferenceEquals(_v7Binding, binding) ||
                !_observationAccepted || string.IsNullOrWhiteSpace(_acceptedObservationId) ||
                _acceptedObservation == null ||
                !string.Equals(_acceptedObservationId, _acceptedObservation.ObservationId, StringComparison.Ordinal) ||
                !IsExactTutorialObservationForContext(_context, _acceptedObservation) ||
                !ReferenceEquals(_resolutionScope, scope) || _v7Gateway == null || !_attemptInProgress ||
                _state != F10TutorialAdvanceState.Resolving || _resolver == null || _objectiveDriver == null ||
                !ReferenceEquals(binding.Composition, composition) || !ReferenceEquals(binding.Run, application.ActiveRun) ||
                !ReferenceEquals(registration.V7InitializationBinding, binding) || !registration.IsOwnerActive ||
                !ReferenceEquals(registration.CurrentActivation?.Context, _context) ||
                !ReferenceEquals(registration.CurrentActivation?.Source, _snapshotSource) ||
                !ReferenceEquals(registration.CurrentActivation?.Scope, _context?.Scope) ||
                !IsCurrentTutorialActivation() || !_v7Gateway.OwnsRetainedResolutionScope(scope))
                return false;

            return scope.HasCompletion && scope.RunId == binding.Run.RunId &&
                scope.SourceRoomId == ExpeditionRoomIdentity.ForNode(binding.Run.RunId, TutorialNodeId) &&
                string.Equals(scope.SourceNodeId, TutorialNodeId, StringComparison.Ordinal) &&
                string.Equals(scope.TargetNodeId, C1NodeId, StringComparison.Ordinal) &&
                ReferenceEquals(scope.RoomScopeToken, _context.Scope);
        }

        /// <summary>
        /// Proves the first V7 durable mutation belongs to this coordinator's private synchronous
        /// observation acceptance and the exact resolver scope created from that acceptance.
        /// It intentionally does not call IsDeliveringTo again after the observation callback.
        /// </summary>
        private bool compositionReadyForSource()
        {
            ExpeditionReadinessCompositionView view = _composition.CaptureReadinessCompositionView();
            return _composition.IsReady && view != null && view.IsReady &&
                ReferenceEquals(view.Application, _application) && ReferenceEquals(view.ReadinessRegistration, _registration) &&
                ReferenceEquals(view.PlayerMotor, _context.Player);
        }

        private static bool IsExactTutorialContext(RoomEncounterRuntimeContext context,
            ExpeditionRoomActivationRegistration activation, ExpeditionReadinessCompositionView readiness,
            ApplicationBootstrapper application)
        {
            return context != null && activation != null && readiness != null && application != null &&
                context.Plan == null && context.IsCurrentRoomScope() &&
                string.Equals(context.NodeId, TutorialNodeId, StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, TutorialTemplateId, StringComparison.Ordinal) &&
                context.RunId == activation.RunId && context.RoomInstanceId == activation.RoomInstanceId &&
                ReferenceEquals(context.Scope, activation.Scope) && ReferenceEquals(context.Controller, activation.Controller) &&
                ReferenceEquals(context.Player, readiness.PlayerMotor) && application.ActiveRun != null &&
                application.ActiveRun.RunId == context.RunId;
        }

        internal static bool IsExactTutorialObservationForContext(RoomEncounterRuntimeContext context,
            F10ObjectiveObservation observation)
        {
            return context != null && observation != null && context.Plan == null && context.IsCurrentRoomScope() &&
                string.Equals(context.NodeId, TutorialNodeId, StringComparison.Ordinal) &&
                string.Equals(context.TemplateId, TutorialTemplateId, StringComparison.Ordinal) &&
                observation.Kind == F10ObjectiveObservationKind.TutorialCompleted &&
                observation.RunId == context.RunId && observation.RoomInstanceId == context.RoomInstanceId &&
                string.Equals(observation.NodeId, context.NodeId, StringComparison.Ordinal) &&
                string.Equals(observation.TemplateId, context.TemplateId, StringComparison.Ordinal) &&
                ReferenceEquals(observation.Scope, context.Scope) && ReferenceEquals(observation.Controller, context.Controller) &&
                ReferenceEquals(observation.Player, context.Player) && context.Player != null &&
                context.Player.ActorId.IsValid && observation.ActorId == context.Player.ActorId &&
                observation.ActivationGeneration == context.ActivationGeneration && observation.Tick >= 0 &&
                !string.IsNullOrWhiteSpace(observation.ObservationId);
        }

        private void Update()
        {
            if (_state == F10TutorialAdvanceState.Completed) return;
            TryReconcileSavedActivation();
        }

        private void OnDestroy()
        {
            _objectiveDriver = null;
            _snapshotSource = null;
            _context = null;
            _v7Gateway?.ReleaseRetainedScope();
            _v7Gateway = null;
        }

        private sealed class F10V7TutorialAdvanceGateway : IExpeditionEncounterAdvanceGateway
        {
            private readonly ApplicationBootstrapper _application;
            private readonly ExpeditionGameplayComposition _composition;
            private readonly ExpeditionSessionReadinessRegistration _registration;
            private readonly ApplicationBootstrapper.F10V7SessionInitializationBinding _binding;
            private readonly ExpeditionRoomTransitionController _transitions;
            private readonly ExpeditionRunConfiguration _run;
            private ExpeditionEncounterResolutionScope _scope;

            internal F10V7TutorialAdvanceGateway(ApplicationBootstrapper application,
                ExpeditionGameplayComposition composition, ExpeditionSessionReadinessRegistration registration,
                ApplicationBootstrapper.F10V7SessionInitializationBinding binding,
                ExpeditionRoomTransitionController transitions, ExpeditionRunConfiguration run)
            {
                _application = application ?? throw new ArgumentNullException(nameof(application));
                _composition = composition ?? throw new ArgumentNullException(nameof(composition));
                _registration = registration ?? throw new ArgumentNullException(nameof(registration));
                _binding = binding ?? throw new ArgumentNullException(nameof(binding));
                _transitions = transitions ?? throw new ArgumentNullException(nameof(transitions));
                _run = run ?? throw new ArgumentNullException(nameof(run));
            }

            public RunId RunId => _run.RunId;
            public RoomInstanceId CurrentRoomId => _transitions.CurrentRoomId;
            public RoomInstanceId SavedRoomId => _application.ActiveExpedition == null
                ? default
                : ExpeditionRoomIdentity.ForNode(_run.RunId, _application.ActiveExpedition.currentNodeId);
            public string CurrentNodeId => _transitions.CurrentNodeId;
            public ExpeditionInventory CurrentInventory => _application.ActiveRun == null
                ? null
                : _application.ActiveRun.Inventory;
            public long CurrentExpeditionRevision => _application.ActiveExpeditionRevision;
            public object CurrentRoomScopeToken => _transitions.ActiveScope;

            internal void RetainResolutionScope(ExpeditionEncounterResolutionScope scope)
            {
                if (scope == null) throw new ArgumentNullException(nameof(scope));
                if (_scope != null && !ReferenceEquals(_scope, scope))
                    throw new InvalidOperationException("Only the exact Tutorial completion scope may be retained for retry.");
                _scope = scope;
            }

            internal bool OwnsRetainedResolutionScope(ExpeditionEncounterResolutionScope scope)
            {
                return scope != null && ReferenceEquals(_scope, scope) &&
                    ReferenceEquals(ApplicationBootstrapper.Instance, _application) &&
                    ReferenceEquals(_composition, _registration.Owner) &&
                    ReferenceEquals(_registration.Application, _application) &&
                    ReferenceEquals(_registration.V7InitializationBinding, _binding) &&
                    ReferenceEquals(_transitions, _composition.RoomTransitions) &&
                    ReferenceEquals(_transitions.ActiveScope, scope.RoomScopeToken) &&
                    string.Equals(_transitions.CurrentNodeId, F10V7TutorialAdvanceCandidate.TutorialNodeId,
                        StringComparison.Ordinal) &&
                    scope.RunId == _run.RunId && scope.SourceRoomId == _transitions.CurrentRoomId &&
                    ReferenceEquals(_application.ActiveRun, _run);
            }

            internal void ReleaseRetainedScope() => _scope = null;

            internal bool TryReconcileAlreadyActivated(ExpeditionEncounterResolutionScope scope,
                out ExpeditionEncounterAdvanceOutcome outcome)
            {
                return _application.TryReconcileAdmittedV7TutorialAdvance(_composition,
                    _registration, _binding, scope, out outcome);
            }

            public bool HasRouteEdge(string sourceNodeId, string targetNodeId)
            {
                return IsCurrentOwner() && _run.Route != null &&
                    _run.Route.Connections.Any(connection => connection != null &&
                        string.Equals(connection.FromNodeId, sourceNodeId, StringComparison.Ordinal) &&
                        string.Equals(connection.ToNodeId, targetNodeId, StringComparison.Ordinal));
            }

            public bool IsRoomScopeActive(object scopeToken, RoomInstanceId roomId)
            {
                if (!IsCurrentOwner() || !(scopeToken is RoomLifetimeScope capturedScope)) return false;
                ExpeditionRoomActivationRegistration activation = _registration.CurrentActivation;
                return ReferenceEquals(_transitions.ActiveScope, capturedScope) &&
                    capturedScope.isActiveAndEnabled && !capturedScope.IsDisposed &&
                    capturedScope.RoomInstanceId == roomId && _transitions.CurrentRoomId == roomId &&
                    activation != null && activation.State == ExpeditionRoomActivationState.Bound &&
                    ReferenceEquals(activation.Scope, capturedScope);
            }

            public bool TryAcquireSimulationPauseLease(out IDisposable lease, out string error)
            {
                return _application.TryAcquireAdmittedV7TutorialPauseLease(_composition,
                    _registration, _binding, out lease, out error);
            }

            public Task<ExpeditionEncounterAdvanceOutcome> CompleteAndAdvanceRoomAsync(
                RoomInstanceId sourceRoomId, string targetNodeId, string resultId, string resultJson,
                ExpeditionInventory candidateInventory, string expectedBaseInventorySnapshotJson,
                long expectedExpeditionRevision)
            {
                ExpeditionEncounterResolutionScope scope = _scope;
                if (scope == null || scope.RunId != _run.RunId || scope.SourceRoomId != sourceRoomId ||
                    !string.Equals(scope.SourceNodeId, F10V7TutorialAdvanceCandidate.TutorialNodeId, StringComparison.Ordinal) ||
                    !string.Equals(scope.TargetNodeId, F10V7TutorialAdvanceCandidate.C1NodeId, StringComparison.Ordinal) ||
                    !string.Equals(scope.ResultId, resultId, StringComparison.Ordinal) ||
                    !string.Equals(scope.ResultJson, resultJson, StringComparison.Ordinal) ||
                    !ReferenceEquals(scope.RoomScopeToken, _transitions.ActiveScope))
                    return Task.FromResult(ExpeditionEncounterAdvanceOutcome.Failure(false,
                        "The V7 gateway received a different or stale Tutorial completion scope."));

                return _application.CommitAdmittedV7TutorialAdvanceAsync(_composition, _registration,
                    _binding, scope, candidateInventory, expectedBaseInventorySnapshotJson,
                    expectedExpeditionRevision);
            }

            private bool IsCurrentOwner()
            {
                return ReferenceEquals(ApplicationBootstrapper.Instance, _application) &&
                    _application.IsCurrentV7TutorialAdvanceOwner(_composition, _registration, _binding) &&
                    ReferenceEquals(_application.ActiveRun, _run);
            }
        }

        private sealed class AttachmentView
        {
            internal AttachmentView(ExpeditionSessionReadinessRegistration registration,
                ExpeditionRoomTransitionController transitions, ExpeditionRunConfiguration run,
                string targetNodeId, RoomLifetimeScope scope, PlayerMotor2D player, Collider2D playerCollider,
                ApplicationBootstrapper.F10V7SessionInitializationBinding v7Binding)
            {
                Registration = registration;
                Transitions = transitions;
                Run = run;
                TargetNodeId = targetNodeId;
                Scope = scope;
                Player = player;
                PlayerCollider = playerCollider;
                V7Binding = v7Binding;
            }

            internal ExpeditionSessionReadinessRegistration Registration { get; }
            internal ExpeditionRoomTransitionController Transitions { get; }
            internal ExpeditionRunConfiguration Run { get; }
            internal string TargetNodeId { get; }
            internal RoomLifetimeScope Scope { get; }
            internal PlayerMotor2D Player { get; }
            internal Collider2D PlayerCollider { get; }
            internal ApplicationBootstrapper.F10V7SessionInitializationBinding V7Binding { get; }
        }
    }
}
#endif
