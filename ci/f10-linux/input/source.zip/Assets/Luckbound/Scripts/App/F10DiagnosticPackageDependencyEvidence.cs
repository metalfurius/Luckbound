#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;

namespace Luckbound.App
{
    [Serializable]
    public sealed class F10DiagnosticPackageDependencyEvidence
    {
        public int schemaVersion;
        public string packageName;
        public string packageVersion;
        public string packageSource;
        public string packageId;
        public string registryUrl;
        public bool registryIsDefault;
        public string packageAssetPath;
        public string resolvedRootKind;
        public string resolvedRootRelativePath;
        public string resolvedRootAbsolutePath;
        public string resolvedRootIdentity;
        public string lockEntrySource;
        public string lockEntryVersion;
        public string lockEntryUrl;
        public string lockEntryHash;
        public string lockFileSha256;
        public string certifiedProjectEditorVersion;
        public string editorVersion;
        public string editorApplicationPath;
        public string editorExecutableFinalPath;
        public string editorExecutableSha256;
        public long editorExecutableLength;
        public string editorExecutableIdentity;
        public uint editorExecutableLinkCount;
        public string[] dependencyAssetPaths;
        public F10DiagnosticPackageDependencyFile[] files;
    }

    [Serializable]
    public sealed class F10DiagnosticPackageDependencyFile
    {
        public string relativePath;
        public string projectRelativePath;
        public string[] roles;
        public string[] assetPaths;
        public string sha256;
        public long length;
        public string identity;
        public uint linkCount;
    }

    /// <summary>
    /// Measures package dependency files selected from the certified lock. Registry packages retain
    /// their copy-local policy; the sole external exception is the URP BuiltIn package in the running Editor.
    /// Embedded, Git, local, tarball, engine and otherwise unrepresentable dependencies fail closed.
    /// </summary>
    public static class F10DiagnosticPackageDependencyEvidenceReader
    {
        private const string PackageLockRelativePath = "Packages/packages-lock.json";
        private const string CertificateRelativePath = "Logs/F10DisposableArt-20261116/copy-certificate.json";
        private const string BuiltInUniversalPackageName = "com.unity.render-pipelines.universal";
        private const string BuiltInUniversalRootRelativePath = "@editor/Data/Resources/PackageManager/BuiltInPackages/com.unity.render-pipelines.universal";
        private const int FileIdInfoClass = 18;
        private const uint GenericRead = 0x80000000;
        private const uint FileReadAttributes = 0x00000080;
        private const uint ShareRead = 0x00000001;
        private const uint OpenExisting = 3;
        private const uint FileFlagOpenReparsePoint = 0x00200000;
        private const uint FileFlagSequentialScan = 0x08000000;
        private const uint FileFlagBackupSemantics = 0x02000000;
        private const uint AttributeDirectory = 0x00000010;
        private const uint AttributeReparsePoint = 0x00000400;
        private const int MaximumMetadataBytes = 1024 * 1024;
        private static readonly StringComparison WindowsPathComparison = StringComparison.OrdinalIgnoreCase;
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        /// <summary>
        /// Captures package-only dependency paths freshly observed from AssetDatabase.GetDependencies.
        /// Pass the SHA in the already-validated copy-certificate row for Packages/packages-lock.json.
        /// The helper independently compares it with both the certificate row and bytes read from disk.
        /// </summary>
        public static F10DiagnosticPackageDependencyEvidence[] Capture(string projectRoot,
            IEnumerable<string> actualPackageAssetPaths, string certifiedPackagesLockSha256)
        {
            string root = CanonicalPath(projectRoot);
            EnsureWindows();
            EnsurePlainPath(root);
            LockSnapshot packageLock = ReadCertifiedLock(root, certifiedPackagesLockSha256);
            ReadDirectoryIdentity(root, out string rootFinalPath, out _);

            string[] paths = NormalizeDistinctAssetPaths(actualPackageAssetPaths);
            var groups = new SortedDictionary<string, PackageBuild>(StringComparer.Ordinal);
            EditorBinarySnapshot editorBinary = null;
            foreach (string dependencyPath in paths)
            {
                PackageInfo info = PackageInfo.FindForAssetPath(dependencyPath);
                PackageContext context = ResolveContext(root, rootFinalPath, dependencyPath, info, packageLock, ref editorBinary);
                string key = context.Name + "\0" + context.RootRelativePath;
                if (!groups.TryGetValue(key, out PackageBuild group))
                {
                    group = new PackageBuild(context);
                    groups.Add(key, group);
                }
                else if (!group.Context.SamePackage(context))
                {
                    throw new InvalidDataException("PackageInfo changed while the package closure was being measured: " + dependencyPath);
                }
                group.DependencyPaths.Add(dependencyPath);
            }

            var result = new List<F10DiagnosticPackageDependencyEvidence>(groups.Count);
            foreach (PackageBuild group in groups.Values)
            {
                AddPackageManifestFiles(root, rootFinalPath, group);
                foreach (string dependencyPath in group.DependencyPaths)
                    AddDependencyFiles(root, rootFinalPath, group, dependencyPath);
                ValidateUniqueMetaGuids(group);
                result.Add(group.ToEvidence());
            }
            return result.ToArray();
        }

        /// <summary>Re-resolves and remeasures the full package subset in a later process (A/B).</summary>
        public static void ValidateRecorded(string projectRoot,
            F10DiagnosticPackageDependencyEvidence[] recorded,
            IEnumerable<string> actualPackageAssetPaths, string certifiedPackagesLockSha256)
        {
            if (recorded == null) throw new InvalidDataException("The recorded package dependency closure is missing.");
            F10DiagnosticPackageDependencyEvidence[] current = Capture(projectRoot, actualPackageAssetPaths,
                certifiedPackagesLockSha256);
            if (recorded.Length != current.Length)
                throw new InvalidDataException("The measured package set differs from the live AssetDatabase package closure.");

            var rows = new Dictionary<string, F10DiagnosticPackageDependencyEvidence>(StringComparer.Ordinal);
            foreach (F10DiagnosticPackageDependencyEvidence row in recorded)
            {
                if (row == null || row.schemaVersion != 2 || row.files == null || row.dependencyAssetPaths == null)
                    throw new InvalidDataException("A package dependency evidence row is malformed.");
                ValidateRecordedSourceIdentity(row);
                string key = PackageKey(row.packageName, row.resolvedRootRelativePath);
                if (!rows.TryAdd(key, row))
                    throw new InvalidDataException("The package dependency receipt contains a duplicate package/root row.");
            }

            foreach (F10DiagnosticPackageDependencyEvidence live in current)
            {
                string key = PackageKey(live.packageName, live.resolvedRootRelativePath);
                if (!rows.TryGetValue(key, out F10DiagnosticPackageDependencyEvidence prior) || !Equal(prior, live))
                    throw new InvalidDataException("Package identity, lock selection, file evidence, or exact closure changed: " + live.packageName);
            }
        }

        internal sealed class PackageLockEntry
        {
            internal string Name;
            internal string Version;
            internal string Source;
            internal string Url;
            internal string Hash;
        }

        /// <summary>Narrow parser for the UPM lock's top-level dependencies map; not a general JSON API.</summary>
        internal static PackageLockEntry ParseRegistryPackageLockEntry(string json, string packageName)
        {
            return ParsePackageLockEntry(json, packageName, "registry", requireHttpsUrl: true);
        }

        internal static PackageLockEntry ParseBuiltInUniversalPackageLockEntry(string json, string packageName)
        {
            if (!string.Equals(packageName, BuiltInUniversalPackageName, StringComparison.Ordinal))
                throw new InvalidDataException("Only the exact Universal Render Pipeline BuiltIn package is representable.");
            return ParsePackageLockEntry(json, packageName, "builtin", requireHttpsUrl: false);
        }

        private static PackageLockEntry ParsePackageLockEntry(string json, string packageName, string expectedSource,
            bool requireHttpsUrl)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(packageName))
                throw new ArgumentException("A lock JSON document and package name are required.");
            var reader = new LockJsonReader(json);
            PackageLockEntry found = null;
            reader.Expect('{');
            var rootKeys = new HashSet<string>(StringComparer.Ordinal);
            bool dependenciesSeen = false;
            while (!reader.TryConsume('}'))
            {
                string rootKey = reader.ReadString();
                if (!rootKeys.Add(rootKey)) throw new FormatException("The package lock has a duplicate root key.");
                reader.Expect(':');
                if (string.Equals(rootKey, "dependencies", StringComparison.Ordinal))
                {
                    if (dependenciesSeen) throw new FormatException("The package lock has duplicate dependency maps.");
                    dependenciesSeen = true;
                    reader.Expect('{');
                    var names = new HashSet<string>(StringComparer.Ordinal);
                    while (!reader.TryConsume('}'))
                    {
                        string name = reader.ReadString();
                        if (!names.Add(name)) throw new FormatException("The package lock has a duplicate package name.");
                        reader.Expect(':');
                        if (string.Equals(name, packageName, StringComparison.Ordinal))
                            found = ReadLockEntry(reader, name);
                        else
                            reader.SkipValue(0);
                        if (reader.TryConsume(',')) continue;
                        reader.Expect('}');
                        break;
                    }
                }
                else reader.SkipValue(0);
                if (reader.TryConsume(',')) continue;
                reader.Expect('}');
                break;
            }
            reader.RequireEnd();
            if (!dependenciesSeen || found == null)
                throw new InvalidDataException("The certified packages-lock.json does not select the observed package: " + packageName);
            if (!string.Equals(found.Source, expectedSource, StringComparison.Ordinal))
                throw new InvalidDataException("The package lock source is not representable for this package: " + packageName + " (" + found.Source + ").");
            if (string.IsNullOrWhiteSpace(found.Version))
                throw new InvalidDataException("A package lock entry must include an exact version: " + packageName);
            if (requireHttpsUrl && (string.IsNullOrWhiteSpace(found.Url) ||
                !Uri.TryCreate(found.Url, UriKind.Absolute, out Uri registryUri) ||
                !string.Equals(registryUri.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidDataException("A Registry lock entry must include an exact version and HTTPS registry URL: " + packageName);
            return found;
        }

        private static PackageLockEntry ReadLockEntry(LockJsonReader reader, string name)
        {
            var entry = new PackageLockEntry { Name = name };
            var keys = new HashSet<string>(StringComparer.Ordinal);
            reader.Expect('{');
            while (!reader.TryConsume('}'))
            {
                string key = reader.ReadString();
                if (!keys.Add(key)) throw new FormatException("A package lock entry contains a duplicate field: " + key);
                reader.Expect(':');
                if (key == "version") entry.Version = reader.ReadString();
                else if (key == "source") entry.Source = reader.ReadString();
                else if (key == "url") entry.Url = reader.ReadString();
                else if (key == "hash") entry.Hash = reader.ReadString();
                else reader.SkipValue(0);
                if (reader.TryConsume(',')) continue;
                reader.Expect('}');
                break;
            }
            if (entry.Source == null || entry.Version == null)
                throw new InvalidDataException("A package lock entry is missing source or version: " + name);
            return entry;
        }

        private static LockSnapshot ReadCertifiedLock(string projectRoot, string expectedSha256)
        {
            if (!IsSha256(expectedSha256)) throw new InvalidDataException("The certified packages-lock SHA-256 is missing or malformed.");
            string certificatePath = ProjectPath(projectRoot, CertificateRelativePath);
            EnsurePlainPath(certificatePath);
            if (!File.Exists(certificatePath)) throw new FileNotFoundException("The copy certificate is required for package resolution.", certificatePath);
            F10DiagnosticCopyCertificate certificate;
            try { certificate = JsonUtility.FromJson<F10DiagnosticCopyCertificate>(StrictUtf8.GetString(File.ReadAllBytes(certificatePath))); }
            catch (Exception exception) { throw new FormatException("The copy certificate could not be read for package-lock binding.", exception); }
            if (certificate == null || certificate.schemaVersion != 1 || certificate.files == null ||
                !string.Equals(certificate.status, "verified", StringComparison.Ordinal) || !PathEquals(certificate.copyRoot, projectRoot))
                throw new InvalidDataException("The package lock is not bound to a verified certificate for this exact copy.");

            F10DiagnosticCopyCertificateFile[] lockRows = certificate.files.Where(row => row != null &&
                string.Equals(row.path, PackageLockRelativePath, StringComparison.Ordinal)).ToArray();
            if (lockRows.Length != 1 || !string.Equals(lockRows[0].sha256, expectedSha256, StringComparison.Ordinal))
                throw new InvalidDataException("The caller's package-lock digest does not equal the certificate row; the caller value is not authority.");

            FileEvidence measured = MeasureFile(projectRoot, CanonicalPath(projectRoot), string.Empty,
                PackageLockRelativePath, ProjectPath(projectRoot, PackageLockRelativePath), "package-lock", Array.Empty<string>(), includeBytes: true);
            if (measured.LinkCount != 1 || !string.Equals(measured.Sha256, lockRows[0].sha256, StringComparison.Ordinal) ||
                !LegacyCertificateIdentityMatches(measured.Identity, lockRows[0].copyFileId))
                throw new InvalidDataException("The physical packages-lock file differs from its certified hash/identity or is hard-linked.");
            if (measured.Bytes == null) throw new InvalidDataException("The package lock bytes were not captured from the measured file handle.");
            string json = StrictUtf8.GetString(measured.Bytes);
            return new LockSnapshot(json, measured.Sha256, certificate);
        }

        private static PackageContext ResolveContext(string projectRoot, string projectFinalPath,
            string dependencyPath, PackageInfo info, LockSnapshot packageLock, ref EditorBinarySnapshot editorBinary)
        {
            if (info == null) throw new InvalidDataException("AssetDatabase returned a package path with no PackageInfo resolution: " + dependencyPath);
            bool isRegistry = info.source == PackageSource.Registry;
            bool isBuiltInUrp = info.source == PackageSource.BuiltIn &&
                string.Equals(info.name, BuiltInUniversalPackageName, StringComparison.Ordinal);
            if (!isRegistry && !isBuiltInUrp)
                throw new InvalidDataException("The observed package source/name is not representable: " + info.name + " (" + info.source + ").");
            string name = info.name;
            if (!IsPackageName(name) || string.IsNullOrWhiteSpace(info.version) ||
                (isRegistry && (string.IsNullOrWhiteSpace(info.packageId) || info.registry == null)))
                throw new InvalidDataException("PackageInfo lacks the required package identity for " + dependencyPath);
            string logicalRoot = NormalizeAssetPath(info.assetPath);
            string expectedLogicalRoot = "Packages/" + name;
            if (!string.Equals(logicalRoot, expectedLogicalRoot, StringComparison.Ordinal) ||
                !(string.Equals(dependencyPath, logicalRoot, StringComparison.Ordinal) ||
                  dependencyPath.StartsWith(logicalRoot + "/", StringComparison.Ordinal)))
                throw new InvalidDataException("PackageInfo assetPath does not exactly own the observed package dependency: " + dependencyPath);

            PackageLockEntry selected = isRegistry
                ? ParseRegistryPackageLockEntry(packageLock.Json, name)
                : ParseBuiltInUniversalPackageLockEntry(packageLock.Json, name);
            string registryUrl = info.registry == null ? string.Empty : info.registry.url ?? string.Empty;
            if (!string.Equals(info.version, selected.Version, StringComparison.Ordinal) ||
                (isRegistry && !string.Equals(registryUrl, selected.Url, StringComparison.Ordinal)))
                throw new InvalidDataException("PackageInfo name/version/source/registry do not match the exact certified lock selection: " + name);
            PackageInfo registered = PackageInfo.FindForPackageName(name);
            if (registered == null || registered.source != info.source ||
                !string.Equals(registered.name, info.name, StringComparison.Ordinal) ||
                !string.Equals(registered.version, info.version, StringComparison.Ordinal) ||
                !string.Equals(registered.packageId, info.packageId, StringComparison.Ordinal) ||
                !PathEquals(registered.resolvedPath, info.resolvedPath) ||
                !string.Equals(registered.assetPath, info.assetPath, StringComparison.Ordinal))
                throw new InvalidDataException("FindForPackageName disagrees with FindForAssetPath for " + name);

            string resolvedRoot = CanonicalPath(info.resolvedPath);
            string rootRelative;
            if (isRegistry)
            {
                rootRelative = ToProjectRelative(projectRoot, resolvedRoot);
                if (!IsAllowedResolvedRoot(rootRelative, name))
                    throw new InvalidDataException("PackageInfo.resolvedPath is outside the copy's exact PackageCache/Packages roots: " + rootRelative);
            }
            else
            {
                if (editorBinary == null)
                {
                    editorBinary = CaptureEditorBinary();
                    editorBinary.CertifiedProjectVersion = ValidateEditorAgainstCertifiedProject(projectRoot,
                        packageLock.Certificate, editorBinary);
                }
                string exactBuiltInRoot = DeriveBuiltInUniversalRoot(editorBinary.ApplicationPath);
                if (!PathEquals(resolvedRoot, exactBuiltInRoot))
                    throw new InvalidDataException("URP BuiltIn resolvedPath is not the official root under the executing Editor: " + resolvedRoot);
                rootRelative = BuiltInUniversalRootRelativePath;
            }
            EnsurePlainPath(resolvedRoot);
            string resolvedFinalPath;
            string resolvedIdentity;
            ReadDirectoryIdentity(resolvedRoot, out resolvedFinalPath, out resolvedIdentity);
            if (!PathEquals(resolvedFinalPath, resolvedRoot) ||
                (isRegistry && !IsWithin(projectFinalPath, resolvedFinalPath)))
                throw new InvalidDataException("The package resolved root does not match its authorized physical root: " + rootRelative);

            string packageJsonPath = ProjectPath(resolvedRoot, "package.json");
            FileEvidence packageJson = MeasureFile(projectRoot, resolvedRoot, rootRelative,
                "package.json", packageJsonPath, "package-json", Array.Empty<string>(), includeBytes: true,
                externalEditorRoot: isBuiltInUrp);
            PackageJsonIdentity packageIdentity = ParsePackageJsonIdentity(StrictUtf8.GetString(packageJson.Bytes));
            if (!string.Equals(packageIdentity.Name, name, StringComparison.Ordinal) ||
                !string.Equals(packageIdentity.Version, selected.Version, StringComparison.Ordinal))
                throw new InvalidDataException("The measured package.json name/version differs from PackageInfo and lock: " + name);

            if (isBuiltInUrp)
                ValidateBuiltInUrpPolicy(name, info.source.ToString(), logicalRoot, info.version, info.packageId,
                    selected.Name, selected.Source, selected.Version, packageIdentity.Name, packageIdentity.Version,
                    resolvedRoot, editorBinary.ApplicationPath);

            return new PackageContext
            {
                Name = name,
                Version = info.version,
                Source = info.source.ToString(),
                PackageId = info.packageId,
                RegistryUrl = registryUrl,
                RegistryIsDefault = info.registry != null && info.registry.isDefault,
                PackageAssetPath = logicalRoot,
                RootKind = isBuiltInUrp ? "builtin-editor" : "project",
                RootRelativePath = rootRelative,
                RootAbsolutePath = resolvedRoot,
                RootFinalPath = resolvedFinalPath,
                RootIdentity = resolvedIdentity,
                LockSource = selected.Source,
                LockVersion = selected.Version,
                LockUrl = selected.Url,
                LockHash = selected.Hash ?? string.Empty,
                LockFileSha256 = packageLock.Sha256,
                PackageJson = packageJson,
                CertifiedProjectEditorVersion = isBuiltInUrp ? editorBinary.CertifiedProjectVersion : string.Empty,
                EditorBinary = isBuiltInUrp ? editorBinary : null
            };
        }

        private static string ValidateEditorAgainstCertifiedProject(string projectRoot,
            F10DiagnosticCopyCertificate certificate, EditorBinarySnapshot editorBinary)
        {
            const string projectVersionPath = "ProjectSettings/ProjectVersion.txt";
            F10DiagnosticCopyCertificateFile[] rows = certificate.files.Where(row => row != null &&
                string.Equals(row.path, projectVersionPath, StringComparison.Ordinal)).ToArray();
            if (rows.Length != 1 || !IsSha256(rows[0].sha256) || string.IsNullOrWhiteSpace(rows[0].copyFileId))
                throw new InvalidDataException("The certified copy does not contain one valid ProjectVersion.txt identity row.");
            FileEvidence measured = MeasureFile(projectRoot, CanonicalPath(projectRoot), string.Empty,
                projectVersionPath, ProjectPath(projectRoot, projectVersionPath), "project-version", Array.Empty<string>(),
                includeBytes: true);
            if (measured.LinkCount != 1 || !string.Equals(measured.Sha256, rows[0].sha256, StringComparison.Ordinal) ||
                !LegacyCertificateIdentityMatches(measured.Identity, rows[0].copyFileId))
                throw new InvalidDataException("ProjectVersion.txt differs from its certified copy hash/identity or is hard-linked.");
            string certifiedVersion = ParseProjectEditorVersion(StrictUtf8.GetString(measured.Bytes));
            if (!string.Equals(certifiedVersion, editorBinary.Version, StringComparison.Ordinal))
                throw new InvalidDataException("The executing Editor version differs from the certified copy's ProjectVersion.txt.");
            return certifiedVersion;
        }

        internal static string ParseProjectEditorVersion(string text)
        {
            const string prefix = "m_EditorVersion: ";
            string[] matches = (text ?? string.Empty).Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(line => line.StartsWith(prefix, StringComparison.Ordinal)).ToArray();
            if (matches.Length != 1) throw new InvalidDataException("ProjectVersion.txt must declare exactly one m_EditorVersion.");
            string version = matches[0].Substring(prefix.Length).Trim();
            if (string.IsNullOrWhiteSpace(version) || version.Any(char.IsWhiteSpace))
                throw new InvalidDataException("ProjectVersion.txt contains an invalid Editor version.");
            return version;
        }

        internal static string DeriveBuiltInUniversalRoot(string editorApplicationPath)
        {
            if (string.IsNullOrWhiteSpace(editorApplicationPath) || !Path.IsPathRooted(editorApplicationPath) ||
                !string.Equals(Path.GetFileName(editorApplicationPath), "Unity.exe", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("The running Editor applicationPath must identify its Unity.exe executable.");
            string editorDirectory = Path.GetDirectoryName(CanonicalPath(editorApplicationPath));
            return CanonicalPath(Path.Combine(editorDirectory, "Data", "Resources", "PackageManager", "BuiltInPackages",
                BuiltInUniversalPackageName));
        }

        internal static void ValidateBuiltInUrpPolicy(string packageName, string packageSource, string packageAssetPath,
            string packageInfoVersion, string packageId, string lockName, string lockSource, string lockVersion,
            string packageJsonName, string packageJsonVersion, string packageResolvedPath, string editorApplicationPath)
        {
            string expectedRoot = DeriveBuiltInUniversalRoot(editorApplicationPath);
            if (!string.Equals(packageName, BuiltInUniversalPackageName, StringComparison.Ordinal) ||
                !string.Equals(packageSource, "BuiltIn", StringComparison.Ordinal) ||
                !string.Equals(packageAssetPath, "Packages/" + BuiltInUniversalPackageName, StringComparison.Ordinal) ||
                !string.Equals(lockName, BuiltInUniversalPackageName, StringComparison.Ordinal) ||
                !string.Equals(lockSource, "builtin", StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(packageInfoVersion) || string.IsNullOrWhiteSpace(packageId) ||
                !string.Equals(packageInfoVersion, lockVersion, StringComparison.Ordinal) ||
                !string.Equals(packageInfoVersion, packageJsonVersion, StringComparison.Ordinal) ||
                !string.Equals(packageName, packageJsonName, StringComparison.Ordinal) ||
                !PathEquals(packageResolvedPath, expectedRoot))
                throw new InvalidDataException("The URP BuiltIn identity, certified lock tuple, measured package.json, or official Editor root disagree.");
        }

        private static EditorBinarySnapshot CaptureEditorBinary()
        {
            string applicationPath = CanonicalPath(EditorApplication.applicationPath);
            string version = Application.unityVersion;
            if (string.IsNullOrWhiteSpace(version))
                throw new InvalidDataException("The executing Unity Editor did not report a version.");
            return MeasureEditorBinary(applicationPath, version);
        }

        private static EditorBinarySnapshot MeasureEditorBinary(string applicationPath, string version)
        {
            EnsureWindows();
            string path = CanonicalPath(applicationPath);
            if (!string.Equals(Path.GetFileName(path), "Unity.exe", StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrWhiteSpace(version))
                throw new InvalidDataException("The measured Editor identity requires the real Unity.exe path and version.");
            EnsurePlainPath(path);
            using (SafeFileHandle handle = CreateFile(path, GenericRead, ShareRead, IntPtr.Zero,
                OpenExisting, FileFlagOpenReparsePoint | FileFlagSequentialScan, IntPtr.Zero))
            {
                if (handle.IsInvalid) throw Win32IOException("Could not open the running Unity Editor executable", path);
                if (!GetFileInformationByHandle(handle, out ByHandleFileInformation basic))
                    throw Win32IOException("Could not inspect the running Unity Editor executable", path);
                if ((basic.FileAttributes & AttributeReparsePoint) != 0 ||
                    (basic.FileAttributes & AttributeDirectory) != 0 || basic.LinkCount != 1)
                    throw new InvalidDataException("The running Editor executable must be a plain file with no hard links: " + path);
                string identity = ReadFileIdInfo(handle, path);
                string finalPath = GetFinalPath(handle, path);
                if (!PathEquals(finalPath, path))
                    throw new InvalidDataException("The running Editor executable handle resolved to another path: " + finalPath);
                long length = ((long)basic.FileSizeHigh << 32) | basic.FileSizeLow;
                string sha256;
                using (var stream = new FileStream(handle, FileAccess.Read, 1024 * 1024, false))
                {
                    if (stream.Length != length || length <= 0)
                        throw new IOException("The running Editor executable length changed during identity measurement: " + path);
                    using (SHA256 sha = SHA256.Create()) sha256 = ToHex(sha.ComputeHash(stream));
                }
                return new EditorBinarySnapshot(path, version, finalPath, sha256, length, identity, basic.LinkCount);
            }
        }

        private static void ValidateRecordedSourceIdentity(F10DiagnosticPackageDependencyEvidence row)
        {
            if (string.Equals(row.packageSource, "BuiltIn", StringComparison.Ordinal))
            {
                ValidateBuiltInUrpPolicy(row.packageName, row.packageSource, row.packageAssetPath, row.packageVersion,
                    row.packageId, row.packageName, row.lockEntrySource, row.lockEntryVersion,
                    row.packageName, row.packageVersion, row.resolvedRootAbsolutePath, row.editorApplicationPath);
                if (row.resolvedRootKind != "builtin-editor" ||
                    row.resolvedRootRelativePath != BuiltInUniversalRootRelativePath ||
                    !string.Equals(row.certifiedProjectEditorVersion, row.editorVersion, StringComparison.Ordinal) ||
                    !IsSha256(row.editorExecutableSha256) || row.editorExecutableLength <= 0 ||
                    row.editorExecutableLinkCount != 1 || string.IsNullOrWhiteSpace(row.editorVersion) ||
                    string.IsNullOrWhiteSpace(row.editorExecutableIdentity) ||
                    !PathEquals(row.editorApplicationPath, row.editorExecutableFinalPath) ||
                    row.editorVersion.Any(char.IsWhiteSpace))
                    throw new InvalidDataException("The recorded URP BuiltIn Editor identity is incomplete or malformed.");
                ValidateFileIdentity(row.resolvedRootIdentity);
                ValidateFileIdentity(row.editorExecutableIdentity);
                foreach (F10DiagnosticPackageDependencyFile file in row.files)
                {
                    if (file == null || !IsSha256(file.sha256) || file.length < 0 || file.linkCount != 1)
                        throw new InvalidDataException("A recorded URP dependency file lacks physical identity evidence.");
                    ValidateFileIdentity(file.identity);
                }
            }
            else if (string.Equals(row.packageSource, "Registry", StringComparison.Ordinal))
            {
                if (row.resolvedRootKind != "project" || !string.IsNullOrEmpty(row.resolvedRootAbsolutePath) ||
                    !string.IsNullOrEmpty(row.editorApplicationPath) || !string.IsNullOrEmpty(row.editorExecutableSha256) ||
                    !string.IsNullOrEmpty(row.certifiedProjectEditorVersion) || !string.IsNullOrEmpty(row.editorVersion) ||
                    !string.IsNullOrEmpty(row.editorExecutableFinalPath) || !string.IsNullOrEmpty(row.editorExecutableIdentity) ||
                    row.editorExecutableLength != 0 ||
                    row.editorExecutableLinkCount != 0)
                    throw new InvalidDataException("A Registry package receipt contains unexpected external Editor identity fields.");
            }
            else throw new InvalidDataException("The recorded package source is outside the receipt policy: " + row.packageSource);
        }

        private static void ValidateFileIdentity(string identity)
        {
            string[] parts = (identity ?? string.Empty).Split(':');
            if (parts.Length != 2 || parts[0].Length != 16 || parts[1].Length != 32 ||
                !parts.All(part => part.All(Uri.IsHexDigit)))
                throw new InvalidDataException("A recorded FileIdInfo identity is malformed.");
        }

        private static PackageJsonIdentity ParsePackageJsonIdentity(string json)
        {
            var reader = new LockJsonReader(json);
            string name = null;
            string version = null;
            var keys = new HashSet<string>(StringComparer.Ordinal);
            reader.Expect('{');
            while (!reader.TryConsume('}'))
            {
                string key = reader.ReadString();
                if (!keys.Add(key)) throw new FormatException("package.json contains a duplicate key: " + key);
                reader.Expect(':');
                if (key == "name") name = reader.ReadString();
                else if (key == "version") version = reader.ReadString();
                else reader.SkipValue(0);
                if (reader.TryConsume(',')) continue;
                reader.Expect('}');
                break;
            }
            reader.RequireEnd();
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(version))
                throw new InvalidDataException("The package manifest does not declare required name and version strings.");
            return new PackageJsonIdentity { Name = name, Version = version };
        }

        private static void AddPackageManifestFiles(string projectRoot, string projectFinalPath, PackageBuild group)
        {
            AddMeasuredFile(projectRoot, projectFinalPath, group, "package.json", "package-json", null, includeBytes: false);
            AddMeasuredFile(projectRoot, projectFinalPath, group, "package.json.meta", "package-json-meta", null, includeBytes: true);
            FileEvidence current = group.Files[ProjectPathFromRoot(group.Context.RootRelativePath, "package.json")];
            if (current.Sha256 != group.Context.PackageJson.Sha256 || current.Identity != group.Context.PackageJson.Identity ||
                current.LinkCount != group.Context.PackageJson.LinkCount || current.Length != group.Context.PackageJson.Length)
                throw new InvalidDataException("package.json changed between PackageInfo resolution and closure capture: " + group.Context.Name);
        }

        private static void AddDependencyFiles(string projectRoot, string projectFinalPath, PackageBuild group, string assetPath)
        {
            if (string.Equals(assetPath, group.Context.PackageAssetPath, StringComparison.Ordinal) ||
                assetPath.EndsWith(".meta", StringComparison.Ordinal))
                throw new InvalidDataException("A package closure returned a directory root or .meta path that cannot be represented as an imported file: " + assetPath);
            string relative = assetPath.Substring(group.Context.PackageAssetPath.Length + 1);
            relative = NormalizeRelativePath(relative);
            AddMeasuredFile(projectRoot, projectFinalPath, group, relative, "dependency", assetPath, includeBytes: false);
            AddMeasuredFile(projectRoot, projectFinalPath, group, relative + ".meta", "dependency-meta", assetPath, includeBytes: true);

            string guid = ReadMetaGuid(group.Files[ProjectPathFromRoot(group.Context.RootRelativePath, relative + ".meta")].Bytes, assetPath + ".meta");
            string assetGuid = AssetDatabase.AssetPathToGUID(assetPath);
            if (string.IsNullOrEmpty(assetGuid) || !string.Equals(assetGuid, guid, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(AssetDatabase.GUIDToAssetPath(guid), assetPath, StringComparison.Ordinal))
                throw new InvalidDataException("The package asset's measured meta GUID does not resolve to its exact AssetDatabase path: " + assetPath);
        }

        private static void AddMeasuredFile(string projectRoot, string projectFinalPath, PackageBuild group,
            string relativePath, string role, string assetPath, bool includeBytes)
        {
            bool externalEditorRoot = string.Equals(group.Context.RootKind, "builtin-editor", StringComparison.Ordinal);
            string relative = NormalizeRelativePath(relativePath);
            string projectRelative = ProjectPathFromRoot(group.Context.RootRelativePath, relative);
            if (!group.Files.TryGetValue(projectRelative, out FileEvidence file))
            {
                string absolute = ProjectPath(group.Context.RootAbsolutePath, relative);
                file = MeasureFile(projectRoot, group.Context.RootAbsolutePath, group.Context.RootRelativePath,
                    relative, absolute, role, assetPath == null ? Array.Empty<string>() : new[] { assetPath }, includeBytes,
                    externalEditorRoot: externalEditorRoot);
                if (!IsWithin(group.Context.RootFinalPath, file.FinalPath) ||
                    (!externalEditorRoot && !IsWithin(projectFinalPath, file.FinalPath)))
                    throw new InvalidDataException("A measured package file escaped its resolved root or disposable copy: " + projectRelative);
                group.Files.Add(projectRelative, file);
            }
            else if (includeBytes && file.Bytes == null)
            {
                FileEvidence reread = MeasureFile(projectRoot, group.Context.RootAbsolutePath, group.Context.RootRelativePath,
                    relative, file.AbsolutePath, role, assetPath == null ? Array.Empty<string>() : new[] { assetPath }, includeBytes: true,
                    externalEditorRoot: externalEditorRoot);
                if (!string.Equals(reread.Sha256, file.Sha256, StringComparison.Ordinal) || reread.Length != file.Length ||
                    !string.Equals(reread.Identity, file.Identity, StringComparison.Ordinal) || reread.LinkCount != file.LinkCount ||
                    !string.Equals(reread.FinalPath, file.FinalPath, WindowsPathComparison))
                    throw new IOException("Package metadata changed while its physical evidence was being assembled: " + projectRelative);
                file.Bytes = reread.Bytes;
            }
            file.AddRole(role);
            if (assetPath != null) file.AddAssetPath(assetPath);
        }

        private static void ValidateUniqueMetaGuids(PackageBuild group)
        {
            var guids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (FileEvidence file in group.Files.Values)
            {
                if (!file.Roles.Contains("dependency-meta", StringComparer.Ordinal) &&
                    !file.Roles.Contains("package-json-meta", StringComparer.Ordinal)) continue;
                string guid = ReadMetaGuid(file.Bytes, file.ProjectRelativePath);
                if (!guids.Add(guid)) throw new InvalidDataException("Package dependency metadata contains a duplicate GUID: " + guid);
            }
        }

        private static string ReadMetaGuid(byte[] bytes, string path)
        {
            if (bytes == null || bytes.Length > MaximumMetadataBytes)
                throw new InvalidDataException("A required package .meta file is missing or exceeds the metadata size limit: " + path);
            string text = StrictUtf8.GetString(bytes);
            string[] matches = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(line => line.StartsWith("guid:", StringComparison.Ordinal)).ToArray();
            if (matches.Length != 1) throw new InvalidDataException("A required package .meta must contain exactly one top-level GUID: " + path);
            string guid = matches[0].Substring("guid:".Length).Trim();
            if (guid.Length != 32 || !guid.All(Uri.IsHexDigit)) throw new InvalidDataException("A package .meta GUID is malformed: " + path);
            return guid;
        }

        private static FileEvidence MeasureFile(string projectRoot, string resolvedRoot, string rootRelative,
            string relativePath, string absolutePath, string role, IEnumerable<string> assetPaths, bool includeBytes,
            bool externalEditorRoot = false)
        {
            string relative = NormalizeRelativePath(relativePath);
            string expectedAbsolute = CanonicalPath(absolutePath);
            EnsurePlainPath(expectedAbsolute);
            using (SafeFileHandle handle = CreateFile(expectedAbsolute, GenericRead, ShareRead, IntPtr.Zero,
                OpenExisting, FileFlagOpenReparsePoint | FileFlagSequentialScan, IntPtr.Zero))
            {
                if (handle.IsInvalid) throw Win32IOException("Could not open package dependency file", expectedAbsolute);
                if (!GetFileInformationByHandle(handle, out ByHandleFileInformation basic))
                    throw Win32IOException("Could not inspect package dependency file", expectedAbsolute);
                if ((basic.FileAttributes & AttributeReparsePoint) != 0 || (basic.FileAttributes & AttributeDirectory) != 0)
                    throw new InvalidDataException("Package evidence rejects reparse points and non-file dependencies: " + expectedAbsolute);
                string identity = ReadFileIdInfo(handle, expectedAbsolute);
                string finalPath = GetFinalPath(handle, expectedAbsolute);
                if (basic.LinkCount != 1) throw new InvalidDataException("Package dependency file has a hard link: " + expectedAbsolute);
                long length = ((long)basic.FileSizeHigh << 32) | basic.FileSizeLow;
                byte[] bytes = null;
                string hash;
                using (var stream = new FileStream(handle, FileAccess.Read, 64 * 1024, false))
                {
                    if (stream.Length != length) throw new IOException("The package file length changed during handle inspection: " + expectedAbsolute);
                    if (includeBytes)
                    {
                        if (length > MaximumMetadataBytes) throw new InvalidDataException("Package metadata exceeds the size limit: " + expectedAbsolute);
                        bytes = ReadExact(stream, checked((int)length));
                        hash = HashBytes(bytes);
                    }
                    else
                    {
                        using (SHA256 sha = SHA256.Create()) hash = ToHex(sha.ComputeHash(stream));
                    }
                }
                string expectedRelative = string.IsNullOrEmpty(rootRelative)
                    ? relative
                    : ProjectPathFromRoot(rootRelative, relative);
                string projectRelative = externalEditorRoot
                    ? expectedRelative
                    : ToProjectRelative(projectRoot, expectedAbsolute);
                if (!string.Equals(projectRelative, expectedRelative, StringComparison.Ordinal))
                    throw new InvalidDataException("The resolved package file does not match its exact project-relative path: " + projectRelative);
                if (!IsWithin(GetFinalPathForDirectory(resolvedRoot), finalPath))
                    throw new InvalidDataException("The package file final handle path escapes the measured resolved root: " + expectedAbsolute);
                return new FileEvidence(relative, projectRelative, role, assetPaths, hash, length, identity,
                    basic.LinkCount, expectedAbsolute, finalPath, bytes);
            }
        }

        private static byte[] ReadExact(Stream stream, int length)
        {
            byte[] bytes = new byte[length];
            int offset = 0;
            while (offset < bytes.Length)
            {
                int read = stream.Read(bytes, offset, bytes.Length - offset);
                if (read <= 0) throw new EndOfStreamException("A package evidence file ended before its measured length.");
                offset += read;
            }
            if (stream.ReadByte() != -1) throw new IOException("A package evidence file grew while being measured.");
            return bytes;
        }

        private static void ReadDirectoryIdentity(string path, out string finalPath, out string identity)
        {
            string full = CanonicalPath(path);
            EnsurePlainPath(full);
            using (SafeFileHandle handle = CreateFile(full, FileReadAttributes, ShareRead, IntPtr.Zero,
                OpenExisting, FileFlagOpenReparsePoint | FileFlagBackupSemantics, IntPtr.Zero))
            {
                if (handle.IsInvalid) throw Win32IOException("Could not open package directory", full);
                if (!GetFileInformationByHandle(handle, out ByHandleFileInformation basic))
                    throw Win32IOException("Could not inspect package directory", full);
                if ((basic.FileAttributes & AttributeReparsePoint) != 0 || (basic.FileAttributes & AttributeDirectory) == 0)
                    throw new InvalidDataException("Package roots and project ancestors must be plain directories: " + full);
                identity = ReadFileIdInfo(handle, full);
                finalPath = GetFinalPath(handle, full);
            }
        }

        private static string GetFinalPathForDirectory(string path)
        {
            ReadDirectoryIdentity(path, out string finalPath, out _);
            return finalPath;
        }

        private static string ReadFileIdInfo(SafeFileHandle handle, string path)
        {
            if (!BitConverter.IsLittleEndian) throw new PlatformNotSupportedException("FileIdInfo normalization requires little-endian Windows.");
            IntPtr buffer = Marshal.AllocHGlobal(24);
            try
            {
                if (!GetFileInformationByHandleEx(handle, FileIdInfoClass, buffer, 24))
                    throw Win32IOException("GetFileInformationByHandleEx(FileIdInfo) is unavailable", path);
                ulong volume = unchecked((ulong)Marshal.ReadInt64(buffer, 0));
                byte[] id = new byte[16];
                Marshal.Copy(IntPtr.Add(buffer, 8), id, 0, id.Length);
                return volume.ToString("x16", CultureInfo.InvariantCulture) + ":" + string.Concat(id.Select(value => value.ToString("x2", CultureInfo.InvariantCulture)));
            }
            finally { Marshal.FreeHGlobal(buffer); }
        }

        private static string GetFinalPath(SafeFileHandle handle, string originalPath)
        {
            var builder = new StringBuilder(512);
            uint size = GetFinalPathNameByHandle(handle, builder, (uint)builder.Capacity, 0);
            if (size == 0) throw Win32IOException("Could not resolve final path for package evidence handle", originalPath);
            if (size >= builder.Capacity)
            {
                builder = new StringBuilder(checked((int)size + 1));
                size = GetFinalPathNameByHandle(handle, builder, (uint)builder.Capacity, 0);
                if (size == 0 || size >= builder.Capacity)
                    throw Win32IOException("Could not resolve full final path for package evidence handle", originalPath);
            }
            string value = builder.ToString();
            if (value.StartsWith("\\\\?\\UNC\\", StringComparison.OrdinalIgnoreCase)) value = "\\\\" + value.Substring(8);
            else if (value.StartsWith("\\\\?\\", StringComparison.Ordinal)) value = value.Substring(4);
            return CanonicalPath(value);
        }

        private static void EnsurePlainPath(string path)
        {
            string full = Path.GetFullPath(path);
            string volume = Path.GetPathRoot(full);
            if (string.IsNullOrEmpty(volume)) throw new InvalidDataException("A fully qualified Windows path is required: " + path);
            string current = volume;
            RejectReparseIfPresent(current);
            foreach (string segment in full.Substring(volume.Length).Split(new[] { '\\', '/' }, StringSplitOptions.RemoveEmptyEntries))
            {
                current = Path.Combine(current, segment);
                if (!File.Exists(current) && !Directory.Exists(current))
                    throw new FileNotFoundException("A package evidence path segment is missing.", current);
                RejectReparseIfPresent(current);
            }
        }

        private static void RejectReparseIfPresent(string path)
        {
            if (!File.Exists(path) && !Directory.Exists(path)) throw new FileNotFoundException("A path segment is missing.", path);
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Package evidence rejects reparse points in every ancestor: " + path);
        }

        private static string[] NormalizeDistinctAssetPaths(IEnumerable<string> paths)
        {
            if (paths == null) throw new ArgumentNullException(nameof(paths));
            var unique = new SortedSet<string>(StringComparer.Ordinal);
            foreach (string raw in paths)
            {
                string path = NormalizeAssetPath(raw);
                if (!path.StartsWith("Packages/", StringComparison.Ordinal))
                    throw new InvalidDataException("The package evidence API accepts only live Packages/ closure paths: " + path);
                unique.Add(path);
            }
            return unique.ToArray();
        }

        private static string NormalizeAssetPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || path.IndexOf('\\') >= 0 || Path.IsPathRooted(path) || path.IndexOf(':') >= 0 ||
                path.Split('/').Any(segment => segment.Length == 0 || segment == "." || segment == ".."))
                throw new InvalidDataException("AssetDatabase returned an unsafe package dependency path: " + (path ?? "<null>"));
            return path;
        }

        private static string NormalizeRelativePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || path.IndexOf('\\') >= 0 || Path.IsPathRooted(path) || path.IndexOf(':') >= 0 ||
                path.Split('/').Any(segment => segment.Length == 0 || segment == "." || segment == ".."))
                throw new InvalidDataException("Unsafe package-relative path: " + (path ?? "<null>"));
            return path;
        }

        private static bool IsPackageName(string name)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Contains("/") || name.Contains("\\") || name.Contains("@")) return false;
            string[] parts = name.Split('.');
            return parts.Length >= 2 && parts.All(part => part.Length > 0 && part.All(character =>
                char.IsLetterOrDigit(character) || character == '-' || character == '_'));
        }

        private static bool IsAllowedResolvedRoot(string path, string packageName)
        {
            string[] parts = path.Split('/');
            return parts.Length == 3 && parts[0] == "Library" && parts[1] == "PackageCache" && parts[2].Length > 0 ||
                string.Equals(path, "Packages/" + packageName, StringComparison.Ordinal);
        }

        private static bool LegacyCertificateIdentityMatches(string fileIdInfoIdentity, string certificateIdentity)
        {
            if (string.IsNullOrWhiteSpace(certificateIdentity)) return false;
            string[] parts = certificateIdentity.Split(':');
            if (parts.Length != 2 || !ulong.TryParse(parts[0], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong volume) ||
                !ulong.TryParse(parts[1], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong fileId)) return false;
            string[] measured = fileIdInfoIdentity.Split(':');
            if (measured.Length != 2 || !ulong.TryParse(measured[0], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong measuredVolume)) return false;
            byte[] id = Enumerable.Range(0, 16).Select(index => byte.Parse(measured[1].Substring(index * 2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture)).ToArray();
            if (id.Skip(8).Any(value => value != 0)) return false;
            return volume == measuredVolume && BitConverter.ToUInt64(id, 0) == fileId;
        }

        private static bool IsSha256(string value) => value != null && value.Length == 64 && value.All(character =>
            character >= '0' && character <= '9' || character >= 'a' && character <= 'f');

        private static string HashBytes(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create()) return ToHex(sha.ComputeHash(bytes));
        }

        private static string ToHex(byte[] bytes) => string.Concat(bytes.Select(value => value.ToString("x2", CultureInfo.InvariantCulture)));

        private static string ToProjectRelative(string root, string path)
        {
            string prefix = CanonicalPath(root) + Path.DirectorySeparatorChar;
            string full = CanonicalPath(path);
            if (!full.StartsWith(prefix, WindowsPathComparison))
                throw new InvalidDataException("Package path escaped the certified project root: " + path);
            return full.Substring(prefix.Length).Replace('\\', '/');
        }

        private static string ProjectPath(string root, string relative)
        {
            string normalized = NormalizeRelativePath(relative);
            return Path.GetFullPath(Path.Combine(root, normalized.Replace('/', Path.DirectorySeparatorChar)));
        }

        private static string ProjectPathFromRoot(string rootRelative, string packageRelative)
        {
            return NormalizeRelativePath(rootRelative + "/" + NormalizeRelativePath(packageRelative));
        }

        private static bool IsWithin(string root, string path)
        {
            string prefix = CanonicalPath(root) + Path.DirectorySeparatorChar;
            string full = CanonicalPath(path);
            return full.StartsWith(prefix, WindowsPathComparison);
        }

        private static bool PathEquals(string left, string right)
        {
            return string.Equals(CanonicalPath(left), CanonicalPath(right), WindowsPathComparison);
        }

        private static string CanonicalPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("A path is required.", nameof(path));
            string full = Path.GetFullPath(path);
            string root = Path.GetPathRoot(full) ?? string.Empty;
            while (full.Length > root.Length && (full.EndsWith(Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal) ||
                full.EndsWith(Path.AltDirectorySeparatorChar.ToString(), StringComparison.Ordinal)))
                full = full.Substring(0, full.Length - 1);
            return full;
        }

        private static string PackageKey(string name, string root)
        {
            if (!IsPackageName(name)) throw new InvalidDataException("A recorded package name is invalid.");
            return name + "\0" + NormalizeRelativePath(root);
        }

        private static bool Equal(F10DiagnosticPackageDependencyEvidence left, F10DiagnosticPackageDependencyEvidence right)
        {
            if (left.schemaVersion != right.schemaVersion || left.packageName != right.packageName ||
                left.packageVersion != right.packageVersion || left.packageSource != right.packageSource || left.packageId != right.packageId ||
                left.registryUrl != right.registryUrl || left.registryIsDefault != right.registryIsDefault || left.packageAssetPath != right.packageAssetPath ||
                left.resolvedRootKind != right.resolvedRootKind || left.resolvedRootRelativePath != right.resolvedRootRelativePath ||
                left.resolvedRootAbsolutePath != right.resolvedRootAbsolutePath || left.resolvedRootIdentity != right.resolvedRootIdentity ||
                left.lockEntrySource != right.lockEntrySource || left.lockEntryVersion != right.lockEntryVersion ||
                left.lockEntryUrl != right.lockEntryUrl || left.lockEntryHash != right.lockEntryHash || left.lockFileSha256 != right.lockFileSha256 ||
                left.certifiedProjectEditorVersion != right.certifiedProjectEditorVersion || left.editorVersion != right.editorVersion ||
                left.editorApplicationPath != right.editorApplicationPath || left.editorExecutableFinalPath != right.editorExecutableFinalPath ||
                left.editorExecutableSha256 != right.editorExecutableSha256 || left.editorExecutableLength != right.editorExecutableLength ||
                left.editorExecutableIdentity != right.editorExecutableIdentity || left.editorExecutableLinkCount != right.editorExecutableLinkCount)
                return false;
            if (!left.dependencyAssetPaths.SequenceEqual(right.dependencyAssetPaths, StringComparer.Ordinal) || left.files.Length != right.files.Length)
                return false;
            for (int index = 0; index < left.files.Length; index++)
            {
                F10DiagnosticPackageDependencyFile a = left.files[index];
                F10DiagnosticPackageDependencyFile b = right.files[index];
                if (a == null || b == null || a.relativePath != b.relativePath || a.projectRelativePath != b.projectRelativePath ||
                    a.sha256 != b.sha256 || a.length != b.length || a.identity != b.identity || a.linkCount != b.linkCount ||
                    a.roles == null || b.roles == null || a.assetPaths == null || b.assetPaths == null ||
                    !a.roles.SequenceEqual(b.roles, StringComparer.Ordinal) || !a.assetPaths.SequenceEqual(b.assetPaths, StringComparer.Ordinal))
                    return false;
            }
            return true;
        }

        private static void EnsureWindows()
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || Path.DirectorySeparatorChar != '\\')
                throw new PlatformNotSupportedException("F10 package identity evidence is implemented only for Windows and fails closed elsewhere.");
        }

        private static IOException Win32IOException(string message, string path)
        {
            int error = Marshal.GetLastWin32Error();
            return new IOException(message + ": " + path + " (Win32 " + error.ToString(CultureInfo.InvariantCulture) + ").",
                Marshal.GetExceptionForHR(Marshal.GetHRForLastWin32Error()));
        }

        private static void AddRole(this FileEvidence file, string role)
        {
            if (!file.Roles.Contains(role, StringComparer.Ordinal)) file.Roles.Add(role);
            file.Roles.Sort(StringComparer.Ordinal);
        }

        private static void AddAssetPath(this FileEvidence file, string assetPath)
        {
            if (!file.AssetPaths.Contains(assetPath, StringComparer.Ordinal)) file.AssetPaths.Add(assetPath);
            file.AssetPaths.Sort(StringComparer.Ordinal);
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFile(string name, uint desiredAccess, uint shareMode,
            IntPtr securityAttributes, uint creationDisposition, uint flagsAndAttributes, IntPtr templateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out ByHandleFileInformation information);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandleEx(SafeFileHandle handle, int informationClass, IntPtr information, uint size);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern uint GetFinalPathNameByHandle(SafeFileHandle handle, StringBuilder path, uint length, uint flags);

        [StructLayout(LayoutKind.Sequential)]
        private struct ByHandleFileInformation
        {
            internal uint FileAttributes;
            internal System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            internal uint VolumeSerialNumber;
            internal uint FileSizeHigh;
            internal uint FileSizeLow;
            internal uint LinkCount;
            internal uint FileIndexHigh;
            internal uint FileIndexLow;
        }

        private sealed class PackageBuild
        {
            internal PackageBuild(PackageContext context) { Context = context; DependencyPaths = new SortedSet<string>(StringComparer.Ordinal); Files = new SortedDictionary<string, FileEvidence>(StringComparer.Ordinal); }
            internal PackageContext Context { get; }
            internal SortedSet<string> DependencyPaths { get; }
            internal SortedDictionary<string, FileEvidence> Files { get; }

            internal F10DiagnosticPackageDependencyEvidence ToEvidence()
            {
                return new F10DiagnosticPackageDependencyEvidence
                {
                    schemaVersion = 2,
                    packageName = Context.Name,
                    packageVersion = Context.Version,
                    packageSource = Context.Source,
                    packageId = Context.PackageId,
                    registryUrl = Context.RegistryUrl,
                    registryIsDefault = Context.RegistryIsDefault,
                    packageAssetPath = Context.PackageAssetPath,
                    resolvedRootKind = Context.RootKind,
                    resolvedRootRelativePath = Context.RootRelativePath,
                    resolvedRootAbsolutePath = Context.EditorBinary == null ? string.Empty : Context.RootAbsolutePath,
                    resolvedRootIdentity = Context.RootIdentity,
                    lockEntrySource = Context.LockSource,
                    lockEntryVersion = Context.LockVersion,
                    lockEntryUrl = Context.LockUrl,
                    lockEntryHash = Context.LockHash,
                    lockFileSha256 = Context.LockFileSha256,
                    certifiedProjectEditorVersion = Context.CertifiedProjectEditorVersion,
                    editorVersion = Context.EditorBinary == null ? string.Empty : Context.EditorBinary.Version,
                    editorApplicationPath = Context.EditorBinary == null ? string.Empty : Context.EditorBinary.ApplicationPath,
                    editorExecutableFinalPath = Context.EditorBinary == null ? string.Empty : Context.EditorBinary.FinalPath,
                    editorExecutableSha256 = Context.EditorBinary == null ? string.Empty : Context.EditorBinary.Sha256,
                    editorExecutableLength = Context.EditorBinary == null ? 0 : Context.EditorBinary.Length,
                    editorExecutableIdentity = Context.EditorBinary == null ? string.Empty : Context.EditorBinary.Identity,
                    editorExecutableLinkCount = Context.EditorBinary == null ? 0 : Context.EditorBinary.LinkCount,
                    dependencyAssetPaths = DependencyPaths.ToArray(),
                    files = Files.Values.Select(file => file.ToFileEvidence()).ToArray()
                };
            }
        }

        private sealed class PackageContext
        {
            internal string Name, Version, Source, PackageId, RegistryUrl, PackageAssetPath;
            internal bool RegistryIsDefault;
            internal string RootKind, RootRelativePath, RootAbsolutePath, RootFinalPath, RootIdentity;
            internal string LockSource, LockVersion, LockUrl, LockHash, LockFileSha256;
            internal string CertifiedProjectEditorVersion;
            internal EditorBinarySnapshot EditorBinary;
            internal FileEvidence PackageJson;

            internal bool SamePackage(PackageContext other) => Name == other.Name && Version == other.Version && Source == other.Source &&
                PackageId == other.PackageId && RegistryUrl == other.RegistryUrl && RegistryIsDefault == other.RegistryIsDefault &&
                PackageAssetPath == other.PackageAssetPath && RootKind == other.RootKind && RootRelativePath == other.RootRelativePath &&
                RootAbsolutePath == other.RootAbsolutePath && RootIdentity == other.RootIdentity &&
                LockSource == other.LockSource && LockVersion == other.LockVersion && LockUrl == other.LockUrl && LockHash == other.LockHash &&
                LockFileSha256 == other.LockFileSha256 && CertifiedProjectEditorVersion == other.CertifiedProjectEditorVersion &&
                ((EditorBinary == null && other.EditorBinary == null) || (EditorBinary != null && other.EditorBinary != null && EditorBinary.Same(other.EditorBinary)));
        }

        private sealed class EditorBinarySnapshot
        {
            internal EditorBinarySnapshot(string applicationPath, string version, string finalPath, string sha256,
                long length, string identity, uint linkCount)
            {
                ApplicationPath = applicationPath;
                Version = version;
                FinalPath = finalPath;
                Sha256 = sha256;
                Length = length;
                Identity = identity;
                LinkCount = linkCount;
            }
            internal string ApplicationPath { get; }
            internal string Version { get; }
            internal string FinalPath { get; }
            internal string Sha256 { get; }
            internal long Length { get; }
            internal string Identity { get; }
            internal uint LinkCount { get; }
            internal string CertifiedProjectVersion { get; set; }
            internal bool Same(EditorBinarySnapshot other) => ApplicationPath == other.ApplicationPath && Version == other.Version &&
                FinalPath == other.FinalPath && Sha256 == other.Sha256 && Length == other.Length && Identity == other.Identity &&
                LinkCount == other.LinkCount && CertifiedProjectVersion == other.CertifiedProjectVersion;
        }

        private sealed class FileEvidence
        {
            internal FileEvidence(string relativePath, string projectRelativePath, string role, IEnumerable<string> assetPaths,
                string sha256, long length, string identity, uint linkCount, string absolutePath, string finalPath, byte[] bytes)
            {
                RelativePath = relativePath; ProjectRelativePath = projectRelativePath; Roles = new List<string> { role };
                AssetPaths = assetPaths == null ? new List<string>() : assetPaths.Distinct(StringComparer.Ordinal).OrderBy(value => value, StringComparer.Ordinal).ToList();
                Sha256 = sha256; Length = length; Identity = identity; LinkCount = linkCount; AbsolutePath = absolutePath; FinalPath = finalPath; Bytes = bytes;
            }
            internal string RelativePath { get; }
            internal string ProjectRelativePath { get; }
            internal List<string> Roles { get; }
            internal List<string> AssetPaths { get; }
            internal string Sha256 { get; }
            internal long Length { get; }
            internal string Identity { get; }
            internal uint LinkCount { get; }
            internal string AbsolutePath { get; }
            internal string FinalPath { get; }
            internal byte[] Bytes { get; set; }
            internal F10DiagnosticPackageDependencyFile ToFileEvidence() => new F10DiagnosticPackageDependencyFile
            {
                relativePath = RelativePath,
                projectRelativePath = ProjectRelativePath,
                roles = Roles.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
                assetPaths = AssetPaths.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
                sha256 = Sha256,
                length = Length,
                identity = Identity,
                linkCount = LinkCount
            };
        }

        private sealed class LockSnapshot
        {
            internal LockSnapshot(string json, string sha256, F10DiagnosticCopyCertificate certificate)
            { Json = json; Sha256 = sha256; Certificate = certificate; }
            internal string Json { get; }
            internal string Sha256 { get; }
            internal F10DiagnosticCopyCertificate Certificate { get; }
        }

        private sealed class PackageJsonIdentity { internal string Name, Version; }

        private sealed class LockJsonReader
        {
            private readonly string _text;
            private int _index;
            internal LockJsonReader(string text) { _text = text ?? throw new ArgumentNullException(nameof(text)); }
            internal void Expect(char expected)
            {
                SkipWhite();
                if (_index >= _text.Length || _text[_index] != expected) throw new FormatException("Invalid JSON token; expected '" + expected + "'.");
                _index++;
            }
            internal bool TryConsume(char value)
            {
                SkipWhite();
                if (_index < _text.Length && _text[_index] == value) { _index++; return true; }
                return false;
            }
            internal string ReadString()
            {
                SkipWhite();
                Expect('"');
                var output = new StringBuilder();
                while (_index < _text.Length)
                {
                    char value = _text[_index++];
                    if (value == '"') return output.ToString();
                    if (value < 0x20) throw new FormatException("Unescaped control character in JSON string.");
                    if (value != '\\') { output.Append(value); continue; }
                    if (_index >= _text.Length) throw new FormatException("Incomplete JSON escape.");
                    char escaped = _text[_index++];
                    switch (escaped)
                    {
                        case '"': output.Append('"'); break;
                        case '\\': output.Append('\\'); break;
                        case '/': output.Append('/'); break;
                        case 'b': output.Append('\b'); break;
                        case 'f': output.Append('\f'); break;
                        case 'n': output.Append('\n'); break;
                        case 'r': output.Append('\r'); break;
                        case 't': output.Append('\t'); break;
                        case 'u':
                            if (_index + 4 > _text.Length) throw new FormatException("Incomplete Unicode escape.");
                            string hex = _text.Substring(_index, 4);
                            if (!ushort.TryParse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ushort code))
                                throw new FormatException("Invalid Unicode escape.");
                            output.Append((char)code); _index += 4; break;
                        default: throw new FormatException("Invalid JSON escape.");
                    }
                }
                throw new FormatException("Unterminated JSON string.");
            }
            internal void SkipValue(int depth)
            {
                if (depth > 64) throw new FormatException("JSON nesting exceeds the package-lock limit.");
                SkipWhite();
                if (_index >= _text.Length) throw new FormatException("JSON value is missing.");
                char value = _text[_index];
                if (value == '"') { ReadString(); return; }
                if (value == '{')
                {
                    _index++; SkipWhite();
                    if (TryConsume('}')) return;
                    while (true)
                    {
                        ReadString(); Expect(':'); SkipValue(depth + 1);
                        if (TryConsume(',')) continue;
                        Expect('}'); return;
                    }
                }
                if (value == '[')
                {
                    _index++; SkipWhite();
                    if (TryConsume(']')) return;
                    while (true)
                    {
                        SkipValue(depth + 1);
                        if (TryConsume(',')) continue;
                        Expect(']'); return;
                    }
                }
                if (ConsumeLiteral("true") || ConsumeLiteral("false") || ConsumeLiteral("null")) return;
                ReadNumber();
            }
            internal void RequireEnd() { SkipWhite(); if (_index != _text.Length) throw new FormatException("Trailing bytes after JSON document."); }
            private void ReadNumber()
            {
                int start = _index;
                if (_index < _text.Length && _text[_index] == '-') _index++;
                if (_index >= _text.Length) throw new FormatException("Invalid JSON number.");
                if (_text[_index] == '0') _index++;
                else
                {
                    if (!IsDigit(_text[_index])) throw new FormatException("Invalid JSON value.");
                    while (_index < _text.Length && IsDigit(_text[_index])) _index++;
                }
                if (_index < _text.Length && _text[_index] == '.') { _index++; ReadDigits(); }
                if (_index < _text.Length && (_text[_index] == 'e' || _text[_index] == 'E'))
                {
                    _index++; if (_index < _text.Length && (_text[_index] == '+' || _text[_index] == '-')) _index++; ReadDigits();
                }
                if (start == _index) throw new FormatException("Invalid JSON value.");
            }
            private void ReadDigits()
            {
                int start = _index;
                while (_index < _text.Length && IsDigit(_text[_index])) _index++;
                if (start == _index) throw new FormatException("Invalid JSON number.");
            }
            private bool ConsumeLiteral(string literal)
            {
                SkipWhite();
                if (_index + literal.Length > _text.Length || string.CompareOrdinal(_text, _index, literal, 0, literal.Length) != 0) return false;
                _index += literal.Length; return true;
            }
            private static bool IsDigit(char value) => value >= '0' && value <= '9';
            private void SkipWhite() { while (_index < _text.Length && (_text[_index] == ' ' || _text[_index] == '\t' || _text[_index] == '\r' || _text[_index] == '\n')) _index++; }
        }
    }
}
#endif
