#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Enemies;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>
    /// Editor-only bridge for the isolated F10 technical session. Prefabs and JSON are captured once by TryFreeze;
    /// this class builds the C1 adapter plan from the C08 IDs and the active room's validated marker transforms.
    /// It does not arm a runtime, write a profile, settle a room, or produce a victory.
    /// </summary>
    internal sealed class F10TechnicalEncounterPlanProvider
    {
        internal const string C1NodeId = "sample.patio.combat";
        internal const string C1TemplateId = "room.patio.c1";
        internal const string GuardianNodeId = "sample.patio.guardian";
        internal const string GuardianTemplateId = "room.patio.guardian";

        private const string C08EncounterId = "encounter.c08_arena";
        private const string BossSpawnId = "boss.custodian";
        private const float MarkerPositionTolerance = 0.001f;

        private readonly GameObject _slimePrototype;
        private readonly GameObject _boneguardPrototype;
        private readonly GameObject _custodianPrototype;
        private readonly GameObject _custodianWavePrototype;
        private readonly CombatEncounterData _c08Encounter;
        private readonly string _custodianBossJson;
        private readonly int _groundLayer;

        private F10TechnicalEncounterPlanProvider(GameObject slimePrototype,
            GameObject boneguardPrototype, GameObject custodianPrototype,
            GameObject custodianWavePrototype, CombatEncounterData c08Encounter,
            string custodianBossJson, int groundLayer)
        {
            _slimePrototype = slimePrototype;
            _boneguardPrototype = boneguardPrototype;
            _custodianPrototype = custodianPrototype;
            _custodianWavePrototype = custodianWavePrototype;
            _c08Encounter = c08Encounter;
            _custodianBossJson = custodianBossJson ?? string.Empty;
            _groundLayer = groundLayer;
        }

        /// <summary>
        /// Freezes explicit session references. No prefab or JSON is loaded implicitly from Resources, and callers
        /// retain this instance for the technical session instead of swapping actor assets between rooms.
        /// </summary>
        internal static bool TryFreeze(GameObject slimePrototype, GameObject boneguardPrototype,
            GameObject custodianPrototype, GameObject custodianWavePrototype,
            TextAsset c08Source, TextAsset custodianBossSource,
            out F10TechnicalEncounterPlanProvider provider, out string error)
        {
            provider = null;
            error = string.Empty;
            if (slimePrototype == null || boneguardPrototype == null ||
                custodianPrototype == null || custodianWavePrototype == null)
                return Fail("The four explicit F10 technical actor prefabs must be supplied together.", out error);
            if (c08Source == null || custodianBossSource == null)
                return Fail("C08Arena.json and CustodianBoss.json must be supplied as explicit session sources.", out error);

            int groundLayer = LayerMask.NameToLayer("Ground");
            if (groundLayer < 0)
                return Fail("The project has no Ground layer for the encounter actor adapters.", out error);
            if (!IsSlimePrototype(slimePrototype))
                return Fail("SlimePrototype must contain one root Slime2D, Rigidbody2D, and Collider2D.", out error);
            if (!IsBoneguardPrototype(boneguardPrototype))
                return Fail("HuesoguardiaPrototype must contain one root Huesoguardia2D, Rigidbody2D, and Collider2D.", out error);

            CombatEncounterData encounter;
            try
            {
                encounter = CombatEncounterJsonLoader.Load(c08Source.text);
            }
            catch (Exception exception)
            {
                return Fail("C08Arena.json is invalid: " + exception.GetType().Name + ".", out error);
            }

            if (!IsExactC08TechnicalContract(encounter))
                return Fail("C08Arena.json does not match the frozen two-wave F10 technical roster.", out error);

            provider = new F10TechnicalEncounterPlanProvider(slimePrototype, boneguardPrototype,
                custodianPrototype, custodianWavePrototype, encounter, custodianBossSource.text, groundLayer);
            return true;
        }

        /// <summary>Builds C1 from C08 spawn IDs and the two real C1 marker transforms.</summary>
        internal bool TryBuildC1(ExpeditionRunConfiguration run, RoomLifetimeScope scope,
            RoomTemplatePrefab2D room, out RoomEncounterRuntimePlan plan, out string error)
        {
            plan = null;
            error = string.Empty;
            if (!TryValidateRoom(run, C1NodeId, C1TemplateId, ExpeditionRouteNodeKind.Combat,
                expectedMainPathIndex: 1, scope, room, out RoomTemplateData roomData, out error))
                return false;

            LayerMask groundMask = 1 << _groundLayer;
            if (_groundLayer != LayerMask.NameToLayer("Ground") || !IsSlimePrototype(_slimePrototype) ||
                !IsBoneguardPrototype(_boneguardPrototype))
                return Fail("The frozen C1 prefabs or Ground layer changed after the session snapshot.", out error);

            if (!TryFindRoomMarker(room, roomData, "spawn.slime.01", "enemy_spawn", out RoomPositionMarker2D firstAnchor, out error) ||
                !TryFindRoomMarker(room, roomData, "spawn.slime.02", "enemy_spawn", out RoomPositionMarker2D secondAnchor, out error))
                return false;

            var rosterWaves = new List<ExpeditionEncounterWavePlan>(_c08Encounter.waves.Length);
            var actorWaves = new List<RoomEncounterWaveActorDefinition>(_c08Encounter.waves.Length);
            try
            {
                for (int waveIndex = 0; waveIndex < _c08Encounter.waves.Length; waveIndex++)
                {
                    CombatEncounterWaveData sourceWave = _c08Encounter.waves[waveIndex];
                    var actorDefinitions = new List<RoomEncounterActorDefinition>(sourceWave.spawns.Length);
                    var spawnKeys = new List<string>(sourceWave.spawns.Length);
                    for (int spawnIndex = 0; spawnIndex < sourceWave.spawns.Length; spawnIndex++)
                    {
                        CombatEnemySpawnData spawn = sourceWave.spawns[spawnIndex];
                        if (!TryGetC1Anchor(spawn.spawnId, out RoomPositionMarker2D anchor))
                            return Fail("C08 spawn " + spawn.spawnId + " has no exact C1 marker mapping.", out error);

                        GameObject actorPrefab = string.Equals(spawn.enemyId, "enemy.slime", StringComparison.Ordinal)
                            ? _slimePrototype
                            : string.Equals(spawn.enemyId, "enemy.huesoguardia", StringComparison.Ordinal)
                                ? _boneguardPrototype
                                : null;
                        if (actorPrefab == null)
                            return Fail("C08 spawn " + spawn.spawnId + " has no frozen technical actor prefab.", out error);

                        EncounterSpawnIdentityV1 identity = EncounterSpawnIdentityV1.Create(
                            run.RunId, checked((uint)run.Route.GenerationVersion), C1NodeId,
                            scope.RoomInstanceId, _c08Encounter.encounterId, spawn.spawnId);
                        Vector3 scopeLocalPosition = scope.transform.InverseTransformPoint(anchor.transform.position);
                        Quaternion scopeLocalRotation = Quaternion.Inverse(scope.transform.rotation) * anchor.transform.rotation;
                        var actor = new RoomEncounterActorDefinition(identity.Key, actorPrefab,
                            groundMask, scopeLocalPosition, scopeLocalRotation);
                        if (!actor.SupportsConcreteActorAdapter)
                            return Fail("C08 spawn " + spawn.spawnId + " does not resolve to a supported concrete actor prefab.", out error);

                        spawnKeys.Add(identity.Key);
                        actorDefinitions.Add(actor);
                    }

                    rosterWaves.Add(new ExpeditionEncounterWavePlan(waveIndex + 1, spawnKeys));
                    actorWaves.Add(new RoomEncounterWaveActorDefinition(waveIndex + 1, actorDefinitions));
                }

                var candidate = new RoomEncounterRuntimePlan(
                    new ExpeditionEncounterRosterPlan(rosterWaves), actorWaves);
                if (!candidate.HasOnlySupportedActors)
                    return Fail("The C1 actor plan does not completely cover the frozen C08 roster.", out error);
                plan = candidate;
                return true;
            }
            catch (Exception exception)
            {
                return Fail("C1 plan creation failed closed: " + exception.GetType().Name + ".", out error);
            }

            bool TryGetC1Anchor(string spawnId, out RoomPositionMarker2D anchor)
            {
                switch (spawnId)
                {
                    case "spawn.slime.01":
                    case "spawn.huesoguardia.01":
                        anchor = firstAnchor;
                        return true;
                    case "spawn.slime.02":
                    case "spawn.huesoguardia.02":
                        anchor = secondAnchor;
                        return true;
                    default:
                        anchor = null;
                        return false;
                }
            }
        }

        /// <summary>
        /// Verifies Guardian's real room, frozen boss sources, and the installer-issued current physical boundary
        /// witness before returning the single Custodian actor plan.
        /// </summary>
        internal bool TryBuildGuardian(ExpeditionRunConfiguration run, RoomLifetimeScope scope,
            RoomTemplatePrefab2D room, F10GuardianPhysicalBoundaryInstaller.InstallationWitness boundaryWitness,
            out RoomEncounterRuntimePlan plan, out string error)
        {
            plan = null;
            error = string.Empty;
            if (!F10GuardianPhysicalBoundaryInstaller.IsCurrent(boundaryWitness, run, scope, room))
                return Fail("Guardian requires the current installer-issued physical boundary witness for this exact room scope.", out error);
            if (!TryValidateRoom(run, GuardianNodeId, GuardianTemplateId, ExpeditionRouteNodeKind.Guardian,
                expectedMainPathIndex: 3, scope, room, out RoomTemplateData roomData, out error))
                return false;
            if (!TryFindRoomMarker(room, roomData, BossSpawnId, "boss_spawn", out RoomPositionMarker2D bossMarker, out error))
                return false;

            CustodianBossDefinition boss;
            try
            {
                boss = CustodianBossJsonLoader.Load(_custodianBossJson);
                if (!string.Equals(boss.BossId, "boss.custodian_of_the_oaks", StringComparison.Ordinal))
                    return Fail("CustodianBoss.json does not identify the F10 Custodian.", out error);
            }
            catch (Exception exception)
            {
                return Fail("CustodianBoss.json is unavailable or invalid: " + exception.GetType().Name + ".", out error);
            }

            if (_groundLayer != LayerMask.NameToLayer("Ground") ||
                !IsCustodianPrototype(_custodianPrototype) || !IsCustodianWavePrototype(_custodianWavePrototype))
                return Fail("The frozen Custodian or wave prototype is missing required physical actor components.", out error);

            try
            {
                EncounterSpawnIdentityV1 identity = EncounterSpawnIdentityV1.Create(
                    run.RunId, checked((uint)run.Route.GenerationVersion), GuardianNodeId,
                    scope.RoomInstanceId, boss.BossId, BossSpawnId);
                Vector3 scopeLocalPosition = scope.transform.InverseTransformPoint(bossMarker.transform.position);
                Quaternion scopeLocalRotation = Quaternion.Inverse(scope.transform.rotation) * bossMarker.transform.rotation;
                LayerMask groundMask = 1 << _groundLayer;
                var bossConfiguration = new RoomEncounterCustodianBossConfiguration(
                    boss, _custodianWavePrototype, boundaryWitness.LeftEdgeX,
                    boundaryWitness.RightEdgeX, boundaryWitness.FloorTopY);
                var actor = new RoomEncounterActorDefinition(identity.Key, _custodianPrototype,
                    groundMask, scopeLocalPosition, scopeLocalRotation, bossConfiguration);
                if (!actor.SupportsConcreteActorAdapter || !bossConfiguration.ContainsBossPosition(bossMarker.transform.position))
                    return Fail("The real Guardian boss marker or frozen Custodian actor does not fit the current physical boundary witness.", out error);

                var roster = new ExpeditionEncounterRosterPlan(new[]
                {
                    new ExpeditionEncounterWavePlan(1, new[] { identity.Key })
                });
                var candidate = new RoomEncounterRuntimePlan(roster,
                    new[] { new RoomEncounterWaveActorDefinition(1, new[] { actor }) });
                if (!candidate.HasOnlySupportedActors)
                    return Fail("Guardian's single physical Custodian plan does not cover its exact actor roster.", out error);
                if (!F10GuardianPhysicalBoundaryInstaller.IsCurrent(boundaryWitness, run, scope, room))
                    return Fail("Guardian's physical boundary witness became stale before its plan was returned.", out error);

                plan = candidate;
                return true;
            }
            catch (Exception exception)
            {
                return Fail("Guardian plan creation failed closed: " + exception.GetType().Name + ".", out error);
            }
        }

        /// <summary>Legacy no-witness entry point retained only as a fail-closed guard for stale callers.</summary>
        internal bool TryBuildGuardian(ExpeditionRunConfiguration run, RoomLifetimeScope scope,
            RoomTemplatePrefab2D room, out RoomEncounterRuntimePlan plan, out string error)
        {
            plan = null;
            return Fail("Guardian requires the installer-issued boundary witness; without it the Custodian does not confine its own body.", out error);
        }

        private static bool TryValidateRoom(ExpeditionRunConfiguration run, string nodeId,
            string templateId, ExpeditionRouteNodeKind expectedKind, int expectedMainPathIndex,
            RoomLifetimeScope scope, RoomTemplatePrefab2D room, out RoomTemplateData roomData,
            out string error)
        {
            roomData = null;
            error = string.Empty;
            if (run == null || run.Route == null || run.Route.GenerationVersion != 2)
                return Fail("The technical encounter provider requires the explicit F10 generation-2 run.", out error);

            ExpeditionRouteNode routeNode = run.Route.Nodes.SingleOrDefault(candidate =>
                candidate != null && string.Equals(candidate.NodeId, nodeId, StringComparison.Ordinal));
            if (routeNode == null || routeNode.Kind != expectedKind || !routeNode.IsMandatory ||
                routeNode.MainPathIndex != expectedMainPathIndex ||
                !string.Equals(routeNode.TemplateId, templateId, StringComparison.Ordinal))
                return Fail("The run does not contain the exact mandatory F10 node/template pair for this encounter.", out error);

            RoomInstanceId expectedRoomId;
            try
            {
                expectedRoomId = ExpeditionRoomIdentity.ForNode(run.RunId, nodeId);
            }
            catch (Exception exception)
            {
                return Fail("The F10 node cannot derive a room identity: " + exception.GetType().Name + ".", out error);
            }

            if (scope == null || room == null || !scope.isActiveAndEnabled || scope.IsDisposed ||
                scope.RoomInstanceId != expectedRoomId || !string.Equals(scope.TemplateId, templateId, StringComparison.Ordinal) ||
                !room.isActiveAndEnabled || !room.gameObject.activeInHierarchy ||
                !room.transform.IsChildOf(scope.transform))
                return Fail("The encounter requires the active, initialized scope and room instance for the exact F10 node.", out error);

            RoomTemplatePrefab2D[] activeScopeRooms = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (activeScopeRooms.Length != 1 || !ReferenceEquals(activeScopeRooms[0], room))
                return Fail("The exact active room scope must contain exactly one matching RoomTemplatePrefab2D.", out error);

            try
            {
                roomData = room.ValidateGeneratedPrefab();
            }
            catch (Exception exception)
            {
                return Fail("The active room's real source, Ground tilemap, ports, or markers are invalid: " +
                    exception.GetType().Name + ".", out error);
            }

            if (roomData == null || !string.Equals(roomData.templateId, templateId, StringComparison.Ordinal) ||
                room.SourceDefinition == null || roomData.schemaVersion != 1)
                return Fail("The active room definition does not match the exact F10 template.", out error);

            return true;
        }

        private static bool TryFindRoomMarker(RoomTemplatePrefab2D room, RoomTemplateData roomData,
            string markerId, string markerKind, out RoomPositionMarker2D marker, out string error)
        {
            marker = null;
            error = string.Empty;
            RoomPositionMarkerData[] definitions = (roomData.markers ?? Array.Empty<RoomPositionMarkerData>())
                .Where(item => item != null && string.Equals(item.id, markerId, StringComparison.Ordinal))
                .ToArray();
            RoomPositionMarker2D[] components = room.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(item => item != null && string.Equals(item.MarkerId, markerId, StringComparison.Ordinal))
                .ToArray();
            if (definitions.Length != 1 || components.Length != 1 ||
                !string.Equals(definitions[0].kind, markerKind, StringComparison.Ordinal) ||
                !string.Equals(components[0].Kind, markerKind, StringComparison.Ordinal) ||
                components[0].TilePosition != new Vector2Int(definitions[0].tileX, definitions[0].tileY) ||
                !components[0].enabled || !components[0].gameObject.activeInHierarchy ||
                !components[0].transform.IsChildOf(room.transform))
                return Fail("The active room is missing the unique real marker " + markerId + " (" + markerKind + ").", out error);

            Vector3 expectedWorldPosition = room.transform.TransformPoint(new Vector3(
                (definitions[0].tileX + 0.5f) * roomData.tileSize,
                definitions[0].tileY * roomData.tileSize, 0f));
            if (!IsNear(components[0].transform.position, expectedWorldPosition))
                return Fail("The active room marker " + markerId + " is not at its source-definition pose.", out error);

            marker = components[0];
            return true;
        }

        private static bool IsExactC08TechnicalContract(CombatEncounterData encounter)
        {
            return encounter != null && encounter.schemaVersion == 2 &&
                string.Equals(encounter.encounterId, C08EncounterId, StringComparison.Ordinal) &&
                encounter.waves != null && encounter.waves.Length == 2 &&
                HasWave(encounter.waves[0], "wave.slimes", "spawn.slime.01", "spawn.slime.02", "enemy.slime") &&
                HasWave(encounter.waves[1], "wave.huesoguardias", "spawn.huesoguardia.01",
                    "spawn.huesoguardia.02", "enemy.huesoguardia");
        }

        private static bool HasWave(CombatEncounterWaveData wave, string waveId,
            string firstSpawnId, string secondSpawnId, string enemyId)
        {
            return wave != null && string.Equals(wave.id, waveId, StringComparison.Ordinal) &&
                wave.spawns != null && wave.spawns.Length == 2 &&
                string.Equals(wave.spawns[0].spawnId, firstSpawnId, StringComparison.Ordinal) &&
                string.Equals(wave.spawns[0].enemyId, enemyId, StringComparison.Ordinal) &&
                string.Equals(wave.spawns[1].spawnId, secondSpawnId, StringComparison.Ordinal) &&
                string.Equals(wave.spawns[1].enemyId, enemyId, StringComparison.Ordinal);
        }

        private static bool IsSlimePrototype(GameObject prefab)
        {
            return HasOneRootActor<Slime2D>(prefab) &&
                prefab.GetComponentsInChildren<Huesoguardia2D>(true).Length == 0 &&
                prefab.GetComponentsInChildren<CustodianBoss2D>(true).Length == 0 &&
                prefab.GetComponent<Rigidbody2D>() != null && prefab.GetComponent<Collider2D>() != null;
        }

        private static bool IsBoneguardPrototype(GameObject prefab)
        {
            return HasOneRootActor<Huesoguardia2D>(prefab) &&
                prefab.GetComponentsInChildren<Slime2D>(true).Length == 0 &&
                prefab.GetComponentsInChildren<CustodianBoss2D>(true).Length == 0 &&
                prefab.GetComponent<Rigidbody2D>() != null && prefab.GetComponent<Collider2D>() != null;
        }

        private static bool IsCustodianPrototype(GameObject prefab)
        {
            return HasOneRootActor<CustodianBoss2D>(prefab) &&
                prefab.GetComponentsInChildren<Slime2D>(true).Length == 0 &&
                prefab.GetComponentsInChildren<Huesoguardia2D>(true).Length == 0 &&
                prefab.GetComponent<Rigidbody2D>() != null && prefab.GetComponent<Collider2D>() != null &&
                prefab.GetComponent<SpriteRenderer>() != null;
        }

        private static bool HasOneRootActor<TActor>(GameObject prefab) where TActor : Component
        {
            if (prefab == null) return false;
            TActor[] actors = prefab.GetComponentsInChildren<TActor>(true);
            return actors.Length == 1 && actors[0] != null && ReferenceEquals(actors[0].gameObject, prefab);
        }

        private static bool IsCustodianWavePrototype(GameObject prefab)
        {
            return prefab != null && prefab.GetComponents<CustodianWaveHazard2D>().Length == 1 &&
                prefab.GetComponent<Rigidbody2D>() != null && prefab.GetComponent<Collider2D>() != null;
        }

        private static bool IsNear(Vector3 actual, Vector3 expected)
        {
            return IsFinite(actual) && IsFinite(expected) &&
                (actual - expected).sqrMagnitude <= MarkerPositionTolerance * MarkerPositionTolerance;
        }

        private static bool IsFinite(Vector3 value)
        {
            return !float.IsNaN(value.x) && !float.IsInfinity(value.x) &&
                !float.IsNaN(value.y) && !float.IsInfinity(value.y) &&
                !float.IsNaN(value.z) && !float.IsInfinity(value.z);
        }

        private static bool Fail(string reason, out string error)
        {
            error = reason;
            return false;
        }
    }
}
#endif
