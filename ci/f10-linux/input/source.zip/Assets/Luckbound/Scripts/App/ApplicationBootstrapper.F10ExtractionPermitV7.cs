#if UNITY_EDITOR
using System;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves.V7;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEngine;

namespace Luckbound.App
{
    public sealed partial class ApplicationBootstrapper
    {
        /// <summary>
        /// Coordinator entry used from TryAcceptLocalObservation before the callback returns.
        /// The opaque settlement owner, pause lease and readiness registration are read from the
        /// App's private retained operation; callers cannot substitute them.
        /// </summary>
        internal bool TryIssueCurrentF10ExtractionPermitV7FromHandoff(
            ExpeditionGameplayComposition composition, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation,
            ItemCatalog itemCatalog, EncounterCatalogRegistryV1 exactRegistry,
            out F10ExtractionPermitV7 permit, out string error)
        {
            permit = null;
            error = string.Empty;
            F10ExtractionSettlementOperation operation = _f10ExtractionSettlement;
            if (operation == null || operation.Capture == null || operation.Lease == null)
                return FailF10ExtractionPermitV7("AppOwnerRequired: no retained F10 extraction operation owns a simulation lease.", out error);

            return F10ExtractionPermitV7.TryIssueFromAppHandoff(this, composition, driver,
                handoff, observation, operation, operation.Lease, operation.Capture.Registration,
                itemCatalog, exactRegistry, out permit, out error);
        }

        /// <summary>
        /// Validates the opaque owner carried by the permit against the current private App
        /// operation. At issuance it also re-runs the full extraction capture while delivery is
        /// active. At repository bind time it checks the retained lease and current Bound room
        /// identity only; the physical callback has already ended and must not be replayed.
        /// </summary>
        internal bool TryValidateF10ExtractionPermitV7Owner(
            ExpeditionGameplayComposition composition, F10ObjectiveDriver2D driver,
            IF10ObjectiveObservationHandoff handoff, F10ObjectiveObservation observation,
            object appSettlementOperationOwner, IDisposable simulationLease,
            ExpeditionSessionReadinessRegistration readinessRegistration,
            ItemCatalog itemCatalog, bool requireDriverDelivery, out string error)
        {
            error = string.Empty;
            F10ExtractionSettlementOperation operation = appSettlementOperationOwner as F10ExtractionSettlementOperation;
            if (operation == null || !ReferenceEquals(operation, _f10ExtractionSettlement) ||
                operation.Capture == null || operation.Lease == null ||
                !ReferenceEquals(operation.Lease, simulationLease) ||
                !ReferenceEquals(operation.Capture.Registration, readinessRegistration) ||
                operation.CandidateAdopted || operation.Finished || operation.Persisted ||
                !ReferenceEquals(operation.Composition, composition) ||
                !ReferenceEquals(operation.Driver, driver) || !ReferenceEquals(operation.Handoff, handoff) ||
                !ReferenceEquals(operation.Observation, observation) || observation == null ||
                !string.Equals(operation.Observation.ObservationId, observation.ObservationId, StringComparison.Ordinal) ||
                !ReferenceEquals(operation.Capture.Composition, composition) ||
                !ReferenceEquals(operation.Capture.Registration, readinessRegistration) ||
                operation.Capture.RunId != observation.RunId || operation.Capture.ActorId != observation.ActorId ||
                operation.Capture.Context == null ||
                !ReferenceEquals(operation.Capture.Context.Scope, observation.Scope) ||
                !ReferenceEquals(operation.Capture.Context.Controller, observation.Controller) ||
                !ReferenceEquals(operation.Capture.Context.Player, observation.Player) ||
                operation.Capture.Context.ActivationGeneration != observation.ActivationGeneration)
                return FailF10ExtractionPermitV7("AppOwnerMismatch: the private operation, retained simulation lease, readiness registration, or extraction fact is not the exact active owner.", out error);

            if (!Application.isPlaying || !ReferenceEquals(ApplicationBootstrapper.Instance, this) ||
                !OwnsF10DiagnosticRun(ActiveRun) || composition == null || !composition.isActiveAndEnabled ||
                !composition.IsReady || driver == null || driver.IsDisposed || driver.IsFaulted ||
                handoff == null || observation.Kind != F10ObjectiveObservationKind.ExtractionInteractionRequested ||
                !string.Equals(observation.NodeId, "sample.safe_extraction", StringComparison.Ordinal) ||
                !string.Equals(observation.TemplateId, "room.sample.extraction", StringComparison.Ordinal) ||
                !readinessRegistration.IsOwnerActive || readinessRegistration.IsDisposed ||
                !ReferenceEquals(readinessRegistration.Owner, composition))
                return FailF10ExtractionPermitV7("AppRuntimeMismatch: the F10 extraction owner is no longer live in Play Mode.", out error);

            ExpeditionReadinessCompositionView view = composition.CaptureReadinessCompositionView();
            ExpeditionRoomActivationRegistration activation = readinessRegistration.CurrentActivation;
            RoomEncounterRuntimeContext context = activation == null ? null : activation.Context;
            ExpeditionRoomTransitionController transitions = view == null ? null : view.RoomTransitions;
            ExpeditionReadinessTransitionView transition = transitions == null
                ? null
                : transitions.CaptureReadinessTransitionView();
            F10ExtractionCapture captured = operation.Capture;

            if (itemCatalog == null || view == null || !view.IsReady ||
                !ReferenceEquals(view.Owner, composition) || !ReferenceEquals(view.Application, this) ||
                !ReferenceEquals(view.ReadinessRegistration, readinessRegistration) ||
                !ReferenceEquals(view.ItemCatalog, itemCatalog) || view.Run == null || ActiveRun == null ||
                !RunsHaveSameRoute(view.Run, ActiveRun) || !RunsHaveSameRoute(captured.Run, ActiveRun) ||
                transitions == null || transitions.IsDisposed || !ReferenceEquals(transitions, captured.Controller) ||
                transition == null || !transition.IsInitialized || transition.IsDisposed ||
                transition.IsTransitioning || transition.HasPreparedTransition ||
                !ReferenceEquals(transition.ActiveScope, captured.Context.Scope) ||
                !ReferenceEquals(transition.ActiveRoomRoot, captured.Context.Scope.gameObject) ||
                !string.Equals(transition.ActiveNodeId, "sample.safe_extraction", StringComparison.Ordinal) ||
                !string.Equals(transition.ActiveTemplateId, "room.sample.extraction", StringComparison.Ordinal) ||
                activation == null || activation.State != ExpeditionRoomActivationState.Bound ||
                !ReferenceEquals(activation, captured.Activation) ||
                !ReferenceEquals(activation.Controller, transitions) || activation.RunId != captured.RunId ||
                !ReferenceEquals(activation.Scope, captured.Context.Scope) ||
                !ReferenceEquals(context, captured.Context) || !context.IsCurrentRoomScope() ||
                !ReferenceEquals(context.Controller, transitions) || !ReferenceEquals(context.Player, view.PlayerMotor) ||
                context.RunId != captured.RunId || context.ActivationGeneration != observation.ActivationGeneration ||
                !ReferenceEquals(view.PlayerMotor, composition.PlayerMotor) ||
                view.PlayerMotor == null || !view.PlayerMotor.isActiveAndEnabled ||
                view.PlayerMotor.ActorId != captured.ActorId || view.PlayerMotor.ActorId != observation.ActorId ||
                !ReferenceEquals(driver, context.Scope.GetComponent<F10ObjectiveDriver2D>()))
                return FailF10ExtractionPermitV7("ReadinessMismatch: the same current Bound extraction activation, composition, actor, item catalog, and transition are required.", out error);

            if (requireDriverDelivery)
            {
                if (!driver.IsDeliveringTo(handoff, observation))
                    return FailF10ExtractionPermitV7("PhysicalDeliveryRequired: the exact extraction fact is no longer inside its driver callback.", out error);

                if (!TryCaptureF10Extraction(composition, driver, handoff, observation,
                    requireDelivery: true, underOwnGate: operation.GateHeld,
                    out F10ExtractionCapture current, out error)) return false;
                if (!SameF10ExtractionCapture(captured, current))
                    return FailF10ExtractionPermitV7("CaptureChanged: the retained extraction operation differs from its synchronous physical witness.", out error);
            }

            error = string.Empty;
            return true;
        }

        private static bool FailF10ExtractionPermitV7(string message, out string error)
        {
            error = string.IsNullOrWhiteSpace(message) ? "PhysicalPermitRejected." : message;
            return false;
        }
    }
}
#endif
