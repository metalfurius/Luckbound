#if UNITY_EDITOR
using System;
using System.Linq;
using Luckbound.Content;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using UnityEditor;
using UnityEngine;

namespace Luckbound.App
{
    /// <summary>Editor-only staging helper for the F10 noncombat objective driver.</summary>
    internal static class F10ObjectiveSetupDemo
    {
        private const float PoseTolerance = 0.001f;

        private enum ObjectiveRole { Tutorial, ExplorationExit, Extraction }

        private readonly struct RoleContract
        {
            internal RoleContract(ObjectiveRole role, string nodeId, string templateId,
                string markerId, string markerKind, int tileX, int tileY)
            {
                Role = role;
                NodeId = nodeId;
                TemplateId = templateId;
                MarkerId = markerId;
                MarkerKind = markerKind;
                TileX = tileX;
                TileY = tileY;
            }

            internal ObjectiveRole Role { get; }
            internal string NodeId { get; }
            internal string TemplateId { get; }
            internal string MarkerId { get; }
            internal string MarkerKind { get; }
            internal int TileX { get; }
            internal int TileY { get; }
        }

        /// <summary>
        /// Adds one temporary cell trigger to the active room instance and attaches the exact room driver.
        /// It never edits the prefab asset, saves progress, or advances the route.
        /// </summary>
        internal static F10ObjectiveDriver2D Attach(RoomEncounterRuntimeContext context,
            IRoomEncounterRuntimeSessionSnapshotSource sessionSource, Collider2D playerCollider,
            IF10ObjectiveObservationHandoff observationHandoff)
        {
            if (!Application.isPlaying)
                throw new InvalidOperationException("The F10 setup demo can only attach to a live Editor play session.");
            if (context == null) throw new ArgumentNullException(nameof(context));
            if (sessionSource == null) throw new ArgumentNullException(nameof(sessionSource));
            if (playerCollider == null) throw new ArgumentNullException(nameof(playerCollider));
            if (observationHandoff == null) throw new ArgumentNullException(nameof(observationHandoff));
            if (!context.IsCurrentRoomScope())
                throw new InvalidOperationException("Setup requires the exact current room activation and scope.");

            RoomLifetimeScope scope = context.Scope;
            if (scope == null || !scope.isActiveAndEnabled || scope.IsDisposed ||
                scope.GetComponent<F10ObjectiveDriver2D>() != null)
                throw new InvalidOperationException("The active scope is unavailable or already owns an objective driver.");
            if (context.Player == null || !context.Player.isActiveAndEnabled ||
                !ReferenceEquals(playerCollider.gameObject, context.Player.gameObject) ||
                !ReferenceEquals(playerCollider.GetComponent<PlayerMotor2D>(), context.Player) ||
                context.Player.GetComponent<Rigidbody2D>() == null || !context.Player.ActorId.IsValid)
                throw new InvalidOperationException("Setup requires the collider and Rigidbody2D of the exact bound player.");
            ValidateReadiness(context, sessionSource);

            RoleContract contract = ResolveRole(context);
            RoomTemplatePrefab2D[] roomPrefabs = scope.GetComponentsInChildren<RoomTemplatePrefab2D>(true);
            if (roomPrefabs.Length != 1 || roomPrefabs[0] == null || !roomPrefabs[0].isActiveAndEnabled ||
                EditorUtility.IsPersistent(roomPrefabs[0].gameObject) || roomPrefabs[0].SourceDefinition == null ||
                !IsDescendantOf(roomPrefabs[0].transform, scope.transform))
                throw new InvalidOperationException("The active scope must contain exactly one non-asset room definition.");

            RoomTemplatePrefab2D roomPrefab = roomPrefabs[0];
            RoomTemplateData data = RoomTemplateJsonLoader.Load(roomPrefab.SourceDefinition.text);
            if (!string.Equals(data.templateId, contract.TemplateId, StringComparison.Ordinal) ||
                !string.Equals(scope.TemplateId, contract.TemplateId, StringComparison.Ordinal))
                throw new InvalidOperationException("The active room source does not match the F10 node/template role.");

            RoomPositionMarkerData[] definitions = data.markers.Where(marker => marker != null &&
                string.Equals(marker.id, contract.MarkerId, StringComparison.Ordinal)).ToArray();
            if (definitions.Length != 1 ||
                !string.Equals(definitions[0].kind, contract.MarkerKind, StringComparison.Ordinal) ||
                definitions[0].tileX != contract.TileX || definitions[0].tileY != contract.TileY)
                throw new InvalidOperationException("The JSON source does not contain the unique marker required by this F10 role.");

            RoomPositionMarker2D[] markers = scope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Where(marker => marker != null && string.Equals(marker.MarkerId, contract.MarkerId, StringComparison.Ordinal))
                .ToArray();
            if (markers.Length != 1)
                throw new InvalidOperationException("The active scope must contain exactly one runtime marker with the required ID.");

            RoomPositionMarker2D markerInstance = markers[0];
            RoomPositionMarkerData definition = definitions[0];
            Vector3 expectedPose = roomPrefab.transform.TransformPoint(new Vector3(
                (definition.tileX + 0.5f) * data.tileSize, definition.tileY * data.tileSize, 0f));
            if (EditorUtility.IsPersistent(markerInstance.gameObject) || !markerInstance.enabled ||
                !markerInstance.gameObject.activeInHierarchy ||
                !string.Equals(markerInstance.Kind, contract.MarkerKind, StringComparison.Ordinal) ||
                markerInstance.TilePosition != new Vector2Int(contract.TileX, contract.TileY) ||
                !IsDescendantOf(markerInstance.transform, roomPrefab.transform) ||
                !IsNear(markerInstance.transform.position, expectedPose) ||
                !IsNear(markerInstance.transform.lossyScale, Vector3.one) ||
                markerInstance.GetComponentsInChildren<Collider2D>(true).Length != 0)
                throw new InvalidOperationException("The runtime marker is moved, disabled, asset-backed, or already has colliders.");

            var triggerObject = new GameObject("F10ObjectiveTrigger." + contract.MarkerId);
            triggerObject.transform.SetParent(markerInstance.transform, false);
            triggerObject.transform.localPosition = Vector3.zero;
            triggerObject.transform.localRotation = Quaternion.identity;
            triggerObject.transform.localScale = Vector3.one;
            BoxCollider2D trigger = triggerObject.AddComponent<BoxCollider2D>();
            trigger.size = Vector2.one * data.tileSize;
            trigger.offset = Vector2.zero;
            trigger.isTrigger = true;
            var triggerLease = new TemporaryTriggerLease(triggerObject, trigger);

            try
            {
                scope.OwnResource(triggerLease);
                return F10ObjectiveDriver2D.Prepare(context, sessionSource, playerCollider,
                    contract.Role == ObjectiveRole.Tutorial ? trigger : null,
                    contract.Role == ObjectiveRole.ExplorationExit ? trigger : null,
                    contract.Role == ObjectiveRole.Extraction ? trigger : null,
                    observationHandoff);
            }
            catch
            {
                triggerLease.Dispose();
                throw;
            }
        }

        private static void ValidateReadiness(RoomEncounterRuntimeContext context,
            IRoomEncounterRuntimeSessionSnapshotSource sessionSource)
        {
            RoomEncounterRuntimeSessionSnapshot snapshot;
            try
            {
                if (!sessionSource.TryCapture(context, out snapshot))
                    throw new InvalidOperationException("The activation-owned readiness source is unavailable.");
            }
            catch (Exception exception) when (!(exception is InvalidOperationException))
            {
                throw new InvalidOperationException("The activation-owned readiness source failed.", exception);
            }

            if (!snapshot.IsInitialized || !snapshot.Matches(context) ||
                snapshot.ActivationGeneration != context.ActivationGeneration || !snapshot.CanArmOrDrain)
                throw new InvalidOperationException("The readiness snapshot does not admit this exact active F10 activation.");
        }

        private static RoleContract ResolveRole(RoomEncounterRuntimeContext context)
        {
            if (context.NodeId == "sample.tutorial" && context.TemplateId == "room.sample.tutorial")
                return new RoleContract(ObjectiveRole.Tutorial, "sample.tutorial", "room.sample.tutorial",
                    "tutorial.interaction", "encounter_anchor", 13, 1);
            if (context.NodeId == "sample.patio.exploration" && context.TemplateId == "room.patio.e1")
                return new RoleContract(ObjectiveRole.ExplorationExit, "sample.patio.exploration", "room.patio.e1",
                    "exit.trigger", "exit_trigger", 43, 3);
            if (context.NodeId == "sample.safe_extraction" && context.TemplateId == "room.sample.extraction")
                return new RoleContract(ObjectiveRole.Extraction, "sample.safe_extraction", "room.sample.extraction",
                    "extraction.interact", "extraction", 12, 1);
            throw new InvalidOperationException("No editor setup role is defined for this exact F10 node/template pair.");
        }

        private static bool IsDescendantOf(Transform candidate, Transform root)
        {
            return candidate != null && root != null &&
                (ReferenceEquals(candidate, root) || candidate.IsChildOf(root));
        }

        private static bool IsNear(Vector3 actual, Vector3 expected)
        {
            return (actual - expected).sqrMagnitude <= PoseTolerance * PoseTolerance;
        }

        private sealed class TemporaryTriggerLease : IDisposable
        {
            private GameObject _triggerObject;
            private Collider2D _trigger;
            private bool _disposed;

            internal TemporaryTriggerLease(GameObject triggerObject, Collider2D trigger)
            {
                _triggerObject = triggerObject;
                _trigger = trigger;
            }

            public void Dispose()
            {
                if (_disposed) return;
                _disposed = true;
                if (_trigger != null) _trigger.enabled = false;
                if (_triggerObject != null) UnityEngine.Object.Destroy(_triggerObject);
                _trigger = null;
                _triggerObject = null;
            }
        }
    }
}
#endif
