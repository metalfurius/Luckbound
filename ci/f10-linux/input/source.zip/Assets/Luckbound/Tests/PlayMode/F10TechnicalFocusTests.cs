#if UNITY_EDITOR
using Luckbound.App;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.UI;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10TechnicalFocusTests
    {
        [Test]
        public void TechnicalModeCanContinueWithoutFocusWhileNormalModeStillPauses()
        {
            float previousScale = Time.timeScale;
            SimulationMode2D previousMode = Physics2D.simulationMode;
            var labelObject = new GameObject("Focus test label", typeof(RectTransform), typeof(Text));
            var technicalObject = new GameObject("Technical pause");
            var normalObject = new GameObject("Normal pause");
            try
            {
                Time.timeScale = 1f;
                ExpeditionPauseController technical = technicalObject.AddComponent<ExpeditionPauseController>();
                technical.Initialize(labelObject.GetComponent<Text>(), pauseOnFocusLoss: false);
                technical.HandleApplicationFocus(false);
                Assert.That(technical.IsPaused, Is.False);
                Assert.That(Time.timeScale, Is.EqualTo(1f));

                ExpeditionPauseController normal = normalObject.AddComponent<ExpeditionPauseController>();
                normal.Initialize(labelObject.GetComponent<Text>(), pauseOnFocusLoss: true);
                normal.HandleApplicationFocus(false);
                Assert.That(normal.IsPaused, Is.True);
                Assert.That(Time.timeScale, Is.Zero);
                normal.SetPaused(false);
                Assert.That(Time.timeScale, Is.EqualTo(1f));
            }
            finally
            {
                Object.DestroyImmediate(technicalObject);
                Object.DestroyImmediate(normalObject);
                Object.DestroyImmediate(labelObject);
                Time.timeScale = previousScale;
                Physics2D.simulationMode = previousMode;
            }
        }
    }
}
#endif
