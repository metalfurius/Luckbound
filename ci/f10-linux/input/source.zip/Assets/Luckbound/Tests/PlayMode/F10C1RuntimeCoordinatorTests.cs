#if UNITY_EDITOR
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.App;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10C1RuntimeCoordinatorTests
    {
        [Test]
        public void CoordinatorLifetimeIsOwnedByItsRoomScopeAndCannotInventClear()
        {
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId,
                new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
            var root = new GameObject("F10 C1 coordinator scope test");
            try
            {
                RoomLifetimeScope scope = root.AddComponent<RoomLifetimeScope>();
                scope.Initialize(ExpeditionRoomIdentity.ForNode(run.RunId,
                    F10TechnicalEncounterPlanProvider.C1NodeId),
                    F10TechnicalEncounterPlanProvider.C1TemplateId);
                F10C1RuntimeCoordinator coordinator = root.AddComponent<F10C1RuntimeCoordinator>();
                scope.OwnResource(coordinator);

                Assert.That(scope.OwnedResourceCount, Is.EqualTo(1));
                Assert.That(coordinator.RuntimeStatus, Is.EqualTo(RoomEncounterRuntimeStatus.NotReady));
                Assert.That(coordinator.HasPhysicalClearObservation, Is.False);
                Assert.That(coordinator.StatusMessage, Does.Not.Contain("clear observed"));

                scope.Dispose();

                Assert.That(coordinator.IsDisposed, Is.True);
                Assert.That(coordinator.HasPhysicalClearObservation, Is.False);
            }
            finally
            {
                if (root != null) Object.DestroyImmediate(root);
            }
        }
    }
}
#endif
