using System;
using System.Linq;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    /// <summary>Runs against the real JSON loader and generated prefab contract after candidate integration.</summary>
    public sealed class F10RoomTemplateTests
    {
        private const string RouteResourcePath = "Luckbound/Data/Rooms/F10SampleRoute";
        private static readonly string[] ExpectedTemplateIds =
        {
            "room.sample.tutorial",
            "room.patio.c1",
            "room.patio.e1",
            "room.patio.guardian",
            "room.sample.extraction"
        };

        [TestCase("F10TutorialRoom", "room.sample.tutorial", 20, 12)]
        [TestCase("F10PatioCombatC1Room", "room.patio.c1", 44, 18)]
        [TestCase("F10PatioExplorationE1Room", "room.patio.e1", 46, 20)]
        [TestCase("F10PatioGuardianRoom", "room.patio.guardian", 20, 12)]
        [TestCase("F10SafeExtractionRoom", "room.sample.extraction", 20, 12)]
        public void EveryF10RoomDefinitionPassesTheProductionLoader(string fileName, string templateId,
            int widthTiles, int heightTiles)
        {
            TextAsset source = Resources.Load<TextAsset>("Luckbound/Data/Rooms/" + fileName);
            Assert.That(source, Is.Not.Null, "The integrated F10 JSON resource is missing: " + fileName);

            RoomTemplateData room = RoomTemplateJsonLoader.Load(source.text);

            Assert.That(room.templateId, Is.EqualTo(templateId));
            Assert.That(room.widthTiles, Is.EqualTo(widthTiles));
            Assert.That(room.heightTiles, Is.EqualTo(heightTiles));
            Assert.That(room.tileSize, Is.EqualTo(1f));
            Assert.That(room.widthTiles * room.tileSize, Is.GreaterThanOrEqualTo(20f));
            Assert.That(room.heightTiles * room.tileSize, Is.GreaterThanOrEqualTo(11.25f));
            Assert.That(room.ports.Select(port => port.id), Is.EquivalentTo(new[] { "port.entry.west", "port.exit.east" }));
            Assert.That(room.ports.All(port => port.clearanceTiles >= 3), Is.True);
            Assert.That(room.markers.Count(marker => marker.kind == "player_spawn"), Is.EqualTo(1));
            Assert.That(room.markers.Any(marker => marker.kind == "hazard"), Is.False,
                "F10 candidate rooms contain no provisional danger marker.");
        }

        [Test]
        public void F10RouteTemplateIdsAndRoomPortIdsAreIdentical()
        {
            TextAsset source = Resources.Load<TextAsset>(RouteResourcePath);
            Assert.That(source, Is.Not.Null);
            ExpeditionSampleRouteDefinition route = ExpeditionSampleRouteJsonLoader.Load(source.text);
            Assert.That(route.Nodes.Select(node => node.TemplateId), Is.EqualTo(ExpectedTemplateIds));
            Assert.That(route.Connections.Count, Is.EqualTo(4));
            Assert.That(route.Connections.Any(connection => connection.IsOptionalBranch), Is.False);

            foreach (string templateId in ExpectedTemplateIds)
            {
                TextAsset roomSource = LoadRoomSource(templateId);
                RoomTemplateData room = RoomTemplateJsonLoader.Load(roomSource.text);
                Assert.That(room.ports, Has.Length.EqualTo(2));
                Assert.That(room.ports.Select(port => port.id),
                    Is.EquivalentTo(new[] { "port.entry.west", "port.exit.east" }), templateId);
                RoomPortData entry = room.ports.Single(port => port.id == "port.entry.west");
                RoomPortData exit = room.ports.Single(port => port.id == "port.exit.east");
                Assert.That(entry.type, Is.EqualTo("entry"));
                Assert.That(entry.side, Is.EqualTo("west"));
                Assert.That(entry.tileX, Is.Zero);
                Assert.That(exit.type, Is.EqualTo("exit"));
                Assert.That(exit.side, Is.EqualTo("east"));
                Assert.That(exit.tileX, Is.EqualTo(room.widthTiles - 1));
            }
        }

        [Test]
        public void C1HasContinuousFloorAndExactlyTwoOneTileRaisedFeatures()
        {
            RoomTemplateData room = RoomTemplateJsonLoader.Load(LoadRoomSource("room.patio.c1").text);
            for (int x = 0; x < room.widthTiles; x++)
                Assert.That(RoomTemplateJsonLoader.GetCell(room, x, 0), Is.EqualTo('#'), "Base floor at x=" + x);

            int[] raisedCells = Enumerable.Range(0, room.widthTiles)
                .Where(x => RoomTemplateJsonLoader.GetCell(room, x, 1) == '#').ToArray();
            Assert.That(raisedCells, Is.EqualTo(new[] { 18, 19, 20, 29, 30, 31 }));
            Assert.That(raisedCells.All(x => RoomTemplateJsonLoader.GetCell(room, x, 2) == '.'), Is.True,
                "Both raised features are one tile tall.");
        }

        [Test]
        public void E1KeepsTheRequiredLowerRouteOpenAndLimitsItsRiseToTwoTiles()
        {
            RoomTemplateData room = RoomTemplateJsonLoader.Load(LoadRoomSource("room.patio.e1").text);
            int previousSurface = -1;
            for (int x = 0; x < room.widthTiles; x++)
            {
                int surface = x < 14 || x >= 24 ? 3 : 1;
                Assert.That(RoomTemplateJsonLoader.GetCell(room, x, surface - 1), Is.EqualTo('#'), "Route support at x=" + x);
                Assert.That(RoomTemplateJsonLoader.GetCell(room, x, surface), Is.EqualTo('.'), "Route feet space at x=" + x);
                Assert.That(RoomTemplateJsonLoader.GetCell(room, x, surface + 1), Is.EqualTo('.'), "Route headroom at x=" + x);
                if (previousSurface >= 0)
                    Assert.That(Math.Abs(surface - previousSurface), Is.LessThanOrEqualTo(2), "Route step at x=" + x);
                previousSurface = surface;
            }

            int[] stepSurfaces = { 4, 6, 8 };
            int[] stepStarts = { 14, 17, 20 };
            int[] stepEnds = { 17, 20, 23 };
            for (int index = 0; index < stepSurfaces.Length; index++)
            {
                int surface = stepSurfaces[index];
                int x = stepStarts[index];
                Assert.That(RoomTemplateJsonLoader.GetCell(room, x, surface - 1), Is.EqualTo('#'));
                if (index > 0)
                    Assert.That(surface - stepSurfaces[index - 1], Is.LessThanOrEqualTo(2));
                Assert.That(stepEnds[index] - stepStarts[index], Is.GreaterThanOrEqualTo(3));
            }

            RoomPositionMarkerData cache = room.markers.Single(marker => marker.kind == "treasure");
            Assert.That(cache.tileX, Is.EqualTo(21));
            Assert.That(cache.tileY, Is.EqualTo(8));
            Assert.That(RoomTemplateJsonLoader.GetCell(room, cache.tileX, cache.tileY - 1), Is.EqualTo('#'));
        }

        private static TextAsset LoadRoomSource(string templateId)
        {
            string fileName = templateId switch
            {
                "room.sample.tutorial" => "F10TutorialRoom",
                "room.patio.c1" => "F10PatioCombatC1Room",
                "room.patio.e1" => "F10PatioExplorationE1Room",
                "room.patio.guardian" => "F10PatioGuardianRoom",
                "room.sample.extraction" => "F10SafeExtractionRoom",
                _ => throw new ArgumentOutOfRangeException(nameof(templateId), templateId, "Unknown F10 room template.")
            };
            return Resources.Load<TextAsset>("Luckbound/Data/Rooms/" + fileName);
        }
    }
}
