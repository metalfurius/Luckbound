#if UNITY_EDITOR
using System;
using System.Linq;
using Luckbound.App;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Fortune;
using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Inventory;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10TechnicalRoomPaymentTests
    {
        private static readonly RunId TestRunId = new RunId(Guid.Parse("9dfc1e22-5306-44a6-a225-7d7000000001"));

        [Test]
        public void C1PaysEnemyAndRoomGoldWhileLeavingPhysicalMaterialDropsUnclaimed()
        {
            var request = new ExpeditionEncounterRewardRequest(TestRunId, 0u, 2,
                F10TechnicalEncounterPlanProvider.C1NodeId, F10TechnicalEncounterPlanProvider.C1TemplateId,
                "patio", ExpeditionRouteNodeKind.Combat,
                new[]
                {
                    new ExpeditionEncounterRewardSpawn("spawn.test.1", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.2", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.3", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.4", ExpeditionEncounterRewardEnemyKind.Normal)
                });
            ExpeditionEncounterRewardResolution resolution = ExpeditionEncounterRewardPolicy.Resolve(request);

            Assert.That(resolution.EnemyOutcomes.SelectMany(enemy => enemy.BaseMaterialGrants).Count(), Is.GreaterThan(0),
                "This fixed policy fixture must exercise the 50% physical material drop path.");
            Assert.That(ApplicationBootstrapper.TryCollectF10TechnicalPaymentValues(true, resolution,
                out int totalGold, out int renown, out string[] claims, out string error), Is.True, error);
            Assert.That(totalGold, Is.EqualTo(resolution.RoomPayout.Gold + resolution.EnemyOutcomes.Sum(enemy => enemy.TotalGold)));
            Assert.That(renown, Is.EqualTo(resolution.RoomPayout.Renown));

            string[] expectedClaims = resolution.EnemyOutcomes.Where(enemy => enemy.TotalGold > 0)
                .Select(enemy => enemy.GoldGrantId)
                .Concat(new[] { resolution.RoomPayout.GoldGrantId, resolution.RoomPayout.RenownGrantId })
                .OrderBy(id => id, StringComparer.Ordinal).ToArray();
            CollectionAssert.AreEqual(expectedClaims, claims);
            string[] physicalMaterialClaims = resolution.EnemyOutcomes
                .SelectMany(enemy => enemy.BaseMaterialGrants.Concat(enemy.VinculoMaterialGrants))
                .Select(grant => grant.GrantId).ToArray();
            Assert.That(claims.Intersect(physicalMaterialClaims, StringComparer.Ordinal), Is.Empty);

            TransactionId allClaimsTransaction = ApplicationBootstrapper.CreateF10TechnicalRoomTransactionId(
                resolution.ResolutionId, claims);
            TransactionId reorderedTransaction = ApplicationBootstrapper.CreateF10TechnicalRoomTransactionId(
                resolution.ResolutionId, claims.Reverse());
            TransactionId partialTransaction = ApplicationBootstrapper.CreateF10TechnicalRoomTransactionId(
                resolution.ResolutionId, claims.Take(claims.Length - 1));
            Assert.That(reorderedTransaction, Is.EqualTo(allClaimsTransaction));
            Assert.That(partialTransaction, Is.Not.EqualTo(allClaimsTransaction));
        }

        [Test]
        public void E1PaymentContainsOnlyRoomRenownAndKeepsCacheGoldAsSeparatePickup()
        {
            var request = new ExpeditionEncounterRewardRequest(TestRunId, 0u, 2,
                "sample.patio.exploration", "room.patio.e1", "patio", ExpeditionRouteNodeKind.Exploration,
                Array.Empty<ExpeditionEncounterRewardSpawn>(), hasExplorationCache: true,
                explorationCacheKey: ExplorationGoldCachePickup2D.F10MarkerId);
            ExpeditionEncounterRewardResolution resolution = ExpeditionEncounterRewardPolicy.Resolve(request);

            Assert.That(ApplicationBootstrapper.TryCollectF10TechnicalPaymentValues(false, resolution,
                out int totalGold, out int renown, out string[] claims, out string error), Is.True, error);
            Assert.That(totalGold, Is.Zero);
            Assert.That(renown, Is.EqualTo(3));
            CollectionAssert.AreEqual(new[] { resolution.RoomPayout.RenownGrantId }, claims);
            Assert.That(claims, Does.Not.Contain(resolution.ExplorationCacheReward.GoldGrantId));
        }

        [Test]
        public void E1CacheMayBeUncollectedOrHaveItsExactDurableClaimAfterPickupIsHidden()
        {
            Assert.That(ApplicationBootstrapper.IsF10E1CacheActorStateCoherent(
                pickupIsActiveAndEnabled: true, pickupActiveSelf: true, claimPersisted: false,
                matchingTransaction: false, anyCacheTransaction: false), Is.True);
            Assert.That(ApplicationBootstrapper.IsF10E1CacheActorStateCoherent(
                pickupIsActiveAndEnabled: false, pickupActiveSelf: false, claimPersisted: true,
                matchingTransaction: true, anyCacheTransaction: true), Is.True);
            Assert.That(ApplicationBootstrapper.IsF10E1CacheActorStateCoherent(
                pickupIsActiveAndEnabled: false, pickupActiveSelf: false, claimPersisted: false,
                matchingTransaction: false, anyCacheTransaction: false), Is.False);
            Assert.That(ApplicationBootstrapper.IsF10E1CacheActorStateCoherent(
                pickupIsActiveAndEnabled: false, pickupActiveSelf: false, claimPersisted: true,
                matchingTransaction: false, anyCacheTransaction: true), Is.False);
        }

        [Test]
        public void RoomClaimsAllowFreshAndExactReplayButRejectPartialClaimsAndOrphanTransactions()
        {
            string[] claims = { "room.gold", "room.renown", "enemy.gold" };
            Assert.That(ApplicationBootstrapper.TryClassifyF10RoomClaimState(claims,
                Array.Empty<string>(), transactionIdExists: false, transactionExpected: true,
                exactTransactionExists: false, out bool fresh), Is.True);
            Assert.That(fresh, Is.False);

            Assert.That(ApplicationBootstrapper.TryClassifyF10RoomClaimState(claims,
                claims, transactionIdExists: true, transactionExpected: true,
                exactTransactionExists: true, out bool replay), Is.True);
            Assert.That(replay, Is.True);
            Assert.That(ApplicationBootstrapper.TryClassifyF10RoomClaimState(claims,
                new[] { claims[0] }, transactionIdExists: false, transactionExpected: true,
                exactTransactionExists: false, out _), Is.False);
            Assert.That(ApplicationBootstrapper.TryClassifyF10RoomClaimState(claims,
                Array.Empty<string>(), transactionIdExists: true, transactionExpected: true,
                exactTransactionExists: true, out _), Is.False);

            Assert.That(ApplicationBootstrapper.TryClassifyF10RoomClaimState(claims,
                claims, transactionIdExists: false, transactionExpected: false,
                exactTransactionExists: false, out bool explorationReplay), Is.True);
            Assert.That(explorationReplay, Is.True);
        }

        [Test]
        public void GuardianPolicyPaymentClaimsGoldRenownAndChargeUnderOneStableTransactionSet()
        {
            var request = new ExpeditionEncounterRewardRequest(TestRunId, 0u, 2,
                F10TechnicalEncounterPlanProvider.GuardianNodeId,
                F10TechnicalEncounterPlanProvider.GuardianTemplateId, "patio",
                ExpeditionRouteNodeKind.Guardian,
                new[] { new ExpeditionEncounterRewardSpawn("guardian.custodian", ExpeditionEncounterRewardEnemyKind.Guardian) });
            ExpeditionEncounterRewardResolution resolution = ExpeditionEncounterRewardPolicy.Resolve(request);

            Assert.That(ApplicationBootstrapper.TryCollectF10GuardianPaymentValues(resolution,
                out int totalGold, out int renown, out string chargeGrantId,
                out string[] claims, out string error), Is.True, error);
            Assert.That(totalGold, Is.EqualTo(40));
            Assert.That(renown, Is.EqualTo(20));
            Assert.That(resolution.EnemyOutcomes[0].TotalGold, Is.EqualTo(40));
            Assert.That(resolution.RoomPayout.Gold, Is.Zero);
            Assert.That(resolution.RoomPayout.GoldGrantId, Is.Null);
            Assert.That(resolution.EnemyOutcomes[0].FortuneCharges, Is.EqualTo(1));
            Assert.That(chargeGrantId, Is.EqualTo(resolution.EnemyOutcomes[0].FortuneChargeGrantId));
            Assert.That(claims, Does.Contain(resolution.EnemyOutcomes[0].GoldGrantId));
            Assert.That(claims, Does.Contain(resolution.RoomPayout.RenownGrantId));
            Assert.That(claims, Does.Contain(chargeGrantId));
            Assert.That(claims, Has.Length.EqualTo(3));

            TransactionId allClaims = ApplicationBootstrapper.CreateF10TechnicalRoomTransactionId(
                resolution.ResolutionId, claims);
            TransactionId noChargeClaim = ApplicationBootstrapper.CreateF10TechnicalRoomTransactionId(
                resolution.ResolutionId, claims.Where(id => !string.Equals(id, chargeGrantId, StringComparison.Ordinal)));
            Assert.That(allClaims.IsValid, Is.True);
            Assert.That(noChargeClaim, Is.Not.EqualTo(allClaims));
        }

        [Test]
        public void GuardianClaimsGoldTransactionAndProcessedChargeMustReplayAsOneCompleteSet()
        {
            string[] claims = { "guardian.gold", "room.renown", "guardian.charge" };
            Assert.That(ApplicationBootstrapper.TryClassifyF10GuardianRewardState(claims,
                Array.Empty<string>(), transactionIdExists: false, exactGoldTransactionExists: false,
                guardianGrantPersisted: false, out bool fresh), Is.True);
            Assert.That(fresh, Is.False);
            Assert.That(ApplicationBootstrapper.TryClassifyF10GuardianRewardState(claims,
                claims, transactionIdExists: true, exactGoldTransactionExists: true,
                guardianGrantPersisted: true, out bool replay), Is.True);
            Assert.That(replay, Is.True);
            Assert.That(ApplicationBootstrapper.TryClassifyF10GuardianRewardState(claims,
                claims, transactionIdExists: true, exactGoldTransactionExists: true,
                guardianGrantPersisted: false, out _), Is.False);
            Assert.That(ApplicationBootstrapper.TryClassifyF10GuardianRewardState(claims,
                claims.Take(2), transactionIdExists: false, exactGoldTransactionExists: false,
                guardianGrantPersisted: false, out _), Is.False);
            Assert.That(ApplicationBootstrapper.TryClassifyF10GuardianRewardState(claims,
                Array.Empty<string>(), transactionIdExists: true, exactGoldTransactionExists: true,
                guardianGrantPersisted: false, out _), Is.False);
        }

        [Test]
        public void FortuneBookConsumesGuardianIdentityEvenWhenAtCapacityAndAfterRestore()
        {
            var book = new FortuneOfferBook(2, 0x1234u, "race.human");
            Assert.That(book.GrantGuardianCharge("guardian.fill").Status,
                Is.EqualTo(FortuneOperationStatus.Succeeded));
            Assert.That(book.CurrentCharges, Is.EqualTo(FortuneOfferBook.MaximumCharges));

            string guardianGrantId = "encounter-reward.v1:guardian-charge-at-cap";
            FortuneChargeResult capped = book.GrantGuardianCharge(guardianGrantId);
            Assert.That(capped.Status, Is.EqualTo(FortuneOperationStatus.RejectedAtCapacity));
            FortuneOfferBookSnapshot committed = book.CreateSnapshot();
            Assert.That(committed.processedGuardianIds, Does.Contain(guardianGrantId));
            Assert.That(committed.charges, Is.EqualTo(FortuneOfferBook.MaximumCharges));

            FortuneOfferBook restored = FortuneOfferBook.Restore(committed);
            Assert.That(restored.GrantGuardianCharge(guardianGrantId).Status,
                Is.EqualTo(FortuneOperationStatus.AlreadyApplied));
            CollectionAssert.AreEqual(committed.processedGuardianIds, restored.CreateSnapshot().processedGuardianIds);
        }
    }
}
#endif
