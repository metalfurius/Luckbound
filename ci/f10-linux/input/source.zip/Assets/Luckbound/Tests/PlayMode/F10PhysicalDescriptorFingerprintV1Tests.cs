#if UNITY_EDITOR
using Luckbound.App;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10PhysicalDescriptorFingerprintV1Tests
    {
        private const string Root = "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioCombatC1Diagnostic.prefab";
        private const string Source = "Assets/Resources/Luckbound/Data/Rooms/F10PatioCombatC1Room.json";
        private static readonly string Physical = new string('a', 64);
        private static readonly string Bundle = new string('b', 64);

        [Test]
        public void ComputesTheIndependentlyEncodedEightFieldVector()
        {
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, Source, Physical, Bundle, out string value), Is.True);
            Assert.That(value, Is.EqualTo("196c074b21a296abfcd3a1d3b30ee320289752beaa954f590a5b2f35e5149eab"));
        }

        [Test]
        public void ChangesInSourceOrBundleChangeTheFingerprint()
        {
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, Source, Physical, Bundle, out string original), Is.True);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, Source + ".different", Physical, Bundle, out string changedSource), Is.True);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, Source, Physical, new string('c', 64), out string changedBundle), Is.True);
            Assert.That(changedSource, Is.Not.EqualTo(original));
            Assert.That(changedBundle, Is.Not.EqualTo(original));
        }

        [Test]
        public void RejectsMissingRoomSourceNonCanonicalPathAndMalformedDigests()
        {
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, "", Physical, Bundle, out _), Is.False);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                "Assets/../player.prefab", Source, Physical, Bundle, out _), Is.False);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "room", 1,
                Root, Source, new string('A', 64), Bundle, out _), Is.False);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("room.patio.c1", "ROOM", 1,
                Root, Source, Physical, Bundle, out _), Is.False);
            Assert.That(F10PhysicalDescriptorFingerprintV1.TryCompute("enemy.slime", "enemy", 1,
                "Assets/Luckbound/Prefabs/CombatArena/SlimePrototype.prefab", "", Physical, Bundle,
                out string enemy), Is.True);
            Assert.That(enemy, Has.Length.EqualTo(64));
        }
    }
}
#endif
