#if UNITY_EDITOR
using System.Collections;
using System.IO;
using System.Threading.Tasks;
using Luckbound.App;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Saves;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10DiagnosticSessionTests
    {
        [UnityTest]
        public IEnumerator NewIsolatedSessionPersistsBeforeExposingItsRun()
        {
            Assert.That(ApplicationBootstrapper.Instance, Is.Null);
            Assert.That(ApplicationBootstrapper.EditorSaveStoreFactoryForTests, Is.Null);
            Assert.That(SceneManager.GetSceneByName("F10Diagnostic").IsValid(), Is.False);
            Scene previous = SceneManager.GetActiveScene();
            Scene technical = SceneManager.CreateScene("F10Diagnostic");
            Assert.That(SceneManager.SetActiveScene(technical), Is.True);
            ApplicationBootstrapper app = null;
            try
            {
                Task<ApplicationBootstrapper> begin = ApplicationBootstrapper.BeginF10DiagnosticSessionAsync();
                for (int frame = 0; frame < 600 && !begin.IsCompleted; frame++) yield return null;
                Assert.That(begin.IsCompleted, Is.True, "Starting the diagnostic session must finish.");
                Assert.That(begin.IsFaulted, Is.False, begin.Exception?.ToString());
                Assert.That(begin.IsCanceled, Is.False);
                app = begin.Result;

                Assert.That(app, Is.SameAs(ApplicationBootstrapper.Instance));
                Assert.That(app.SaveDataReady, Is.True);
                Assert.That(app.OwnsF10DiagnosticRun(app.ActiveRun), Is.True);
                Assert.That(app.ActiveRun.Route.GenerationVersion, Is.EqualTo(2));
                ApplicationBootstrapper.F10DiagnosticSessionWitness witness = app.F10DiagnosticWitness;
                Assert.That(witness, Is.Not.Null);
                string profilePath = witness.Store.GetPrimaryPath(SaveDocument.Profile);
                Assert.That(File.Exists(profilePath), Is.True);
                Assert.That(ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(
                    witness.StoreDirectory, Application.persistentDataPath), Is.True);
                Assert.That(SaveJsonCodec.Decode(File.ReadAllText(profilePath), out ProfileSaveEnvelope saved,
                    out int version), Is.EqualTo(DecodeStatus.Valid));
                Assert.That(version, Is.EqualTo(6));
                Assert.That(saved.activeExpedition.runId, Is.EqualTo(app.ActiveRun.RunId.ToString()));
                Assert.That(ApplicationBootstrapper.EditorSaveStoreFactoryForTests, Is.Null);

                ExpeditionRunConfiguration other = ExpeditionRunConfigurationFactory.CreateSample(
                    BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId,
                    new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
                Assert.That(app.OwnsF10DiagnosticRun(other), Is.False);
            }
            finally
            {
                if (app != null) Object.Destroy(app.gameObject);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
                if (technical.IsValid() && technical.isLoaded) SceneManager.UnloadSceneAsync(technical);
            }
        }

        [TestCase("F10Diagnostic", true)]
        [TestCase("Expedition", false)]
        [TestCase("Bootstrap", false)]
        [TestCase("f10diagnostic", false)]
        public void DiagnosticEntryRequiresTheExplicitTechnicalScene(string sceneName, bool expected)
        {
            Assert.That(ApplicationBootstrapper.IsF10DiagnosticScene(sceneName), Is.EqualTo(expected));
        }

        [Test]
        public void DiagnosticStoreMustNotOverlapPersistentDataPathInEitherDirection()
        {
            string root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "Luckbound", "F10DiagnosticSaves"));
            string session = Path.Combine(root, "session-a");
            string nestedPersistent = Path.Combine(session, "persistent");
            string separatePersistent = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "LuckboundPersistent"));

            Assert.That(ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(session, separatePersistent), Is.True);
            Assert.That(ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(session, root), Is.False);
            Assert.That(ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(session, nestedPersistent), Is.False);
            Assert.That(ApplicationBootstrapper.AreDiagnosticSavePathsDisjoint(null, separatePersistent), Is.False);
        }
    }
}
#endif
