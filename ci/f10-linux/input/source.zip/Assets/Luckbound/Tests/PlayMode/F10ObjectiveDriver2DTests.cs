using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10ObjectiveDriver2DTests
    {
        private readonly List<GameObject> _objects = new List<GameObject>();
        private Vector2 _previousGravity;
        private float _previousTimeScale;
        private float _previousFixedDeltaTime;
        private SimulationMode2D _previousSimulationMode;

        private enum Role { Tutorial, Exploration, Extraction }

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _previousGravity = Physics2D.gravity;
            _previousTimeScale = Time.timeScale;
            _previousFixedDeltaTime = Time.fixedDeltaTime;
            _previousSimulationMode = Physics2D.simulationMode;
            Physics2D.gravity = new Vector2(0f, -9.81f);
            Physics2D.simulationMode = SimulationMode2D.FixedUpdate;
            Time.fixedDeltaTime = 1f / 60f;
            Time.timeScale = 1f;
            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (GameObject gameObject in _objects)
            {
                if (gameObject == null) continue;
                ExpeditionRoomTransitionController controller = gameObject.GetComponent<ExpeditionRoomTransitionController>();
                if (controller != null) controller.Dispose();
            }
            foreach (GameObject gameObject in _objects)
                if (gameObject != null) Object.Destroy(gameObject);
            _objects.Clear();
            yield return null;
            Physics2D.gravity = _previousGravity;
            Physics2D.simulationMode = _previousSimulationMode;
            Time.fixedDeltaTime = _previousFixedDeltaTime;
            Time.timeScale = _previousTimeScale;
        }

        [UnityTest]
        public IEnumerator TutorialNeedsRealMoveThenNewInteractAndRetriesLocalHandoff()
        {
            Fixture fixture = CreateFixture("F10ObjectiveTutorial", Role.Tutorial);
            fixture.AddWalkway();
            Collider2D trigger = fixture.AddObjectiveTrigger(new Vector2(2.5f, 2.5f));
            var handoff = new RecordingHandoff { Accept = false };
            fixture.Attach(handoff);

            long before = fixture.Driver.LastDrainedCommandTick;
            fixture.Input.Press(PlayerAction.Interact);
            yield return WaitForCommandDrain(fixture, before);
            Assert.That(fixture.Driver.PendingHandoffCount, Is.Zero,
                "An Interact before movement, while physically far from the configured marker, is not proof.");

            fixture.Input.Release(PlayerAction.Interact);
            fixture.Input.SetMoveX(1f);
            float startX = fixture.PlayerBody.position.x;
            bool reached = false;
            for (int frame = 0; frame < 300; frame++)
            {
                yield return null;
                if (fixture.PlayerCollider.Distance(trigger).isValid && fixture.PlayerCollider.Distance(trigger).distance <= 0f)
                {
                    reached = true;
                    break;
                }
            }
            Assert.That(reached, Is.True, "The live motor and Rigidbody2D should reach the configured tutorial trigger.");
            fixture.Input.SetMoveX(0f);
            before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);
            Assert.That(fixture.PlayerBody.position.x, Is.GreaterThan(startX + 0.1f));
            Assert.That(fixture.Driver.HasEffectiveTutorialMovement, Is.True);
            Assert.That(fixture.Driver.PendingHandoffCount, Is.Zero,
                "Movement alone does not complete the tutorial.");

            before = fixture.Driver.LastDrainedCommandTick;
            fixture.Input.Press(PlayerAction.Interact);
            yield return WaitForCommandDrain(fixture, before);
            for (int frame = 0; frame < 4; frame++) yield return null;
            Assert.That(fixture.Driver.PendingHandoffCount, Is.EqualTo(1));
            Assert.That(handoff.Attempts.Count, Is.GreaterThan(1), "Declined local handoffs remain pending for retry.");
            Assert.That(handoff.Attempts.Select(item => item.ObservationId).Distinct().Count(), Is.EqualTo(1),
                "Retries retain a stable local deduplication key.");

            handoff.Accept = true;
            for (int frame = 0; frame < 8 && fixture.Driver.PendingHandoffCount > 0; frame++) yield return null;
            Assert.That(fixture.Driver.PendingHandoffCount, Is.Zero);
            Assert.That(handoff.Accepted.Single().Kind, Is.EqualTo(F10ObjectiveObservationKind.TutorialCompleted));
            yield return null;
        }

        [UnityTest]
        public IEnumerator OnlyTheExactObservationBeingDeliveredHasHandoffAuthority()
        {
            Fixture fixture = CreateFixture("F10ObjectiveDeliveryAuthority", Role.Extraction);
            fixture.AddWalkway();
            Collider2D trigger = fixture.AddObjectiveTrigger(new Vector2(2f, 2.5f));
            var handoff = new DeliveryAuthorityHandoff(fixture.Context);
            fixture.Attach(handoff);
            handoff.Driver = fixture.Driver;
            fixture.Input.SetMoveX(1f);
            bool reached = false;
            for (int frame = 0; frame < 240; frame++)
            {
                yield return null;
                ColliderDistance2D distance = fixture.PlayerCollider.Distance(trigger);
                if (distance.isValid && distance.distance <= 0f) { reached = true; break; }
            }
            Assert.That(reached, Is.True);
            fixture.Input.SetMoveX(0f);
            long before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);
            fixture.Input.Press(PlayerAction.Interact);
            for (int frame = 0; frame < 30 && handoff.Count == 0; frame++) yield return null;
            Assert.That(handoff.Count, Is.EqualTo(1));
            Assert.That(handoff.AuthenticAccepted, Is.True);
            Assert.That(handoff.CloneHadSameId, Is.True);
            Assert.That(handoff.CloneAccepted, Is.False);
            Assert.That(handoff.WrongRecipientAccepted, Is.False);
            Assert.That(fixture.Driver.IsDeliveringTo(handoff, handoff.Observed), Is.False,
                "Authority expires as soon as the callback returns.");
        }

        [UnityTest]
        public IEnumerator AcceptedHandoffCanDisposeItsRoomSynchronously()
        {
            Fixture fixture = CreateFixture("F10ObjectiveExtractionDisposal", Role.Extraction);
            fixture.AddWalkway();
            Collider2D trigger = fixture.AddObjectiveTrigger(new Vector2(2f, 2.5f));
            var handoff = new DisposingHandoff(fixture.Scope);
            fixture.Attach(handoff);
            fixture.Input.SetMoveX(1f);
            bool reached = false;
            for (int frame = 0; frame < 240; frame++)
            {
                yield return null;
                ColliderDistance2D distance = fixture.PlayerCollider.Distance(trigger);
                if (distance.isValid && distance.distance <= 0f) { reached = true; break; }
            }
            Assert.That(reached, Is.True, "The player must reach the extraction marker physically.");
            fixture.Input.SetMoveX(0f);
            long before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);
            fixture.Input.Press(PlayerAction.Interact);
            for (int frame = 0; frame < 30 && !fixture.Driver.IsDisposed; frame++) yield return null;
            Assert.That(handoff.Count, Is.EqualTo(1));
            Assert.That(fixture.Driver.IsDisposed, Is.True);
            Assert.That(fixture.Driver.PendingHandoffCount, Is.Zero);
        }

        [UnityTest]
        public IEnumerator ExtractionAcceptsOnlyNearbyNewInteractAndNeverAdvancesRoute()
        {
            Fixture fixture = CreateFixture("F10ObjectiveExtraction", Role.Extraction);
            fixture.AddWalkway();
            Collider2D trigger = fixture.AddObjectiveTrigger(new Vector2(2f, 2.5f));
            var handoff = new RecordingHandoff { Accept = true };
            fixture.Attach(handoff);
            string nodeBefore = fixture.Controller.CurrentNodeId;
            RoomInstanceId roomBefore = fixture.Controller.CurrentRoomId;

            fixture.Input.Press(PlayerAction.Interact);
            long before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);
            Assert.That(handoff.Accepted, Is.Empty, "The extraction request requires current physical overlap.");
            fixture.Input.Release(PlayerAction.Interact);
            fixture.Input.SetMoveX(1f);
            bool reached = false;
            for (int frame = 0; frame < 240; frame++)
            {
                yield return null;
                ColliderDistance2D distance = fixture.PlayerCollider.Distance(trigger);
                if (distance.isValid && distance.distance <= 0f) { reached = true; break; }
            }
            Assert.That(reached, Is.True);
            fixture.Input.SetMoveX(0f);
            before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);
            fixture.Input.Press(PlayerAction.Interact);
            before = fixture.Driver.LastDrainedCommandTick;
            yield return WaitForCommandDrain(fixture, before);

            Assert.That(handoff.Accepted.Count, Is.EqualTo(1));
            Assert.That(handoff.Accepted[0].Kind,
                Is.EqualTo(F10ObjectiveObservationKind.ExtractionInteractionRequested));
            Assert.That(fixture.Controller.CurrentNodeId, Is.EqualTo(nodeBefore));
            Assert.That(fixture.Controller.CurrentRoomId, Is.EqualTo(roomBefore));
            yield return null;
        }

        [UnityTest]
        public IEnumerator ValidRealE1AndExtractionMarkersAttachButWrongRoomRoleIsRejected()
        {
            Fixture e1 = CreateFixture("F10ObjectiveE1", Role.Exploration);
            e1.AddObjectiveTrigger(new Vector2(1.5f, 2f));
            e1.Attach();
            Assert.That(e1.Driver, Is.Not.Null);

            Fixture extraction = CreateFixture("F10ObjectiveExtractionMarker", Role.Extraction);
            Collider2D extractionTrigger = extraction.AddObjectiveTrigger(new Vector2(2f, 2f));
            extraction.Attach();
            Assert.That(extraction.Driver, Is.Not.Null);

            Fixture wrongRoom = CreateFixture("F10ObjectiveWrongRole", Role.Exploration);
            Collider2D wrongRoleCollider = wrongRoom.AddObjectiveTrigger(new Vector2(1f, 2f));
            Assert.Throws<InvalidOperationException>(() => F10ObjectiveDriver2D.Prepare(
                wrongRoom.Context, wrongRoom.Source, wrongRoom.PlayerCollider,
                wrongRoleCollider, null, null));
            Assert.That(extractionTrigger, Is.Not.Null);
            yield return null;
        }

        [UnityTest]
        public IEnumerator RealE1AndExtractionFixturesRejectMarkerColliderParentAndDisabledMutations()
        {
            string[] mutations = { "marker-shift", "marker-disabled", "duplicate-marker", "collider-shift", "collider-reparent", "collider-disabled" };
            foreach (string mutation in mutations)
            {
                Fixture fixture = CreateFixture("F10ObjectiveInvalid_" + mutation, Role.Exploration);
                Collider2D trigger = fixture.AddObjectiveTrigger(new Vector2(1.5f, 2f));
                RoomPositionMarker2D marker = fixture.ObjectiveMarker;
                switch (mutation)
                {
                    case "marker-shift": marker.transform.position += Vector3.right; break;
                    case "marker-disabled": marker.enabled = false; break;
                    case "duplicate-marker":
                        var duplicate = Track(new GameObject("duplicate exit marker"));
                        duplicate.transform.SetParent(fixture.Scope.transform, false);
                        duplicate.transform.position = marker.transform.position;
                        duplicate.AddComponent<RoomPositionMarker2D>().Configure("exit.trigger", "exit_trigger", 43, 3);
                        break;
                    case "collider-shift": trigger.transform.position += Vector3.right; break;
                    case "collider-reparent": trigger.transform.SetParent(fixture.Scope.transform, true); break;
                    case "collider-disabled": trigger.enabled = false; break;
                }
                Assert.Throws<InvalidOperationException>(() => fixture.Attach(), mutation);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ConsumedCommandsAreDeduplicatedAcrossTicksAndDrainRechecksGates()
        {
            Fixture fixture = CreateFixture("F10ObjectiveQueue", Role.Tutorial);
            fixture.AddObjectiveTrigger(new Vector2(2f, 2f));
            fixture.Attach();
            MethodInfo fixedUpdate = FindFixedUpdate();
            for (int tick = 0; tick < 3; tick++) fixedUpdate.Invoke(fixture.Player, null);
            Assert.That(fixture.Player.LastConsumedCommand.Tick, Is.EqualTo(2));
            Assert.That(fixture.Driver.PendingFactCount, Is.EqualTo(3));
            MethodInfo observer = typeof(F10ObjectiveDriver2D).GetMethod("OnCommandConsumed", BindingFlags.Instance | BindingFlags.NonPublic);
            observer.Invoke(fixture.Driver, new object[] { fixture.Player, fixture.Player.LastConsumedCommand });
            Assert.That(fixture.Driver.PendingFactCount, Is.EqualTo(3), "ActorId plus Tick deduplicates a repeated event.");

            fixture.Source.Current = CreateSnapshot(fixture.Context, ready: true, paused: true);
            fixture.Driver.DrainAfterPhysics();
            Assert.That(fixture.Driver.PendingFactCount, Is.Zero, "A closed readiness gate discards queued commands.");
            Assert.That(fixture.Driver.LastDrainedCommandTick, Is.LessThan(0));

            Fixture mutated = CreateFixture("F10ObjectiveDrainRevalidation", Role.Tutorial);
            mutated.AddObjectiveTrigger(new Vector2(2f, 2f));
            mutated.Attach();
            fixedUpdate.Invoke(mutated.Player, null);
            Assert.That(mutated.Driver.PendingFactCount, Is.EqualTo(1));
            mutated.ObjectiveMarker.transform.position += Vector3.right;
            mutated.Driver.DrainAfterPhysics();
            Assert.That(mutated.Driver.IsDisposed, Is.True,
                "A marker moved after command capture invalidates the activation before drain.");
            Assert.That(mutated.Driver.PendingFactCount, Is.Zero);

            Fixture capture = CreateFixture("F10ObjectiveCaptureRevalidation", Role.Exploration);
            Collider2D movedCollider = capture.AddObjectiveTrigger(new Vector2(1.5f, 2f));
            capture.Attach();
            movedCollider.transform.position += Vector3.right;
            fixedUpdate.Invoke(capture.Player, null);
            Assert.That(capture.Driver.IsFaulted, Is.True,
                "The exact source collider is revalidated when a consumed command is captured.");
            yield return null;
        }

        [UnityTest]
        public IEnumerator FullFiniteQueueFailsClosedAndScopeDisposalCancelsSubscriptions()
        {
            Fixture overflow = CreateFixture("F10ObjectiveOverflow", Role.Tutorial);
            overflow.AddObjectiveTrigger(new Vector2(2f, 2f));
            overflow.Attach();
            MethodInfo fixedUpdate = FindFixedUpdate();
            for (int tick = 0; tick < F10ObjectiveDriver2D.QueueCapacity + 1; tick++) fixedUpdate.Invoke(overflow.Player, null);
            Assert.That(overflow.Driver.IsFaulted, Is.True);
            Assert.That(overflow.Driver.IsDisposed, Is.True);
            Assert.That(overflow.Driver.PendingFactCount, Is.Zero);

            Fixture disposed = CreateFixture("F10ObjectiveDisposed", Role.Tutorial);
            disposed.AddObjectiveTrigger(new Vector2(2f, 2f));
            disposed.Attach();
            fixedUpdate.Invoke(disposed.Player, null);
            Assert.That(disposed.Driver.PendingFactCount, Is.EqualTo(1));
            disposed.Scope.Dispose();
            Assert.That(disposed.Driver.IsDisposed, Is.True);
            Assert.That(disposed.Driver.PendingFactCount, Is.Zero);
            yield return null;
        }

        private Fixture CreateFixture(string name, Role role)
        {
            string nodeId = role == Role.Tutorial ? "sample.tutorial" :
                role == Role.Exploration ? "sample.patio.exploration" : "sample.safe_extraction";
            string templateId = role == Role.Tutorial ? "room.sample.tutorial" :
                role == Role.Exploration ? "room.patio.e1" : "room.sample.extraction";
            string resource = role == Role.Tutorial ? "F10TutorialRoom" :
                role == Role.Exploration ? "F10PatioExplorationE1Room" : "F10SafeExtractionRoom";
            TextAsset source = Resources.Load<TextAsset>("Luckbound/Data/Rooms/" + resource);
            Assert.That(source, Is.Not.Null, "The fixture must load the actual F10 room resource.");
            RoomTemplateData data = RoomTemplateJsonLoader.Load(source.text);
            Assert.That(data.templateId, Is.EqualTo(templateId));

            string[] skills = { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId };
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId, skills, 2, 2, 1);
            var input = new PlayerInputBuffer(ActorId.New());
            GameObject playerObject = Track(new GameObject(name + " player"));
            Rigidbody2D body = playerObject.AddComponent<Rigidbody2D>();
            body.gravityScale = 3f;
            body.sleepMode = RigidbodySleepMode2D.NeverSleep;
            CapsuleCollider2D playerCollider = playerObject.AddComponent<CapsuleCollider2D>();
            playerCollider.direction = CapsuleDirection2D.Vertical;
            playerCollider.size = new Vector2(0.75f, 1.5f);
            PlayerMotor2D motor = playerObject.AddComponent<PlayerMotor2D>();
            motor.Initialize(input.ActorId, input, 1 << LayerMask.NameToLayer("Default"));

            GameObject prefab = Track(CreateRoomPrefab(name + " prefab", source, data));
            GameObject controllerObject = Track(new GameObject(name + " controller"));
            ExpeditionRoomTransitionController controller = controllerObject.AddComponent<ExpeditionRoomTransitionController>();
            int targetIndex = run.Route.MandatoryNodeIds.ToList().IndexOf(nodeId);
            Assert.That(targetIndex, Is.GreaterThanOrEqualTo(0));
            controller.Initialize(run.RunId, run.Route, _ => prefab, playerObject.transform,
                run.Route.MandatoryNodeIds.Take(targetIndex + 1));
            ExpeditionRouteNode node = run.Route.Nodes.Single(candidate => candidate.NodeId == nodeId);
            RoomEncounterRuntimeContext context = RoomEncounterRuntimeContext.Create(
                run.RunId, node.NodeId, node.TemplateId, controller.CurrentRoomId,
                controller.ActiveScope, controller, motor, plan: null,
                routeGenerationVersion: run.Route.GenerationVersion);
            var sourceSnapshot = new MutableSnapshotSource
            {
                BoundContext = context,
                Current = CreateSnapshot(context, ready: true)
            };
            string markerId = role == Role.Tutorial ? "tutorial.interaction" :
                role == Role.Exploration ? "exit.trigger" : "extraction.interact";
            RoomPositionMarker2D marker = controller.ActiveScope.GetComponentsInChildren<RoomPositionMarker2D>(true)
                .Single(item => item.MarkerId == markerId);
            return new Fixture(controller, motor, playerCollider, body, input, context, sourceSnapshot, marker, _objects);
        }

        private GameObject CreateRoomPrefab(string name, TextAsset source, RoomTemplateData data)
        {
            var prefab = new GameObject(name);
            prefab.AddComponent<RoomTemplatePrefab2D>().Configure(source, null, null, null);
            foreach (RoomPositionMarkerData definition in data.markers)
            {
                var markerObject = new GameObject(definition.id);
                markerObject.transform.SetParent(prefab.transform, false);
                markerObject.transform.localPosition = new Vector3((definition.tileX + 0.5f) * data.tileSize,
                    definition.tileY * data.tileSize, 0f);
                markerObject.AddComponent<RoomPositionMarker2D>().Configure(
                    definition.id, definition.kind, definition.tileX, definition.tileY);
            }
            return prefab;
        }

        private GameObject Track(GameObject gameObject)
        {
            _objects.Add(gameObject);
            return gameObject;
        }

        private static IEnumerator WaitForCommandDrain(Fixture fixture, long previousTick, int maximumFrames = 30)
        {
            for (int frame = 0; frame < maximumFrames; frame++)
            {
                if (fixture.Driver.LastDrainedCommandTick > previousTick) yield break;
                yield return null;
            }
            Assert.Fail("Timed out waiting for a bounded post-physics command drain.");
        }

        private static RoomEncounterRuntimeSessionSnapshot CreateSnapshot(
            RoomEncounterRuntimeContext context, bool ready, bool paused = false)
        {
            return new RoomEncounterRuntimeSessionSnapshot(context.RunId, context.NodeId,
                context.TemplateId, context.RouteGenerationVersion, context.RoomInstanceId,
                context.Scope, context.Controller, context.Player, context.ActivationGeneration,
                isSessionActive: true, hasBoundPlayer: ready, hasCheckpointBinding: ready,
                hasPublishedSession: ready, hasRequiredGameplayBindings: ready,
                roomCommitAndActivationComplete: ready, hasPendingSessionMutation: false,
                isRoomAdvanceInFlight: false, hasPendingCommitOrActivation: false,
                hasPendingSimulationLeaseOrGate: paused, isSimulationPaused: paused);
        }

        private static MethodInfo FindFixedUpdate()
        {
            MethodInfo method = typeof(PlayerMotor2D).GetMethod("FixedUpdate", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(method, Is.Not.Null);
            return method;
        }

        private sealed class Fixture
        {
            internal Fixture(ExpeditionRoomTransitionController controller, PlayerMotor2D player,
                Collider2D playerCollider, Rigidbody2D playerBody, PlayerInputBuffer input,
                RoomEncounterRuntimeContext context, MutableSnapshotSource source, RoomPositionMarker2D marker,
                List<GameObject> ownedObjects)
            {
                Controller = controller;
                Player = player;
                PlayerCollider = playerCollider;
                PlayerBody = playerBody;
                Input = input;
                Context = context;
                Source = source;
                ObjectiveMarker = marker;
                OwnedObjects = ownedObjects;
            }

            internal ExpeditionRoomTransitionController Controller { get; }
            internal RoomLifetimeScope Scope => Context.Scope;
            internal PlayerMotor2D Player { get; }
            internal Collider2D PlayerCollider { get; }
            internal Rigidbody2D PlayerBody { get; }
            internal PlayerInputBuffer Input { get; }
            internal RoomEncounterRuntimeContext Context { get; }
            internal MutableSnapshotSource Source { get; }
            internal RoomPositionMarker2D ObjectiveMarker { get; }
            private List<GameObject> OwnedObjects { get; }
            internal F10ObjectiveDriver2D Driver { get; private set; }

            internal Collider2D AddObjectiveTrigger(Vector2 size)
            {
                var triggerObject = new GameObject(ObjectiveMarker.MarkerId + " trigger");
                triggerObject.transform.SetParent(ObjectiveMarker.transform, false);
                BoxCollider2D trigger = triggerObject.AddComponent<BoxCollider2D>();
                trigger.isTrigger = true;
                trigger.size = size;
                return trigger;
            }

            internal void AddWalkway()
            {
                float width = Context.TemplateId == "room.patio.e1" ? 50f : 25f;
                var floor = new GameObject("test walkway");
                OwnedObjects.Add(floor);
                floor.transform.position = new Vector2(width * 0.5f, -0.5f);
                BoxCollider2D collider = floor.AddComponent<BoxCollider2D>();
                collider.size = new Vector2(width, 1f);
            }

            internal void Attach(IF10ObjectiveObservationHandoff handoff = null)
            {
                Collider2D[] colliders = ObjectiveMarker.GetComponentsInChildren<Collider2D>(true);
                if (colliders.Length != 1) throw new InvalidOperationException("Fixture requires one configured objective trigger.");
                bool tutorial = Context.NodeId == "sample.tutorial";
                bool exploration = Context.NodeId == "sample.patio.exploration";
                Driver = F10ObjectiveDriver2D.Prepare(Context, Source, PlayerCollider,
                    tutorial ? colliders[0] : null, exploration ? colliders[0] : null,
                    !tutorial && !exploration ? colliders[0] : null, handoff);
            }
        }

        private sealed class MutableSnapshotSource : IRoomEncounterRuntimeSessionSnapshotSource
        {
            internal RoomEncounterRuntimeContext BoundContext;
            internal RoomEncounterRuntimeSessionSnapshot Current;
            public bool TryCapture(RoomEncounterRuntimeContext context, out RoomEncounterRuntimeSessionSnapshot snapshot)
            {
                snapshot = Current;
                return ReferenceEquals(context, BoundContext) && snapshot.IsInitialized;
            }
        }

        private sealed class DeliveryAuthorityHandoff : IF10ObjectiveObservationHandoff
        {
            private readonly RoomEncounterRuntimeContext _context;
            internal F10ObjectiveDriver2D Driver;
            internal F10ObjectiveObservation Observed;
            internal int Count;
            internal bool AuthenticAccepted;
            internal bool CloneHadSameId;
            internal bool CloneAccepted;
            internal bool WrongRecipientAccepted;
            internal DeliveryAuthorityHandoff(RoomEncounterRuntimeContext context) { _context = context; }
            public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
            {
                Count++;
                Observed = observation;
                var clone = new F10ObjectiveObservation(observation.Kind, _context, observation.ActorId, observation.Tick);
                AuthenticAccepted = Driver.IsDeliveringTo(this, observation);
                CloneHadSameId = clone.ObservationId == observation.ObservationId;
                CloneAccepted = Driver.IsDeliveringTo(this, clone);
                WrongRecipientAccepted = Driver.IsDeliveringTo(new RecordingHandoff(), observation);
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
        }

        private sealed class DisposingHandoff : IF10ObjectiveObservationHandoff
        {
            private readonly RoomLifetimeScope _scope;
            internal int Count;
            internal DisposingHandoff(RoomLifetimeScope scope) { _scope = scope; }
            public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
            {
                Count++;
                _scope.Dispose();
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
        }

        private sealed class RecordingHandoff : IF10ObjectiveObservationHandoff
        {
            internal bool Accept;
            internal readonly List<F10ObjectiveObservation> Attempts = new List<F10ObjectiveObservation>();
            internal readonly List<F10ObjectiveObservation> Accepted = new List<F10ObjectiveObservation>();
            public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
            {
                Attempts.Add(observation);
                if (!Accept) return F10ObjectiveHandoffResult.RetryLater;
                Accepted.Add(observation);
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
        }
    }
}
