using System.Collections;
using System.Collections.Generic;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Luckbound.Tests.PlayMode
{
    public sealed class ExplorationGoldCachePickupTests
    {
        private readonly List<GameObject> _objects = new List<GameObject>();
        private Vector2 _previousGravity;
        private float _previousTimeScale;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _previousGravity = Physics2D.gravity;
            _previousTimeScale = Time.timeScale;
            Physics2D.gravity = new Vector2(0f, -9.81f);
            Time.timeScale = 1f;
            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (GameObject item in _objects)
                if (item != null) Object.Destroy(item);
            _objects.Clear();
            yield return null;
            Physics2D.gravity = _previousGravity;
            Time.timeScale = _previousTimeScale;
        }

        [UnityTest]
        public IEnumerator RealPlayerContactRequestsOnceAndCanRetryOnlyAfterRejection()
        {
            Fixture fixture = CreateFixture();
            var contacts = new List<ExplorationGoldCacheContact>();
            fixture.Pickup.ContactRequested += contact =>
            {
                contacts.Add(contact);
                fixture.Input.SetMoveX(0f);
            };

            fixture.Input.SetMoveX(1f);
            for (int tick = 0; tick < 240 && contacts.Count == 0; tick++)
                yield return new WaitForFixedUpdate();

            Assert.That(contacts.Count, Is.EqualTo(1), "A moving player must physically reach the cache trigger.");
            Assert.That(contacts[0].Player, Is.SameAs(fixture.Player));
            Assert.That(contacts[0].Scope, Is.SameAs(fixture.Scope));
            Assert.That(contacts[0].Marker, Is.SameAs(fixture.Marker));
            Assert.That(contacts[0].CacheId, Is.EqualTo("cache.fixture.e1"));
            Assert.That(contacts[0].ActivationGeneration, Is.EqualTo(17));
            Assert.That(fixture.Pickup.IsPendingContactCurrent(contacts[0]), Is.True);
            Assert.That(fixture.Scope.OwnedActorCount, Is.EqualTo(1), "The room owns the cache actor.");
            fixture.Marker.Configure("cache.changed", "treasure", 0, 0);
            Assert.That(fixture.Pickup.IsPendingContactCurrent(contacts[0]), Is.False,
                "A changed marker cannot validate the captured contact.");
            fixture.Marker.Configure("cache.exploration", "treasure", 0, 0);

            for (int tick = 0; tick < 3; tick++) yield return new WaitForFixedUpdate();
            Assert.That(contacts.Count, Is.EqualTo(1), "Stay and multiple colliders must not duplicate a pending request.");
            Assert.That(fixture.Pickup.HasPendingContact, Is.True);
            Assert.That(fixture.Pickup.gameObject.activeInHierarchy, Is.True,
                "Contact alone must not consume a cache or grant gold.");

            Assert.That(fixture.Pickup.ReleaseRejectedContact(contacts[0]), Is.True);
            for (int tick = 0; tick < 5 && contacts.Count < 2; tick++) yield return new WaitForFixedUpdate();
            Assert.That(contacts.Count, Is.EqualTo(2), "A rejected contact may be retried while the player remains touching.");
            Assert.That(contacts[1].Sequence, Is.GreaterThan(contacts[0].Sequence));
            Assert.That(fixture.Pickup.ReleaseRejectedContact(contacts[0]), Is.False,
                "An old callback cannot release a newer pending contact.");

            fixture.Scope.Dispose();
            Assert.That(fixture.Pickup.IsPendingContactCurrent(contacts[1]), Is.False);
            Assert.That(fixture.Pickup.ReleaseRejectedContact(contacts[1]), Is.False);
            yield return null;
        }

        [UnityTest]
        public IEnumerator NoConsumerDoesNotConsumeTheCacheAndStayCanRequestLater()
        {
            Fixture fixture = CreateFixture();
            fixture.Input.SetMoveX(1f);
            for (int tick = 0; tick < 240 && fixture.Player.transform.position.x < -1.5f; tick++)
                yield return new WaitForFixedUpdate();
            fixture.Input.SetMoveX(0f);
            Assert.That(fixture.Player.transform.position.x, Is.GreaterThanOrEqualTo(-1.5f));
            Assert.That(fixture.Pickup.HasPendingContact, Is.False);
            Assert.That(fixture.Pickup.gameObject.activeInHierarchy, Is.True);

            int requests = 0;
            fixture.Pickup.ContactRequested += _ => requests++;
            for (int tick = 0; tick < 10 && requests == 0; tick++) yield return new WaitForFixedUpdate();
            Assert.That(requests, Is.EqualTo(1), "A later owner may observe a real ongoing contact.");
            Assert.That(fixture.Pickup.HasPendingContact, Is.True);
        }

        [UnityTest]
        public IEnumerator ImmediateRejectionDoesNotDuplicateContactsWithinOnePhysicsTick()
        {
            Fixture fixture = CreateFixture();
            var observedTicks = new HashSet<double>();
            int duplicateTicks = 0;
            fixture.Pickup.ContactRequested += contact =>
            {
                if (!observedTicks.Add(contact.CapturedFixedTime)) duplicateTicks++;
                fixture.Input.SetMoveX(0f);
                fixture.Pickup.ReleaseRejectedContact(contact);
            };

            fixture.Input.SetMoveX(1f);
            for (int tick = 0; tick < 240 && observedTicks.Count == 0; tick++)
                yield return new WaitForFixedUpdate();
            Assert.That(observedTicks.Count, Is.GreaterThan(0), "The player must physically reach the cache.");
            for (int tick = 0; tick < 4; tick++) yield return new WaitForFixedUpdate();
            CapsuleCollider2D[] playerColliders = fixture.Player.GetComponents<CapsuleCollider2D>();
            Collider2D cacheTrigger = fixture.Pickup.GetComponent<Collider2D>();
            Assert.That(playerColliders.Length, Is.EqualTo(2));
            Assert.That(cacheTrigger.IsTouching(playerColliders[0]), Is.True, "First player collider must touch the cache.");
            Assert.That(cacheTrigger.IsTouching(playerColliders[1]), Is.True, "Second player collider must also touch the cache.");
            Assert.That(duplicateTicks, Is.Zero, "Two player colliders cannot emit twice in one physics tick.");
        }

        [UnityTest]
        public IEnumerator PlayerChildWithIndependentBodyCannotRequest()
        {
            Fixture fixture = CreateFixture();
            int requests = 0;
            fixture.Pickup.ContactRequested += _ => requests++;
            GameObject child = new GameObject("Independent child body");
            child.transform.SetParent(fixture.Player.transform, false);
            child.transform.position = fixture.Marker.transform.position;
            Rigidbody2D body = child.AddComponent<Rigidbody2D>();
            body.gravityScale = 0f;
            BoxCollider2D collider = child.AddComponent<BoxCollider2D>();

            for (int tick = 0; tick < 5; tick++) yield return new WaitForFixedUpdate();
            Assert.That(fixture.Pickup.GetComponent<Collider2D>().IsTouching(collider), Is.True,
                "The independent child collider must physically touch the cache.");
            Assert.That(collider.attachedRigidbody, Is.SameAs(body));
            Assert.That(collider.attachedRigidbody, Is.Not.SameAs(fixture.Player.GetComponent<Rigidbody2D>()));
            Assert.That(requests, Is.Zero);
            Assert.That(fixture.Pickup.HasPendingContact, Is.False);
        }

        [UnityTest]
        public IEnumerator UnconfiguredActorCannotRequestAndDisposedRoomCannotRearm()
        {
            Fixture fixture = CreateFixture();
            int requests = 0;
            fixture.Pickup.ContactRequested += _ => requests++;
            GameObject unrelated = Track(new GameObject("Unrelated physical collider"));
            unrelated.transform.position = new Vector3(3f, 1f, 0f);
            Rigidbody2D body = unrelated.AddComponent<Rigidbody2D>();
            body.gravityScale = 0f;
            body.linearVelocity = new Vector2(-3f, 0f);
            unrelated.AddComponent<BoxCollider2D>();

            for (int tick = 0; tick < 120 && unrelated.transform.position.x > -0.5f; tick++)
                yield return new WaitForFixedUpdate();
            Assert.That(unrelated.transform.position.x, Is.LessThan(0f),
                "The unrelated collider must physically cross the trigger.");
            Assert.That(requests, Is.Zero);
            Assert.That(fixture.Pickup.HasPendingContact, Is.False);

            fixture.Scope.Dispose();
            fixture.Input.SetMoveX(1f);
            for (int tick = 0; tick < 30; tick++) yield return new WaitForFixedUpdate();
            Assert.That(requests, Is.Zero, "A disposed room cannot issue a new request.");
        }

        private Fixture CreateFixture()
        {
            GameObject scopeObject = Track(new GameObject("Cache test room"));
            RoomLifetimeScope scope = scopeObject.AddComponent<RoomLifetimeScope>();
            scope.Initialize(RoomInstanceId.New(), "room.fixture.e1");

            GameObject ground = Track(new GameObject("Ground"));
            ground.layer = 0;
            ground.transform.position = new Vector3(0f, -0.5f, 0f);
            BoxCollider2D groundCollider = ground.AddComponent<BoxCollider2D>();
            groundCollider.size = new Vector2(20f, 1f);

            GameObject playerObject = Track(new GameObject("Configured player"));
            playerObject.transform.position = new Vector3(-3f, 1.1f, 0f);
            playerObject.AddComponent<Rigidbody2D>();
            CapsuleCollider2D first = playerObject.AddComponent<CapsuleCollider2D>();
            CapsuleCollider2D extra = playerObject.AddComponent<CapsuleCollider2D>();
            extra.size = first.size;
            extra.offset = first.offset;
            extra.direction = first.direction;
            ActorId actorId = ActorId.New();
            var input = new PlayerInputBuffer(actorId);
            PlayerMotor2D player = playerObject.AddComponent<PlayerMotor2D>();
            player.Initialize(actorId, input, groundLayers: 1 << 0);

            GameObject markerObject = Track(new GameObject("cache.exploration"));
            markerObject.transform.SetParent(scope.transform, false);
            markerObject.transform.localPosition = new Vector3(0f, 1f, 0f);
            RoomPositionMarker2D marker = markerObject.AddComponent<RoomPositionMarker2D>();
            marker.Configure("cache.exploration", "treasure", 0, 0);

            GameObject pickupObject = Track(new GameObject("Gold cache fixture"));
            pickupObject.SetActive(false);
            pickupObject.transform.position = marker.transform.position;
            BoxCollider2D trigger = pickupObject.AddComponent<BoxCollider2D>();
            trigger.isTrigger = true;
            trigger.size = new Vector2(4f, 2f);
            ExplorationGoldCachePickup2D pickup = pickupObject.AddComponent<ExplorationGoldCachePickup2D>();
            pickup.Initialize(scope, marker, player, "cache.fixture.e1", 17);
            pickupObject.SetActive(true);
            return new Fixture(scope, marker, player, input, pickup);
        }

        private GameObject Track(GameObject item)
        {
            _objects.Add(item);
            return item;
        }

        private sealed class Fixture
        {
            internal Fixture(RoomLifetimeScope scope, RoomPositionMarker2D marker, PlayerMotor2D player,
                PlayerInputBuffer input, ExplorationGoldCachePickup2D pickup)
            {
                Scope = scope;
                Marker = marker;
                Player = player;
                Input = input;
                Pickup = pickup;
            }

            internal RoomLifetimeScope Scope { get; }
            internal RoomPositionMarker2D Marker { get; }
            internal PlayerMotor2D Player { get; }
            internal PlayerInputBuffer Input { get; }
            internal ExplorationGoldCachePickup2D Pickup { get; }
        }
    }
}
