#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Luckbound.App;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    /// <summary>Tests the App pending-operation gate only; it does not simulate an actor or victory.</summary>
    public sealed class F10V7TutorialAdvanceConcurrencyTests
    {
        [Test]
        public void ConfirmedResultSurvivesAnInterveningFailedReadback()
        {
            Type pendingType = typeof(ApplicationBootstrapper).GetNestedType(
                "PendingF10V7TutorialAdvance", BindingFlags.NonPublic);
            Assert.That(pendingType, Is.Not.Null);
            object pending = Activator.CreateInstance(pendingType, nonPublic: true);
            MethodInfo acquire = typeof(ApplicationBootstrapper).GetMethod(
                "TryAcquirePendingF10V7TutorialAdvanceOperation", BindingFlags.Static | BindingFlags.NonPublic);
            MethodInfo release = typeof(ApplicationBootstrapper).GetMethod(
                "ReleasePendingF10V7TutorialAdvanceOperation", BindingFlags.Static | BindingFlags.NonPublic);
            MethodInfo outcome = typeof(ApplicationBootstrapper).GetMethod(
                "PendingF10V7TutorialOutcome", BindingFlags.Static | BindingFlags.NonPublic);
            MethodInfo capture = pendingType.GetMethod("CaptureRepositoryCommitResult",
                BindingFlags.Instance | BindingFlags.NonPublic);
            PropertyInfo current = pendingType.GetProperty("CommitResult", BindingFlags.Instance | BindingFlags.NonPublic);
            PropertyInfo confirmed = pendingType.GetProperty("ConfirmedCommitResult", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(acquire, Is.Not.Null);
            Assert.That(release, Is.Not.Null);
            Assert.That(outcome, Is.Not.Null);
            Assert.That(capture, Is.Not.Null);
            Assert.That(current, Is.Not.Null);
            Assert.That(confirmed, Is.Not.Null);

            object[] first = { pending, null };
            Assert.That((bool)acquire.Invoke(null, first), Is.True);
            F10V7SessionCommitResult durable = F10V7SessionCommitResult.Confirmed("exact-confirmed-json", "read back");
            capture.Invoke(pending, new object[] { durable });
            pendingType.GetField("RepositoryConfirmed", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(pending, true);
            pendingType.GetField("ConfirmedJson", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(pending, durable.ConfirmedJson);
            release.Invoke(null, new[] { pending, first[1] });

            object[] retry = { pending, null };
            Assert.That((bool)acquire.Invoke(null, retry), Is.True);
            Assert.That(current.GetValue(pending), Is.Null, "A new read must not inherit the previous attempt's success.");
            Assert.That(confirmed.GetValue(pending), Is.SameAs(durable));
            F10V7SessionCommitResult readFailure = F10V7SessionCommitResult.Rejected("temporary read failure", pending: true);
            capture.Invoke(pending, new object[] { readFailure });
            Assert.That(current.GetValue(pending), Is.SameAs(readFailure));
            ExpeditionEncounterAdvanceOutcome stillDurable = (ExpeditionEncounterAdvanceOutcome)outcome.Invoke(null,
                new[] { pending, "readback pending" });
            Assert.That(stillDurable.Persisted, Is.True);
            Assert.That(stillDurable.Pending, Is.True);
            Assert.That(stillDurable.Activated, Is.False);
            release.Invoke(null, new[] { pending, retry[1] });

            object[] finalRetry = { pending, null };
            Assert.That((bool)acquire.Invoke(null, finalRetry), Is.True);
            Assert.That(current.GetValue(pending), Is.Null);
            capture.Invoke(pending, new object[] { F10V7SessionCommitResult.Confirmed("different-json", "not this commit") });
            Assert.That(confirmed.GetValue(pending), Is.SameAs(durable), "Another JSON cannot replace the original proof.");
            capture.Invoke(pending, new object[] { F10V7SessionCommitResult.Confirmed(durable.ConfirmedJson, "read back again") });
            Assert.That(((F10V7SessionCommitResult)current.GetValue(pending)).ConfirmedJson, Is.EqualTo(durable.ConfirmedJson));
            release.Invoke(null, new[] { pending, finalRetry[1] });
        }

        [Test]
        public async Task ConcurrentCallsCanRetainOnlyOneOperationToken()
        {
            Type pendingType = typeof(ApplicationBootstrapper).GetNestedType(
                "PendingF10V7TutorialAdvance", BindingFlags.NonPublic);
            Assert.That(pendingType, Is.Not.Null);
            object pending = Activator.CreateInstance(pendingType, nonPublic: true);
            MethodInfo acquire = typeof(ApplicationBootstrapper).GetMethod(
                "TryAcquirePendingF10V7TutorialAdvanceOperation", BindingFlags.Static | BindingFlags.NonPublic);
            MethodInfo release = typeof(ApplicationBootstrapper).GetMethod(
                "ReleasePendingF10V7TutorialAdvanceOperation", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.That(acquire, Is.Not.Null);
            Assert.That(release, Is.Not.Null);

            using (var start = new ManualResetEventSlim(false))
            {
                Task<(bool Entered, object Token)>[] attempts = Enumerable.Range(0, 24)
                    .Select(_ => Task.Run(() =>
                    {
                        start.Wait();
                        object[] arguments = { pending, null };
                        bool entered = (bool)acquire.Invoke(null, arguments);
                        return (entered, arguments[1]);
                    })).ToArray();
                start.Set();
                (bool Entered, object Token)[] results = await Task.WhenAll(attempts);
                (bool Entered, object Token)[] winners = results.Where(result => result.Entered).ToArray();
                Assert.That(winners, Has.Length.EqualTo(1),
                    "Only one concurrent App call may enter the repository for the retained pending.");
                Assert.That(winners[0].Token, Is.Not.Null);

                release.Invoke(null, new[] { pending, new object() });
                object[] stillBlockedArguments = { pending, null };
                Assert.That((bool)acquire.Invoke(null, stillBlockedArguments), Is.False,
                    "A different token cannot release the current operation guard.");

                release.Invoke(null, new[] { pending, winners[0].Token });
                object[] retryArguments = { pending, null };
                Assert.That((bool)acquire.Invoke(null, retryArguments), Is.True,
                    "After the exact call releases its token, one later retry may enter.");
                Assert.That(retryArguments[1], Is.Not.Null);
                release.Invoke(null, new[] { pending, retryArguments[1] });
            }
        }
    }
}
#endif
