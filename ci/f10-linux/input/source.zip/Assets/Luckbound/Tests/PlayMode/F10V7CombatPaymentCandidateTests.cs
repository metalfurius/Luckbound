#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using Luckbound.App;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10V7CombatPaymentCandidateTests
    {
        private static readonly RunId TestRunId = new RunId(Guid.Parse("9dfc1e22-5306-44a6-a225-7d7000000001"));
        private const string TestConsumableId = "consumable.f10_v7_payment_test";

        [Test]
        public void C1PolicyPaymentAddsOnlyPolicyGoldRenownAndDurableClaims()
        {
            ExpeditionEncounterRewardResolution resolution = ResolveC1();
            ExpeditionSaveData current = CurrentC1Save();
            ExpeditionSaveData candidate = current.Clone();
            ExpeditionInventory inventory = NewInventory(initialGold: 17);
            int expectedGold = resolution.RoomPayout.Gold +
                resolution.EnemyOutcomes.Sum(enemy => enemy.TotalGold);
            string[] expectedClaims = resolution.EnemyOutcomes.Where(enemy => enemy.TotalGold > 0)
                .Select(enemy => enemy.GoldGrantId)
                .Concat(new[] { resolution.RoomPayout.GoldGrantId, resolution.RoomPayout.RenownGrantId })
                .OrderBy(id => id, StringComparer.Ordinal).ToArray();

            Assert.That(ApplyPolicyPayment(current, candidate, inventory, resolution, out string error), Is.True, error);
            Assert.That(inventory.Gold, Is.EqualTo(17 + expectedGold));
            Assert.That(candidate.accumulatedRenown,
                Is.EqualTo(current.accumulatedRenown + resolution.RoomPayout.Renown));
            CollectionAssert.AreEqual(expectedClaims, candidate.claimedRewardIds);
            Assert.That(candidate.claimedRewardIds.Intersect(
                resolution.EnemyOutcomes.SelectMany(enemy => enemy.BaseMaterialGrants)
                    .Concat(resolution.EnemyOutcomes.SelectMany(enemy => enemy.VinculoMaterialGrants))
                    .Select(grant => grant.GrantId), StringComparer.Ordinal), Is.Empty);
        }

        [Test]
        public void ClonedPaidSnapshotReplaysWithoutPayingC1Again()
        {
            ExpeditionEncounterRewardResolution resolution = ResolveC1();
            ExpeditionSaveData initial = CurrentC1Save();
            ExpeditionSaveData committed = initial.Clone();
            ExpeditionInventory liveInventory = NewInventory(initialGold: 5);
            Assert.That(ApplyPolicyPayment(initial, committed, liveInventory, resolution, out string error), Is.True, error);

            // Recreate detached values from the committed snapshot; this is not a disk reopen.
            ExpeditionSaveData reopened = committed.Clone();
            ExpeditionSaveData replayCandidate = reopened.Clone();
            ExpeditionInventory reopenedInventory = ExpeditionInventory.Restore(
                liveInventory.Catalog, liveInventory.CreateSnapshot());
            int goldBefore = reopenedInventory.Gold;
            int renownBefore = replayCandidate.accumulatedRenown;
            string[] claimsBefore = (string[])replayCandidate.claimedRewardIds.Clone();

            Assert.That(ApplyPolicyPayment(reopened, replayCandidate, reopenedInventory,
                resolution, out error), Is.True, error);
            Assert.That(reopenedInventory.Gold, Is.EqualTo(goldBefore));
            Assert.That(replayCandidate.accumulatedRenown, Is.EqualTo(renownBefore));
            CollectionAssert.AreEqual(claimsBefore, replayCandidate.claimedRewardIds);
        }

        [Test]
        public void PartialClaimStateFailsClosedWithoutChangingInventoryOrRenown()
        {
            ExpeditionEncounterRewardResolution resolution = ResolveC1();
            ExpeditionSaveData current = CurrentC1Save();
            current.claimedRewardIds = new[] { resolution.RoomPayout.RenownGrantId };
            ExpeditionSaveData candidate = current.Clone();
            ExpeditionInventory inventory = NewInventory(initialGold: 11);
            int goldBefore = inventory.Gold;

            Assert.That(ApplyPolicyPayment(current, candidate, inventory, resolution,
                out string error), Is.False);
            Assert.That(error, Does.Contain("partial room claim"));
            Assert.That(inventory.Gold, Is.EqualTo(goldBefore));
            Assert.That(candidate.accumulatedRenown, Is.EqualTo(current.accumulatedRenown));
        }

        [Test]
        public void V7RoomProfileComparisonRejectsAnyPermanentProfileMutation()
        {
            var original = SaveV7CandidateMapper.ToV7(ProfileSaveData.CreateNewProfile());
            original.availableRenown = 14;
            var candidate = SaveV7Clone.Clone(original);
            Assert.That(SameF10V7RoomProfile(original, candidate), Is.True);

            candidate.availableRenown++;
            Assert.That(SameF10V7RoomProfile(original, candidate), Is.False);
        }

        [Test]
        public void PlanRuntimeBindingIsRequiredUntilAppFactoryIssuesPrivateBinding()
        {
            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "HasAuthenticatedF10V7CombatPlanRuntimeBinding", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null,
                "The C1-to-E1 builder must keep its plan/runtime provenance gate explicit.");

            bool accepted = (bool)method.Invoke(null, new object[] { null, null, null, null, 1L });
            Assert.That(accepted, Is.False,
                "Caller-shaped session/runtime values must not authorize a payment candidate.");

            MethodInfo captureMethod = typeof(ApplicationBootstrapper).GetMethod(
                "HasAuthenticatedF10V7CombatResourceCapture", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(captureMethod, Is.Not.Null,
                "Room resources require an App-owned actor/collector capture capability.");
            bool captured = (bool)captureMethod.Invoke(null,
                new object[] { null, null, null, null, new ExpeditionSaveData(), null, 1L });
            Assert.That(captured, Is.False,
                "A caller-created save DTO is not proof of capture under the retained lease.");
        }

        [Test]
        public void HelperOnly_DirectC1UsesRollbackCheckpointWhenRuntimeStateDiffers()
        {
            const long openingRevision = 12;
            string openingJson = "authenticated-opening-c1";
            Assert.That(ClassifySnapshot(openingRevision, openingRevision,
                openingJson, openingJson, openingJson, out bool openingRollback, out string error), Is.True, error);
            Assert.That(openingRollback, Is.True);

            ExpeditionSaveDataV7 checkpoint = CurrentC1V7State("checkpoint-inventory",
                new[] { "claim.baseline" });
            ExpeditionSaveDataV7 handleBaseline = SaveV7Clone.Clone(checkpoint);
            ExpeditionSaveDataV7 liveEntry = SaveV7Clone.Clone(checkpoint);
            liveEntry.inventorySnapshotJson = "live-after-c1-use-and-pickup";
            liveEntry.claimedRewardIds = new[] { "claim.baseline", "claim.after-entry" };
            liveEntry.currentHealth = 41;

            Assert.That(SelectBaseline(true, checkpoint, handleBaseline, liveEntry,
                out ExpeditionSaveDataV7 selected), Is.True);
            Assert.That(selected.inventorySnapshotJson, Is.EqualTo("checkpoint-inventory"));
            Assert.That(selected.currentHealth, Is.EqualTo(checkpoint.currentHealth));
            CollectionAssert.AreEqual(new[] { "claim.baseline" }, selected.claimedRewardIds);
        }

        [Test]
        public void HelperOnly_TutorialToC1UsesLaterConfirmedStateWithoutOpeningRollback()
        {
            Assert.That(ClassifySnapshot(12, 13, "admitted-tutorial", "admitted-tutorial",
                "confirmed-c1-after-tutorial", out bool openingRollback, out string error), Is.True, error);
            Assert.That(openingRollback, Is.False);

            ExpeditionSaveDataV7 openingBaseline = CurrentC1V7State("opening-baseline",
                new[] { "claim.opening" });
            ExpeditionSaveDataV7 confirmedC1 = CurrentC1V7State("confirmed-c1-inventory",
                new[] { "claim.opening", "claim.confirmed-c1" });
            confirmedC1.currentHealth = 53;
            Assert.That(SelectBaseline(openingRollback, null, openingBaseline,
                confirmedC1, out ExpeditionSaveDataV7 selected), Is.True);
            Assert.That(selected.inventorySnapshotJson, Is.EqualTo("confirmed-c1-inventory"));
            Assert.That(selected.currentHealth, Is.EqualTo(53));
            CollectionAssert.AreEqual(confirmedC1.claimedRewardIds, selected.claimedRewardIds);
        }

        [Test]
        public void HelperOnly_LiveInventoryCloneKeepsCombatConsumptionAndPickupDespiteEntryDrift()
        {
            ExpeditionInventory entryInventory = NewInventory(initialGold: 11);
            var potion = new InventoryItemStack(ItemInstanceId.New(), TestConsumableId,
                ItemRarity.Common, 0, 2);
            Assert.That(entryInventory.TryCollectItem(potion, TransactionId.New()).Succeeded, Is.True);
            Assert.That(entryInventory.SetQuickConsumable(0, TransactionId.New()).Succeeded, Is.True);
            string entrySnapshotJson = JsonUtility.ToJson(entryInventory.CreateSnapshot());

            ExpeditionInventory liveInventory = ExpeditionInventory.Restore(
                entryInventory.Catalog, entryInventory.CreateSnapshot());
            InventoryItemStack livePotion = liveInventory.QuickConsumable;
            Assert.That(livePotion, Is.Not.Null);
            Assert.That(liveInventory.TryConsumeQuickConsumable(livePotion.InstanceId,
                TestConsumableId, TransactionId.New()).Succeeded, Is.True);
            Assert.That(liveInventory.TryCollectWorldMaterial(MaterialKind.ShadowWood, 2,
                false, TransactionId.New()).Succeeded, Is.True);
            string capturedLiveSnapshotJson = JsonUtility.ToJson(liveInventory.CreateSnapshot());
            Assert.That(capturedLiveSnapshotJson, Is.Not.EqualTo(entrySnapshotJson));

            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "TryCloneF10V7LiveCombatInventory", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null, "The builder must clone the collector's live inventory.");
            object[] arguments =
            {
                entryInventory.Catalog, liveInventory, capturedLiveSnapshotJson,
                null, null, null
            };
            bool cloned = (bool)method.Invoke(null, arguments);
            Assert.That(cloned, Is.True, arguments[5] as string);

            ExpeditionInventory candidate = arguments[3] as ExpeditionInventory;
            string liveJson = arguments[4] as string;
            Assert.That(candidate, Is.Not.Null);
            Assert.That(ReferenceEquals(candidate, liveInventory), Is.False);
            Assert.That(liveJson, Is.EqualTo(capturedLiveSnapshotJson));
            Assert.That(candidate.QuickConsumable.Quantity, Is.EqualTo(1));
            Assert.That(candidate.GetMaterialCount(MaterialKind.ShadowWood), Is.EqualTo(2));
        }

        private static bool ApplyPolicyPayment(ExpeditionSaveData current,
            ExpeditionSaveData candidate, ExpeditionInventory inventory,
            ExpeditionEncounterRewardResolution resolution, out string error)
        {
            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "TryApplyF10PolicyRoomPayment", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null, "The extracted V6/V7 shared helper must remain private.");
            object[] arguments = { current, candidate, inventory, resolution, true, null };
            bool applied = (bool)method.Invoke(null, arguments);
            error = arguments[5] as string ?? string.Empty;
            return applied;
        }

        private static bool SameF10V7RoomProfile(ProfileSaveDataV7 source,
            ProfileSaveDataV7 candidate)
        {
            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "HasSameF10V7RoomProfile", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null, "The V7 builder must use the full permanent-profile comparison.");
            return (bool)method.Invoke(null, new object[] { source, candidate });
        }

        private static bool ClassifySnapshot(long openingRevision, long currentRevision,
            string admittedJson, string handleJson, string currentJson,
            out bool openingRollback, out string error)
        {
            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "TryClassifyF10V7CombatCurrentSnapshot", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null);
            object[] arguments = { openingRevision, currentRevision, admittedJson, handleJson,
                currentJson, false, null };
            bool classified = (bool)method.Invoke(null, arguments);
            openingRollback = arguments[5] is bool value && value;
            error = arguments[6] as string ?? string.Empty;
            return classified;
        }

        private static bool SelectBaseline(bool openingRollback, ExpeditionSaveDataV7 openingRestored,
            ExpeditionSaveDataV7 handleBaseline, ExpeditionSaveDataV7 current,
            out ExpeditionSaveDataV7 selected)
        {
            MethodInfo method = typeof(ApplicationBootstrapper).GetMethod(
                "TrySelectF10V7CombatBaseline", BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null);
            object[] arguments = { openingRollback, openingRestored, handleBaseline, current, null };
            bool selectedResult = (bool)method.Invoke(null, arguments);
            selected = arguments[4] as ExpeditionSaveDataV7;
            return selectedResult;
        }

        private static ExpeditionSaveDataV7 CurrentC1V7State(string inventoryJson, string[] claims) =>
            new ExpeditionSaveDataV7
            {
                runId = TestRunId.ToString(), seed = 0, generationVersion = 2, contentVersion = 7,
                classId = "class.bellator", raceId = "race.human",
                currentNodeId = "sample.patio.combat", inventorySnapshotJson = inventoryJson,
                currentHealth = 87, maximumHealth = 100, currentEnergy = 24, maximumEnergy = 50,
                healthPotionCharges = 2, claimedRewardIds = claims,
                selectedSkillIds = Array.Empty<string>(), startingEquipmentInstanceIds = Array.Empty<string>(),
                visitedNodeIds = new[] { "sample.patio.combat" }, completedRoomIds = Array.Empty<string>(),
                completedRoomResults = Array.Empty<ExpeditionRoomCompletionSaveDataV7>(),
                pactIds = Array.Empty<string>(), collectedItemIds = Array.Empty<string>()
            };

        private static ExpeditionEncounterRewardResolution ResolveC1()
        {
            var request = new ExpeditionEncounterRewardRequest(TestRunId, 0u, 2,
                "sample.patio.combat", "room.patio.c1", "patio", ExpeditionRouteNodeKind.Combat,
                new[]
                {
                    new ExpeditionEncounterRewardSpawn("spawn.test.1", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.2", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.3", ExpeditionEncounterRewardEnemyKind.Normal),
                    new ExpeditionEncounterRewardSpawn("spawn.test.4", ExpeditionEncounterRewardEnemyKind.Normal)
                });
            return ExpeditionEncounterRewardPolicy.Resolve(request);
        }

        private static ExpeditionSaveData CurrentC1Save() => new ExpeditionSaveData
        {
            runId = TestRunId.ToString(), seed = 0, generationVersion = 2,
            currentNodeId = "sample.patio.combat", accumulatedRenown = 7,
            pactIds = Array.Empty<string>(), claimedRewardIds = Array.Empty<string>()
        };

        private static ExpeditionInventory NewInventory(int initialGold)
        {
            ItemDefinition[] materials = Enum.GetValues(typeof(MaterialKind)).Cast<MaterialKind>()
                .Select((kind, index) => new ItemDefinition(
                    "material.f10_v7_payment_test_" + index,
                    "item.fixture.name", "item.fixture.description", ItemKind.Material, 99,
                    materialKind: kind)).ToArray();
            ItemDefinition consumable = new ItemDefinition(TestConsumableId,
                "item.fixture.name", "item.fixture.description", ItemKind.Consumable, 3);
            return new ExpeditionInventory(new ItemCatalog(materials.Concat(new[] { consumable })),
                "class.bellator", initialGold);
        }
    }
}
#endif
