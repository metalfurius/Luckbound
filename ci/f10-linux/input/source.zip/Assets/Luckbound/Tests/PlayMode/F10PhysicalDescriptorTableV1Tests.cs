#if UNITY_EDITOR
using Luckbound.App;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10PhysicalDescriptorTableV1Tests
    {
        private const string PhysicalSha256 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        private const string BundleSha256 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";

        [TestCase("room.sample.tutorial", "room",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10TutorialDiagnostic.prefab",
            "Assets/Resources/Luckbound/Data/Rooms/F10TutorialRoom.json")]
        [TestCase("room.patio.c1", "room",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioCombatC1Diagnostic.prefab",
            "Assets/Resources/Luckbound/Data/Rooms/F10PatioCombatC1Room.json")]
        [TestCase("room.patio.e1", "room",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioExplorationE1Diagnostic.prefab",
            "Assets/Resources/Luckbound/Data/Rooms/F10PatioExplorationE1Room.json")]
        [TestCase("room.patio.guardian", "room",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10PatioGuardianDiagnostic.prefab",
            "Assets/Resources/Luckbound/Data/Rooms/F10PatioGuardianRoom.json")]
        [TestCase("room.sample.extraction", "room",
            "Assets/Luckbound/Editor/Diagnostic/F10/F10SafeExtractionDiagnostic.prefab",
            "Assets/Resources/Luckbound/Data/Rooms/F10SafeExtractionRoom.json")]
        [TestCase("enemy.slime", "enemy",
            "Assets/Luckbound/Prefabs/CombatArena/SlimePrototype.prefab", "")]
        [TestCase("enemy.huesoguardia", "enemy",
            "Assets/Luckbound/Prefabs/CombatArena/HuesoguardiaPrototype.prefab", "")]
        [TestCase("boss.custodian_of_the_oaks", "enemy",
            "Assets/Luckbound/Prefabs/CustodianArena/CustodianPrototype.prefab",
            "Assets/Resources/Luckbound/Data/Encounters/CustodianBoss.json")]
        [TestCase("cache.exploration", "cache",
            "Assets/Luckbound/Editor/Diagnostic/F10GoldCache/F10ExplorationGoldCacheDiagnostic.prefab", "")]
        public void ResolvesEachFixedDescriptorRow(string descriptorId, string kind,
            string rootAssetPath, string sourceDefinitionAssetPath)
        {
            Assert.That(F10PhysicalDescriptorTableV1.TryGetDescriptor(descriptorId,
                out F10PhysicalDescriptorV1 row), Is.True);
            Assert.That(row, Is.Not.Null);
            Assert.That(row.DescriptorId, Is.EqualTo(descriptorId));
            Assert.That(row.Kind, Is.EqualTo(kind));
            Assert.That(row.RootAssetPath, Is.EqualTo(rootAssetPath));
            Assert.That(row.SourceDefinitionAssetPath, Is.EqualTo(sourceDefinitionAssetPath));
            Assert.That(F10PhysicalDescriptorTableV1.DescriptorCount, Is.EqualTo(9));
        }

        [Test]
        public void CustodianUsesItsOwnDefinitionJsonAndEnemyRowsHaveNoIndividualJson()
        {
            Assert.That(F10PhysicalDescriptorTableV1.TryGetDescriptor("boss.custodian_of_the_oaks",
                out F10PhysicalDescriptorV1 custodian), Is.True);
            Assert.That(custodian.SourceDefinitionAssetPath,
                Is.EqualTo("Assets/Resources/Luckbound/Data/Encounters/CustodianBoss.json"));

            Assert.That(F10PhysicalDescriptorTableV1.TryGetDescriptor("enemy.slime",
                out F10PhysicalDescriptorV1 slime), Is.True);
            Assert.That(F10PhysicalDescriptorTableV1.TryGetDescriptor("enemy.huesoguardia",
                out F10PhysicalDescriptorV1 huesoguardia), Is.True);
            Assert.That(slime.SourceDefinitionAssetPath, Is.Empty);
            Assert.That(huesoguardia.SourceDefinitionAssetPath, Is.Empty);
            Assert.That(slime.SourceDefinitionAssetPath, Does.Not.Contain("C08Arena.json"));
            Assert.That(huesoguardia.SourceDefinitionAssetPath, Does.Not.Contain("C08Arena.json"));
        }

        [Test]
        public void RejectsUnknownIdsAndMalformedSuppliedDigests()
        {
            Assert.That(F10PhysicalDescriptorTableV1.TryGetDescriptor("enemy.unknown", out _), Is.False);
            Assert.That(F10PhysicalDescriptorTableV1.TryComputeFingerprint("enemy.unknown", 1,
                PhysicalSha256, BundleSha256, out _), Is.False);
            Assert.That(F10PhysicalDescriptorTableV1.TryComputeFingerprint("room.patio.c1", 1,
                new string('A', 64), BundleSha256, out _), Is.False);
        }

        [Test]
        public void FingerprintUsesTheDerivedRowAndSuppliedDigestValues()
        {
            Assert.That(F10PhysicalDescriptorTableV1.TryComputeFingerprint("room.patio.c1", 1,
                PhysicalSha256, BundleSha256, out F10PhysicalDescriptorFingerprintResultV1 result), Is.True);
            Assert.That(result.Descriptor.RootAssetPath,
                Is.EqualTo("Assets/Luckbound/Editor/Diagnostic/F10/F10PatioCombatC1Diagnostic.prefab"));
            Assert.That(result.Descriptor.SourceDefinitionAssetPath,
                Is.EqualTo("Assets/Resources/Luckbound/Data/Rooms/F10PatioCombatC1Room.json"));
            Assert.That(result.PhysicalDescriptorPayloadSha256, Is.EqualTo(PhysicalSha256));
            Assert.That(result.BundleManifestSha256, Is.EqualTo(BundleSha256));
            Assert.That(result.Fingerprint,
                Is.EqualTo("196c074b21a296abfcd3a1d3b30ee320289752beaa954f590a5b2f35e5149eab"));
        }
    }
}
#endif
