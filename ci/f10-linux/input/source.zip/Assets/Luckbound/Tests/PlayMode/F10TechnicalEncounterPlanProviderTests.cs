#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Gameplay.Enemies;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.Tilemaps;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10TechnicalEncounterPlanProviderTests
    {
        private const string C1RoomPath = "Assets/Resources/Luckbound/Data/Rooms/F10PatioCombatC1Room.json";
        private const string GuardianRoomPath = "Assets/Resources/Luckbound/Data/Rooms/F10PatioGuardianRoom.json";
        private const string C08Path = "Assets/Resources/Luckbound/Data/Encounters/C08Arena.json";
        private const string CustodianBossPath = "Assets/Resources/Luckbound/Data/Encounters/CustodianBoss.json";
        private const string SlimePath = "Assets/Luckbound/Prefabs/CombatArena/SlimePrototype.prefab";
        private const string BoneguardPath = "Assets/Luckbound/Prefabs/CombatArena/HuesoguardiaPrototype.prefab";
        private const string CustodianPath = "Assets/Luckbound/Prefabs/CustodianArena/CustodianPrototype.prefab";
        private const string CustodianWavePath = "Assets/Luckbound/Prefabs/CustodianArena/CustodianWavePrototype.prefab";

        private readonly List<GameObject> _roots = new List<GameObject>();
        private readonly List<Object> _transients = new List<Object>();

        [TearDown]
        public void TearDown()
        {
            foreach (GameObject root in _roots)
                if (root != null) Object.DestroyImmediate(root);
            _roots.Clear();
            foreach (Object transient in _transients)
                if (transient != null) Object.DestroyImmediate(transient);
            _transients.Clear();
        }

        [Test]
        public void C1PlanUsesC08SpawnIdentitiesAndBothRealRoomAnchors()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            TextAsset roomSource = Load<TextAsset>(C1RoomPath);
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomSource.text);
            (RoomLifetimeScope scope, RoomTemplatePrefab2D room) = CreateRoom(run, F10TechnicalEncounterPlanProvider.C1NodeId,
                F10TechnicalEncounterPlanProvider.C1TemplateId, roomSource, roomData);
            F10TechnicalEncounterPlanProvider provider = CreateProvider();

            Assert.That(provider.TryBuildC1(run, scope, room, out RoomEncounterRuntimePlan plan, out string error),
                Is.True, error);
            Assert.That(plan, Is.Not.Null);
            Assert.That(plan.HasOnlySupportedActors, Is.True);
            Assert.That(plan.Waves.Count, Is.EqualTo(2));
            Assert.That(plan.Waves[0].Actors.Count, Is.EqualTo(2));
            Assert.That(plan.Waves[1].Actors.Count, Is.EqualTo(2));

            RoomPositionMarker2D firstAnchor = FindMarker(room, "spawn.slime.01");
            RoomPositionMarker2D secondAnchor = FindMarker(room, "spawn.slime.02");
            CombatEncounterData c08 = CombatEncounterJsonLoader.Load(Load<TextAsset>(C08Path).text);
            Assert.That(c08.encounterId, Is.EqualTo("encounter.c08_arena"));

            AssertActor(plan, run, scope, firstAnchor, 0, 0, c08.waves[0].spawns[0], Load<GameObject>(SlimePath));
            AssertActor(plan, run, scope, secondAnchor, 0, 1, c08.waves[0].spawns[1], Load<GameObject>(SlimePath));
            AssertActor(plan, run, scope, firstAnchor, 1, 0, c08.waves[1].spawns[0], Load<GameObject>(BoneguardPath));
            AssertActor(plan, run, scope, secondAnchor, 1, 1, c08.waves[1].spawns[1], Load<GameObject>(BoneguardPath));

            Vector3 firstWavePosition = plan.Waves[0].Actors[0].RoomLocalPosition;
            Vector3 secondWavePosition = plan.Waves[1].Actors[0].RoomLocalPosition;
            Assert.That(Vector3.Distance(firstWavePosition, secondWavePosition), Is.LessThan(0.001f),
                "The C08 Huesoguardia wave reuses the actual C1 Slime anchor.");
            Assert.That(Vector3.Distance(firstWavePosition,
                new Vector3(c08.waves[0].spawns[0].x, c08.waves[0].spawns[0].y, 0f)), Is.GreaterThan(1f),
                "C08's legacy absolute coordinates must not position the F10 room actors.");
        }

        [Test]
        public void GuardianDoesNotProduceAnArmablePlanWithoutBossBodyConfinement()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            TextAsset roomSource = Load<TextAsset>(GuardianRoomPath);
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomSource.text);
            (RoomLifetimeScope scope, RoomTemplatePrefab2D room) = CreateRoom(run,
                F10TechnicalEncounterPlanProvider.GuardianNodeId,
                F10TechnicalEncounterPlanProvider.GuardianTemplateId, roomSource, roomData);
            F10TechnicalEncounterPlanProvider provider = CreateProvider();

            Assert.That(provider.TryBuildGuardian(run, scope, room, out RoomEncounterRuntimePlan plan, out string error),
                Is.False);
            Assert.That(plan, Is.Null);
            Assert.That(error, Does.Contain("does not confine its own body"));
        }

        [UnityTest]
        public IEnumerator GuardianPlanUsesRealBossMarkerAndCurrentInstallerWitness()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            TextAsset roomSource = Load<TextAsset>(GuardianRoomPath);
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomSource.text);
            (RoomLifetimeScope scope, RoomTemplatePrefab2D room) = CreateRoom(run,
                F10TechnicalEncounterPlanProvider.GuardianNodeId,
                F10TechnicalEncounterPlanProvider.GuardianTemplateId, roomSource, roomData);
            scope.transform.rotation = Quaternion.identity;
            F10TechnicalEncounterPlanProvider provider = CreateProvider();
            yield return null;

            Assert.That(F10GuardianPhysicalBoundaryInstaller.TryInstall(run, scope, room,
                    out F10GuardianPhysicalBoundaryInstaller.InstallationWitness witness, out string boundaryError),
                Is.True, boundaryError);
            Assert.That(provider.TryBuildGuardian(run, scope, room, witness,
                    out RoomEncounterRuntimePlan plan, out string error), Is.True, error);
            Assert.That(plan, Is.Not.Null);
            Assert.That(plan.HasOnlySupportedActors, Is.True);
            Assert.That(plan.Waves.Count, Is.EqualTo(1));
            Assert.That(plan.Waves[0].Actors.Count, Is.EqualTo(1));

            RoomPositionMarker2D bossMarker = FindMarker(room, "boss.custodian");
            CustodianBossDefinition boss = CustodianBossJsonLoader.Load(Load<TextAsset>(CustodianBossPath).text);
            EncounterSpawnIdentityV1 expectedIdentity = EncounterSpawnIdentityV1.Create(run.RunId,
                (uint)run.Route.GenerationVersion, F10TechnicalEncounterPlanProvider.GuardianNodeId,
                scope.RoomInstanceId, boss.BossId, "boss.custodian");
            RoomEncounterActorDefinition actor = plan.Waves[0].Actors[0];
            RoomEncounterCustodianBossConfiguration configuration = actor.CustodianBossConfiguration;
            Assert.That(plan.Roster.Waves[0].SpawnKeys.Single(), Is.EqualTo(expectedIdentity.Key));
            Assert.That(actor.ActorPrefab, Is.SameAs(Load<GameObject>(CustodianPath)));
            Assert.That(Vector3.Distance(actor.RoomLocalPosition,
                scope.transform.InverseTransformPoint(bossMarker.transform.position)), Is.LessThan(0.001f));
            Assert.That(configuration, Is.Not.Null);
            Assert.That(configuration.BossDefinition.BossId, Is.EqualTo("boss.custodian_of_the_oaks"));
            Assert.That(configuration.MinimumX, Is.EqualTo(witness.LeftEdgeX));
            Assert.That(configuration.MaximumX, Is.EqualTo(witness.RightEdgeX));
            Assert.That(configuration.FloorTopY, Is.EqualTo(witness.FloorTopY));

            var forged = new F10GuardianPhysicalBoundaryInstaller.InstallationWitness(scope, room,
                witness.LeftWall, witness.RightWall, witness.RoomInstanceId, witness.LeftEdgeX,
                witness.RightEdgeX, witness.FloorTopY, witness.WallBottomY, witness.WallTopY,
                witness.WallThickness, witness.TileSize, witness.GroundLayer, new object());
            Assert.That(forged.WasIssuedByInstaller, Is.False);
            Assert.That(provider.TryBuildGuardian(run, scope, room, forged,
                    out RoomEncounterRuntimePlan forgedPlan, out _), Is.False);
            Assert.That(forgedPlan, Is.Null);

            witness.LeftWall.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            Assert.That(provider.TryBuildGuardian(run, scope, room, witness,
                    out RoomEncounterRuntimePlan stalePlan, out string staleError), Is.False);
            Assert.That(stalePlan, Is.Null);
            Assert.That(staleError, Does.Contain("current installer-issued physical boundary witness"));
        }

        [Test]
        public void C1RejectsGuardianRoomScopeBeforeItCanReturnAPlan()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            TextAsset roomSource = Load<TextAsset>(GuardianRoomPath);
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomSource.text);
            (RoomLifetimeScope scope, RoomTemplatePrefab2D room) = CreateRoom(run,
                F10TechnicalEncounterPlanProvider.GuardianNodeId,
                F10TechnicalEncounterPlanProvider.GuardianTemplateId, roomSource, roomData);
            F10TechnicalEncounterPlanProvider provider = CreateProvider();

            Assert.That(provider.TryBuildC1(run, scope, room, out RoomEncounterRuntimePlan plan, out string error),
                Is.False);
            Assert.That(plan, Is.Null);
            Assert.That(error, Does.Contain("active, initialized scope"));
        }

        private static void AssertActor(RoomEncounterRuntimePlan plan, ExpeditionRunConfiguration run,
            RoomLifetimeScope scope, RoomPositionMarker2D anchor, int waveIndex, int actorIndex,
            CombatEnemySpawnData sourceSpawn, GameObject expectedPrefab)
        {
            RoomEncounterActorDefinition actor = plan.Waves[waveIndex].Actors[actorIndex];
            EncounterSpawnIdentityV1 expectedIdentity = EncounterSpawnIdentityV1.Create(run.RunId,
                (uint)run.Route.GenerationVersion, F10TechnicalEncounterPlanProvider.C1NodeId,
                scope.RoomInstanceId, "encounter.c08_arena", sourceSpawn.spawnId);
            Vector3 expectedPosition = scope.transform.InverseTransformPoint(anchor.transform.position);

            Assert.That(actor.SpawnKey, Is.EqualTo(expectedIdentity.Key));
            Assert.That(actor.ActorPrefab, Is.SameAs(expectedPrefab));
            Assert.That(Vector3.Distance(actor.RoomLocalPosition, expectedPosition), Is.LessThan(0.001f));
        }

        private (RoomLifetimeScope scope, RoomTemplatePrefab2D room) CreateRoom(
            ExpeditionRunConfiguration run, string nodeId, string templateId,
            TextAsset source, RoomTemplateData data)
        {
            var scopeRoot = new GameObject("F10 provider test scope");
            _roots.Add(scopeRoot);
            scopeRoot.transform.position = new Vector3(53f, -7f, 0f);
            scopeRoot.transform.rotation = Quaternion.Euler(0f, 0f, 11f);
            RoomLifetimeScope scope = scopeRoot.AddComponent<RoomLifetimeScope>();
            scope.Initialize(ExpeditionRoomIdentity.ForNode(run.RunId, nodeId), templateId);

            var roomRoot = new GameObject("Room." + templateId);
            roomRoot.transform.SetParent(scopeRoot.transform, false);
            roomRoot.transform.localPosition = new Vector3(3f, 2f, 0f);
            RoomTemplatePrefab2D room = roomRoot.AddComponent<RoomTemplatePrefab2D>();

            var boundsRoot = new GameObject("CameraBounds");
            boundsRoot.transform.SetParent(roomRoot.transform, false);
            boundsRoot.transform.localPosition = new Vector3(data.widthTiles * data.tileSize * 0.5f,
                data.heightTiles * data.tileSize * 0.5f, 0f);
            BoxCollider2D bounds = boundsRoot.AddComponent<BoxCollider2D>();
            bounds.isTrigger = true;
            bounds.size = new Vector2(data.widthTiles * data.tileSize, data.heightTiles * data.tileSize);

            int groundLayer = LayerMask.NameToLayer("Ground");
            Assert.That(groundLayer, Is.GreaterThanOrEqualTo(0));
            var gridRoot = new GameObject("Grid");
            gridRoot.transform.SetParent(roomRoot.transform, false);
            Grid grid = gridRoot.AddComponent<Grid>();
            grid.cellSize = new Vector3(data.tileSize, data.tileSize, 1f);

            var groundRoot = new GameObject("GroundTilemap", typeof(Tilemap), typeof(TilemapRenderer), typeof(TilemapCollider2D));
            groundRoot.transform.SetParent(gridRoot.transform, false);
            groundRoot.layer = groundLayer;
            Tilemap tilemap = groundRoot.GetComponent<Tilemap>();
            TilemapCollider2D collider = groundRoot.GetComponent<TilemapCollider2D>();
            tilemap.tileAnchor = new Vector3(0.5f, 0.5f, 0f);

            var texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, Color.white);
            texture.Apply();
            _transients.Add(texture);
            Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 16f);
            _transients.Add(sprite);
            Tile floorTile = ScriptableObject.CreateInstance<Tile>();
            floorTile.sprite = sprite;
            floorTile.colliderType = Tile.ColliderType.Grid;
            _transients.Add(floorTile);
            for (int y = 0; y < data.heightTiles; y++)
            {
                for (int x = 0; x < data.widthTiles; x++)
                {
                    if (RoomTemplateJsonLoader.GetCell(data, x, y) == '#')
                        tilemap.SetTile(new Vector3Int(x, y, 0), floorTile);
                }
            }

            foreach (RoomPortData port in data.ports)
            {
                var markerRoot = new GameObject("Port." + port.id);
                markerRoot.transform.SetParent(roomRoot.transform, false);
                markerRoot.transform.localPosition = new Vector3(
                    (port.side == "west" ? 0f : data.widthTiles) * data.tileSize,
                    port.tileY * data.tileSize, 0f);
                markerRoot.AddComponent<RoomPortMarker2D>().Configure(port.id, port.type,
                    port.side, port.tileX, port.tileY, port.clearanceTiles);
            }

            foreach (RoomPositionMarkerData definition in data.markers)
            {
                var markerRoot = new GameObject("Marker." + definition.id);
                markerRoot.transform.SetParent(roomRoot.transform, false);
                markerRoot.transform.localPosition = new Vector3(
                    (definition.tileX + 0.5f) * data.tileSize,
                    definition.tileY * data.tileSize, 0f);
                markerRoot.AddComponent<RoomPositionMarker2D>().Configure(definition.id,
                    definition.kind, definition.tileX, definition.tileY);
            }

            room.Configure(source, bounds, tilemap, collider);
            return (scope, room);
        }

        private static RoomPositionMarker2D FindMarker(RoomTemplatePrefab2D room, string id)
        {
            return room.GetComponentsInChildren<RoomPositionMarker2D>(true).Single(item => item.MarkerId == id);
        }

        private static ExpeditionRunConfiguration CreateSampleRun()
        {
            return ExpeditionRunConfigurationFactory.CreateSample(BellatorSkillLoadout.ClassId,
                ExpeditionRunConfiguration.HumanRaceId,
                new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
        }

        private static F10TechnicalEncounterPlanProvider CreateProvider()
        {
            Assert.That(F10TechnicalEncounterPlanProvider.TryFreeze(
                    Load<GameObject>(SlimePath), Load<GameObject>(BoneguardPath),
                    Load<GameObject>(CustodianPath), Load<GameObject>(CustodianWavePath),
                    Load<TextAsset>(C08Path), Load<TextAsset>(CustodianBossPath),
                    out F10TechnicalEncounterPlanProvider provider, out string error), Is.True, error);
            return provider;
        }

        private static T Load<T>(string path) where T : Object
        {
            T asset = AssetDatabase.LoadAssetAtPath<T>(path);
            Assert.That(asset, Is.Not.Null, "Required F10 technical test source is missing: " + path);
            return asset;
        }
    }
}
#endif
