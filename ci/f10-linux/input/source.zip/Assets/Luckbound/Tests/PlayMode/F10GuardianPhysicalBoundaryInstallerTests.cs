#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Enemies;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.Tilemaps;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10GuardianPhysicalBoundaryInstallerTests
    {
        private const string GuardianRoomPath = "Assets/Resources/Luckbound/Data/Rooms/F10PatioGuardianRoom.json";
        private const string CustodianBossPath = "Assets/Resources/Luckbound/Data/Encounters/CustodianBoss.json";
        private const string CustodianPrefabPath = "Assets/Luckbound/Prefabs/CustodianArena/CustodianPrototype.prefab";
        private const string CustodianWavePrefabPath = "Assets/Luckbound/Prefabs/CustodianArena/CustodianWavePrototype.prefab";

        private GameObject _scopeRoot;
        private RoomLifetimeScope _scope;
        private readonly List<Object> _transients = new List<Object>();

        [UnityTest]
        public IEnumerator RealCustodianRigidbodyCannotCrossEitherInstalledWallAndScopeDisposeCleansThem()
        {
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId,
                new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
            TextAsset roomSource = Load<TextAsset>(GuardianRoomPath);
            RoomTemplateData roomData = RoomTemplateJsonLoader.Load(roomSource.text);
            (RoomTemplatePrefab2D room, RoomPositionMarker2D bossMarker) = CreateGuardianRoom(run, roomSource, roomData);
            yield return null;

            Assert.That(F10GuardianPhysicalBoundaryInstaller.TryInstall(run, _scope, room,
                    out F10GuardianPhysicalBoundaryInstaller.InstallationWitness witness, out string error),
                Is.True, error);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.True);
            Assert.That(witness.LeftWall.layer, Is.EqualTo(LayerMask.NameToLayer("Ground")));
            Assert.That(witness.RightWall.layer, Is.EqualTo(LayerMask.NameToLayer("Ground")));
            Assert.That(witness.LeftWall.GetComponent<Rigidbody2D>().bodyType, Is.EqualTo(RigidbodyType2D.Static));
            Assert.That(witness.RightWall.GetComponent<Rigidbody2D>().bodyType, Is.EqualTo(RigidbodyType2D.Static));
            Assert.That(witness.LeftWall.GetComponent<Renderer>(), Is.Null);
            Assert.That(witness.RightWall.GetComponent<Renderer>(), Is.Null);

            Transform wallTransform = witness.LeftWall.transform;
            BoxCollider2D wallCollider = witness.LeftWall.GetComponent<BoxCollider2D>();
            wallTransform.rotation = Quaternion.Euler(0f, 0f, 90f);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.False,
                "A rotated wall no longer proves the room is confined.");
            wallTransform.rotation = Quaternion.identity;
            wallTransform.localScale = new Vector3(2f, 1f, 1f);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.False,
                "A rescaled wall no longer proves the room is confined.");
            wallTransform.localScale = Vector3.one;
            wallCollider.offset = new Vector2(1f, 0f);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.False,
                "An offset collider no longer proves the room is confined.");
            wallCollider.offset = Vector2.zero;
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.True);

            GameObject custodianPrefab = Load<GameObject>(CustodianPrefabPath);
            float floorTop = room.GroundCollider.bounds.max.y;
            ActorId playerId = ActorId.New();
            var playerObject = new GameObject("F10 Guardian boundary test player");
            playerObject.transform.position = new Vector3((witness.LeftEdgeX + witness.RightEdgeX) * 0.5f,
                floorTop + 0.9f, 0f);
            Rigidbody2D playerBody = playerObject.AddComponent<Rigidbody2D>();
            playerBody.gravityScale = 3f;
            CapsuleCollider2D playerCollider = playerObject.AddComponent<CapsuleCollider2D>();
            playerCollider.direction = CapsuleDirection2D.Vertical;
            playerCollider.size = new Vector2(0.75f, 1.5f);
            PlayerMotor2D player = playerObject.AddComponent<PlayerMotor2D>();
            player.Initialize(playerId, new PlayerInputBuffer(playerId), 1 << LayerMask.NameToLayer("Ground"),
                new CombatStats(5000, 50, 0));
            _scope.OwnActor(playerObject);

            var waveRoot = new GameObject("F10 Guardian boundary test Custodian waves");
            _scope.OwnActor(waveRoot);
            CustodianBossDefinition bossDefinition = CustodianBossJsonLoader.Load(Load<TextAsset>(CustodianBossPath).text);
            GameObject wavePrefab = Load<GameObject>(CustodianWavePrefabPath);
            Physics2D.SyncTransforms();
            CustodianBoss2D leftCustodian = CreateCustodian(custodianPrefab, _scope, player,
                bossDefinition, wavePrefab, waveRoot.transform,
                witness.LeftEdgeX + 2f, floorTop + 0.9f, witness.LeftEdgeX, witness.RightEdgeX, floorTop);
            CustodianBoss2D rightCustodian = CreateCustodian(custodianPrefab, _scope, player,
                bossDefinition, wavePrefab, waveRoot.transform,
                witness.RightEdgeX - 2f, floorTop + 0.9f, witness.LeftEdgeX, witness.RightEdgeX, floorTop);
            Rigidbody2D leftBody = leftCustodian.GetComponent<Rigidbody2D>();
            Rigidbody2D rightBody = rightCustodian.GetComponent<Rigidbody2D>();
            Collider2D leftCollider = leftCustodian.GetComponent<Collider2D>();
            Collider2D rightCollider = rightCustodian.GetComponent<Collider2D>();
            Assert.That(leftBody.bodyType, Is.EqualTo(RigidbodyType2D.Dynamic));
            Assert.That(rightBody.bodyType, Is.EqualTo(RigidbodyType2D.Dynamic));
            Assert.That(leftBody.collisionDetectionMode, Is.EqualTo(CollisionDetectionMode2D.Continuous));
            Assert.That(rightBody.collisionDetectionMode, Is.EqualTo(CollisionDetectionMode2D.Continuous));
            Assert.That(CustodianBoss2D.ChargeSpeed, Is.EqualTo(8f));

            SimulationMode2D previousMode = Physics2D.simulationMode;
            Physics2D.simulationMode = SimulationMode2D.Script;
            try
            {
                AssertBodyStopsAtBoundary(leftBody, leftCollider, witness.LeftEdgeX, direction: -1);
                AssertBodyStopsAtBoundary(rightBody, rightCollider, witness.RightEdgeX, direction: 1);
            }
            finally
            {
                Physics2D.simulationMode = previousMode;
            }

            Assert.That(bossMarker, Is.Not.Null);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.True);
            GameObject leftWall = witness.LeftWall;
            GameObject rightWall = witness.RightWall;
            _scope.Dispose();
            Assert.That(leftWall.activeSelf, Is.False);
            Assert.That(rightWall.activeSelf, Is.False);
            Assert.That(F10GuardianPhysicalBoundaryInstaller.IsCurrent(witness, run, _scope, room), Is.False);

            yield return null;
            Assert.That(leftWall == null, Is.True, "Scope disposal must destroy the installed left wall.");
            Assert.That(rightWall == null, Is.True, "Scope disposal must destroy the installed right wall.");
        }

        [UnityTearDown]
        public IEnumerator Cleanup()
        {
            if (_scopeRoot != null) Object.Destroy(_scopeRoot);
            yield return null;
            foreach (Object transient in _transients)
                if (transient != null) Object.Destroy(transient);
            _transients.Clear();
            yield return null;
            _scopeRoot = null;
            _scope = null;
        }

        private static void AssertBodyStopsAtBoundary(Rigidbody2D body, Collider2D collider,
            float edgeX, int direction)
        {
            body.linearVelocity = new Vector2(direction * CustodianBoss2D.ChargeSpeed, 0f);
            body.angularVelocity = 0f;
            body.WakeUp();
            Physics2D.SyncTransforms();
            for (int tick = 0; tick < 120; tick++)
                Assert.That(Physics2D.Simulate(1f / 60f), Is.True, "Script-mode 2D physics must advance each tick.");
            Physics2D.SyncTransforms();

            if (direction < 0)
                Assert.That(collider.bounds.min.x, Is.GreaterThanOrEqualTo(edgeX - 0.02f),
                    "The live Custodian collider must remain inside the left room edge.");
            else
                Assert.That(collider.bounds.max.x, Is.LessThanOrEqualTo(edgeX + 0.02f),
                    "The live Custodian collider must remain inside the right room edge.");
        }

        private static CustodianBoss2D CreateCustodian(GameObject prefab, RoomLifetimeScope scope,
            PlayerMotor2D player, CustodianBossDefinition definition, GameObject wavePrefab,
            Transform waveParent, float x, float y, float minimumX, float maximumX, float floorTopY)
        {
            GameObject root = Object.Instantiate(prefab);
            root.name = "F10 Guardian physical test Custodian";
            root.transform.position = new Vector3(x, y, 0f);
            scope.OwnActor(root);
            CustodianBoss2D custodian = root.GetComponent<CustodianBoss2D>();
            Assert.That(custodian, Is.Not.Null);
            custodian.Initialize(ActorId.New(), player, definition, wavePrefab, waveParent,
                minimumX, maximumX, floorTopY);
            Assert.That(custodian.CurrentHealth, Is.EqualTo(definition.MaximumHealth));
            return custodian;
        }

        private (RoomTemplatePrefab2D room, RoomPositionMarker2D bossMarker) CreateGuardianRoom(
            ExpeditionRunConfiguration run, TextAsset roomSource, RoomTemplateData data)
        {
            _scopeRoot = new GameObject("F10 Guardian boundary test scope");
            _scopeRoot.transform.position = new Vector3(31f, 12f, 0f);
            _scope = _scopeRoot.AddComponent<RoomLifetimeScope>();
            _scope.Initialize(ExpeditionRoomIdentity.ForNode(run.RunId,
                F10GuardianPhysicalBoundaryInstaller.GuardianNodeId),
                F10GuardianPhysicalBoundaryInstaller.GuardianTemplateId);

            var roomRoot = new GameObject("Room.room.patio.guardian");
            roomRoot.transform.SetParent(_scopeRoot.transform, false);
            roomRoot.transform.localPosition = new Vector3(2f, 3f, 0f);
            RoomTemplatePrefab2D room = roomRoot.AddComponent<RoomTemplatePrefab2D>();

            var cameraRoot = new GameObject("CameraBounds");
            cameraRoot.transform.SetParent(roomRoot.transform, false);
            cameraRoot.transform.localPosition = new Vector3(data.widthTiles * data.tileSize * 0.5f,
                data.heightTiles * data.tileSize * 0.5f, 0f);
            BoxCollider2D cameraBounds = cameraRoot.AddComponent<BoxCollider2D>();
            cameraBounds.isTrigger = true;
            cameraBounds.size = new Vector2(data.widthTiles * data.tileSize, data.heightTiles * data.tileSize);

            int groundLayer = LayerMask.NameToLayer("Ground");
            Assert.That(groundLayer, Is.GreaterThanOrEqualTo(0));
            var gridRoot = new GameObject("Grid");
            gridRoot.transform.SetParent(roomRoot.transform, false);
            Grid grid = gridRoot.AddComponent<Grid>();
            grid.cellSize = new Vector3(data.tileSize, data.tileSize, 1f);
            var tilemapRoot = new GameObject("GroundTilemap", typeof(Tilemap), typeof(TilemapRenderer), typeof(TilemapCollider2D));
            tilemapRoot.transform.SetParent(gridRoot.transform, false);
            tilemapRoot.layer = groundLayer;
            Tilemap tilemap = tilemapRoot.GetComponent<Tilemap>();
            TilemapCollider2D groundCollider = tilemapRoot.GetComponent<TilemapCollider2D>();
            tilemap.tileAnchor = new Vector3(0.5f, 0.5f, 0f);

            var texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, Color.white);
            texture.Apply();
            _transients.Add(texture);
            Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 16f);
            _transients.Add(sprite);
            Tile floorTile = ScriptableObject.CreateInstance<Tile>();
            floorTile.sprite = sprite;
            floorTile.colliderType = Tile.ColliderType.Grid;
            _transients.Add(floorTile);
            for (int y = 0; y < data.heightTiles; y++)
            {
                for (int x = 0; x < data.widthTiles; x++)
                {
                    if (RoomTemplateJsonLoader.GetCell(data, x, y) == '#')
                        tilemap.SetTile(new Vector3Int(x, y, 0), floorTile);
                }
            }

            foreach (RoomPortData port in data.ports)
            {
                var portRoot = new GameObject("Port." + port.id);
                portRoot.transform.SetParent(roomRoot.transform, false);
                portRoot.transform.localPosition = new Vector3(
                    (port.side == "west" ? 0f : data.widthTiles) * data.tileSize,
                    port.tileY * data.tileSize, 0f);
                portRoot.AddComponent<RoomPortMarker2D>().Configure(port.id, port.type,
                    port.side, port.tileX, port.tileY, port.clearanceTiles);
            }

            RoomPositionMarker2D bossMarker = null;
            foreach (RoomPositionMarkerData marker in data.markers)
            {
                var markerRoot = new GameObject("Marker." + marker.id);
                markerRoot.transform.SetParent(roomRoot.transform, false);
                markerRoot.transform.localPosition = new Vector3(
                    (marker.tileX + 0.5f) * data.tileSize, marker.tileY * data.tileSize, 0f);
                RoomPositionMarker2D component = markerRoot.AddComponent<RoomPositionMarker2D>();
                component.Configure(marker.id, marker.kind, marker.tileX, marker.tileY);
                if (marker.id == "boss.custodian") bossMarker = component;
            }

            room.Configure(roomSource, cameraBounds, tilemap, groundCollider);
            return (room, bossMarker);
        }

        private static ExpeditionRunConfiguration CreateSampleRun()
        {
            return ExpeditionRunConfigurationFactory.CreateSample(BellatorSkillLoadout.ClassId,
                ExpeditionRunConfiguration.HumanRaceId,
                new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
        }

        private static T Load<T>(string path) where T : Object
        {
            T asset = AssetDatabase.LoadAssetAtPath<T>(path);
            Assert.That(asset, Is.Not.Null, "Required Guardian physical test source is missing: " + path);
            return asset;
        }
    }
}
#endif
