#if UNITY_EDITOR
using Luckbound.App;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10C1AdvanceRunnerPolicyTests
    {
        [Test]
        public void C1AdvanceRequiresRetainedClearAndClearedRuntimeAndRejectsConcurrentOrRepeatedStarts()
        {
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                true, RoomEncounterRuntimeStatus.Cleared, false, false, false), Is.True);
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                false, RoomEncounterRuntimeStatus.Cleared, false, false, false), Is.False);
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                true, RoomEncounterRuntimeStatus.Armed, false, false, false), Is.False);
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                true, RoomEncounterRuntimeStatus.Cleared, false, true, false), Is.False);
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                true, RoomEncounterRuntimeStatus.Cleared, true, false, false), Is.False);
            Assert.That(F10DiagnosticSceneRunner.CanStartC1RoomAdvanceAttempt(
                true, RoomEncounterRuntimeStatus.Cleared, true, false, true), Is.True);
        }

        [Test]
        public void OnlyAnExplicitPendingCommitResultUsesThePreparedAdvanceRetryPath()
        {
            Assert.That(F10DiagnosticSceneRunner.IsC1PendingAdvanceResult(
                RoomAdvanceCommitResult.Failure(true, "pending")), Is.True);
            Assert.That(F10DiagnosticSceneRunner.IsC1PendingAdvanceResult(
                RoomAdvanceCommitResult.Failure(false, "failed")), Is.False);
            Assert.That(F10DiagnosticSceneRunner.IsC1PendingAdvanceResult(null), Is.False);
        }
    }
}
#endif
