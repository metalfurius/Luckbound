#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using Luckbound.App;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Saves.V7;
using NUnit.Framework;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10V7C1RuntimePlanAdapterTests
    {
        [Test]
        public void ExactOpeningUsesRollbackAndPromotedRevisionUsesCurrentSnapshot()
        {
            Assert.That(TryClassifySnapshot(17, 17, "opening-json", "opening-json",
                "opening-json", out bool openingRollback, out string error), Is.True, error);
            Assert.That(openingRollback, Is.True,
                "Only the exact admitted/opening snapshot may restore through its entry checkpoint.");

            Assert.That(TryClassifySnapshot(17, 18, "opening-json", "opening-json",
                "promoted-json", out bool promotedRollback, out error), Is.True, error);
            Assert.That(promotedRollback, Is.False,
                "A later distinct App-confirmed revision must restore the current durable C1 state.");
        }

        [Test]
        public void AmbiguousOrDriftedOpeningSnapshotCannotChooseEitherRestoreBoundary()
        {
            Assert.That(TryClassifySnapshot(17, 17, "opening-json", "opening-json",
                "edited-json", out bool sameRevisionRollback, out _), Is.False);
            Assert.That(sameRevisionRollback, Is.False);

            Assert.That(TryClassifySnapshot(17, 18, "opening-json", "opening-json",
                "opening-json", out bool staleHandleRollback, out _), Is.False);
            Assert.That(staleHandleRollback, Is.False);

            Assert.That(TryClassifySnapshot(18, 17, "opening-json", "opening-json",
                "promoted-json", out bool regressedRevisionRollback, out _), Is.False);
            Assert.That(regressedRevisionRollback, Is.False);
        }

        [Test]
        public void C1RosterUsesPinnedWaveOrderSpawnIdsAndCanonicalIdentities()
        {
            AdapterFixture fixture = CreateFixture(none: false);

            Assert.That(F10V7C1RuntimePlanAdapter.TryDeriveRoster(fixture.Plan,
                out ExpeditionEncounterRosterPlan roster, out string error), Is.True, error);
            Assert.That(roster.Waves.Count, Is.EqualTo(2));
            Assert.That(roster.Waves[0].WaveNumber, Is.EqualTo(1));
            Assert.That(roster.Waves[1].WaveNumber, Is.EqualTo(2));
            CollectionAssert.AreEqual(new[]
            {
                fixture.Plan.GetSpawnIdentity("spawn.slime.01").Key,
                fixture.Plan.GetSpawnIdentity("spawn.huesoguardia.01").Key
            }, roster.Waves[0].SpawnKeys);
            CollectionAssert.AreEqual(new[]
            {
                fixture.Plan.GetSpawnIdentity("spawn.slime.02").Key,
                fixture.Plan.GetSpawnIdentity("spawn.huesoguardia.02").Key
            }, roster.Waves[1].SpawnKeys);
            Assert.That(roster.Waves[0].SpawnKeys, Does.Not.Contain("spawn.slime.01"));
        }

        [Test]
        public void CanonicalPlanDigestMustMatchBothCurrentPinEntryAndTypedCheckpointEntry()
        {
            AdapterFixture fixture = CreateFixture(none: false);
            Assert.That(F10V7C1RuntimePlanAdapter.TryValidatePinnedC1Plan(fixture.Plan,
                fixture.Pin, fixture.Checkpoint, out string digest, out string error), Is.True, error);
            Assert.That(digest, Is.EqualTo(fixture.Pin.Entry.ResolvedPlanSha256));
            Assert.That(digest, Is.EqualTo(fixture.Checkpoint.encounterEntry.resolvedPlanSha256));

            fixture.Checkpoint.encounterEntry.resolvedPlanSha256 = new string('f', 64);
            Assert.That(F10V7C1RuntimePlanAdapter.TryValidatePinnedC1Plan(fixture.Plan,
                fixture.Pin, fixture.Checkpoint, out _, out error), Is.False);
            Assert.That(error, Does.Contain("pin.entry or checkpoint.encounterEntry"));
        }

        [Test]
        public void NonePlanCannotProduceC1RosterOrPhysicalRuntimePlan()
        {
            AdapterFixture fixture = CreateFixture(none: true);
            Assert.That(F10V7C1RuntimePlanAdapter.TryDeriveRoster(fixture.Plan,
                out ExpeditionEncounterRosterPlan roster, out _), Is.False);
            Assert.That(roster, Is.Null);
        }

        [Test]
        public void PhysicalRuntimePlanFailsClosedWithoutAppMeasuredAssetSnapshot()
        {
            AdapterFixture fixture = CreateFixture(none: false);
            Assert.That(F10V7C1RuntimePlanAdapter.TryBuildRuntimePlan(null, null, 0,
                null, null, fixture.Plan, null,
                out RoomEncounterRuntimePlan runtimePlan, out string error), Is.False);
            Assert.That(runtimePlan, Is.Null);
            Assert.That(error, Does.Contain("measured asset snapshot"));
        }

        private static AdapterFixture CreateFixture(bool none)
        {
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId,
                new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });

            EncounterCatalogManifest manifest = none ? CreateNoneManifest() : CreateEncounterManifest();
            Assert.That(EncounterPlanResolverV1.TryResolve(manifest, run,
                ApplicationBootstrapper.F10V7C1NodeId, Array.Empty<string>(),
                out ResolvedEncounterPlanV1 plan, out EncounterPlanResolutionErrorV1 resolveError),
                Is.True, resolveError.Message);

            EncounterPlanPinV1 pin = EncounterPlanPinV1.Capture(manifest, run,
                new[] { plan }, ApplicationBootstrapper.F10V7C1NodeId);
            var checkpoint = new ExpeditionRoomCheckpointSaveDataV7
            {
                roomNodeId = ApplicationBootstrapper.F10V7C1NodeId,
                encounterEntry = new EncounterPlanEntryReferenceSaveDataV7
                {
                    nodeId = pin.Entry.NodeId,
                    resolvedPlanSha256 = pin.Entry.ResolvedPlanSha256
                }
            };
            return new AdapterFixture(plan, pin, checkpoint);
        }

        private static bool TryClassifySnapshot(long openingRevision, long currentRevision,
            string admittedJson, string handleExactJson, string currentConfirmedJson,
            out bool openingRollback, out string error)
        {
            MethodInfo classifier = typeof(ApplicationBootstrapper).GetMethod(
                "TryClassifyF10V7CombatCurrentSnapshot",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(classifier, Is.Not.Null,
                "Runtime C1 must share App's private current-snapshot classifier with settlement.");

            object[] arguments =
            {
                openingRevision, currentRevision, admittedJson, handleExactJson,
                currentConfirmedJson, false, string.Empty
            };
            bool result = (bool)classifier.Invoke(null, arguments);
            openingRollback = (bool)arguments[5];
            error = (string)arguments[6];
            return result;
        }

        private static EncounterCatalogManifest CreateEncounterManifest()
        {
            var descriptors = new List<EncounterCatalogDescriptor>();
            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptor("room.patio.c1", 1,
                EncounterCatalogDescriptorKind.Room, new string('a', 64),
                out EncounterCatalogDescriptor roomDescriptor, out EncounterCatalogError error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptor("enemy.slime", 1,
                EncounterCatalogDescriptorKind.Enemy, new string('b', 64),
                out EncounterCatalogDescriptor slimeDescriptor, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptor("enemy.huesoguardia", 1,
                EncounterCatalogDescriptorKind.Enemy, new string('c', 64),
                out EncounterCatalogDescriptor boneguardDescriptor, out error), Is.True, error.Message);
            descriptors.Add(roomDescriptor);
            descriptors.Add(slimeDescriptor);
            descriptors.Add(boneguardDescriptor);

            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptorRef("room.patio.c1", 1,
                out EncounterCatalogDescriptorRef roomReference, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptorRef("enemy.slime", 1,
                out EncounterCatalogDescriptorRef slimeReference, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateDescriptorRef("enemy.huesoguardia", 1,
                out EncounterCatalogDescriptorRef boneguardReference, out error), Is.True, error.Message);

            EncounterCatalogWave first = CreateWave("wave.c1.01", new[]
            {
                CreateSpawn("spawn.slime.01", "enemy.slime", slimeReference, "spawn.slime.01"),
                CreateSpawn("spawn.huesoguardia.01", "enemy.huesoguardia", boneguardReference, "spawn.slime.01")
            });
            EncounterCatalogWave second = CreateWave("wave.c1.02", new[]
            {
                CreateSpawn("spawn.slime.02", "enemy.slime", slimeReference, "spawn.slime.02"),
                CreateSpawn("spawn.huesoguardia.02", "enemy.huesoguardia", boneguardReference, "spawn.slime.02")
            });
            Assert.That(EncounterCatalogFactoryV1.TryCreateVariant("variant.c1.adapter.synthetic",
                Array.Empty<string>(), Array.Empty<string>(), 0, roomReference,
                new[] { first, second }, null, out EncounterCatalogVariant variant, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateDefinition("encounter.c1.adapter.synthetic", 1,
                new[] { variant }, out EncounterCatalogDefinition definition, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateBinding(2,
                ApplicationBootstrapper.F10V7C1TemplateId, ExpeditionRouteNodeKind.Combat,
                EncounterCatalogBindingMode.Encounter, "encounter.c1.adapter.synthetic", 1,
                out EncounterCatalogBinding binding, out error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateManifest(1, "catalog.c1.adapter.synthetic", 1,
                "encounter-spawn.v1", EncounterPlanResolverV1.SupportedResolverId,
                EncounterPlanResolverV1.SupportedResolverRevision, new[] { 2 }, descriptors,
                new[] { binding }, new[] { definition }, out EncounterCatalogManifest manifest,
                out error), Is.True, error.Message);
            return manifest;
        }

        private static EncounterCatalogManifest CreateNoneManifest()
        {
            Assert.That(EncounterCatalogFactoryV1.TryCreateBinding(2,
                ApplicationBootstrapper.F10V7C1TemplateId, ExpeditionRouteNodeKind.Combat,
                EncounterCatalogBindingMode.None, null, 0,
                out EncounterCatalogBinding binding, out EncounterCatalogError error), Is.True, error.Message);
            Assert.That(EncounterCatalogFactoryV1.TryCreateManifest(1, "catalog.c1.none.synthetic", 1,
                "encounter-spawn.v1", EncounterPlanResolverV1.SupportedResolverId,
                EncounterPlanResolverV1.SupportedResolverRevision, new[] { 2 },
                Array.Empty<EncounterCatalogDescriptor>(), new[] { binding },
                Array.Empty<EncounterCatalogDefinition>(), out EncounterCatalogManifest manifest,
                out error), Is.True, error.Message);
            return manifest;
        }

        private static EncounterCatalogSpawn CreateSpawn(string spawnId, string enemyId,
            EncounterCatalogDescriptorRef descriptor, string anchorId)
        {
            Assert.That(EncounterCatalogFactoryV1.TryCreateSpawn(spawnId, enemyId, descriptor,
                anchorId, ExpeditionEncounterRewardEnemyKind.Normal, 0,
                out EncounterCatalogSpawn spawn, out EncounterCatalogError error), Is.True, error.Message);
            return spawn;
        }

        private static EncounterCatalogWave CreateWave(string waveId,
            IEnumerable<EncounterCatalogSpawn> spawns)
        {
            Assert.That(EncounterCatalogFactoryV1.TryCreateWave(waveId, spawns,
                out EncounterCatalogWave wave, out EncounterCatalogError error), Is.True, error.Message);
            return wave;
        }

        private sealed class AdapterFixture
        {
            internal AdapterFixture(ResolvedEncounterPlanV1 plan, EncounterPlanPinV1 pin,
                ExpeditionRoomCheckpointSaveDataV7 checkpoint)
            { Plan = plan; Pin = pin; Checkpoint = checkpoint; }
            internal ResolvedEncounterPlanV1 Plan { get; }
            internal EncounterPlanPinV1 Pin { get; }
            internal ExpeditionRoomCheckpointSaveDataV7 Checkpoint { get; }
        }
    }
}
#endif
