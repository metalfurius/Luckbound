using System.Collections;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Enemies;
using Luckbound.Gameplay.Movement;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class CustodianBossArenaBoundsTests
    {
        private const float ArenaWidth = 4f;
        private const float ArenaFloorTop = 7.5f;
        private const float ArenaMinimumX = 40f;
        private const float ArenaMaximumX = ArenaMinimumX + ArenaWidth;

        [UnityTest]
        public IEnumerator WaveSpawnsAndTravelsInsideTranslatedArenaFromLeftBoundary()
        {
            yield return RunBoundaryWaveScenario(leftBoundary: true);
        }

        [UnityTest]
        public IEnumerator WaveSpawnsAndTravelsInsideTranslatedArenaFromRightBoundary()
        {
            yield return RunBoundaryWaveScenario(leftBoundary: false);
        }

        [UnityTest]
        public IEnumerator ChargeOutsideArenaSuppressesTheNextInvalidWave()
        {
            const float worldOffsetY = 11f;
            float floorTopY = worldOffsetY + ArenaFloorTop;
            float bossX = ArenaMaximumX - 0.25f;
            float playerX = bossX + 7f;
            var fixture = CreateFixture(bossX, floorTopY + 0.9f, floorTopY,
                ArenaMinimumX, ArenaMaximumX, playerX,
                new Vector3(ArenaMinimumX + 90f, worldOffsetY + 70f, 0f));

            try
            {
                bool secondWavePattern = false;
                for (int tick = 0; tick < 900; tick++)
                {
                    yield return new WaitForFixedUpdate();
                    if (fixture.Boss.WavePatternCount >= 2)
                    {
                        secondWavePattern = true;
                        break;
                    }
                }

                Assert.That(secondWavePattern, Is.True, "The boss must reach its next wave pattern after charging.");
                Assert.That(fixture.Boss.ChargePatternCount, Is.GreaterThanOrEqualTo(1));
                Assert.That(fixture.Boss.transform.position.x, Is.GreaterThan(ArenaMaximumX),
                    "The charge must physically carry the boss beyond the arena bound.");
                Assert.That(fixture.Boss.WaveSpawnCount, Is.EqualTo(1),
                    "The out-of-bounds boss must not emit a wave with an invalid spawn pose.");
                Assert.That(fixture.WaveRoot.GetComponentsInChildren<CustodianWaveHazard2D>().Length, Is.Zero);
            }
            finally
            {
                fixture.Destroy();
            }

            yield return null;
        }

        [UnityTest]
        public IEnumerator WorldBoundsOverloadRejectsInvalidBoundsAndPositionAndLegacyOverloadStillInitializes()
        {
            ArenaFixture[] fixtures = new ArenaFixture[5];
            try
            {
                fixtures[0] = CreateFixture(ArenaMinimumX + 1f, ArenaFloorTop + 0.9f, ArenaFloorTop,
                    ArenaMinimumX, ArenaMaximumX, ArenaMinimumX + 2.5f, Vector3.zero, initializeBoss: false);
                Assert.Throws<System.ArgumentOutOfRangeException>(() => fixtures[0].Boss.Initialize(
                    fixtures[0].BossActorId, fixtures[0].Player, fixtures[0].Definition, fixtures[0].WavePrefab,
                    fixtures[0].WaveRoot.transform, float.NaN, ArenaMaximumX, ArenaFloorTop));

                fixtures[1] = CreateFixture(ArenaMinimumX + 1f, ArenaFloorTop + 0.9f, ArenaFloorTop,
                    ArenaMinimumX, ArenaMaximumX, ArenaMinimumX + 2.5f, Vector3.zero, initializeBoss: false);
                Assert.Throws<System.ArgumentException>(() => fixtures[1].Boss.Initialize(
                    fixtures[1].BossActorId, fixtures[1].Player, fixtures[1].Definition, fixtures[1].WavePrefab,
                    fixtures[1].WaveRoot.transform, ArenaMaximumX, ArenaMaximumX, ArenaFloorTop));

                fixtures[2] = CreateFixture(ArenaMinimumX + 1f, ArenaFloorTop + 0.9f, ArenaFloorTop,
                    ArenaMinimumX, ArenaMaximumX, ArenaMinimumX + 2.5f, Vector3.zero, initializeBoss: false);
                Assert.Throws<System.ArgumentException>(() => fixtures[2].Boss.Initialize(
                    fixtures[2].BossActorId, fixtures[2].Player, fixtures[2].Definition, fixtures[2].WavePrefab,
                    fixtures[2].WaveRoot.transform, ArenaMinimumX + 1.1f, ArenaMaximumX, ArenaFloorTop));

                fixtures[3] = CreateFixture(ArenaMinimumX + 1f, ArenaFloorTop + 0.9f, ArenaFloorTop,
                    ArenaMinimumX, ArenaMaximumX, ArenaMinimumX + 2.5f, Vector3.zero, initializeBoss: false);
                Assert.Throws<System.ArgumentException>(() => fixtures[3].Boss.Initialize(
                    fixtures[3].BossActorId, fixtures[3].Player, fixtures[3].Definition, fixtures[3].WavePrefab,
                    fixtures[3].WaveRoot.transform, ArenaMinimumX, ArenaMaximumX, ArenaFloorTop + 1f));

                fixtures[4] = CreateFixture(0f, 0f, ArenaFloorTop, ArenaMinimumX, ArenaMaximumX,
                    ArenaMinimumX + 2.5f, Vector3.zero, initializeBoss: false);
                fixtures[4].Boss.Initialize(fixtures[4].BossActorId, fixtures[4].Player,
                    fixtures[4].Definition, fixtures[4].WavePrefab, fixtures[4].WaveRoot.transform);
                Assert.That(fixtures[4].Boss.CurrentHealth, Is.EqualTo(fixtures[4].Definition.MaximumHealth));
            }
            finally
            {
                foreach (ArenaFixture fixture in fixtures)
                {
                    if (fixture != null) fixture.Destroy();
                }
            }
            yield return null;
        }

        private static IEnumerator RunBoundaryWaveScenario(bool leftBoundary)
        {
            const float worldOffsetX = 40f;
            const float worldOffsetY = 11f;
            float minimumX = worldOffsetX;
            float maximumX = worldOffsetX + ArenaWidth;
            float floorTopY = worldOffsetY + ArenaFloorTop;
            float bossX = leftBoundary ? minimumX + 0.25f : maximumX - 0.25f;
            float playerX = leftBoundary ? bossX - 2.75f : bossX + 2.75f;
            var fixture = CreateFixture(bossX, floorTopY + 0.9f, floorTopY,
                minimumX, maximumX, playerX, new Vector3(worldOffsetX + 90f, worldOffsetY + 70f, 0f));

            try
            {
                bool waveSpawned = false;
                for (int tick = 0; tick < 360; tick++)
                {
                    yield return new WaitForFixedUpdate();
                    if (fixture.Boss.WaveSpawnCount > 0)
                    {
                        waveSpawned = true;
                        break;
                    }
                }

                Assert.That(waveSpawned, Is.True, "The physical boss must reach its wave pattern.");
                CustodianWaveHazard2D wave = fixture.WaveRoot.GetComponentInChildren<CustodianWaveHazard2D>();
                Assert.That(wave, Is.Not.Null);
                float spawnX = wave.transform.position.x;
                float spawnY = wave.transform.position.y;
                float bossWorldX = fixture.Boss.transform.position.x;
                Assert.That(spawnX, Is.InRange(minimumX, maximumX));
                Assert.That(spawnY, Is.EqualTo(floorTopY + 0.25f).Within(0.05f));
                Assert.That(wave.transform.parent, Is.EqualTo(fixture.WaveRoot.transform));
                Assert.That(leftBoundary ? spawnX > bossWorldX : spawnX < bossWorldX,
                    Is.True, "At an edge, the wave must spawn on the inward side of the boss.");

                for (int tick = 0; tick < 3; tick++) yield return new WaitForFixedUpdate();
                Assert.That(wave == null, Is.False, "The wave should still be inside the arena after three ticks.");
                float movedX = wave.transform.position.x;
                Assert.That(leftBoundary ? movedX > spawnX : movedX < spawnX,
                    Is.True, "The wave must travel toward the arena interior from either edge.");
                Assert.That(movedX, Is.InRange(minimumX, maximumX));

                for (int tick = 0; tick < 45 && wave != null; tick++) yield return new WaitForFixedUpdate();
                yield return null;
                Assert.That(wave == null, Is.True, "The wave should be removed when it crosses the opposite arena bound.");
            }
            finally
            {
                fixture.Destroy();
            }

            yield return null;
        }

        private static ArenaFixture CreateFixture(float bossX, float bossY, float floorTopY,
            float minimumX, float maximumX, float playerX, Vector3 parentOffset, bool initializeBoss = true)
        {
            int groundLayer = LayerMask.NameToLayer("Ground");
            Assert.That(groundLayer, Is.GreaterThanOrEqualTo(0), "Ground layer is required by PlayerMotor2D.");

            var floor = new GameObject("CustodianBoundsTest_Ground");
            floor.layer = groundLayer;
            floor.transform.position = new Vector3((minimumX + maximumX) * 0.5f, floorTopY - 0.5f, 0f);
            BoxCollider2D floorCollider = floor.AddComponent<BoxCollider2D>();
            float floorWidth = Mathf.Max(maximumX - minimumX + 12f,
                Mathf.Abs(playerX - (minimumX + maximumX) * 0.5f) * 2f + 4f);
            floorCollider.size = new Vector2(floorWidth, 1f);

            ActorId playerId = ActorId.New();
            var input = new PlayerInputBuffer(playerId);
            var playerObject = new GameObject("CustodianBoundsTest_Player");
            playerObject.transform.position = new Vector3(playerX, floorTopY + 0.9f, 0f);
            Rigidbody2D playerBody = playerObject.AddComponent<Rigidbody2D>();
            playerBody.gravityScale = 3f;
            CapsuleCollider2D playerCollider = playerObject.AddComponent<CapsuleCollider2D>();
            playerCollider.direction = CapsuleDirection2D.Vertical;
            playerCollider.size = new Vector2(0.75f, 1.5f);
            PlayerMotor2D player = playerObject.AddComponent<PlayerMotor2D>();
            player.Initialize(playerId, input, 1 << groundLayer, new CombatStats(5000, 50, 0));

            var waveRoot = new GameObject("CustodianBoundsTest_WaveRoot");
            waveRoot.transform.position = parentOffset;
            var wavePrefab = new GameObject("CustodianBoundsTest_WavePrefab");
            wavePrefab.AddComponent<Rigidbody2D>();
            BoxCollider2D waveCollider = wavePrefab.AddComponent<BoxCollider2D>();
            waveCollider.size = new Vector2(0.75f, 0.4f);
            waveCollider.isTrigger = true;
            wavePrefab.AddComponent<CustodianWaveHazard2D>();

            var bossObject = new GameObject("CustodianBoundsTest_Boss");
            bossObject.transform.position = new Vector3(bossX, bossY, 0f);
            bossObject.AddComponent<Rigidbody2D>().gravityScale = 3f;
            bossObject.AddComponent<BoxCollider2D>();
            bossObject.AddComponent<SpriteRenderer>();
            CustodianBoss2D boss = bossObject.AddComponent<CustodianBoss2D>();
            ActorId bossId = ActorId.New();
            TextAsset bossJson = Resources.Load<TextAsset>("Luckbound/Data/Encounters/CustodianBoss");
            Assert.That(bossJson, Is.Not.Null, "Custodian data is required by the physical fixture.");
            CustodianBossDefinition definition = CustodianBossJsonLoader.Load(bossJson.text);
            Physics2D.SyncTransforms();
            if (initializeBoss)
                boss.Initialize(bossId, player, definition, wavePrefab, waveRoot.transform,
                    minimumX, maximumX, floorTopY);
            return new ArenaFixture(floor, playerObject, player, waveRoot, wavePrefab, bossObject, boss,
                bossId, definition);
        }

        private sealed class ArenaFixture
        {
            public ArenaFixture(GameObject floor, GameObject playerObject, PlayerMotor2D player,
                GameObject waveRoot, GameObject wavePrefab, GameObject bossObject, CustodianBoss2D boss,
                ActorId bossActorId, CustodianBossDefinition definition)
            {
                Floor = floor;
                PlayerObject = playerObject;
                Player = player;
                WaveRoot = waveRoot;
                WavePrefab = wavePrefab;
                BossObject = bossObject;
                Boss = boss;
                BossActorId = bossActorId;
                Definition = definition;
            }

            public GameObject Floor { get; }
            public GameObject PlayerObject { get; }
            public PlayerMotor2D Player { get; }
            public GameObject WaveRoot { get; }
            public GameObject WavePrefab { get; }
            public GameObject BossObject { get; }
            public CustodianBoss2D Boss { get; }
            public ActorId BossActorId { get; }
            public CustodianBossDefinition Definition { get; }

            public void Destroy()
            {
                Object.Destroy(BossObject);
                Object.Destroy(PlayerObject);
                Object.Destroy(Floor);
                Object.Destroy(WaveRoot);
                Object.Destroy(WavePrefab);
            }
        }
    }
}
