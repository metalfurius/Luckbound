#if UNITY_EDITOR
using System;
using System.Globalization;
using Luckbound.App;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Saves;
using NUnit.Framework;

namespace Luckbound.Tests.App
{
    public sealed class F10ExtractionSettlementOwnershipTests
    {
        [Test]
        public void ProfileGateBusyIsIgnoredOnlyWhenItIsTheExtractionCallersOwnGate()
        {
            Assert.That(ApplicationBootstrapper.IsForeignF10ExtractionProfileGateBusy(
                gateBusy: true, underOwnGate: false), Is.True);
            Assert.That(ApplicationBootstrapper.IsForeignF10ExtractionProfileGateBusy(
                gateBusy: true, underOwnGate: true), Is.False);
            Assert.That(ApplicationBootstrapper.IsForeignF10ExtractionProfileGateBusy(
                gateBusy: false, underOwnGate: false), Is.False);
        }

        [Test]
        public void PendingCandidateIsAdoptedBeforeSaveAndRetryCanOwnOnlyThatExactCandidate()
        {
            var ownership = new ApplicationBootstrapper.F10ExtractionCandidateOwnership();
            object receiptAndProfileCandidate = new object();
            object replacementCandidate = new object();

            Assert.That(ownership.TryAdoptBeforeSave(receiptAndProfileCandidate), Is.True);
            Assert.That(ownership.IsAdoptedBeforeSave, Is.True);
            Assert.That(ownership.HasStartedSave, Is.False);

            ownership.MarkSaveStarted();

            Assert.That(ownership.HasStartedSave, Is.True);
            Assert.That(ownership.OwnsExact(receiptAndProfileCandidate), Is.True);
            Assert.That(ownership.OwnsExact(replacementCandidate), Is.False);
            Assert.That(ownership.TryAdoptBeforeSave(replacementCandidate), Is.False);
        }

        [Test]
        public void PendingRetryRequiresAuthenticatedV6ProfileMatchingTheExactProcessedRun()
        {
            RunId runId = RunId.New();
            ProfileSaveData expected = ProfileSaveData.CreateNewProfile();
            expected.processedSettlementRunIds = new[] { runId.ToString() };
            string validJson = SaveJsonCodec.Encode(ProfileEnvelope(expected, hasActiveExpedition: false));

            Assert.That(ApplicationBootstrapper.TryAuthenticateExactF10ExtractionPendingProfileJson(
                validJson, runId, expected, out string validError), Is.True, validError);

            ProfileSaveData different = expected.Clone();
            different.availableRenown++;
            Assert.That(ApplicationBootstrapper.TryAuthenticateExactF10ExtractionPendingProfileJson(
                validJson, runId, different, out _), Is.False);

            string activeExpeditionJson = SaveJsonCodec.Encode(
                ProfileEnvelope(expected, hasActiveExpedition: true));
            Assert.That(ApplicationBootstrapper.TryAuthenticateExactF10ExtractionPendingProfileJson(
                activeExpeditionJson, runId, expected, out _), Is.False);

            ProfileSaveData unprocessed = ProfileSaveData.CreateNewProfile();
            string unprocessedJson = SaveJsonCodec.Encode(
                ProfileEnvelope(unprocessed, hasActiveExpedition: false));
            Assert.That(ApplicationBootstrapper.TryAuthenticateExactF10ExtractionPendingProfileJson(
                unprocessedJson, runId, unprocessed, out _), Is.False);
        }

        private static ProfileSaveEnvelope ProfileEnvelope(ProfileSaveData profile, bool hasActiveExpedition)
        {
            profile.NormalizeForSave();
            return new ProfileSaveEnvelope
            {
                schemaVersion = SaveFormat.SchemaVersion,
                contentVersion = SaveFormat.ContentVersion,
                generation = 1,
                sequence = 1,
                savedAtUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                profile = profile,
                hasActiveExpedition = hasActiveExpedition,
                activeExpedition = null
            };
        }
    }
}
#endif
