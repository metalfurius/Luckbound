using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10ObjectiveSetupDemoTests
    {
        private readonly List<GameObject> _objects = new List<GameObject>();

        private enum Role { Tutorial, Exploration, Extraction }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (GameObject gameObject in _objects)
            {
                if (gameObject == null) continue;
                ExpeditionRoomTransitionController controller = gameObject.GetComponent<ExpeditionRoomTransitionController>();
                if (controller != null) controller.Dispose();
            }
            foreach (GameObject gameObject in _objects)
                if (gameObject != null) Object.Destroy(gameObject);
            _objects.Clear();
            yield return null;
        }

        [UnityTest]
        public IEnumerator SetupUsesTheRealRoleMarkersAddsOneCellAndCleansUpWithEachScope()
        {
            foreach (Role role in Enum.GetValues(typeof(Role)))
            {
                Fixture fixture = CreateFixture(role);
                RoomPositionMarker2D sourceMarker = fixture.Prefab.GetComponentsInChildren<RoomPositionMarker2D>(true)
                    .Single(marker => marker.MarkerId == fixture.MarkerId);
                Assert.That(sourceMarker.GetComponentsInChildren<Collider2D>(true), Is.Empty,
                    "The source template remains unchanged before setup.");

                var handoff = new RecordingHandoff();
                int ownedBefore = fixture.Scope.OwnedResourceCount;
                F10ObjectiveDriver2D driver = F10ObjectiveSetupDemo.Attach(
                    fixture.Context, fixture.SnapshotSource, fixture.PlayerCollider, handoff);
                Assert.That(driver, Is.Not.Null);
                Assert.That(fixture.Scope.GetComponent<F10ObjectiveDriver2D>(), Is.SameAs(driver));
                Assert.That(fixture.Prefab.GetComponentsInChildren<Collider2D>(true), Is.Empty,
                    "The helper modifies only the live room instance, never the prefab source.");

                BoxCollider2D[] triggers = fixture.Scope.GetComponentsInChildren<BoxCollider2D>(true)
                    .Where(collider => collider.gameObject.name.StartsWith("F10ObjectiveTrigger.", StringComparison.Ordinal))
                    .ToArray();
                Assert.That(triggers.Length, Is.EqualTo(1));
                Assert.That(triggers[0].enabled, Is.True);
                Assert.That(triggers[0].isTrigger, Is.True);
                Assert.That(triggers[0].offset, Is.EqualTo(Vector2.zero));
                Assert.That(triggers[0].size, Is.EqualTo(Vector2.one * fixture.TileSize));
                Assert.That(triggers[0].transform.parent, Is.SameAs(
                    fixture.Scope.GetComponentsInChildren<RoomPositionMarker2D>(true).Single(marker => marker.MarkerId == fixture.MarkerId).transform));
                Assert.That(fixture.Scope.OwnedResourceCount, Is.GreaterThan(ownedBefore));

                int ownedAfterSetup = fixture.Scope.OwnedResourceCount;
                Assert.Throws<InvalidOperationException>(() => F10ObjectiveSetupDemo.Attach(
                    fixture.Context, fixture.SnapshotSource, fixture.PlayerCollider, handoff),
                    "A second setup in the same activation must be rejected before creating another trigger.");
                Assert.That(fixture.Scope.OwnedResourceCount, Is.EqualTo(ownedAfterSetup));
                Assert.That(fixture.Scope.GetComponentsInChildren<BoxCollider2D>(true)
                    .Count(collider => collider.gameObject.name.StartsWith("F10ObjectiveTrigger.", StringComparison.Ordinal)), Is.EqualTo(1));

                fixture.Scope.Dispose();
                Assert.That(triggers[0].enabled, Is.False,
                    "Scope disposal disables the temporary trigger before destroying it.");
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator IncorrectActiveRoomSourceFailsBeforeItAddsAnything()
        {
            Fixture fixture = CreateFixture(Role.Exploration);
            RoomTemplatePrefab2D activeTemplate = fixture.Scope.GetComponentInChildren<RoomTemplatePrefab2D>(true);
            TextAsset wrongSource = Resources.Load<TextAsset>("Luckbound/Data/Rooms/F10SafeExtractionRoom");
            Assert.That(wrongSource, Is.Not.Null);
            activeTemplate.Configure(wrongSource, null, null, null);
            int resourcesBefore = fixture.Scope.OwnedResourceCount;

            Assert.Throws<InvalidOperationException>(() => F10ObjectiveSetupDemo.Attach(
                fixture.Context, fixture.SnapshotSource, fixture.PlayerCollider, new RecordingHandoff()));
            Assert.That(fixture.Scope.GetComponentsInChildren<Collider2D>(true), Is.Empty);
            Assert.That(fixture.Scope.GetComponent<F10ObjectiveDriver2D>(), Is.Null);
            Assert.That(fixture.Scope.OwnedResourceCount, Is.EqualTo(resourcesBefore));
            yield return null;
        }

        private Fixture CreateFixture(Role role)
        {
            string nodeId = role == Role.Tutorial ? "sample.tutorial" :
                role == Role.Exploration ? "sample.patio.exploration" : "sample.safe_extraction";
            string templateId = role == Role.Tutorial ? "room.sample.tutorial" :
                role == Role.Exploration ? "room.patio.e1" : "room.sample.extraction";
            string resource = role == Role.Tutorial ? "F10TutorialRoom" :
                role == Role.Exploration ? "F10PatioExplorationE1Room" : "F10SafeExtractionRoom";
            string markerId = role == Role.Tutorial ? "tutorial.interaction" :
                role == Role.Exploration ? "exit.trigger" : "extraction.interact";
            TextAsset source = Resources.Load<TextAsset>("Luckbound/Data/Rooms/" + resource);
            Assert.That(source, Is.Not.Null);
            RoomTemplateData data = RoomTemplateJsonLoader.Load(source.text);
            Assert.That(data.templateId, Is.EqualTo(templateId));

            string[] skills = { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId };
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId, skills, 2, 2, 1);
            var input = new PlayerInputBuffer(ActorId.New());
            GameObject playerObject = Track(new GameObject("F10 setup demo player"));
            playerObject.AddComponent<Rigidbody2D>().gravityScale = 3f;
            CapsuleCollider2D playerCollider = playerObject.AddComponent<CapsuleCollider2D>();
            playerCollider.direction = CapsuleDirection2D.Vertical;
            playerCollider.size = new Vector2(0.75f, 1.5f);
            PlayerMotor2D motor = playerObject.AddComponent<PlayerMotor2D>();
            motor.Initialize(input.ActorId, input, 1 << LayerMask.NameToLayer("Default"));

            GameObject prefab = Track(CreateRoomPrefab(source, data));
            GameObject controllerObject = Track(new GameObject("F10 setup demo room controller"));
            ExpeditionRoomTransitionController controller = controllerObject.AddComponent<ExpeditionRoomTransitionController>();
            int targetIndex = run.Route.MandatoryNodeIds.ToList().IndexOf(nodeId);
            Assert.That(targetIndex, Is.GreaterThanOrEqualTo(0));
            controller.Initialize(run.RunId, run.Route, _ => prefab, playerObject.transform,
                run.Route.MandatoryNodeIds.Take(targetIndex + 1));

            ExpeditionRouteNode node = run.Route.Nodes.Single(candidate => candidate.NodeId == nodeId);
            RoomEncounterRuntimeContext context = RoomEncounterRuntimeContext.Create(
                run.RunId, node.NodeId, node.TemplateId, controller.CurrentRoomId,
                controller.ActiveScope, controller, motor, plan: null,
                routeGenerationVersion: run.Route.GenerationVersion);
            var snapshotSource = new MutableSnapshotSource
            {
                BoundContext = context,
                Current = CreateSnapshot(context)
            };
            return new Fixture(context, snapshotSource, playerCollider, prefab, markerId, data.tileSize);
        }

        private GameObject CreateRoomPrefab(TextAsset source, RoomTemplateData data)
        {
            var prefab = new GameObject("F10 setup demo template prefab");
            prefab.AddComponent<RoomTemplatePrefab2D>().Configure(source, null, null, null);
            foreach (RoomPositionMarkerData definition in data.markers)
            {
                var markerObject = new GameObject(definition.id);
                markerObject.transform.SetParent(prefab.transform, false);
                markerObject.transform.localPosition = new Vector3((definition.tileX + 0.5f) * data.tileSize,
                    definition.tileY * data.tileSize, 0f);
                markerObject.AddComponent<RoomPositionMarker2D>().Configure(
                    definition.id, definition.kind, definition.tileX, definition.tileY);
            }
            return prefab;
        }

        private GameObject Track(GameObject gameObject)
        {
            _objects.Add(gameObject);
            return gameObject;
        }

        private static RoomEncounterRuntimeSessionSnapshot CreateSnapshot(RoomEncounterRuntimeContext context)
        {
            return new RoomEncounterRuntimeSessionSnapshot(context.RunId, context.NodeId,
                context.TemplateId, context.RouteGenerationVersion, context.RoomInstanceId,
                context.Scope, context.Controller, context.Player, context.ActivationGeneration,
                isSessionActive: true, hasBoundPlayer: true, hasCheckpointBinding: true,
                hasPublishedSession: true, hasRequiredGameplayBindings: true,
                roomCommitAndActivationComplete: true, hasPendingSessionMutation: false,
                isRoomAdvanceInFlight: false, hasPendingCommitOrActivation: false,
                hasPendingSimulationLeaseOrGate: false, isSimulationPaused: false);
        }

        private sealed class Fixture
        {
            internal Fixture(RoomEncounterRuntimeContext context, MutableSnapshotSource snapshotSource,
                Collider2D playerCollider, GameObject prefab, string markerId, float tileSize)
            {
                Context = context;
                SnapshotSource = snapshotSource;
                PlayerCollider = playerCollider;
                Prefab = prefab;
                MarkerId = markerId;
                TileSize = tileSize;
            }

            internal RoomEncounterRuntimeContext Context { get; }
            internal MutableSnapshotSource SnapshotSource { get; }
            internal Collider2D PlayerCollider { get; }
            internal GameObject Prefab { get; }
            internal string MarkerId { get; }
            internal float TileSize { get; }
            internal RoomLifetimeScope Scope => Context.Scope;
        }

        private sealed class MutableSnapshotSource : IRoomEncounterRuntimeSessionSnapshotSource
        {
            internal RoomEncounterRuntimeContext BoundContext;
            internal RoomEncounterRuntimeSessionSnapshot Current;
            public bool TryCapture(RoomEncounterRuntimeContext context, out RoomEncounterRuntimeSessionSnapshot snapshot)
            {
                snapshot = Current;
                return ReferenceEquals(context, BoundContext) && snapshot.IsInitialized;
            }
        }

        private sealed class RecordingHandoff : IF10ObjectiveObservationHandoff
        {
            public F10ObjectiveHandoffResult TryAcceptLocalObservation(F10ObjectiveObservation observation)
            {
                return F10ObjectiveHandoffResult.AcceptedLocalObservation;
            }
        }
    }
}
