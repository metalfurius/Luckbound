#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using System.Text;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    /// <summary>
    /// Storage-shape test for the Tutorial-to-C1 candidate. The fixture is synthetic and does not
    /// claim a physical objective, combat outcome, or successful room transition.
    /// </summary>
    public sealed class F10V7TutorialAdvanceCandidateTests
    {
        [Test]
        public void CandidatePreservesAuthenticatedProfileAndBuildsPinnedRewardlessC1Checkpoint()
        {
            ExpeditionRunConfiguration run = Fixture<ExpeditionRunConfiguration>("CreateRun", 0x61f09u);
            EncounterCatalogManifest manifest = Fixture<EncounterCatalogManifest>("CreateManifest",
                1, "variant.tutorial-candidate.fixture", false, false);
            EncounterCatalogRegistryV1 registry = Fixture<EncounterCatalogRegistryV1>("Registry",
                (object)new[] { manifest });
            PinnedProfileCandidateV7 initial = Fixture<PinnedProfileCandidateV7>("Initial", run, manifest);
            ProfileSaveEnvelopeV7 constructed = initial.CreateEnvelope(1, 1, "2026-11-20T00:00:00.0000000Z");
            constructed.profile.processedSettlementRunIds = new[] { RunId.New().ToString() };
            constructed.activeExpedition.claimedRewardIds = new[] { "claim.fixture.before-tutorial" };
            byte[] confirmedBytes = SaveV7JsonCodec.EncodeProfile(constructed);
            Assert.That(SaveV7JsonCodec.TryDecodeProfile(confirmedBytes,
                out ProfileSaveEnvelopeV7 authenticated, out SaveV7Error decodeError), Is.True, decodeError.Message);
            string confirmedJson = Encoding.UTF8.GetString(confirmedBytes);
            Assert.That(F10V7ExpeditionReadProjector.TryCreateCurrent(authenticated,
                run.Inventory.Catalog, registry, out F10V7ExpeditionReadProjection projection,
                out decodeError), Is.True, decodeError.Message);

            string inventoryJson = JsonUtility.ToJson(run.Inventory.CreateSnapshot());
            RoomInstanceId tutorialRoom = ExpeditionRoomIdentity.ForNode(run.RunId,
                F10V7TutorialAdvanceCandidate.TutorialNodeId);
            const string resultId = "room-result.v1:";
            string completionId = resultId + tutorialRoom;
            string completionJson = "{\"schema\":1,\"outcome\":\"cleared\",\"roomInstanceId\":\"" +
                tutorialRoom + "\",\"sourceNodeId\":\"sample.tutorial\",\"targetNodeId\":\"sample.patio.combat\",\"rewardIds\":[]}";
            Assert.That(F10V7TutorialAdvanceCandidate.TryCreateCommonCandidate(projection, run,
                tutorialRoom, completionId, completionJson, out ExpeditionSaveData capturedCommonCandidate,
                out string commonError), Is.True, commonError);
            // Data-only binder capture sentinel. This proves the V7 checkpoint consumes the
            // prepared common snapshot; it is not an actor observation or gameplay evidence.
            capturedCommonCandidate.currentHealth = Math.Max(1, capturedCommonCandidate.currentHealth - 1);
            capturedCommonCandidate.currentEnergy = Math.Max(0, capturedCommonCandidate.currentEnergy - 1);

            string checksum = authenticated.checksum;
            string alteredChecksum = (checksum[0] == 'a' ? "b" : "a") + checksum.Substring(1);
            string corruptedJson = confirmedJson.Replace(checksum, alteredChecksum);
            Assert.That(corruptedJson, Is.Not.EqualTo(confirmedJson));
            Assert.That(F10V7TutorialAdvanceCandidate.TryCreate(corruptedJson, projection, run, registry,
                tutorialRoom, completionId, completionJson, run.Inventory, inventoryJson, capturedCommonCandidate,
                out PinnedProfileCandidateV7 rejected, out _), Is.False);
            Assert.That(rejected, Is.Null, "An unauthenticated profile cannot produce a candidate.");

            string forgedRewardJson = completionJson.Replace("\"rewardIds\":[]", "\"rewardIds\":[\"claim.fake\"]");
            Assert.That(F10V7TutorialAdvanceCandidate.TryCreate(confirmedJson, projection, run, registry,
                tutorialRoom, completionId, forgedRewardJson, run.Inventory, inventoryJson, capturedCommonCandidate,
                out rejected, out _), Is.False);
            Assert.That(rejected, Is.Null, "Tutorial completion must remain rewardless.");

            ExpeditionSaveData alteredCapture = capturedCommonCandidate.Clone();
            alteredCapture.claimedRewardIds = new[] { "claim.fixture.forged" };
            Assert.That(F10V7TutorialAdvanceCandidate.TryCreate(confirmedJson, projection, run, registry,
                tutorialRoom, completionId, completionJson, run.Inventory, inventoryJson, alteredCapture,
                out rejected, out _), Is.False);
            Assert.That(rejected, Is.Null, "The actor capture cannot replace V7 claim history.");

            Assert.That(F10V7TutorialAdvanceCandidate.TryCreate(confirmedJson, projection, run, registry,
                tutorialRoom, completionId, completionJson, run.Inventory, inventoryJson, capturedCommonCandidate,
                out PinnedProfileCandidateV7 candidate, out string error), Is.True, error);
            ProfileSaveEnvelopeV7 encodedCandidate = candidate.CreateEnvelope(2, 2,
                "2026-11-20T00:00:01.0000000Z");
            Assert.That(SaveV7JsonCodec.TryDecodeProfile(SaveV7JsonCodec.EncodeProfile(encodedCandidate),
                out ProfileSaveEnvelopeV7 decoded, out decodeError), Is.True, decodeError.Message);

            Assert.That(SaveV7CandidateMapper.HasSameProfilePayload(authenticated.profile, decoded.profile), Is.True);
            CollectionAssert.AreEqual(authenticated.profile.processedSettlementRunIds,
                decoded.profile.processedSettlementRunIds);
            CollectionAssert.AreEqual(authenticated.activeExpedition.claimedRewardIds,
                decoded.activeExpedition.claimedRewardIds);
            Assert.That(decoded.activeExpedition.currentNodeId, Is.EqualTo(F10V7TutorialAdvanceCandidate.C1NodeId));
            CollectionAssert.AreEqual(new[] { F10V7TutorialAdvanceCandidate.TutorialNodeId },
                decoded.activeExpedition.completedRoomIds);
            Assert.That(decoded.activeExpedition.completedRoomResults, Has.Length.EqualTo(1));
            Assert.That(decoded.activeExpedition.completedRoomResults[0].resultJson, Is.EqualTo(completionJson));
            Assert.That(decoded.activeExpedition.completedRoomResults[0].resultId, Is.EqualTo(completionId));
            Assert.That(decoded.activeExpedition.inventorySnapshotJson, Is.EqualTo(inventoryJson));
            Assert.That(decoded.activeExpedition.encounterPlanPin.entry.nodeId,
                Is.EqualTo(F10V7TutorialAdvanceCandidate.C1NodeId));
            Assert.That(SaveV7JsonCodec.TryDecodeCheckpoint(Encoding.UTF8.GetBytes(
                decoded.activeExpedition.roomEntryCheckpointJson),
                out ExpeditionRoomCheckpointSaveDataV7 checkpoint, out decodeError), Is.True, decodeError.Message);
            Assert.That(checkpoint.roomNodeId, Is.EqualTo(F10V7TutorialAdvanceCandidate.C1NodeId));
            Assert.That(checkpoint.encounterEntry.nodeId, Is.EqualTo(F10V7TutorialAdvanceCandidate.C1NodeId));
            Assert.That(checkpoint.currentHealth, Is.EqualTo(capturedCommonCandidate.currentHealth));
            Assert.That(checkpoint.currentEnergy, Is.EqualTo(capturedCommonCandidate.currentEnergy));
            CollectionAssert.AreEqual(authenticated.activeExpedition.claimedRewardIds, checkpoint.claimedRewardIds);
        }

        private static T Fixture<T>(string methodName, params object[] arguments)
        {
            MethodInfo method = typeof(SaveV7AtomicRepositoryTests).GetMethod(methodName,
                BindingFlags.Static | BindingFlags.NonPublic);
            Assert.That(method, Is.Not.Null, "Existing V7 fixture helper was not found: " + methodName);
            return (T)method.Invoke(null, arguments);
        }
    }
}
#endif
