#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Luckbound.App;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Input;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10TutorialAdvanceCoordinatorTests
    {
        private readonly List<GameObject> _objects = new List<GameObject>();

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (GameObject gameObject in _objects)
            {
                if (gameObject == null) continue;
                ExpeditionRoomTransitionController controller = gameObject.GetComponent<ExpeditionRoomTransitionController>();
                if (controller != null) controller.Dispose();
            }
            foreach (GameObject gameObject in _objects)
                if (gameObject != null) Object.Destroy(gameObject);
            _objects.Clear();
            yield return null;
        }

        [UnityTest]
        public IEnumerator TutorialHandoffRequiresTheExactCurrentTutorialActorAndKind()
        {
            string[] skills = { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId };
            ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId, skills, 2, 2, 1);
            ActorId actorId = ActorId.New();
            var input = new PlayerInputBuffer(actorId);
            GameObject playerObject = Track(new GameObject("F10 tutorial coordinator test player"));
            playerObject.AddComponent<Rigidbody2D>();
            playerObject.AddComponent<CapsuleCollider2D>();
            PlayerMotor2D player = playerObject.AddComponent<PlayerMotor2D>();
            player.Initialize(actorId, input, 1 << LayerMask.NameToLayer("Default"));

            GameObject prefab = Track(new GameObject("F10 tutorial context test room"));
            GameObject spawnObject = new GameObject("spawn.player");
            spawnObject.transform.SetParent(prefab.transform, false);
            spawnObject.AddComponent<RoomPositionMarker2D>().Configure("spawn.player", "player_spawn", 2, 1);
            GameObject controllerObject = Track(new GameObject("F10 tutorial context test controller"));
            ExpeditionRoomTransitionController controller = controllerObject.AddComponent<ExpeditionRoomTransitionController>();
            controller.Initialize(run.RunId, run.Route, _ => prefab, playerObject.transform);

            ExpeditionRouteNode tutorial = run.Route.Nodes.Single(node => node.NodeId == "sample.tutorial");
            RoomEncounterRuntimeContext context = RoomEncounterRuntimeContext.Create(run.RunId,
                tutorial.NodeId, tutorial.TemplateId, controller.CurrentRoomId,
                controller.ActiveScope, controller, player, plan: null,
                routeGenerationVersion: run.Route.GenerationVersion);
            var valid = new F10ObjectiveObservation(F10ObjectiveObservationKind.TutorialCompleted,
                context, actorId, tick: 7);
            var wrongActor = new F10ObjectiveObservation(F10ObjectiveObservationKind.TutorialCompleted,
                context, ActorId.New(), tick: 7);
            var wrongKind = new F10ObjectiveObservation(F10ObjectiveObservationKind.ExplorationExitTouched,
                context, actorId, tick: 7);

            Assert.That(F10TutorialAdvanceCoordinator.IsExactTutorialObservationForContext(context, valid), Is.True);
            Assert.That(F10TutorialAdvanceCoordinator.IsExactTutorialObservationForContext(context, wrongActor), Is.False);
            Assert.That(F10TutorialAdvanceCoordinator.IsExactTutorialObservationForContext(context, wrongKind), Is.False);
            Assert.That(context.Plan, Is.Null, "The noncombat test context remains roster-free.");
            yield return null;
        }

        private GameObject Track(GameObject gameObject)
        {
            _objects.Add(gameObject);
            return gameObject;
        }
    }
}
#endif
