#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using Luckbound.App;
using Luckbound.Core.Combat;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Saves;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10DiagnosticCompositionGuardTests
    {
        [Test]
        public void ProductionRejectsDemoPlayerAndTechnicalEntryRejectsAnOrdinarySession()
        {
            Assert.That(ApplicationBootstrapper.Instance, Is.Null, "This isolated test requires no existing application.");
            Func<ISaveStore> previousFactory = ApplicationBootstrapper.EditorSaveStoreFactoryForTests;
            var appObject = new GameObject("Composition guard application");
            var productionObject = new GameObject("Production composition guard");
            var diagnosticObject = new GameObject("Diagnostic composition guard");
            var demoPlayer = new GameObject("MovementDemoPlayer");
            var technicalPlayer = new GameObject("F10TechnicalDiagnosticPlayer");
            try
            {
                string unusedPath = Path.Combine(Path.GetTempPath(), "LuckboundCompositionGuard", Guid.NewGuid().ToString("N"));
                ApplicationBootstrapper.EditorSaveStoreFactoryForTests = () => new FileSaveStore(unusedPath, null);
                appObject.AddComponent<ApplicationBootstrapper>();
                ExpeditionRunConfiguration run = ExpeditionRunConfigurationFactory.CreateSample(
                    BellatorSkillLoadout.ClassId, ExpeditionRunConfiguration.HumanRaceId,
                    new[] { BellatorSkillLoadout.ChargeId, BellatorSkillLoadout.CircularCutId });
                ExpeditionSaveData checkpoint = ExpeditionSaveMapper.Create(run);

                ExpeditionGameplayComposition production = productionObject.AddComponent<ExpeditionGameplayComposition>();
                FieldInfo productionPrefab = typeof(ExpeditionGameplayComposition).GetField(
                    "_productionPlayerPrefab", BindingFlags.Instance | BindingFlags.NonPublic);
                Assert.That(productionPrefab, Is.Not.Null);
                productionPrefab.SetValue(production, demoPlayer);
                Assert.That(production.TryInitialize(run, checkpoint, out string productionError), Is.False);
                Assert.That(productionError, Does.Contain("B07"));
                Assert.That(production.PlayerObject, Is.Null);

                ExpeditionGameplayComposition diagnostic = diagnosticObject.AddComponent<ExpeditionGameplayComposition>();
                Assert.That(diagnostic.TryInitializeF10Technical(run, checkpoint, technicalPlayer,
                    Array.Empty<ExpeditionRoomPrefabEntry>(), out string diagnosticError), Is.False);
                Assert.That(diagnosticError, Does.Contain("sesión F10 aislada"));
                Assert.That(diagnostic.PlayerObject, Is.Null);
                Assert.That(Directory.Exists(unusedPath), Is.False, "The guard check must not write a profile.");
            }
            finally
            {
                Object.DestroyImmediate(productionObject);
                Object.DestroyImmediate(diagnosticObject);
                Object.DestroyImmediate(demoPlayer);
                Object.DestroyImmediate(technicalPlayer);
                Object.DestroyImmediate(appObject);
                ApplicationBootstrapper.EditorSaveStoreFactoryForTests = previousFactory;
            }
        }
    }
}
#endif
