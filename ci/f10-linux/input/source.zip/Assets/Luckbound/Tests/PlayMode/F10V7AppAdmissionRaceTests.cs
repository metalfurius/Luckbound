#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Luckbound.App;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Inventory;
using Luckbound.Core.Saves;
using Luckbound.Core.Saves.V7;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    [Parallelizable(ParallelScope.None)]
    public sealed class F10V7AppAdmissionRaceTests
    {
        private GameObject _root;
        private object _previousInstance;

        [TearDown]
        public void TearDown()
        {
            if (_root != null)
            {
                ApplicationBootstrapper app = _root.GetComponent<ApplicationBootstrapper>();
                if (ReferenceEquals(ReadStaticField(typeof(ApplicationBootstrapper), "_instance"), app))
                    SetStaticField(typeof(ApplicationBootstrapper), "_instance", _previousInstance);
                UnityEngine.Object.DestroyImmediate(_root);
            }
        }

        [Test]
        public async Task ChangedRevisionAndRepositoryDuringBlockedReadKeepsAdmissionClosed()
        {
            ActiveV7Fixture fixture = CreateActiveV7Fixture();
            var blockedStore = new ControlledStore { Primary = null };
            var admissionRepository = new SaveRepository(blockedStore);
            SaveLoadResult<ProfileSaveEnvelope> initialLoad = await admissionRepository.LoadProfileAsync();
            Assert.That(initialLoad.Status, Is.EqualTo(SaveLoadStatus.Missing));
            Assert.That(admissionRepository.ProfileAccess, Is.EqualTo(SaveDataAccess.ReadWrite));

            blockedStore.Primary = fixture.Json;
            blockedStore.BlockNextProfileRead();
            ApplicationBootstrapper app = CreateApp(admissionRepository, SaveLoadStatus.Missing, revision: 4);
            Assert.That(app.CanWriteProfile, Is.True);

            Task<F10V7AppAdmissionResult> admissionTask = app.AdmitActiveV7ForPreproductionAsync(
                fixture.ItemCatalog, fixture.Registry);
            try
            {
                await Wait(blockedStore.ReadStarted.Task);
                Assert.That(app.CanWriteProfile, Is.False, "The App write gate must close before awaiting repository I/O.");
                var replacementStore = new ControlledStore();
                var replacementRepository = new SaveRepository(replacementStore);
                SaveLoadResult<ProfileSaveEnvelope> replacementLoad = await replacementRepository.LoadProfileAsync();
                Assert.That(replacementLoad.Status, Is.EqualTo(SaveLoadStatus.Missing));
                SetField(app, "_activeExpeditionRevision", 5L);
                SetField(app, "_saveRepository", replacementRepository);
            }
            finally
            {
                blockedStore.ReleaseBlockedRead();
                await Wait(admissionTask);
            }
            F10V7AppAdmissionResult result = await admissionTask;

            Assert.That(result.Admitted, Is.False);
            Assert.That(result.AdmissionArmed, Is.True);
            Assert.That(result.Message, Does.Contain("AppReviewChanged"));
            Assert.That(app.ActiveRun, Is.Null);
            Assert.That(app.ActiveExpedition, Is.Null);
            Assert.That(ReadField(app, "_f10V7AdmissionContext"), Is.Null);
            Assert.That(app.CanWriteProfile, Is.False, "The changed App review must leave the admission block in place.");
            Assert.That(admissionRepository.V7V6ProfileWriteAdmissionBarrierArmedSnapshot, Is.True);
            Assert.That(blockedStore.Writes, Is.Zero);
        }

        [Test]
        public async Task ExistingV6PendingWriteReleasesOnlyTemporaryAppBlockWithoutMoreIo()
        {
            ActiveV7Fixture fixture = CreateActiveV7Fixture();
            var store = new ControlledStore { FailWrites = true };
            var repository = new SaveRepository(store);
            SaveLoadResult<ProfileSaveEnvelope> load = await repository.LoadProfileAsync();
            Assert.That(load.Status, Is.EqualTo(SaveLoadStatus.Missing));

            SaveWriteResult pending = await repository.SaveProfileAsync(ProfileSaveData.CreateNewProfile());
            Assert.That(pending.Succeeded, Is.False);
            string retainedPendingJson = repository.ExportPendingJson(SaveDocument.Profile);
            Assert.That(retainedPendingJson, Is.Not.Null.And.Not.Empty);
            int readsBeforeAdmission = store.Reads;
            int writesBeforeAdmission = store.Writes;

            ApplicationBootstrapper app = CreateApp(repository, SaveLoadStatus.Missing, revision: 11);
            Assert.That(app.CanWriteProfile, Is.True);

            F10V7AppAdmissionResult result = await app.AdmitActiveV7ForPreproductionAsync(
                fixture.ItemCatalog, fixture.Registry);

            Assert.That(result.Admitted, Is.False);
            Assert.That(result.AdmissionArmed, Is.False);
            Assert.That(result.Message, Does.Contain("WritePending"));
            Assert.That(repository.ExportPendingJson(SaveDocument.Profile), Is.EqualTo(retainedPendingJson));
            Assert.That(repository.V7V6ProfileWriteAdmissionBarrierArmedSnapshot, Is.False);
            Assert.That(store.Reads, Is.EqualTo(readsBeforeAdmission), "A prior pending V6 retry must prevent another storage read.");
            Assert.That(store.Writes, Is.EqualTo(writesBeforeAdmission), "Admission must not retry or replace the pending write.");
            Assert.That(ReadField(app, "_f10V7AdmissionContext"), Is.Null);
            Assert.That(ReadField(app, "_f10V7AdmissionProfileWriteBlock"), Is.EqualTo(false));
            Assert.That(app.CanWriteProfile, Is.True, "Only the temporary App gate should be released for the existing retry owner.");
        }

        [Test]
        public async Task ChangedRevisionWithUnarmedRepositoryKeepsTheAppWriteBlock()
        {
            ActiveV7Fixture fixture = CreateActiveV7Fixture();
            var store = new ControlledStore();
            var repository = new SaveRepository(store);
            Assert.That((await repository.LoadProfileAsync()).Status, Is.EqualTo(SaveLoadStatus.Missing));
            ApplicationBootstrapper app = CreateApp(repository, SaveLoadStatus.Missing, revision: 8);
            store.BlockNextProfileWriteThenFail();
            Task<SaveWriteResult> pendingWrite = repository.SaveProfileAsync(ProfileSaveData.CreateNewProfile());
            Task<F10V7AppAdmissionResult> admissionTask = null;
            try
            {
                await Wait(store.WriteStarted.Task);
                admissionTask = app.AdmitActiveV7ForPreproductionAsync(fixture.ItemCatalog, fixture.Registry);
                Assert.That(admissionTask.IsCompleted, Is.False, "Admission must wait for the existing repository operation.");
                Assert.That(app.CanWriteProfile, Is.False);
                SetField(app, "_activeExpeditionRevision", 9L);
            }
            finally
            {
                store.ReleaseBlockedWrite();
                await Wait(pendingWrite);
                if (admissionTask != null) await Wait(admissionTask);
            }

            Assert.That((await pendingWrite).Succeeded, Is.False);
            F10V7AppAdmissionResult result = await admissionTask;
            Assert.That(result.Admitted, Is.False);
            Assert.That(result.AdmissionArmed, Is.False);
            Assert.That(result.Message, Does.Contain("AppReviewChanged"));
            Assert.That(repository.V7V6ProfileWriteAdmissionBarrierArmedSnapshot, Is.False);
            Assert.That(repository.ExportPendingJson(SaveDocument.Profile), Is.Not.Null.And.Not.Empty);
            Assert.That(ReadField(app, "_f10V7AdmissionProfileWriteBlock"), Is.EqualTo(true));
            Assert.That(ReadField(app, "_f10V7AdmissionContext"), Is.Null);
            Assert.That(app.ActiveRun, Is.Null);
            Assert.That(app.CanWriteProfile, Is.False);
        }

        private ApplicationBootstrapper CreateApp(SaveRepository repository, SaveLoadStatus status, long revision)
        {
            _root = new GameObject("F10 V7 App admission race test");
            _root.SetActive(false);
            ApplicationBootstrapper app = _root.AddComponent<ApplicationBootstrapper>();
            _previousInstance = ReadStaticField(typeof(ApplicationBootstrapper), "_instance");
            SetStaticField(typeof(ApplicationBootstrapper), "_instance", app);
            SetField(app, "_saveRepository", repository);
            SetField(app, "_activeExpeditionRevision", revision);
            SetProperty(app, "SaveDataReady", true);
            SetProperty(app, "ProfileLoadStatus", status);
            return app;
        }

        private static ActiveV7Fixture CreateActiveV7Fixture()
        {
            ExpeditionRunConfiguration run = InvokeFixture<ExpeditionRunConfiguration>("CreateRun", 0x61f09u);
            EncounterCatalogManifest manifest = InvokeFixture<EncounterCatalogManifest>(
                "CreateManifest", 1, "variant.r1", false, false);
            EncounterCatalogRegistryV1 registry = InvokeFixture<EncounterCatalogRegistryV1>(
                "Registry", (object)new[] { manifest });
            PinnedProfileCandidateV7 candidate = InvokeFixture<PinnedProfileCandidateV7>("Initial", run, manifest);
            var store = new ControlledStore();
            var repository = new SaveRepository(store);
            SaveWriteResult seeded = repository.CommitPinnedV7ForPreproductionAsync(candidate, run, registry)
                .GetAwaiter().GetResult();
            Assert.That(seeded.Succeeded, Is.True, seeded.Message);
            Assert.That(store.Primary, Is.Not.Null.And.Not.Empty);
            return new ActiveV7Fixture(run.Inventory.Catalog, registry, store.Primary);
        }

        private static T InvokeFixture<T>(string methodName, params object[] arguments)
        {
            MethodInfo method = typeof(SaveV7AtomicRepositoryTests).GetMethod(methodName,
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(method, Is.Not.Null, "V7 fixture method is missing: " + methodName);
            return (T)method.Invoke(null, arguments);
        }

        private static object ReadField(object target, string name) =>
            target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(target);

        private static void SetField(object target, string name, object value) =>
            target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).SetValue(target, value);

        private static object ReadStaticField(Type type, string name) =>
            type.GetField(name, BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);

        private static void SetStaticField(Type type, string name, object value) =>
            type.GetField(name, BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, value);

        private static void SetProperty(object target, string name, object value) =>
            target.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public)
                .GetSetMethod(nonPublic: true).Invoke(target, new[] { value });

        private static async Task Wait(Task task)
        {
            if (await Task.WhenAny(task, Task.Delay(TimeSpan.FromSeconds(5))) != task)
                throw new TimeoutException("The controlled operation did not finish within five seconds.");
            await task;
        }

        private sealed class ActiveV7Fixture
        {
            internal ActiveV7Fixture(ItemCatalog itemCatalog, EncounterCatalogRegistryV1 registry, string json)
            {
                ItemCatalog = itemCatalog;
                Registry = registry;
                Json = json;
            }

            internal ItemCatalog ItemCatalog { get; }
            internal EncounterCatalogRegistryV1 Registry { get; }
            internal string Json { get; }
        }

        private sealed class ControlledStore : ISaveStore
        {
            private TaskCompletionSource<SaveStorageSnapshot> _blockedRead;
            private bool _blockNextProfileRead;
            private TaskCompletionSource<bool> _blockedWrite;
            private bool _blockNextProfileWrite;

            internal string Primary;
            internal string Backup;
            internal int Reads;
            internal int Writes;
            internal bool FailWrites;
            internal readonly TaskCompletionSource<bool> ReadStarted =
                new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            internal readonly TaskCompletionSource<bool> WriteStarted =
                new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);

            public Task<SaveStorageSnapshot> ReadAsync(SaveDocument document)
            {
                Reads++;
                if (document == SaveDocument.Profile && _blockNextProfileRead)
                {
                    _blockNextProfileRead = false;
                    ReadStarted.TrySetResult(true);
                    return _blockedRead.Task;
                }
                return Task.FromResult(new SaveStorageSnapshot(Primary, Backup));
            }

            public Task WriteAsync(SaveDocument document, string json, string lastKnownGoodPrimaryJson)
            {
                Writes++;
                if (document == SaveDocument.Profile && _blockNextProfileWrite)
                {
                    _blockNextProfileWrite = false;
                    WriteStarted.TrySetResult(true);
                    return FailAfterReleaseAsync(_blockedWrite);
                }
                if (FailWrites) throw new IOException("Controlled test write failure.");
                if (lastKnownGoodPrimaryJson != null) Backup = lastKnownGoodPrimaryJson;
                Primary = json;
                return Task.CompletedTask;
            }

            internal void BlockNextProfileRead()
            {
                _blockedRead = new TaskCompletionSource<SaveStorageSnapshot>(TaskCreationOptions.RunContinuationsAsynchronously);
                _blockNextProfileRead = true;
            }

            internal void BlockNextProfileWriteThenFail()
            {
                _blockedWrite = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                _blockNextProfileWrite = true;
            }

            internal void ReleaseBlockedRead()
            {
                _blockedRead?.TrySetResult(new SaveStorageSnapshot(Primary, Backup));
            }

            internal void ReleaseBlockedWrite() => _blockedWrite?.TrySetResult(true);

            private static async Task FailAfterReleaseAsync(TaskCompletionSource<bool> release)
            {
                await release.Task;
                throw new IOException("Controlled delayed write failure.");
            }
        }
    }
}
#endif
