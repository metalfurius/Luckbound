#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Luckbound.App;
using Luckbound.Core.Identifiers;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10CachePendingContactIdentityTests
    {
        [Test]
        public void PendingCacheOwnerQueryRequiresExactOwnerAndContactReferences()
        {
            var objects = new List<GameObject>();
            try
            {
                ApplicationBootstrapper application = CreateInactive(objects, "cache-app")
                    .AddComponent<ApplicationBootstrapper>();
                ExpeditionGameplayComposition owner = CreateInactive(objects, "cache-owner")
                    .AddComponent<ExpeditionGameplayComposition>();
                ExpeditionGameplayComposition otherOwner = CreateInactive(objects, "other-cache-owner")
                    .AddComponent<ExpeditionGameplayComposition>();

                RoomLifetimeScope scope = CreateInactive(objects, "cache-scope")
                    .AddComponent<RoomLifetimeScope>();
                scope.Initialize(RoomInstanceId.New(), "room.patio.e1");
                ExplorationGoldCachePickup2D pickup = CreateInactive(objects, "cache-pickup")
                    .AddComponent<ExplorationGoldCachePickup2D>();
                RoomPositionMarker2D marker = CreateInactive(objects, "cache-marker")
                    .AddComponent<RoomPositionMarker2D>();
                marker.Configure("cache.exploration", "treasure", 21, 8);
                PlayerMotor2D player = CreateInactive(objects, "cache-player").AddComponent<PlayerMotor2D>();
                typeof(PlayerMotor2D).GetField("_actorId", BindingFlags.Instance | BindingFlags.NonPublic)
                    .SetValue(player, ActorId.New());
                Collider2D playerCollider = player.gameObject.AddComponent<BoxCollider2D>();

                ExplorationGoldCacheContact contact = CreateContact(pickup, scope, marker, player,
                    playerCollider, sequence: 1);
                ExplorationGoldCacheContact otherContact = CreateContact(pickup, scope, marker, player,
                    playerCollider, sequence: 2);

                Type pendingType = typeof(ApplicationBootstrapper).GetNestedType(
                    "PendingF10CacheClaim", BindingFlags.NonPublic);
                ConstructorInfo pendingConstructor = pendingType.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic)
                    .Single(constructor => constructor.GetParameters().Length == 8);
                object pendingClaim = pendingConstructor.Invoke(new object[]
                {
                    owner, contact, default(RunId), scope.RoomInstanceId, null, "cache.test.grant", 15, null
                });
                typeof(ApplicationBootstrapper).GetField("_pendingF10CacheClaim",
                    BindingFlags.Instance | BindingFlags.NonPublic).SetValue(application, pendingClaim);
                typeof(ApplicationBootstrapper).GetField("_pendingExpeditionSessionPublication",
                    BindingFlags.Instance | BindingFlags.NonPublic).SetValue(application, new Action(() => { }));

                // This object is an identity token for the read-only query only; no physical contact or grant is asserted.
                Assert.That(application.OwnsPendingF10CacheContact(owner, contact), Is.True);
                Assert.That(application.OwnsPendingF10CacheContact(otherOwner, contact), Is.False);
                Assert.That(application.OwnsPendingF10CacheContact(owner, otherContact), Is.False);
                Assert.That(application.OwnsPendingF10CacheContact(owner, null), Is.False);
            }
            finally
            {
                foreach (GameObject gameObject in objects)
                    if (gameObject != null) UnityEngine.Object.DestroyImmediate(gameObject);
            }
        }

        private static GameObject CreateInactive(List<GameObject> objects, string name)
        {
            var gameObject = new GameObject(name);
            gameObject.SetActive(false);
            objects.Add(gameObject);
            return gameObject;
        }

        private static ExplorationGoldCacheContact CreateContact(ExplorationGoldCachePickup2D pickup,
            RoomLifetimeScope scope, RoomPositionMarker2D marker, PlayerMotor2D player,
            Collider2D playerCollider, long sequence)
        {
            ConstructorInfo constructor = typeof(ExplorationGoldCacheContact)
                .GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic)
                .Single(candidate => candidate.GetParameters().Length == 8);
            return (ExplorationGoldCacheContact)constructor.Invoke(new object[]
            {
                pickup, scope, marker, player, playerCollider, "cache.exploration", 1L, sequence
            });
        }
    }
}
#endif
