#if UNITY_EDITOR
using System;
using System.Linq;
using System.Threading.Tasks;
using Luckbound.App;
using Luckbound.Core.Expeditions;
using Luckbound.Core.Identifiers;
using Luckbound.Core.Inventory;
using Luckbound.Core.Pacts;
using Luckbound.Core.Saves;
using Luckbound.Gameplay.Inventory;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.PlayMode
{
    public sealed class F10CacheCommitTests
    {
        [Test]
        public void SavedE1PactContextDerivesGoldAndInventoryReplayDoesNotGrantTwice()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            ExpeditionSaveData checkpoint = CreateE1FixtureCheckpoint(run);
            ExpeditionRouteNode node = FindE1Node(run);

            ExpeditionExplorationCacheReward ordinary =
                ApplicationBootstrapper.ResolveF10CacheRewardFromSavedContext(run, checkpoint, node,
                    ExplorationGoldCachePickup2D.F10MarkerId);
            checkpoint.pactIds = new[] { PactIds.Avarice };
            ExpeditionExplorationCacheReward avarice =
                ApplicationBootstrapper.ResolveF10CacheRewardFromSavedContext(run, checkpoint, node,
                    ExplorationGoldCachePickup2D.F10MarkerId);

            Assert.That(ordinary.Gold, Is.EqualTo(15));
            Assert.That(avarice.Gold, Is.EqualTo(20), "Avarice is applied to this cache source once and rounded down.");
            Assert.That(avarice.GoldGrantId, Is.EqualTo(ordinary.GoldGrantId),
                "The stable grant identity derives from the saved run/node/cache, while the saved pact derives its amount.");

            TransactionId transactionId = ApplicationBootstrapper.CreateF10CacheTransactionId(avarice.GoldGrantId);
            Assert.That(ApplicationBootstrapper.CreateF10CacheTransactionId(avarice.GoldGrantId), Is.EqualTo(transactionId));
            ExpeditionInventory candidate = ExpeditionInventory.Restore(run.Inventory.Catalog,
                run.Inventory.CreateSnapshot());
            int initialGold = candidate.Gold;
            InventoryOperationOutcome first = candidate.TryAddGold(avarice.Gold, transactionId);
            Assert.That(first.Succeeded, Is.True);
            Assert.That(candidate.Gold, Is.EqualTo(initialGold + 20));

            InventoryOperationOutcome replay = candidate.TryAddGold(avarice.Gold, transactionId);
            Assert.That(replay.Succeeded, Is.True);
            Assert.That(candidate.Gold, Is.EqualTo(initialGold + 20), "A retry with the stable transaction cannot add the gold twice.");
            Assert.That(run.Inventory.Gold, Is.EqualTo(initialGold), "The candidate inventory is not published by this calculation.");

            ExpeditionSaveData wrongCursor = checkpoint.Clone();
            wrongCursor.currentNodeId = "sample.patio.combat";
            Assert.Throws<InvalidOperationException>(() =>
                ApplicationBootstrapper.ResolveF10CacheRewardFromSavedContext(run, wrongCursor, node,
                    ExplorationGoldCachePickup2D.F10MarkerId));
        }

        [Test]
        public void FailedProfileWriteRetainsTheExactCacheCandidateUntilRetry()
        {
            ExpeditionRunConfiguration run = CreateSampleRun();
            ExpeditionSaveData candidateSave = CreateE1FixtureCheckpoint(run);
            ExpeditionRouteNode node = FindE1Node(run);
            candidateSave.pactIds = new[] { PactIds.Avarice };
            candidateSave.roomEntryCheckpointJson = JsonUtility.ToJson(ExpeditionSaveMapper.CreateCheckpoint(candidateSave));
            ExpeditionExplorationCacheReward reward =
                ApplicationBootstrapper.ResolveF10CacheRewardFromSavedContext(run, candidateSave, node,
                    ExplorationGoldCachePickup2D.F10MarkerId);
            TransactionId transactionId = ApplicationBootstrapper.CreateF10CacheTransactionId(reward.GoldGrantId);
            ExpeditionInventory candidateInventory = ExpeditionInventory.Restore(run.Inventory.Catalog,
                run.Inventory.CreateSnapshot());
            int initialGold = run.Inventory.Gold;
            Assert.That(candidateInventory.TryAddGold(reward.Gold, transactionId).Succeeded, Is.True);
            candidateSave.claimedRewardIds = new[] { reward.GoldGrantId };
            candidateSave.inventorySnapshotJson = JsonUtility.ToJson(candidateInventory.CreateSnapshot());

            var store = new RetryMemorySaveStore { FailNextProfileWrite = true };
            var repository = new SaveRepository(store);
            SaveLoadResult<ProfileSaveEnvelope> loaded = repository.LoadProfileAsync().GetAwaiter().GetResult();
            Assert.That(loaded.Status, Is.EqualTo(SaveLoadStatus.Missing));

            SaveWriteResult failed = repository.SaveProfileAsync(loaded.Data.profile, candidateSave)
                .GetAwaiter().GetResult();
            string pendingJson = repository.ExportPendingJson(SaveDocument.Profile);
            Assert.That(failed.Succeeded, Is.False);
            Assert.That(pendingJson, Is.Not.Null.And.Not.Empty);
            Assert.That(store.ProfilePrimary, Is.Null, "An I/O failure must not publish the candidate.");
            Assert.That(run.Inventory.Gold, Is.EqualTo(initialGold), "The live run remains unchanged while the write is pending.");

            SaveWriteResult retried = repository.RetryPendingAsync(SaveDocument.Profile).GetAwaiter().GetResult();
            Assert.That(retried.Succeeded, Is.True, retried.Message);
            Assert.That(store.ProfilePrimary, Is.EqualTo(pendingJson), "Retry writes the exact bytes retained after the first failure.");
            Assert.That(repository.ExportPendingJson(SaveDocument.Profile), Is.Null);
            Assert.That(candidateInventory.Gold, Is.EqualTo(initialGold + reward.Gold));
            Assert.That(candidateInventory.TryAddGold(reward.Gold, transactionId).Succeeded, Is.True);
            Assert.That(candidateInventory.Gold, Is.EqualTo(initialGold + reward.Gold),
                "The exact transaction replay remains idempotent after the candidate has been retried.");
        }

        private static ExpeditionRunConfiguration CreateSampleRun()
        {
            return ExpeditionRunConfigurationFactory.CreateSample("class.bellator",
                ExpeditionRunConfiguration.HumanRaceId,
                new[] { "skill.bellator.circular_cut", "skill.bellator.guard" });
        }

        private static ExpeditionRouteNode FindE1Node(ExpeditionRunConfiguration run)
        {
            return run.Route.Nodes.Single(node => string.Equals(node.NodeId,
                "sample.patio.exploration", StringComparison.Ordinal));
        }

        private static ExpeditionSaveData CreateE1FixtureCheckpoint(ExpeditionRunConfiguration run)
        {
            ExpeditionSaveData checkpoint = ExpeditionSaveMapper.Create(run);
            checkpoint.currentNodeId = "sample.patio.exploration";
            checkpoint.visitedNodeIds = run.Route.Nodes.Take(3).Select(node => node.NodeId).ToArray();
            checkpoint.roomEntryCheckpointJson = JsonUtility.ToJson(ExpeditionSaveMapper.CreateCheckpoint(checkpoint));
            return checkpoint;
        }

        private sealed class RetryMemorySaveStore : ISaveStore
        {
            private string _profileBackup;
            private string _settingsPrimary;
            private string _settingsBackup;

            public bool FailNextProfileWrite { get; set; }
            internal string ProfilePrimary { get; private set; }

            public Task<SaveStorageSnapshot> ReadAsync(SaveDocument document)
            {
                return Task.FromResult(document == SaveDocument.Profile
                    ? new SaveStorageSnapshot(ProfilePrimary, _profileBackup)
                    : new SaveStorageSnapshot(_settingsPrimary, _settingsBackup));
            }

            public Task WriteAsync(SaveDocument document, string json, string lastKnownGoodPrimaryJson)
            {
                if (document == SaveDocument.Profile && FailNextProfileWrite)
                {
                    FailNextProfileWrite = false;
                    throw new System.IO.IOException("simulated isolated profile write failure");
                }

                if (document == SaveDocument.Profile)
                {
                    if (!string.IsNullOrWhiteSpace(lastKnownGoodPrimaryJson)) _profileBackup = lastKnownGoodPrimaryJson;
                    ProfilePrimary = json;
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(lastKnownGoodPrimaryJson)) _settingsBackup = lastKnownGoodPrimaryJson;
                    _settingsPrimary = json;
                }
                return Task.CompletedTask;
            }
        }
    }
}
#endif
