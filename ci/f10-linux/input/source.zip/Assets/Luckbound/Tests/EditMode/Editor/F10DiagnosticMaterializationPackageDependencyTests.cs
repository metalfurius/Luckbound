#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using Luckbound.App;
using Luckbound.Editor;

namespace Luckbound.Tests.Editor
{
    public sealed class F10DiagnosticMaterializationPackageDependencyTests
    {
        private static MethodInfo Classifier => typeof(F10DiagnosticMaterializationReceiptValidator).GetMethod(
            "ClassifyDependencyPath", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo EvidenceShapeValidator => typeof(F10DiagnosticMaterializationReceiptValidator).GetMethod(
            "ValidatePackageDependencyEvidenceShape", BindingFlags.Static | BindingFlags.NonPublic);

        [TestCase("Packages/com.unity.render-pipelines.core/Runtime/Core.shader", false, "embedded-core-candidate")]
        [TestCase("Packages/com.unity.render-pipelines.core/Runtime/Core.shader", true, "embedded-core-candidate")]
        [TestCase("Packages/com.unity.render-pipelines.core-extra/Runtime/Core.shader", false, "package-helper")]
        [TestCase("Packages/com.unity.render-pipelines.universal/Shaders/Universal.shader", false, "package-helper")]
        [TestCase("Assets/Luckbound/Materials/World.mat", false, "uncovered")]
        [TestCase("Library/PackageCache/com.unity.render-pipelines.universal@17.6.0/package.json", false, "unrepresentable-package")]
        public void ClassifierKeepsCoreExclusionExactAndCertificateBound(string path, bool certified, string expected)
        {
            Assert.AreEqual(expected, Classifier.Invoke(null, new object[] { path, certified }));
        }

        [Test]
        public void ExporterAndValidatorMeasureTheSameGeneratorSourcesIncludingThePackageHelper()
        {
            const string helperPath = "Assets/Luckbound/Scripts/App/F10DiagnosticPackageDependencyEvidence.cs";
            string[] exporterPaths = (string[])typeof(F10DiagnosticMaterializationReceiptExporter)
                .GetField("GeneratorSourcePaths", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);
            string[] validatorPaths = (string[])typeof(F10DiagnosticMaterializationReceiptValidator)
                .GetField("GeneratorSourcePaths", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);

            CollectionAssert.AreEqual(validatorPaths, exporterPaths);
            Assert.AreEqual(1, Array.FindAll(exporterPaths, path =>
                string.Equals(path, helperPath, StringComparison.Ordinal)).Length);
        }

        [Test]
        public void PackageEvidenceMustCoverExactlyTheLiveHelperSubset()
        {
            const string path = "Packages/com.unity.render-pipelines.universal/Runtime/Universal.shader";
            F10DiagnosticPackageDependencyEvidence[] evidence = { Evidence(path) };
            Assert.DoesNotThrow(() => EvidenceShapeValidator.Invoke(null, new object[] { evidence, new[] { path } }));
        }

        [TestCase("missing")]
        [TestCase("extra")]
        [TestCase("duplicate")]
        [TestCase("incomplete row")]
        public void PackageEvidenceRejectsIncompleteOrBroadenedInventories(string mutation)
        {
            const string path = "Packages/com.unity.render-pipelines.universal/Runtime/Universal.shader";
            object[] arguments;
            if (mutation == "missing")
                arguments = new object[] { Array.Empty<F10DiagnosticPackageDependencyEvidence>(), new[] { path } };
            else if (mutation == "extra")
                arguments = new object[] { new[] { Evidence(path), Evidence(path + ".other") }, new[] { path } };
            else if (mutation == "duplicate")
                arguments = new object[] { new[] { Evidence(path), Evidence(path) }, new[] { path } };
            else
            {
                F10DiagnosticPackageDependencyEvidence incomplete = Evidence(path);
                incomplete.files = null;
                arguments = new object[] { new[] { incomplete }, new[] { path } };
            }

            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                EvidenceShapeValidator.Invoke(null, arguments));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException, mutation);
        }

        private static F10DiagnosticPackageDependencyEvidence Evidence(string path)
        {
            return new F10DiagnosticPackageDependencyEvidence
            {
                schemaVersion = 2,
                packageName = "com.unity.render-pipelines.universal",
                resolvedRootRelativePath = "Library/PackageCache/com.unity.render-pipelines.universal@17.6.0",
                dependencyAssetPaths = new[] { path },
                files = Array.Empty<F10DiagnosticPackageDependencyFile>()
            };
        }
    }
}
#endif
