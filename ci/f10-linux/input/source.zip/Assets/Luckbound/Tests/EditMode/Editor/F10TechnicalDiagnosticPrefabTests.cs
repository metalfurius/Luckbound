using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Luckbound.Editor;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.EditMode
{
    public sealed class F10TechnicalDiagnosticPrefabTests
    {
        private static readonly ExpectedRoom[] ExpectedRooms =
        {
            new ExpectedRoom("room.sample.tutorial", 20, 12, "F10TutorialDiagnostic.prefab"),
            new ExpectedRoom("room.patio.c1", 44, 18, "F10PatioCombatC1Diagnostic.prefab"),
            new ExpectedRoom("room.patio.e1", 46, 20, "F10PatioExplorationE1Diagnostic.prefab"),
            new ExpectedRoom("room.patio.guardian", 20, 12, "F10PatioGuardianDiagnostic.prefab"),
            new ExpectedRoom("room.sample.extraction", 20, 12, "F10SafeExtractionDiagnostic.prefab")
        };

        [Test]
        public void PreflightChecksPrototypeAndAllDestinationsWithoutWritingAssets()
        {
            string[] outputs = new[] { F10TechnicalDiagnosticPrefabGenerator.DiagnosticTilePath }
                .Concat(ExpectedRooms.Select(room => F10TechnicalDiagnosticPrefabGenerator.DiagnosticF10Folder + "/" + room.PrefabFileName))
                .ToArray();
            Dictionary<string, string> before = SnapshotExistingFiles(outputs);

            F10TechnicalDiagnosticPrefabGenerator.PreflightOnly();

            Dictionary<string, string> after = SnapshotExistingFiles(outputs);
            CollectionAssert.AreEquivalent(before.Keys, after.Keys, "Preflight must not create or remove output files.");
            foreach (string path in before.Keys)
                Assert.That(after[path], Is.EqualTo(before[path]), "Preflight changed " + path + ".");

            Assert.That(F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot, Does.Contain("/Diagnostic"));
            Assert.That(F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot, Does.Not.Contain("/Rooms/F10"));
        }

        [Test]
        public void DestinationPreflightAcceptsOnlyEmptyOrCompleteImportedAssets()
        {
            Assert.That(F10TechnicalDiagnosticPrefabGenerator.ClassifyDestination(false, false, false).ToString(), Is.EqualTo("Create"));
            Assert.That(F10TechnicalDiagnosticPrefabGenerator.ClassifyDestination(true, true, true).ToString(), Is.EqualTo("Reuse"));
        }

        [TestCase(true, false, false)]
        [TestCase(false, true, false)]
        [TestCase(true, true, false)]
        [TestCase(false, false, true)]
        public void DestinationPreflightRejectsPartialOrUnimportedAssets(bool fileExists, bool metaExists, bool importedAssetExists)
        {
            Assert.Throws<InvalidOperationException>(() =>
                F10TechnicalDiagnosticPrefabGenerator.ClassifyDestination(fileExists, metaExists, importedAssetExists));
        }

        private static Dictionary<string, string> SnapshotExistingFiles(IEnumerable<string> assetPaths)
        {
            var snapshot = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (string assetPath in assetPaths)
            {
                foreach (string path in new[] { assetPath, assetPath + ".meta" })
                {
                    string fullPath = ToProjectPath(path);
                    if (File.Exists(fullPath)) snapshot.Add(path, Sha256(fullPath));
                }
            }
            return snapshot;
        }

        private static string ToProjectPath(string assetPath)
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            return Path.GetFullPath(Path.Combine(projectRoot, assetPath));
        }

        private static string Sha256(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", string.Empty).ToLowerInvariant();
        }

        private sealed class ExpectedRoom
        {
            internal ExpectedRoom(string templateId, int widthTiles, int heightTiles, string prefabFileName)
            {
                TemplateId = templateId;
                WidthTiles = widthTiles;
                HeightTiles = heightTiles;
                PrefabFileName = prefabFileName;
            }

            internal string TemplateId { get; }
            internal int WidthTiles { get; }
            internal int HeightTiles { get; }
            internal string PrefabFileName { get; }
        }
    }
}
