using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Luckbound.Editor;
using NUnit.Framework;
using UnityEngine;

namespace Luckbound.Tests.EditMode
{
    /// <summary>Small synthetic integrity fixtures; these checks do not claim physical or registry acceptance.</summary>
    public sealed class F10PhysicalBundleIntegrityTests
    {
        private string _fixtureRoot;

        [SetUp]
        public void SetUp()
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            _fixtureRoot = Path.Combine(projectRoot, "Library", "F10V7PhysicalBundleTests-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_fixtureRoot);
        }

        // Keep the uniquely named fixtures in Library for inspection. Tests must not
        // recursively delete a computed filesystem path.

        [Test]
        public void IntactBundlePassesBytesButRemainsRegistryIneligibleWithoutPhysicalAuthority()
        {
            BundleFixture fixture = CreateBundle("intact", omitAsset: false);

            bool integrity = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                fixture.DirectoryPath, fixture.ManifestSha256, out bool registryEligible, out string error);

            Assert.That(integrity, Is.True, error);
            Assert.That(registryEligible, Is.False);
        }

        [Test]
        public void ManifestClaimingInstallableCannotEnableRegistry()
        {
            BundleFixture fixture = CreateBundle("lying-installable", omitAsset: false, installable: true);

            bool integrity = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                fixture.DirectoryPath, fixture.ManifestSha256, out bool registryEligible, out string error);

            Assert.That(integrity, Is.True, error);
            Assert.That(registryEligible, Is.False);
        }

        [Test]
        public void AlteredPayloadFailsAgainstPinnedManifest()
        {
            BundleFixture fixture = CreateBundle("altered", omitAsset: false);
            File.WriteAllBytes(fixture.AssetPath, Utf8("altered fixture asset\n"));

            bool integrity = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                fixture.DirectoryPath, fixture.ManifestSha256, out bool registryEligible, out string error);

            Assert.That(integrity, Is.False);
            Assert.That(registryEligible, Is.False);
            Assert.That(error, Does.Contain("Bundle payload bytes changed"));
        }

        [Test]
        public void MissingPayloadFailsClosed()
        {
            BundleFixture fixture = CreateBundle("missing", omitAsset: true);

            bool integrity = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                fixture.DirectoryPath, fixture.ManifestSha256, out bool registryEligible, out string error);

            Assert.That(integrity, Is.False);
            Assert.That(registryEligible, Is.False);
            Assert.That(error, Is.Not.Empty);
        }

        private BundleFixture CreateBundle(string name, bool omitAsset, bool installable = false)
        {
            string bundleDirectory = Path.Combine(_fixtureRoot, name);
            string assetPayloadPath = "payload/assets/Assets/Test/PhysicalFixture.asset";
            string metaPayloadPath = assetPayloadPath + ".meta";
            string descriptorPayloadPath = "payload/evidence/physical-descriptor.json";
            byte[] asset = Utf8("synthetic test asset\n");
            byte[] meta = Utf8("fileFormatVersion: 2\nguid: 11111111111111111111111111111111\n");
            byte[] descriptor = Utf8("{\"schema\":\"test-only\"}\n");
            string absoluteAsset = WritePayload(bundleDirectory, assetPayloadPath, asset, omitAsset);
            WritePayload(bundleDirectory, metaPayloadPath, meta, omitAsset: false);
            WritePayload(bundleDirectory, descriptorPayloadPath, descriptor, omitAsset: false);

            var manifest = new F10TechnicalPhysicalDescriptorExporter.BundleManifestData
            {
                schema = "luckbound.f10.v7.physical-bundle.v1",
                revisionId = "synthetic-test-fixture",
                installable = installable,
                rootAssetPaths = new[] { "Assets/Test/PhysicalFixture.asset" },
                missingDependencyIds = new string[0],
                payloads = new[]
                {
                    Payload(assetPayloadPath, "Assets/Test/PhysicalFixture.asset", asset),
                    Payload(metaPayloadPath, "Assets/Test/PhysicalFixture.asset.meta", meta),
                    Payload(descriptorPayloadPath, "synthetic:descriptor", descriptor)
                },
                dependencies = new[]
                {
                    new F10TechnicalPhysicalDescriptorExporter.BundleDependencyRecord
                    {
                        assetPath = "Assets/Test/PhysicalFixture.asset",
                        assetPayloadPath = assetPayloadPath,
                        metaPayloadPath = metaPayloadPath,
                        guid = "11111111111111111111111111111111",
                        assetSha256 = Hash(asset),
                        metaSha256 = Hash(meta)
                    }
                }
            };
            string manifestPath = Path.Combine(bundleDirectory, "bundle-manifest.json");
            Directory.CreateDirectory(bundleDirectory);
            byte[] manifestBytes = Utf8(JsonUtility.ToJson(manifest, false));
            WriteNew(manifestPath, manifestBytes);
            return new BundleFixture(bundleDirectory, absoluteAsset, Hash(manifestBytes));
        }

        private static string WritePayload(string bundleDirectory, string relativePath, byte[] bytes, bool omitAsset)
        {
            string absolutePath = Path.Combine(bundleDirectory, relativePath.Replace('/', Path.DirectorySeparatorChar));
            if (!omitAsset)
            {
                Directory.CreateDirectory(Directory.GetParent(absolutePath).FullName);
                WriteNew(absolutePath, bytes);
            }
            return absolutePath;
        }

        private static F10TechnicalPhysicalDescriptorExporter.BundlePayloadRecord Payload(
            string path, string sourcePath, byte[] bytes)
        {
            return new F10TechnicalPhysicalDescriptorExporter.BundlePayloadRecord
            {
                path = path,
                sourcePath = sourcePath,
                role = "test-fixture",
                bytes = bytes.LongLength,
                sha256 = Hash(bytes)
            };
        }

        private static void WriteNew(string path, byte[] bytes)
        {
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(true);
            }
        }

        private static byte[] Utf8(string value) => new UTF8Encoding(false, true).GetBytes(value);

        private static string Hash(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", string.Empty).ToLowerInvariant();
        }

        private sealed class BundleFixture
        {
            internal BundleFixture(string directoryPath, string assetPath, string manifestSha256)
            { DirectoryPath = directoryPath; AssetPath = assetPath; ManifestSha256 = manifestSha256; }
            internal string DirectoryPath { get; }
            internal string AssetPath { get; }
            internal string ManifestSha256 { get; }
        }
    }
}
