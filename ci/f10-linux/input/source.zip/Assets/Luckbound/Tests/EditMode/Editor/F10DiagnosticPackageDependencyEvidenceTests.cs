#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using Luckbound.App;

namespace Luckbound.Tests.Editor
{
    public sealed class F10DiagnosticPackageDependencyEvidenceTests
    {
        private const string UrpName = "com.unity.render-pipelines.universal";
        private const string EditorPath = @"C:\Unity\Hub\Editor\6000.6.10f1\Editor\Unity.exe";
        private static MethodInfo RegistryParser => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "ParseRegistryPackageLockEntry", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo BuiltInParser => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "ParseBuiltInUniversalPackageLockEntry", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo BuiltInPolicy => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "ValidateBuiltInUrpPolicy", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo RootDeriver => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "DeriveBuiltInUniversalRoot", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo EditorVersionParser => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "ParseProjectEditorVersion", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo RecordedEquality => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "Equal", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo RecordedIdentityPolicy => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "ValidateRecordedSourceIdentity", BindingFlags.Static | BindingFlags.NonPublic);
        private static MethodInfo AssetPathNormalizer => typeof(F10DiagnosticPackageDependencyEvidenceReader).GetMethod(
            "NormalizeDistinctAssetPaths", BindingFlags.Static | BindingFlags.NonPublic);

        [Test]
        public void RegistryParserKeepsTheExistingTopLevelTuplePolicy()
        {
            const string json = "{\"dependencies\":{\"com.example.package\":{\"version\":\"1.2.3\",\"depth\":0,\"source\":\"registry\",\"dependencies\":{\"com.example.transitive\":\"4.5.6\"},\"url\":\"https://registry.example.test\"}}}";
            object entry = RegistryParser.Invoke(null, new object[] { json, "com.example.package" });
            Type type = entry.GetType();
            Assert.AreEqual("com.example.package", type.GetField("Name", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
            Assert.AreEqual("1.2.3", type.GetField("Version", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
            Assert.AreEqual("registry", type.GetField("Source", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
            Assert.AreEqual("https://registry.example.test", type.GetField("Url", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
        }

        [TestCase("builtin")]
        [TestCase("embedded")]
        [TestCase("git")]
        [TestCase("local")]
        public void RegistryParserStillRejectsOtherSources(string source)
        {
            string json = "{\"dependencies\":{\"com.example.package\":{\"version\":\"1.2.3\",\"source\":\"" + source + "\",\"url\":\"https://registry.example.test\"}}}";
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                RegistryParser.Invoke(null, new object[] { json, "com.example.package" }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void BuiltInParserAcceptsOnlyUniversalAndExactBuiltinLockTuple()
        {
            const string json = "{\"dependencies\":{\"com.unity.render-pipelines.universal\":{\"version\":\"17.6.0\",\"depth\":0,\"source\":\"builtin\"}}}";
            object entry = BuiltInParser.Invoke(null, new object[] { json, UrpName });
            Type type = entry.GetType();
            Assert.AreEqual(UrpName, type.GetField("Name", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
            Assert.AreEqual("17.6.0", type.GetField("Version", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
            Assert.AreEqual("builtin", type.GetField("Source", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(entry));
        }

        [TestCase("registry")]
        [TestCase("embedded")]
        [TestCase("git")]
        [TestCase("local")]
        public void BuiltInParserRejectsEveryOtherLockSource(string source)
        {
            string json = "{\"dependencies\":{\"com.unity.render-pipelines.universal\":{\"version\":\"17.6.0\",\"source\":\"" + source + "\"}}}";
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                BuiltInParser.Invoke(null, new object[] { json, UrpName }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void BuiltInParserRejectsCoreEvenWhenItsLockSourceIsEmbedded()
        {
            const string json = "{\"dependencies\":{\"com.unity.render-pipelines.core\":{\"version\":\"17.6.0\",\"source\":\"embedded\"}}}";
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                BuiltInParser.Invoke(null, new object[] { json, "com.unity.render-pipelines.core" }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void BuiltInRootIsDerivedFromTheExecutingEditorExecutable()
        {
            string expected = Path.Combine(Path.GetDirectoryName(EditorPath), "Data", "Resources", "PackageManager",
                "BuiltInPackages", UrpName);
            Assert.AreEqual(Path.GetFullPath(expected), RootDeriver.Invoke(null, new object[] { EditorPath }));
        }

        [TestCase("")]
        [TestCase("C:\\Unity\\Hub\\Editor\\6000.6.10f1\\Editor\\UnityCrashHandler64.exe")]
        [TestCase("6000.6.10f1/Editor/Unity.exe")]
        public void BuiltInRootRejectsMissingOrNonEditorExecutablePaths(string editorPath)
        {
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                RootDeriver.Invoke(null, new object[] { editorPath }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void BuiltInPolicyAcceptsOnlyTheExactPackageLockManifestAndEditorRoot()
        {
            string root = (string)RootDeriver.Invoke(null, new object[] { EditorPath });
            Assert.DoesNotThrow(() => InvokeBuiltInPolicy(root, "BuiltIn", "builtin", "17.6.0", "17.6.0"));
        }

        [TestCase("com.unity.render-pipelines.core", "BuiltIn", "builtin", "17.6.0", "17.6.0", "name")]
        [TestCase("com.unity.render-pipelines.universal", "Embedded", "builtin", "17.6.0", "17.6.0", "source")]
        [TestCase("com.unity.render-pipelines.universal", "BuiltIn", "registry", "17.6.0", "17.6.0", "lock source")]
        [TestCase("com.unity.render-pipelines.universal", "BuiltIn", "builtin", "17.6.1", "17.6.0", "lock version")]
        [TestCase("com.unity.render-pipelines.universal", "BuiltIn", "builtin", "17.6.0", "17.6.1", "manifest version")]
        public void BuiltInPolicyRejectsIdentityAndLockDrift(string name, string source, string lockSource,
            string lockVersion, string manifestVersion, string reason)
        {
            string root = (string)RootDeriver.Invoke(null, new object[] { EditorPath });
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() => InvokeBuiltInPolicy(
                root, source, lockSource, lockVersion, manifestVersion, name));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException, reason);
        }

        [Test]
        public void BuiltInPolicyRejectsAnyRootOutsideOfficialEditorPackageDirectory()
        {
            string alternate = Path.Combine(Path.GetDirectoryName(EditorPath), "Data", "Resources", "PackageManager",
                "BuiltInPackagesMirror", UrpName);
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                InvokeBuiltInPolicy(alternate, "BuiltIn", "builtin", "17.6.0", "17.6.0"));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void BuiltInPolicyRejectsAssetPathsOutsideTheResolvedPackage()
        {
            string root = (string)RootDeriver.Invoke(null, new object[] { EditorPath });
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() => InvokeBuiltInPolicy(
                root, "BuiltIn", "builtin", "17.6.0", "17.6.0", UrpName, "Packages/com.unity.render-pipelines.core"));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [Test]
        public void ProjectVersionParserRequiresOneExactEditorVersion()
        {
            const string text = "m_EditorVersion: 6000.6.10f1\r\nm_EditorVersionWithRevision: 6000.6.10f1 (40e81493c67d)\r\n";
            Assert.AreEqual("6000.6.10f1", EditorVersionParser.Invoke(null, new object[] { text }));
            Assert.Throws<TargetInvocationException>(() => EditorVersionParser.Invoke(null, new object[] {
                "m_EditorVersion: 6000.6.10f1\nm_EditorVersion: 6000.6.7f1\n" }));
        }

        [Test]
        public void EngineBuiltinExtraIsNotARepresentablePackageAssetPath()
        {
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                AssetPathNormalizer.Invoke(null, new object[] { new[] { "Resources/unity_builtin_extra" } }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        [TestCase("editor version")]
        [TestCase("editor path")]
        [TestCase("editor hash")]
        [TestCase("editor identity")]
        [TestCase("editor length")]
        public void AtoBEqualityBindsEditorIdentityToThePackageReceipt(string mutation)
        {
            F10DiagnosticPackageDependencyEvidence first = BuiltInRow();
            F10DiagnosticPackageDependencyEvidence second = BuiltInRow();
            if (mutation == "editor version") second.editorVersion = "6000.6.7f1";
            else if (mutation == "editor path") second.editorApplicationPath += ".other";
            else if (mutation == "editor hash") second.editorExecutableSha256 = new string('b', 64);
            else if (mutation == "editor identity") second.editorExecutableIdentity = "0000000000000001:00000000000000000000000000000002";
            else second.editorExecutableLength++;
            Assert.IsFalse((bool)RecordedEquality.Invoke(null, new object[] { first, second }), mutation);
        }

        [Test]
        public void BuiltInReceiptAcceptsACompleteEditorAndCertifiedVersionIdentity()
        {
            Assert.DoesNotThrow(() => RecordedIdentityPolicy.Invoke(null, new object[] { BuiltInRow() }));
        }

        [TestCase("version drift")]
        [TestCase("bad editor hash")]
        [TestCase("bad editor identity")]
        [TestCase("editor hard link")]
        [TestCase("editor path drift")]
        [TestCase("bad package root identity")]
        [TestCase("package id missing")]
        public void BuiltInReceiptRejectsIncompleteOrDriftedEditorIdentity(string mutation)
        {
            F10DiagnosticPackageDependencyEvidence row = BuiltInRow();
            if (mutation == "version drift") row.editorVersion = "6000.6.7f1";
            else if (mutation == "bad editor hash") row.editorExecutableSha256 = "xyz";
            else if (mutation == "bad editor identity") row.editorExecutableIdentity = "1:2";
            else if (mutation == "editor hard link") row.editorExecutableLinkCount = 2;
            else if (mutation == "editor path drift") row.editorExecutableFinalPath += ".other";
            else if (mutation == "bad package root identity") row.resolvedRootIdentity = "bad";
            else row.packageId = string.Empty;
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                RecordedIdentityPolicy.Invoke(null, new object[] { row }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException, mutation);
        }

        [Test]
        public void RegistryLockParserRejectsDuplicatePackageKeys()
        {
            const string json = "{\"dependencies\":{\"com.example.package\":{\"version\":\"1.2.3\",\"source\":\"registry\",\"url\":\"https://registry.example.test\"},\"com.example.package\":{\"version\":\"9.9.9\",\"source\":\"registry\",\"url\":\"https://registry.example.test\"}}}";
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                RegistryParser.Invoke(null, new object[] { json, "com.example.package" }));
            Assert.IsInstanceOf<FormatException>(wrapper.InnerException);
        }

        [Test]
        public void RegistryLockParserRejectsNonHttpsUrl()
        {
            const string json = "{\"dependencies\":{\"com.example.package\":{\"version\":\"1.2.3\",\"source\":\"registry\",\"url\":\"http://registry.example.test\"}}}";
            TargetInvocationException wrapper = Assert.Throws<TargetInvocationException>(() =>
                RegistryParser.Invoke(null, new object[] { json, "com.example.package" }));
            Assert.IsInstanceOf<InvalidDataException>(wrapper.InnerException);
        }

        private static void InvokeBuiltInPolicy(string root, string source, string lockSource, string lockVersion,
            string manifestVersion, string name = UrpName, string packageAssetPath = null)
        {
            BuiltInPolicy.Invoke(null, new object[] {
                name,
                source,
                packageAssetPath ?? "Packages/" + UrpName,
                "17.6.0",
                UrpName + "@17.6.0",
                name,
                lockSource,
                lockVersion,
                name,
                manifestVersion,
                root,
                EditorPath
            });
        }

        private static F10DiagnosticPackageDependencyEvidence BuiltInRow()
        {
            return new F10DiagnosticPackageDependencyEvidence
            {
                schemaVersion = 2,
                packageName = UrpName,
                packageVersion = "17.6.0",
                packageSource = "BuiltIn",
                packageId = UrpName + "@17.6.0",
                registryUrl = string.Empty,
                packageAssetPath = "Packages/" + UrpName,
                resolvedRootKind = "builtin-editor",
                resolvedRootRelativePath = "@editor/Data/Resources/PackageManager/BuiltInPackages/" + UrpName,
                resolvedRootAbsolutePath = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(EditorPath), "Data", "Resources",
                    "PackageManager", "BuiltInPackages", UrpName)),
                resolvedRootIdentity = "0000000000000001:00000000000000000000000000000003",
                lockEntrySource = "builtin",
                lockEntryVersion = "17.6.0",
                lockFileSha256 = new string('a', 64),
                certifiedProjectEditorVersion = "6000.6.10f1",
                editorVersion = "6000.6.10f1",
                editorApplicationPath = Path.GetFullPath(EditorPath),
                editorExecutableFinalPath = Path.GetFullPath(EditorPath),
                editorExecutableSha256 = new string('a', 64),
                editorExecutableLength = 120000,
                editorExecutableIdentity = "0000000000000001:00000000000000000000000000000001",
                editorExecutableLinkCount = 1,
                dependencyAssetPaths = Array.Empty<string>(),
                files = Array.Empty<F10DiagnosticPackageDependencyFile>()
            };
        }
    }
}
#endif
