using System;
using System.IO;
using System.Threading.Tasks;
using Luckbound.App;
using Luckbound.Core.Saves;
using NUnit.Framework;

namespace Luckbound.Tests.App
{
    public sealed class FileSaveStoreSyncFailureTests
    {
        private string _directory;

        [SetUp]
        public void SetUp()
        {
            _directory = Path.Combine(Path.GetTempPath(), "LuckboundFileStoreSync-" + Guid.NewGuid().ToString("N"));
            Assert.That(Directory.Exists(_directory), Is.False);
            Directory.CreateDirectory(_directory);
        }

        [TearDown]
        public void TearDown()
        {
            if (!Directory.Exists(_directory)) return;
            // Remove only names that this store can create; unexpected files are preserved.
            foreach (string name in new[]
            {
                FileSaveStore.ProfileFileName, FileSaveStore.ProfileFileName + ".bak",
                FileSaveStore.ProfileFileName + ".tmp", FileSaveStore.ProfileFileName + ".bak.tmp",
                FileSaveStore.SettingsFileName, FileSaveStore.SettingsFileName + ".bak",
                FileSaveStore.SettingsFileName + ".tmp", FileSaveStore.SettingsFileName + ".bak.tmp"
            })
            {
                string path = Path.Combine(_directory, name);
                if (File.Exists(path)) File.Delete(path);
            }
            if (Directory.GetFileSystemEntries(_directory).Length == 0) Directory.Delete(_directory);
        }

        [Test]
        public async Task MatchingReadbackAfterFlushFailureDoesNotProveSynchronization()
        {
            const string previous = "{\"run\":\"active\"}";
            const string terminal = "{\"run\":\"extracted\"}";
            var syncer = new FailingSyncer();
            var store = new FileSaveStore(_directory, syncer);

            await store.WriteAsync(SaveDocument.Profile, previous, null);
            syncer.FailNextFlush = true;
            Assert.ThrowsAsync<IOException>(async () =>
                await store.WriteAsync(SaveDocument.Profile, terminal, previous));

            SaveStorageSnapshot afterFailure = await store.ReadAsync(SaveDocument.Profile);
            Assert.That(afterFailure.PrimaryJson, Is.EqualTo(terminal));
            Assert.That(afterFailure.BackupJson, Is.EqualTo(previous));
            Assert.That(syncer.CompletedFlushes, Is.EqualTo(1));

            await store.WriteAsync(SaveDocument.Profile, terminal, previous);
            SaveStorageSnapshot afterRetry = await store.ReadAsync(SaveDocument.Profile);
            Assert.That(afterRetry.PrimaryJson, Is.EqualTo(terminal));
            Assert.That(afterRetry.BackupJson, Is.EqualTo(previous));
            Assert.That(syncer.CompletedFlushes, Is.EqualTo(2));
        }

        private sealed class FailingSyncer : IPersistentFileSystemSyncer
        {
            public bool FailNextFlush { get; set; }
            public int CompletedFlushes { get; private set; }

            public Task PrepareForReadAsync() => Task.CompletedTask;

            public Task FlushAsync()
            {
                if (FailNextFlush)
                {
                    FailNextFlush = false;
                    throw new IOException("Injected failure after replacing the primary save.");
                }
                CompletedFlushes++;
                return Task.CompletedTask;
            }
        }
    }
}
