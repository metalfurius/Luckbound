using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;
using Luckbound.App;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Luckbound.Editor
{
    /// <summary>
    /// Create-only Editor entrypoint for the isolated F10 scene. It does not touch the live checkout
    /// or write a receipt until the complete asset delta and real AssetDatabase closures are measured.
    /// </summary>
    public static class F10DiagnosticMaterializationReceiptExporter
    {
        private const string ReceiptRelativePath = F10DiagnosticMaterializationReceiptValidator.ReceiptRelativePath;
        private static readonly string[] RequiredAssetPaths =
        {
            F10DiagnosticSceneGenerator.ScenePath,
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot + "/F10TutorialDiagnostic.prefab",
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot + "/F10PatioCombatC1Diagnostic.prefab",
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot + "/F10PatioExplorationE1Diagnostic.prefab",
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot + "/F10PatioGuardianDiagnostic.prefab",
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticRoot + "/F10SafeExtractionDiagnostic.prefab",
            F10TechnicalDiagnosticPrefabGenerator.DiagnosticTilePath,
            F10TechnicalDiagnosticPlayerPrefabGenerator.PrefabPath,
            F10PhysicalGoldCacheDiagnosticPrefabGenerator.PrefabPath
        };
        private static readonly string[] GeneratorSourcePaths =
        {
            "Assets/Luckbound/Editor/F10DiagnosticSceneGenerator.cs",
            "Assets/Luckbound/Editor/F10TechnicalDiagnosticPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10RoomTemplatePrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10TechnicalDiagnosticPlayerPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10PhysicalGoldCacheDiagnosticPrefabGenerator.cs",
            "Assets/Luckbound/Editor/F10DiagnosticMaterializationReceiptExporter.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticMaterializationReceiptValidator.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticPackageDependencyEvidence.cs",
            "Assets/Luckbound/Scripts/App/F10DiagnosticSceneRunner.cs",
            "Assets/Luckbound/Scripts/App/ApplicationBootstrapper.F10Diagnostic.cs"
        };
        private static readonly string[] InventoryRoots = { "Assets", "Packages", "ProjectSettings" };
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        [MenuItem("Luckbound/Technical Diagnostic/Materialize F10 Scene and Measured Receipt (Disposable Copy Only)")]
        private static void RunFromMenu()
        {
            MaterializeAndMeasure();
        }

        /// <summary>Testable, fail-closed Editor operation. Existing content and partial failures are preserved.</summary>
        public static string MaterializeAndMeasure()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("F10 materialization is only allowed outside Play Mode.");

            string projectRoot = CanonicalPath(Directory.GetParent(Application.dataPath).FullName);
            F10DiagnosticMaterializationReceiptValidator.VerifyCertifiedBaseBeforeMaterialization(projectRoot);

            // Run every producer's complete no-write preflight before the first file is created.
            F10TechnicalDiagnosticPrefabGenerator.PreflightOnly();
            F10TechnicalDiagnosticPlayerPrefabGenerator.PreflightOnly();
            F10PhysicalGoldCacheDiagnosticPrefabGenerator.PreflightOnly();
            VerifySceneDestinationAbsent(projectRoot);

            Dictionary<string, FileEvidence> beforeFiles = CaptureFiles(projectRoot);
            HashSet<string> beforeDirectories = CaptureDirectories(projectRoot);
            F10DiagnosticSceneGenerator.Generate();

            VerifyImportedAssets();
            Dictionary<string, FileEvidence> afterFiles = CaptureFiles(projectRoot);
            HashSet<string> afterDirectories = CaptureDirectories(projectRoot);
            string[] createdDirectories = afterDirectories.Except(beforeDirectories, StringComparer.Ordinal)
                .OrderBy(path => path, StringComparer.Ordinal).ToArray();
            F10DiagnosticMaterializedOutput[] outputs = MeasureCompleteDelta(beforeFiles, afterFiles, createdDirectories);

            F10DiagnosticDependencyClosure[] dependencies =
                F10DiagnosticMaterializationReceiptValidator.CaptureMeasuredDependencies(projectRoot,
                    createdDirectories, out F10DiagnosticPackageDependencyEvidence[] packageDependencies);
            var receipt = new F10DiagnosticMaterializationReceipt
            {
                schemaVersion = 2,
                status = "measured",
                copyRoot = projectRoot,
                copyCertificateSha256 = HashFile(AbsolutePath(projectRoot, F10DiagnosticMaterializationReceiptValidator.CertificateRelativePath)),
                outputs = outputs,
                generatorFiles = MeasureGeneratorFiles(projectRoot),
                dependencies = dependencies,
                packageDependencies = packageDependencies,
                createdDirectories = createdDirectories
            };

            // This rechecks the full certified base, outputs, physical file identities and live AssetDatabase closure.
            F10DiagnosticMaterializationReceiptValidator.ValidateMeasuredReceipt(projectRoot, receipt);
            string receiptPath = AbsolutePath(projectRoot, ReceiptRelativePath);
            WriteCreateOnly(receiptPath, JsonUtility.ToJson(receipt, false));
            F10DiagnosticMaterializationReceiptValidator.ValidateForRuntime(projectRoot);
            return receiptPath;
        }

        private static void VerifySceneDestinationAbsent(string projectRoot)
        {
            string scenePath = F10DiagnosticSceneGenerator.ScenePath;
            string fullPath = AbsolutePath(projectRoot, scenePath);
            if (ExistsAsAnyEntry(fullPath) || ExistsAsAnyEntry(fullPath + ".meta") ||
                AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) != null)
                throw new IOException("F10 diagnostic scene destination is occupied; existing content was preserved: " + scenePath);
        }

        private static void VerifyImportedAssets()
        {
            foreach (string path in RequiredAssetPaths)
            {
                UnityEngine.Object asset = AssetDatabase.LoadMainAssetAtPath(path);
                if (asset == null || !AssetDatabase.Contains(asset) ||
                    !string.Equals(AssetDatabase.GetAssetPath(asset), path, StringComparison.Ordinal))
                    throw new InvalidOperationException("Generated asset was not imported at its exact allowlisted path: " + path);
                if (!File.Exists(AbsolutePath(CanonicalPath(Directory.GetParent(Application.dataPath).FullName), path)) ||
                    !File.Exists(AbsolutePath(CanonicalPath(Directory.GetParent(Application.dataPath).FullName), path + ".meta")))
                    throw new IOException("Generated asset or its metadata sidecar is missing: " + path);
            }
            if (AssetDatabase.LoadMainAssetAtPath(F10TechnicalDiagnosticPrefabGenerator.DiagnosticTilePath) is not Tile)
                throw new InvalidDataException("The generated shared diagnostic asset is not a Tile.");
        }

        private static F10DiagnosticMaterializedOutput[] MeasureCompleteDelta(
            IDictionary<string, FileEvidence> beforeFiles,
            IDictionary<string, FileEvidence> afterFiles,
            IEnumerable<string> createdDirectories)
        {
            foreach (KeyValuePair<string, FileEvidence> oldFile in beforeFiles)
            {
                if (!afterFiles.TryGetValue(oldFile.Key, out FileEvidence current) ||
                    !string.Equals(oldFile.Value.Sha256, current.Sha256, StringComparison.Ordinal) ||
                    !string.Equals(oldFile.Value.Identity, current.Identity, StringComparison.Ordinal) ||
                    oldFile.Value.LinkCount != current.LinkCount)
                    throw new InvalidDataException("Materialization changed or removed immutable base bytes/identity: " + oldFile.Key);
            }

            string[] added = afterFiles.Keys.Except(beforeFiles.Keys, StringComparer.Ordinal)
                .OrderBy(path => path, StringComparer.Ordinal).ToArray();
            string[] expected = RequiredAssetPaths.SelectMany(path => new[] { path, path + ".meta" })
                .Concat(createdDirectories.Select(path => path + ".meta"))
                .Distinct(StringComparer.Ordinal).OrderBy(path => path, StringComparer.Ordinal).ToArray();
            if (!added.SequenceEqual(expected, StringComparer.Ordinal))
            {
                string extra = added.Except(expected, StringComparer.Ordinal).FirstOrDefault();
                string missing = expected.Except(added, StringComparer.Ordinal).FirstOrDefault();
                throw new InvalidDataException("Materialization produced an unexpected file delta; extra=" + (extra ?? "<none>") +
                    ", missing=" + (missing ?? "<none>") + ". Outputs were preserved without a receipt.");
            }

            var usedIdentities = new HashSet<string>(beforeFiles.Values.Select(value => NormalizeIdentity(value.Identity)), StringComparer.Ordinal);
            var outputRows = new List<F10DiagnosticMaterializedOutput>(added.Length);
            foreach (string path in added)
            {
                FileEvidence evidence = afterFiles[path];
                string normalizedIdentity = NormalizeIdentity(evidence.Identity);
                if (evidence.LinkCount != 1 || !usedIdentities.Add(normalizedIdentity))
                    throw new InvalidDataException("A materialized output has a hard link or shares another file identity: " + path);
                outputRows.Add(new F10DiagnosticMaterializedOutput
                {
                    path = path,
                    sha256 = evidence.Sha256,
                    length = evidence.Length,
                    identity = evidence.Identity,
                    linkCount = evidence.LinkCount
                });
            }
            return outputRows.ToArray();
        }

        private static F10DiagnosticGeneratorFile[] MeasureGeneratorFiles(string projectRoot)
        {
            return GeneratorSourcePaths.OrderBy(path => path, StringComparer.Ordinal)
                .Select(path =>
                {
                    string fullPath = AbsolutePath(projectRoot, path);
                    if (!File.Exists(fullPath)) throw new FileNotFoundException("A required Editor/generator source is missing.", fullPath);
                    return new F10DiagnosticGeneratorFile { path = path, sha256 = HashFile(fullPath) };
                }).ToArray();
        }

        private static Dictionary<string, FileEvidence> CaptureFiles(string projectRoot)
        {
            var result = new Dictionary<string, FileEvidence>(StringComparer.Ordinal);
            foreach (string inventoryRoot in InventoryRoots)
            {
                string root = AbsolutePath(projectRoot, inventoryRoot);
                if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Project inventory root is missing: " + root);
                var pending = new Stack<string>();
                pending.Push(root);
                while (pending.Count > 0)
                {
                    string directory = pending.Pop();
                    RejectReparsePoint(directory);
                    foreach (string entry in Directory.EnumerateFileSystemEntries(directory))
                    {
                        RejectReparsePoint(entry);
                        if (Directory.Exists(entry)) { pending.Push(entry); continue; }
                        string relative = ToRelativePath(projectRoot, entry);
                        PhysicalFileInformation physical = ReadPhysicalFileInformation(entry);
                        var evidence = new FileEvidence(relative, entry, new FileInfo(entry).Length,
                            HashFile(entry), physical.Identity, physical.LinkCount);
                        if (!result.TryAdd(relative, evidence))
                            throw new InvalidDataException("Project inventory contains a duplicate path: " + relative);
                    }
                }
            }
            return result;
        }

        private static HashSet<string> CaptureDirectories(string projectRoot)
        {
            var result = new HashSet<string>(StringComparer.Ordinal);
            foreach (string inventoryRoot in InventoryRoots)
            {
                string root = AbsolutePath(projectRoot, inventoryRoot);
                if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Project inventory root is missing: " + root);
                var pending = new Stack<string>();
                pending.Push(root);
                while (pending.Count > 0)
                {
                    string directory = pending.Pop();
                    RejectReparsePoint(directory);
                    result.Add(ToRelativePath(projectRoot, directory));
                    foreach (string child in Directory.EnumerateDirectories(directory))
                    {
                        RejectReparsePoint(child);
                        pending.Push(child);
                    }
                }
            }
            return result;
        }

        private static void WriteCreateOnly(string path, string text)
        {
            string directory = Path.GetDirectoryName(path);
            if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory) || IsReparsePoint(directory))
                throw new DirectoryNotFoundException("The fixed receipt directory must exist as a plain directory before writing.");
            byte[] bytes = StrictUtf8.GetBytes(text ?? throw new ArgumentNullException(nameof(text)));
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(true);
            }
            PhysicalFileInformation physical = ReadPhysicalFileInformation(path);
            if (physical.LinkCount != 1 || !string.Equals(HashFile(path), F10DiagnosticMaterializationReceiptValidator.Sha256Hex(bytes), StringComparison.Ordinal))
                throw new IOException("The create-only materialization receipt failed physical readback; it was preserved for diagnosis.");
        }

        private static string NormalizeAssetPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || Path.IsPathRooted(path) || path.IndexOf(':') >= 0 ||
                path.Split('/').Any(segment => segment == ".." || segment == "." || segment.Length == 0))
                throw new InvalidDataException("AssetDatabase returned an unsafe dependency path: " + (path ?? "<null>"));
            return path.Replace('\\', '/');
        }

        private static string ToRelativePath(string root, string path)
        {
            string prefix = CanonicalPath(root) + Path.DirectorySeparatorChar;
            string full = CanonicalPath(path);
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Project inventory path escaped the disposable copy: " + path);
            return full.Substring(prefix.Length).Replace('\\', '/');
        }

        private static void RejectReparsePoint(string path)
        {
            if (!ExistsAsAnyEntry(path)) throw new FileNotFoundException("Expected project entry is missing.", path);
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Materialization rejects reparse points: " + path);
        }

        private static bool IsReparsePoint(string path)
        {
            return ExistsAsAnyEntry(path) && (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;
        }

        private static bool ExistsAsAnyEntry(string path) => File.Exists(path) || Directory.Exists(path);

        private static PhysicalFileInformation ReadPhysicalFileInformation(string path)
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || Path.DirectorySeparatorChar != '\\')
                throw new PlatformNotSupportedException("Physical output identity is implemented for Windows only.");
            using (SafeFileHandle handle = CreateFile(path, 0, FileShare.ReadWrite | FileShare.Delete,
                IntPtr.Zero, FileMode.Open, 0x02000000 | 0x00200000, IntPtr.Zero))
            {
                if (handle.IsInvalid || !GetFileInformationByHandle(handle, out ByHandleFileInformation info))
                    throw new IOException("Could not read actual Windows output identity: " + path,
                        Marshal.GetExceptionForHR(Marshal.GetHRForLastWin32Error()));
                byte[] fileIdInfo = new byte[24];
                if (!GetFileInformationByHandleEx(handle, 18, fileIdInfo, (uint)fileIdInfo.Length))
                    throw new IOException("Could not read 64-bit FileIdInfo required to match the certificate's Python st_dev: " + path,
                        Marshal.GetExceptionForHR(Marshal.GetHRForLastWin32Error()));
                ulong volumeId = BitConverter.ToUInt64(fileIdInfo, 0);
                ulong fileIdLow = BitConverter.ToUInt64(fileIdInfo, 8);
                ulong fileIdHigh = BitConverter.ToUInt64(fileIdInfo, 16);
                ulong legacyFileIndex = ((ulong)info.FileIndexHigh << 32) | info.FileIndexLow;
                if (fileIdHigh != 0 || fileIdLow != legacyFileIndex || volumeId == 0)
                    throw new IOException("This filesystem's 128-bit file ID cannot be represented exactly by the certified Python device/inode pair: " + path);
                string identity = volumeId.ToString("X16", CultureInfo.InvariantCulture) + ":" +
                    fileIdLow.ToString("X16", CultureInfo.InvariantCulture);
                return new PhysicalFileInformation(identity, info.LinkCount);
            }
        }

        private static string NormalizeIdentity(string value)
        {
            string[] parts = (value ?? string.Empty).Split(':');
            if (parts.Length != 2 || !ulong.TryParse(parts[0], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong volume) ||
                !ulong.TryParse(parts[1], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out ulong file))
                throw new InvalidDataException("Unsupported physical file identity: " + (value ?? "<null>"));
            return volume.ToString("X16", CultureInfo.InvariantCulture) + ":" + file.ToString("X16", CultureInfo.InvariantCulture);
        }

        private static string HashFile(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                return F10DiagnosticMaterializationReceiptValidator.ToLowerHex(sha.ComputeHash(stream));
        }

        private static string CanonicalPath(string path)
        {
            string full = Path.GetFullPath(path);
            string root = Path.GetPathRoot(full) ?? string.Empty;
            while (full.Length > root.Length &&
                (full[full.Length - 1] == Path.DirectorySeparatorChar || full[full.Length - 1] == Path.AltDirectorySeparatorChar))
                full = full.Substring(0, full.Length - 1);
            return full;
        }

        private static string AbsolutePath(string root, string relative)
        {
            if (Path.IsPathRooted(relative) || relative.IndexOf(':') >= 0 ||
                relative.Replace('\\', '/').Split('/').Any(segment => segment == ".." || segment == "." || segment.Length == 0))
                throw new InvalidDataException("Unsafe project-relative path: " + relative);
            return Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
        }

        private sealed class FileEvidence
        {
            internal FileEvidence(string relativePath, string absolutePath, long length, string sha256, string identity, uint linkCount)
            {
                RelativePath = relativePath;
                AbsolutePath = absolutePath;
                Length = length;
                Sha256 = sha256;
                Identity = identity;
                LinkCount = linkCount;
            }
            internal string RelativePath { get; }
            internal string AbsolutePath { get; }
            internal long Length { get; }
            internal string Sha256 { get; }
            internal string Identity { get; }
            internal uint LinkCount { get; }
        }

        private sealed class PhysicalFileInformation
        {
            internal PhysicalFileInformation(string identity, uint linkCount) { Identity = identity; LinkCount = linkCount; }
            internal string Identity { get; }
            internal uint LinkCount { get; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct ByHandleFileInformation
        {
            internal uint FileAttributes;
            internal System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            internal uint VolumeSerialNumber;
            internal uint FileSizeHigh;
            internal uint FileSizeLow;
            internal uint LinkCount;
            internal uint FileIndexHigh;
            internal uint FileIndexLow;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFile(string fileName, uint desiredAccess, FileShare shareMode,
            IntPtr securityAttributes, FileMode creationDisposition, uint flagsAndAttributes, IntPtr templateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out ByHandleFileInformation information);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileInformationByHandleEx(SafeFileHandle handle, int fileInformationClass,
            [Out] byte[] information, uint bufferSize);
    }
}
