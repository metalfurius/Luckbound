using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Luckbound.Gameplay.Inventory;
using Luckbound.Gameplay.Movement;
using Luckbound.Presentation;
using UnityEditor;
using UnityEngine;

namespace Luckbound.Editor
{
    /// <summary>Creates an isolated technical player copy for the F10 demo without changing its B07 source.</summary>
    public static class F10TechnicalDiagnosticPlayerPrefabGenerator
    {
        public const string SourcePrefabPath = "Assets/Luckbound/Prefabs/MovementDemoPlayer.prefab";
        public const string PrefabPath = "Assets/Luckbound/Editor/Diagnostic/F10TechnicalDiagnosticPlayer.prefab";
        public const string PrefabName = "F10TechnicalDiagnosticPlayer";
        private const string DiagnosticRoot = "Assets/Luckbound/Editor/Diagnostic/";

        [MenuItem("Luckbound/Technical Diagnostic/Generate F10 Technical Player Prefab")]
        private static void GenerateFromMenu()
        {
            GameObject generated = Generate();
            Debug.Log("Created isolated F10 technical player prefab at " + AssetDatabase.GetAssetPath(generated) + ".");
        }

        /// <summary>Checks the imported source and create-only destination without writing assets.</summary>
        public static void PreflightOnly()
        {
            Preflight();
        }

        /// <summary>Copies the movement demo prefab and adds ItemCollector2D only to the new diagnostic copy.</summary>
        public static GameObject Generate()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Diagnostic prefab generation is only allowed outside Play Mode.");

            Preflight();
            string sourceBytesHash = Sha256File(ProjectPath(SourcePrefabPath));
            string sourceMetaHash = Sha256File(ProjectPath(SourcePrefabPath + ".meta"));
            GameObject contents = PrefabUtility.LoadPrefabContents(SourcePrefabPath);
            if (contents == null) throw new InvalidOperationException("MovementDemoPlayer prefab contents could not be loaded.");

            try
            {
                TechnicalPlayerFingerprint original = CaptureAndValidateSource(contents);
                contents.name = PrefabName;
                ItemCollector2D[] collectors = contents.GetComponentsInChildren<ItemCollector2D>(true);
                if (collectors.Length == 0) contents.AddComponent<ItemCollector2D>();
                else if (collectors.Length != 1 || !ReferenceEquals(collectors[0].gameObject, contents))
                    throw new InvalidOperationException("MovementDemoPlayer has an unexpected ItemCollector2D hierarchy; preserving source and refusing to duplicate it.");

                ValidateDiagnosticCopy(contents, original);
                EnsureAssetFolder("Assets/Luckbound/Editor/Diagnostic");
                EnsureDestinationAbsent();
                GameObject saved = PrefabUtility.SaveAsPrefabAsset(contents, PrefabPath);
                if (saved == null || !File.Exists(ProjectPath(PrefabPath)) || !File.Exists(ProjectPath(PrefabPath + ".meta")))
                    throw new IOException("Unity did not persist the technical diagnostic player prefab and its .meta sidecar.");

                AssetDatabase.ImportAsset(PrefabPath, ImportAssetOptions.ForceSynchronousImport);
                if (!string.Equals(sourceBytesHash, Sha256File(ProjectPath(SourcePrefabPath)), StringComparison.Ordinal) ||
                    !string.Equals(sourceMetaHash, Sha256File(ProjectPath(SourcePrefabPath + ".meta")), StringComparison.Ordinal))
                    throw new IOException("MovementDemoPlayer source bytes or .meta changed during diagnostic copy generation.");

                GameObject imported = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
                if (imported == null || !string.Equals(AssetDatabase.GetAssetPath(imported), PrefabPath, StringComparison.Ordinal))
                    throw new InvalidOperationException("Generated diagnostic player did not import at its exact new path.");
                ValidateDiagnosticCopy(imported, original);
                return imported;
            }
            finally
            {
                PrefabUtility.UnloadPrefabContents(contents);
            }
        }

        private static TechnicalPlayerFingerprint CaptureAndValidateSource(GameObject source)
        {
            if (!string.Equals(source.name, "MovementDemoPlayer", StringComparison.Ordinal))
                throw new InvalidOperationException("Source prefab root must remain MovementDemoPlayer.");
            Rigidbody2D body = source.GetComponent<Rigidbody2D>();
            Collider2D[] colliders = source.GetComponents<Collider2D>();
            SpriteRenderer renderer = source.GetComponent<SpriteRenderer>();
            Animator animator = source.GetComponent<Animator>();
            if (body == null || colliders.Length != 1 || renderer == null || renderer.sprite == null ||
                animator == null || animator.runtimeAnimatorController == null ||
                source.GetComponent<PlayerMotor2D>() == null || source.GetComponent<PlayerVisualStatePresenter>() == null)
                throw new InvalidOperationException("MovementDemoPlayer must keep its root Rigidbody2D, one Collider2D, SpriteRenderer, Animator controller, PlayerMotor2D, and PlayerVisualStatePresenter.");

            return new TechnicalPlayerFingerprint(source, body, colliders[0], renderer, animator);
        }

        private static void ValidateDiagnosticCopy(GameObject copy, TechnicalPlayerFingerprint original)
        {
            if (copy == null || !string.Equals(copy.name, PrefabName, StringComparison.Ordinal) ||
                copy.layer != original.Layer || copy.tag != original.Tag || copy.activeSelf != original.ActiveSelf ||
                copy.transform.localPosition != original.LocalPosition || copy.transform.localRotation != original.LocalRotation ||
                copy.transform.localScale != original.LocalScale ||
                copy.GetComponent<PlayerMotor2D>() == null || copy.GetComponent<PlayerVisualStatePresenter>() == null)
                throw new InvalidOperationException("Technical player copy changed the source movement, root transform, layer, tag, or visual presenter contract.");

            Rigidbody2D body = copy.GetComponent<Rigidbody2D>();
            Collider2D[] colliders = copy.GetComponents<Collider2D>();
            SpriteRenderer renderer = copy.GetComponent<SpriteRenderer>();
            Animator animator = copy.GetComponent<Animator>();
            if (body == null || !original.Matches(body) || colliders.Length != 1 || !original.Matches(colliders[0]) ||
                renderer == null || !original.Matches(renderer) || animator == null ||
                animator.runtimeAnimatorController != original.AnimatorController ||
                copy.GetComponentsInChildren<ItemCollector2D>(true).Length != 1 ||
                copy.GetComponent<ItemCollector2D>() == null)
                throw new InvalidOperationException("Technical player copy must preserve source physics, sprite, and animator while adding one root ItemCollector2D.");
        }

        private static void Preflight()
        {
            if (!PrefabPath.StartsWith(DiagnosticRoot, StringComparison.Ordinal) ||
                PrefabPath.StartsWith("Assets/Resources/", StringComparison.Ordinal) ||
                !string.Equals(Path.GetFileNameWithoutExtension(PrefabPath), PrefabName, StringComparison.Ordinal))
                throw new InvalidOperationException("Technical player output must be named explicitly in the Editor-only diagnostic tree.");

            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(SourcePrefabPath);
            if (source == null || !AssetDatabase.Contains(source) ||
                !string.Equals(AssetDatabase.GetAssetPath(source), SourcePrefabPath, StringComparison.Ordinal) ||
                !File.Exists(ProjectPath(SourcePrefabPath)) || !File.Exists(ProjectPath(SourcePrefabPath + ".meta")))
                throw new FileNotFoundException("The imported MovementDemoPlayer source prefab and .meta are required.", ProjectPath(SourcePrefabPath));

            EnsureDestinationAbsent();
        }

        private static void EnsureDestinationAbsent()
        {
            string fullPath = ProjectPath(PrefabPath);
            if (File.Exists(fullPath) || File.Exists(fullPath + ".meta") || Directory.Exists(fullPath) ||
                AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) != null)
                throw new IOException("Technical diagnostic player destination already exists; preserving it: " + PrefabPath);
        }

        private static void EnsureAssetFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;
            int split = folder.LastIndexOf('/');
            string parent = folder.Substring(0, split);
            string name = folder.Substring(split + 1);
            EnsureAssetFolder(parent);
            string guid = AssetDatabase.CreateFolder(parent, name);
            if (string.IsNullOrWhiteSpace(guid) || !AssetDatabase.IsValidFolder(folder))
                throw new IOException("Unity failed to create the technical diagnostic folder: " + folder);
        }

        private static string ProjectPath(string assetPath)
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            return Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }

        private static string Sha256File(string path)
        {
            if (!File.Exists(path)) throw new FileNotFoundException("Required source file is missing.", path);
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
                return string.Concat(sha.ComputeHash(stream).Select(value => value.ToString("x2", System.Globalization.CultureInfo.InvariantCulture)));
        }

        private sealed class TechnicalPlayerFingerprint
        {
            internal TechnicalPlayerFingerprint(GameObject source, Rigidbody2D body, Collider2D collider,
                SpriteRenderer renderer, Animator animator)
            {
                Layer = source.layer;
                Tag = source.tag;
                ActiveSelf = source.activeSelf;
                LocalPosition = source.transform.localPosition;
                LocalRotation = source.transform.localRotation;
                LocalScale = source.transform.localScale;
                BodyType = body.bodyType;
                Mass = body.mass;
                GravityScale = body.gravityScale;
                Constraints = body.constraints;
                CollisionDetectionMode = body.collisionDetectionMode;
                Interpolation = body.interpolation;
                Simulated = body.simulated;
                LinearDamping = body.linearDamping;
                AngularDamping = body.angularDamping;
                ColliderType = collider.GetType();
                ColliderEnabled = collider.enabled;
                ColliderTrigger = collider.isTrigger;
                ColliderOffset = collider.offset;
                BoxSize = collider is BoxCollider2D box ? box.size : Vector2.zero;
                CapsuleSize = collider is CapsuleCollider2D capsule ? capsule.size : Vector2.zero;
                CapsuleDirection = collider is CapsuleCollider2D capsuleCollider ? capsuleCollider.direction : CapsuleDirection2D.Vertical;
                CircleRadius = collider is CircleCollider2D circle ? circle.radius : 0f;
                Sprite = renderer.sprite;
                SpriteColor = renderer.color;
                SpriteFlipX = renderer.flipX;
                SpriteFlipY = renderer.flipY;
                SpriteSortingOrder = renderer.sortingOrder;
                SpriteDrawMode = renderer.drawMode;
                SpriteSize = renderer.size;
                AnimatorController = animator.runtimeAnimatorController;
            }

            internal int Layer { get; }
            internal string Tag { get; }
            internal bool ActiveSelf { get; }
            internal Vector3 LocalPosition { get; }
            internal Quaternion LocalRotation { get; }
            internal Vector3 LocalScale { get; }
            internal RuntimeAnimatorController AnimatorController { get; }

            private RigidbodyType2D BodyType { get; }
            private float Mass { get; }
            private float GravityScale { get; }
            private RigidbodyConstraints2D Constraints { get; }
            private CollisionDetectionMode2D CollisionDetectionMode { get; }
            private RigidbodyInterpolation2D Interpolation { get; }
            private bool Simulated { get; }
            private float LinearDamping { get; }
            private float AngularDamping { get; }
            private Type ColliderType { get; }
            private bool ColliderEnabled { get; }
            private bool ColliderTrigger { get; }
            private Vector2 ColliderOffset { get; }
            private Vector2 BoxSize { get; }
            private Vector2 CapsuleSize { get; }
            private CapsuleDirection2D CapsuleDirection { get; }
            private float CircleRadius { get; }
            private Sprite Sprite { get; }
            private Color SpriteColor { get; }
            private bool SpriteFlipX { get; }
            private bool SpriteFlipY { get; }
            private int SpriteSortingOrder { get; }
            private SpriteDrawMode SpriteDrawMode { get; }
            private Vector2 SpriteSize { get; }

            internal bool Matches(Rigidbody2D body) => body.bodyType == BodyType && body.mass == Mass &&
                body.gravityScale == GravityScale && body.constraints == Constraints &&
                body.collisionDetectionMode == CollisionDetectionMode && body.interpolation == Interpolation &&
                body.simulated == Simulated && body.linearDamping == LinearDamping && body.angularDamping == AngularDamping;

            internal bool Matches(Collider2D collider) => collider.GetType() == ColliderType &&
                collider.enabled == ColliderEnabled && collider.isTrigger == ColliderTrigger && collider.offset == ColliderOffset &&
                (!(collider is BoxCollider2D box) || box.size == BoxSize) &&
                (!(collider is CapsuleCollider2D capsule) || (capsule.size == CapsuleSize && capsule.direction == CapsuleDirection)) &&
                (!(collider is CircleCollider2D circle) || circle.radius == CircleRadius);

            internal bool Matches(SpriteRenderer renderer) => renderer.sprite == Sprite && renderer.color == SpriteColor &&
                renderer.flipX == SpriteFlipX && renderer.flipY == SpriteFlipY && renderer.sortingOrder == SpriteSortingOrder &&
                renderer.drawMode == SpriteDrawMode && renderer.size == SpriteSize;
        }
    }
}
