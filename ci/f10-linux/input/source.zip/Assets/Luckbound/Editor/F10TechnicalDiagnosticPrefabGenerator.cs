using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Luckbound.Content;
using Luckbound.Core.Expeditions;
using Luckbound.Gameplay.Movement;
using Luckbound.Gameplay.Rooms;
using Luckbound.Presentation;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Luckbound.Editor
{
    /// <summary>
    /// Creates an isolated, internal F10 diagnostic asset set from imported prototype content.
    /// It does not compose a scene, actor, camera, HUD, RoomLifetimeScope, route registry, or product room.
    /// </summary>
    public static class F10TechnicalDiagnosticPrefabGenerator
    {
        public const string RouteDefinitionPath = "Assets/Resources/Luckbound/Data/Rooms/F10SampleRoute.json";
        public const string StonePrototypeSpritePath = "Assets/Luckbound/Art/Prototypes/MovementDemo/StonePrototype.png";
        public const string MovementDemoPlayerSourcePath = "Assets/Luckbound/Prefabs/MovementDemoPlayer.prefab";
        public const string DiagnosticRoot = "Assets/Luckbound/Editor/Diagnostic/F10";
        public const string DiagnosticTilePath = "Assets/Luckbound/Editor/Diagnostic/Shared/StonePrototypeDiagnosticTile.asset";
        public const string DiagnosticF10Folder = DiagnosticRoot;

        private static readonly RoomSpec[] Rooms =
        {
            new RoomSpec("sample.tutorial", "F10TutorialRoom.json", "room.sample.tutorial", 20, 12, "F10TutorialDiagnostic.prefab"),
            new RoomSpec("sample.patio.combat", "F10PatioCombatC1Room.json", "room.patio.c1", 44, 18, "F10PatioCombatC1Diagnostic.prefab"),
            new RoomSpec("sample.patio.exploration", "F10PatioExplorationE1Room.json", "room.patio.e1", 46, 20, "F10PatioExplorationE1Diagnostic.prefab"),
            new RoomSpec("sample.patio.guardian", "F10PatioGuardianRoom.json", "room.patio.guardian", 20, 12, "F10PatioGuardianDiagnostic.prefab"),
            new RoomSpec("sample.safe_extraction", "F10SafeExtractionRoom.json", "room.sample.extraction", 20, 12, "F10SafeExtractionDiagnostic.prefab")
        };

        [MenuItem("Luckbound/Technical Diagnostic/Generate F10 Rooms From Imported Prototypes")]
        private static void GenerateFromMenu()
        {
            try
            {
                GameObject[] generated = GenerateAll().ToArray();
                Debug.Log("Prepared " + generated.Length + " isolated F10 diagnostic room prefabs under " + DiagnosticF10Folder + ".");
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                throw;
            }
        }

        /// <summary>Validates every input and destination without creating folders or saving assets.</summary>
        public static void PreflightOnly()
        {
            PreflightAll();
        }

        /// <summary>
        /// Preflights the complete diagnostic set before the first write, then creates or exactly reuses
        /// one persistent Grid-collider Tile and five diagnostic-only room prefabs.
        /// </summary>
        public static IReadOnlyList<GameObject> GenerateAll()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Diagnostic room assets can only be generated outside Play Mode.");

            PreparedBatch prepared = PreflightAll();
            Tile floorTile = CreateOrReuseDiagnosticTile(prepared.StonePrototypeSprite, prepared.ExistingTile);
            var generated = new GameObject[prepared.Rooms.Length];

            for (int index = 0; index < prepared.Rooms.Length; index++)
            {
                PreparedRoom room = prepared.Rooms[index];
                GameObject prefab = F10RoomTemplatePrefabGenerator.GeneratePrefab(
                    room.Definition, floorTile, room.PrefabPath);
                ValidateDiagnosticPrefab(prefab, room, floorTile);
                generated[index] = prefab;
            }

            return Array.AsReadOnly(generated);
        }

        internal static DiagnosticDestinationDisposition ClassifyDestination(
            bool assetFileExists, bool metaFileExists, bool importedAssetExists)
        {
            if (!assetFileExists && !metaFileExists && !importedAssetExists)
                return DiagnosticDestinationDisposition.Create;
            if (assetFileExists && metaFileExists && importedAssetExists)
                return DiagnosticDestinationDisposition.Reuse;

            throw new InvalidOperationException(
                "Diagnostic destination is partial, unimported, or registered without both files; preserving it.");
        }

        private static PreparedBatch PreflightAll()
        {
            if (!DiagnosticRoot.StartsWith("Assets/Luckbound/Editor/Diagnostic/", StringComparison.Ordinal) ||
                DiagnosticRoot.StartsWith("Assets/Resources/", StringComparison.Ordinal) ||
                !DiagnosticTilePath.StartsWith("Assets/Luckbound/Editor/Diagnostic/", StringComparison.Ordinal))
                throw new InvalidOperationException("Diagnostic outputs must remain Editor-only and outside every Resources folder.");

            TextAsset routeAsset = LoadImportedAsset<TextAsset>(RouteDefinitionPath, "F10 sample route");
            ExpeditionSampleRouteDefinition route = ExpeditionSampleRouteJsonLoader.Load(routeAsset.text);
            ValidateRoute(route);

            Sprite stoneSprite = LoadImportedAsset<Sprite>(StonePrototypeSpritePath, "StonePrototype diagnostic sprite");
            if (Math.Abs(stoneSprite.pixelsPerUnit - 16f) > 0.001f)
                throw new InvalidOperationException("StonePrototype must remain imported at exactly 16 PPU.");

            GameObject diagnosticPlayerSource = LoadImportedAsset<GameObject>(
                MovementDemoPlayerSourcePath, "MovementDemoPlayer diagnostic source");
            ValidateMovementDemoPlayerSource(diagnosticPlayerSource);

            DiagnosticDestinationDisposition tileDisposition = InspectDestination(DiagnosticTilePath);
            Tile existingTile = null;
            if (tileDisposition == DiagnosticDestinationDisposition.Reuse)
            {
                existingTile = AssetDatabase.LoadAssetAtPath<Tile>(DiagnosticTilePath);
                ValidateDiagnosticTile(existingTile, stoneSprite);
            }

            var preparedRooms = new PreparedRoom[Rooms.Length];
            for (int index = 0; index < Rooms.Length; index++)
            {
                RoomSpec spec = Rooms[index];
                string sourcePath = "Assets/Resources/Luckbound/Data/Rooms/" + spec.DefinitionFileName;
                TextAsset definition = LoadImportedAsset<TextAsset>(sourcePath, "F10 room definition");
                RoomTemplateData data = RoomTemplateJsonLoader.Load(definition.text);
                ValidateRoomDefinition(data, spec, route.Nodes[index]);

                string prefabPath = DiagnosticF10Folder + "/" + spec.PrefabFileName;
                DiagnosticDestinationDisposition prefabDisposition = InspectDestination(prefabPath);
                if (prefabDisposition == DiagnosticDestinationDisposition.Reuse)
                {
                    if (existingTile == null)
                    {
                        throw new InvalidOperationException(
                            "An existing diagnostic prefab cannot be proven exact without its persistent diagnostic Tile; preserving it.");
                    }

                    // The production generator's existing-destination path validates source identity,
                    // exact Tile use, prefab structure, RoomTemplatePrefab2D, and the registry contract.
                    GameObject existing = F10RoomTemplatePrefabGenerator.GeneratePrefab(definition, existingTile, prefabPath);
                    if (existing == null || !string.Equals(AssetDatabase.GetAssetPath(existing), prefabPath, StringComparison.Ordinal))
                        throw new InvalidOperationException("Existing diagnostic prefab did not resolve at its exact path; preserving it.");
                }

                preparedRooms[index] = new PreparedRoom(spec, definition, data, prefabPath);
            }

            if (tileDisposition == DiagnosticDestinationDisposition.Create &&
                preparedRooms.Any(room => InspectDestination(room.PrefabPath) == DiagnosticDestinationDisposition.Reuse))
            {
                throw new InvalidOperationException(
                    "Existing room prefab destinations require an already-persistent matching diagnostic Tile; preserving all destinations.");
            }

            // Detect folder/file conflicts before the first folder creation or asset save.
            PreflightFolderChain("Assets/Luckbound/Editor/Diagnostic/Shared");
            PreflightFolderChain(DiagnosticF10Folder);

            return new PreparedBatch(stoneSprite, existingTile, preparedRooms);
        }

        private static void ValidateRoute(ExpeditionSampleRouteDefinition route)
        {
            if (route.Nodes.Count != Rooms.Length || route.Connections.Count != Rooms.Length - 1 ||
                route.MandatoryNodeIds.Count != Rooms.Length)
                throw new InvalidOperationException("F10 diagnostic generation requires the fixed five-node linear route.");

            for (int index = 0; index < Rooms.Length; index++)
            {
                ExpeditionSampleRouteNodeDefinition node = route.Nodes[index];
                RoomSpec spec = Rooms[index];
                if (!string.Equals(node.NodeId, spec.NodeId, StringComparison.Ordinal) ||
                    !string.Equals(node.TemplateId, spec.TemplateId, StringComparison.Ordinal) ||
                    !node.IsMandatory || node.MainPathIndex != index ||
                    !string.Equals(node.EntryPortId, "port.entry.west", StringComparison.Ordinal) ||
                    !string.Equals(node.ExitPortId, "port.exit.east", StringComparison.Ordinal))
                    throw new InvalidOperationException("F10 route no longer matches diagnostic room contract at index " + index + ".");
            }

            foreach (ExpeditionSampleRouteConnectionDefinition connection in route.Connections)
            {
                if (connection.IsOptionalBranch)
                    throw new InvalidOperationException("Diagnostic F10 route must remain linear with no optional branches.");
            }
        }

        private static void ValidateRoomDefinition(RoomTemplateData data, RoomSpec spec,
            ExpeditionSampleRouteNodeDefinition routeNode)
        {
            if (!string.Equals(data.templateId, spec.TemplateId, StringComparison.Ordinal) ||
                data.widthTiles != spec.WidthTiles || data.heightTiles != spec.HeightTiles ||
                !string.Equals(routeNode.TemplateId, data.templateId, StringComparison.Ordinal))
                throw new InvalidOperationException("F10 room source no longer matches its diagnostic route definition: " + spec.DefinitionFileName + ".");

            RoomPortData entry = data.ports.SingleOrDefault(port => port.id == "port.entry.west");
            RoomPortData exit = data.ports.SingleOrDefault(port => port.id == "port.exit.east");
            if (data.ports.Length != 2 || entry == null || exit == null ||
                entry.type != "entry" || entry.side != "west" || entry.tileX != 0 || entry.clearanceTiles < 3 ||
                exit.type != "exit" || exit.side != "east" || exit.tileX != data.widthTiles - 1 || exit.clearanceTiles < 3)
                throw new InvalidOperationException("F10 room must retain its exact safe west-entry/east-exit ports.");
        }

        private static void ValidateMovementDemoPlayerSource(GameObject source)
        {
            if (source == null || !string.Equals(source.name, "MovementDemoPlayer", StringComparison.Ordinal) ||
                source.GetComponent<Rigidbody2D>() == null || source.GetComponent<Collider2D>() == null ||
                source.GetComponent<PlayerMotor2D>() == null || source.GetComponent<SpriteRenderer>() == null ||
                source.GetComponent<Animator>() == null || source.GetComponent<Animator>().runtimeAnimatorController == null ||
                source.GetComponent<PlayerVisualStatePresenter>() == null)
                throw new InvalidOperationException(
                    "MovementDemoPlayer must retain Rigidbody2D, Collider2D, PlayerMotor2D, SpriteRenderer, Animator and PlayerVisualStatePresenter as the explicit diagnostic source.");
        }

        private static Tile CreateOrReuseDiagnosticTile(Sprite sprite, Tile existingTile)
        {
            if (existingTile != null)
            {
                ValidateDiagnosticTile(existingTile, sprite);
                return existingTile;
            }

            if (InspectDestination(DiagnosticTilePath) != DiagnosticDestinationDisposition.Create)
                throw new InvalidOperationException("Diagnostic Tile destination changed after preflight; preserving it.");

            EnsureAssetFolder("Assets/Luckbound/Editor/Diagnostic/Shared");
            var created = ScriptableObject.CreateInstance<Tile>();
            created.name = "StonePrototypeDiagnosticTile";
            created.sprite = sprite;
            created.colliderType = Tile.ColliderType.Grid;

            try
            {
                AssetDatabase.CreateAsset(created, DiagnosticTilePath);
                if (!File.Exists(GetProjectPath(DiagnosticTilePath)) || !File.Exists(GetProjectPath(DiagnosticTilePath + ".meta")))
                    throw new IOException("Unity did not persist both the diagnostic Tile and its .meta sidecar.");

                Tile persisted = AssetDatabase.LoadAssetAtPath<Tile>(DiagnosticTilePath);
                ValidateDiagnosticTile(persisted, sprite);
                return persisted;
            }
            catch
            {
                if (!AssetDatabase.Contains(created)) UnityEngine.Object.DestroyImmediate(created);
                throw;
            }
        }

        private static void ValidateDiagnosticTile(Tile tile, Sprite expectedSprite)
        {
            if (tile == null || !AssetDatabase.Contains(tile) ||
                !string.Equals(AssetDatabase.GetAssetPath(tile), DiagnosticTilePath, StringComparison.Ordinal) ||
                tile.sprite != expectedSprite || tile.colliderType != Tile.ColliderType.Grid)
                throw new InvalidOperationException("Diagnostic Tile must be the persistent Grid Tile using the exact StonePrototype sprite; preserving it.");
        }

        private static void ValidateDiagnosticPrefab(GameObject prefab, PreparedRoom room, Tile floorTile)
        {
            if (prefab == null || !string.Equals(AssetDatabase.GetAssetPath(prefab), room.PrefabPath, StringComparison.Ordinal) ||
                !room.PrefabPath.StartsWith(DiagnosticRoot + "/", StringComparison.Ordinal) ||
                room.PrefabPath.StartsWith("Assets/Resources/Luckbound/Rooms/F10/", StringComparison.Ordinal))
                throw new InvalidOperationException("Generated room must stay at its distinct Diagnostic path.");

            RoomTemplatePrefab2D template = prefab.GetComponent<RoomTemplatePrefab2D>();
            if (template == null || template.SourceDefinition != room.Definition)
                throw new InvalidOperationException("Diagnostic room prefab must keep its exact F10 JSON source.");

            RoomTemplateData data = template.ValidateGeneratedPrefab();
            if (!string.Equals(data.templateId, room.Spec.TemplateId, StringComparison.Ordinal) ||
                data.widthTiles != room.Spec.WidthTiles || data.heightTiles != room.Spec.HeightTiles ||
                template.GroundCollider == null || !template.GroundCollider.enabled || template.GroundCollider.isTrigger ||
                template.GroundTilemap == null || template.GroundTilemap.gameObject.layer != LayerMask.NameToLayer("Ground"))
                throw new InvalidOperationException("Diagnostic room geometry, collision or Ground layer failed validation.");

            for (int y = 0; y < data.heightTiles; y++)
            {
                for (int x = 0; x < data.widthTiles; x++)
                {
                    bool solid = RoomTemplateJsonLoader.GetCell(data, x, y) == '#';
                    Tile actual = template.GroundTilemap.GetTile<Tile>(new Vector3Int(x, y, 0));
                    if (solid ? actual != floorTile : actual != null)
                        throw new InvalidOperationException("Diagnostic Tilemap differs from JSON geometry at " + x + "," + y + ".");
                }
            }

            RoomPortMarker2D[] ports = prefab.GetComponentsInChildren<RoomPortMarker2D>(true);
            RoomPositionMarker2D[] markers = prefab.GetComponentsInChildren<RoomPositionMarker2D>(true);
            if (ports.Length != data.ports.Length || markers.Length != data.markers.Length)
                throw new InvalidOperationException("Diagnostic room markers do not match JSON counts.");

            if (prefab.GetComponentsInChildren<PlayerMotor2D>(true).Length != 0 ||
                prefab.GetComponentsInChildren<Camera>(true).Length != 0 ||
                prefab.GetComponentsInChildren<Canvas>(true).Length != 0 ||
                prefab.GetComponentsInChildren<RoomLifetimeScope>(true).Length != 0)
                throw new InvalidOperationException("Room-only diagnostic prefab cannot own a player, camera, HUD or RoomLifetimeScope.");
        }

        private static T LoadImportedAsset<T>(string assetPath, string description) where T : UnityEngine.Object
        {
            string fullPath = GetProjectPath(assetPath);
            if (!File.Exists(fullPath) || !File.Exists(fullPath + ".meta"))
                throw new FileNotFoundException(description + " must already be imported with its existing .meta sidecar: " + assetPath + ".", fullPath);

            T asset = AssetDatabase.LoadAssetAtPath<T>(assetPath);
            if (asset == null || !AssetDatabase.Contains(asset) ||
                !string.Equals(AssetDatabase.GetAssetPath(asset), assetPath, StringComparison.Ordinal))
                throw new InvalidOperationException(description + " is not imported at its expected asset path: " + assetPath + ".");
            return asset;
        }

        private static DiagnosticDestinationDisposition InspectDestination(string assetPath)
        {
            string fullPath = GetProjectPath(assetPath);
            bool assetFileExists = File.Exists(fullPath);
            bool metaFileExists = File.Exists(fullPath + ".meta");
            UnityEngine.Object imported = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
            return ClassifyDestination(assetFileExists, metaFileExists, imported != null);
        }

        private static void PreflightFolderChain(string assetFolder)
        {
            string normalized = assetFolder.Replace('\\', '/').TrimEnd('/');
            string[] segments = normalized.Split('/');
            if (segments.Length < 2 || segments[0] != "Assets")
                throw new ArgumentException("Diagnostic folders must be rooted under Assets/.", nameof(assetFolder));

            string current = "Assets";
            for (int index = 1; index < segments.Length; index++)
            {
                string next = current + "/" + segments[index];
                string fullPath = GetProjectPath(next);
                bool folderImported = AssetDatabase.IsValidFolder(next);
                if (folderImported)
                {
                    if (!Directory.Exists(fullPath))
                        throw new InvalidOperationException("Imported diagnostic folder is missing on disk; preserving it: " + next + ".");
                }
                else if (Directory.Exists(fullPath) || File.Exists(fullPath) || File.Exists(fullPath + ".meta"))
                {
                    throw new InvalidOperationException("Diagnostic folder path is occupied by unimported content; preserving it: " + next + ".");
                }

                current = next;
            }
        }

        private static void EnsureAssetFolder(string assetFolder)
        {
            PreflightFolderChain(assetFolder);
            string current = "Assets";
            string[] segments = assetFolder.Replace('\\', '/').TrimEnd('/').Split('/');
            for (int index = 1; index < segments.Length; index++)
            {
                string next = current + "/" + segments[index];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    string guid = AssetDatabase.CreateFolder(current, segments[index]);
                    if (string.IsNullOrEmpty(guid) || !AssetDatabase.IsValidFolder(next))
                        throw new IOException("Unity could not create diagnostic folder " + next + ".");
                }
                current = next;
            }
        }

        private static string GetProjectPath(string assetPath)
        {
            if (string.IsNullOrWhiteSpace(assetPath) || !assetPath.StartsWith("Assets/", StringComparison.Ordinal) ||
                assetPath.Contains("..") || assetPath.Contains(":") || assetPath.Contains("\\"))
                throw new ArgumentException("Expected a safe Assets/ diagnostic path.", nameof(assetPath));

            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string fullPath = Path.GetFullPath(Path.Combine(projectRoot, assetPath));
            string assetsRoot = Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar;
            if (!fullPath.StartsWith(assetsRoot, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Diagnostic asset path escaped Assets/.", nameof(assetPath));
            return fullPath;
        }

        internal enum DiagnosticDestinationDisposition
        {
            Create,
            Reuse
        }

        private sealed class RoomSpec
        {
            internal RoomSpec(string nodeId, string definitionFileName, string templateId,
                int widthTiles, int heightTiles, string prefabFileName)
            {
                NodeId = nodeId;
                DefinitionFileName = definitionFileName;
                TemplateId = templateId;
                WidthTiles = widthTiles;
                HeightTiles = heightTiles;
                PrefabFileName = prefabFileName;
            }

            internal string NodeId { get; }
            internal string DefinitionFileName { get; }
            internal string TemplateId { get; }
            internal int WidthTiles { get; }
            internal int HeightTiles { get; }
            internal string PrefabFileName { get; }
        }

        private sealed class PreparedRoom
        {
            internal PreparedRoom(RoomSpec spec, TextAsset definition, RoomTemplateData data, string prefabPath)
            {
                Spec = spec;
                Definition = definition;
                Data = data;
                PrefabPath = prefabPath;
            }

            internal RoomSpec Spec { get; }
            internal TextAsset Definition { get; }
            internal RoomTemplateData Data { get; }
            internal string PrefabPath { get; }
        }

        private sealed class PreparedBatch
        {
            internal PreparedBatch(Sprite stonePrototypeSprite, Tile existingTile, PreparedRoom[] rooms)
            {
                StonePrototypeSprite = stonePrototypeSprite;
                ExistingTile = existingTile;
                Rooms = rooms;
            }

            internal Sprite StonePrototypeSprite { get; }
            internal Tile ExistingTile { get; }
            internal PreparedRoom[] Rooms { get; }
        }
    }
}
