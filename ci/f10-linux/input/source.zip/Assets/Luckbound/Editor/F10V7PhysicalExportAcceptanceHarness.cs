using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Luckbound.Editor;
using UnityEditor;
using UnityEngine;

namespace Luckbound.PhysicalExportAcceptance
{
    /// <summary>
    /// One-shot bundle integrity acceptance for the fixed disposable Unity copy. This checks package bytes only;
    /// it does not simulate combat, prove physical confinement, or authorize a registry/runtime install.
    /// </summary>
    public static class F10V7PhysicalExportAcceptanceHarness
    {
        private const string RevisionRootRelativePath = "Logs/F10V7PhysicalExport-20261116/candidate/revisions";
        private const string AcceptanceRootRelativePath = "Logs/F10V7PhysicalExport-20261116/candidate/acceptance";

        [MenuItem("Luckbound/Technical Diagnostic/Run V7 Physical Bundle Integrity Acceptance")]
        public static void Run()
        {
            F10TechnicalPhysicalDescriptorExporter.VerifyDisposableWorkspaceForAcceptance();
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string sourceBundle = FindLatestRevision(projectRoot);
            string manifestPath = Path.Combine(sourceBundle, "bundle-manifest.json");
            byte[] manifestBytes = ReadOwnedFile(manifestPath);
            string expectedManifestSha256 = Sha256Hex(manifestBytes);
            F10TechnicalPhysicalDescriptorExporter.BundleManifestData manifest = JsonUtility.FromJson<F10TechnicalPhysicalDescriptorExporter.BundleManifestData>(
                new UTF8Encoding(false, true).GetString(manifestBytes));
            if (manifest == null || manifest.payloads == null || manifest.payloads.Length == 0)
                throw new InvalidDataException("Bundle manifest has no payload rows for controlled mutation checks.");

            bool originalValid = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                sourceBundle, expectedManifestSha256, out bool registryEligible, out string originalError);
            if (!originalValid)
                throw new InvalidDataException("The source revision failed its own pinned bundle check: " + originalError);

            string outputRoot = Path.Combine(projectRoot, AcceptanceRootRelativePath.Replace('/', Path.DirectorySeparatorChar));
            EnsureSafeDirectory(outputRoot);
            string runId = DateTime.UtcNow.ToString("yyyyMMddTHHmmssfffffffZ", System.Globalization.CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N");
            string runRoot = Path.Combine(outputRoot, "run-" + runId);
            if (Directory.Exists(runRoot) || File.Exists(runRoot))
                throw new IOException("Acceptance run destination already exists; preserving it: " + runRoot);
            Directory.CreateDirectory(runRoot);

            string firstPayloadPath = manifest.payloads[0].path;
            string alteredCopy = Path.Combine(runRoot, "altered");
            string missingCopy = Path.Combine(runRoot, "missing");
            CopyBundleFixture(sourceBundle, alteredCopy, null);
            CopyBundleFixture(sourceBundle, missingCopy, firstPayloadPath);

            string alteredFilePath = Path.Combine(alteredCopy, firstPayloadPath.Replace('/', Path.DirectorySeparatorChar));
            byte[] alteredBytes = ReadOwnedFile(alteredFilePath);
            if (alteredBytes.Length == 0) alteredBytes = Encoding.ASCII.GetBytes("changed\n");
            else alteredBytes[0] ^= 0xff;
            F10TechnicalPhysicalDescriptorExporter.VerifyOwnedDependencyFileForAcceptanceMutation(alteredFilePath);
            using (var stream = new FileStream(alteredFilePath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(alteredBytes, 0, alteredBytes.Length);
                stream.Flush(true);
            }

            bool alteredValid = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                alteredCopy, expectedManifestSha256, out _, out string alteredError);
            bool missingValid = F10TechnicalPhysicalDescriptorExporter.ValidateBundleIntegrity(
                missingCopy, expectedManifestSha256, out _, out string missingError);

            var result = new AcceptanceResult
            {
                schema = "luckbound.f10.v7.physical-bundle.acceptance.v1",
                sourceRevisionId = manifest.revisionId,
                sourceManifestSha256 = expectedManifestSha256,
                sourceBundleIntegrityPassed = originalValid,
                sourceRegistryEligible = registryEligible,
                alteredPayloadRejected = !alteredValid,
                missingPayloadRejected = !missingValid,
                alteredError = alteredError,
                missingError = missingError,
                fixtureRoot = runRoot,
                physicalSimulationExecuted = false,
                victoryClaimed = false,
                passed = originalValid && !alteredValid && !missingValid
            };
            if (!result.passed)
                throw new InvalidOperationException("Bundle integrity acceptance did not reject every altered or missing fixture.");

            WriteNew(Path.Combine(runRoot, "acceptance-results.json"),
                new UTF8Encoding(false, true).GetBytes(JsonUtility.ToJson(result, true) + "\n"));
            Debug.Log("V7 physical bundle byte-integrity acceptance passed; original revision preserved at " + sourceBundle + ".");
        }

        private static string FindLatestRevision(string projectRoot)
        {
            string revisionsRoot = Path.Combine(projectRoot, RevisionRootRelativePath.Replace('/', Path.DirectorySeparatorChar));
            if (!Directory.Exists(revisionsRoot)) throw new DirectoryNotFoundException("No V7 physical revision directory exists.");
            RejectReparseTreePath(revisionsRoot);
            string revision = Directory.GetDirectories(revisionsRoot, "revision-*", SearchOption.TopDirectoryOnly)
                .OrderByDescending(path => Path.GetFileName(path), StringComparer.Ordinal).FirstOrDefault(path =>
                    File.Exists(Path.Combine(path, "bundle-manifest.json")));
            if (string.IsNullOrEmpty(revision)) throw new FileNotFoundException("No complete physical bundle manifest was found under revisions.");
            RejectReparseTreePath(revision);
            return revision;
        }

        private static void CopyBundleFixture(string sourceRoot, string targetRoot, string omittedRelativePath)
        {
            if (Directory.Exists(targetRoot) || File.Exists(targetRoot))
                throw new IOException("Acceptance fixture destination already exists; preserving it: " + targetRoot);
            Directory.CreateDirectory(targetRoot);
            string sourcePrefix = Path.GetFullPath(sourceRoot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            var pending = new Stack<string>();
            pending.Push(sourceRoot);
            while (pending.Count > 0)
            {
                string directory = pending.Pop();
                RejectReparseTreePath(directory);
                foreach (string entry in Directory.EnumerateFileSystemEntries(directory))
                {
                    FileAttributes attributes = File.GetAttributes(entry);
                    if ((attributes & FileAttributes.ReparsePoint) != 0)
                        throw new IOException("Acceptance refuses a source bundle reparse point: " + entry);
                    if ((attributes & FileAttributes.Directory) != 0)
                    {
                        pending.Push(entry);
                        continue;
                    }
                    string relative = Path.GetFullPath(entry).Substring(sourcePrefix.Length).Replace('\\', '/');
                    if (string.Equals(relative, omittedRelativePath, StringComparison.Ordinal)) continue;
                    string destination = Path.Combine(targetRoot, relative.Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Directory.GetParent(destination).FullName);
                    WriteNew(destination, ReadOwnedFile(entry));
                }
            }
        }

        private static byte[] ReadOwnedFile(string path)
        {
            RejectReparseTreePath(path);
            return File.ReadAllBytes(path);
        }

        private static void EnsureSafeDirectory(string path)
        {
            if (File.Exists(path)) throw new IOException("Acceptance output root is an occupied file; preserving it: " + path);
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            RejectReparseTreePath(path);
        }

        private static void RejectReparseTreePath(string path)
        {
            string full = Path.GetFullPath(path);
            string current = Path.GetPathRoot(full);
            if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Acceptance refuses a reparse-point path: " + current);
            string relative = full.Substring(current.Length);
            foreach (string part in relative.Split(new[] { Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries))
            {
                current = Path.Combine(current, part);
                if (!File.Exists(current) && !Directory.Exists(current))
                    throw new FileNotFoundException("Acceptance path component is missing.", current);
                if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Acceptance refuses a reparse-point path: " + current);
            }
        }

        private static void WriteNew(string path, byte[] bytes)
        {
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(true);
            }
        }

        private static string Sha256Hex(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
                return string.Concat(sha.ComputeHash(bytes).Select(value => value.ToString("x2", System.Globalization.CultureInfo.InvariantCulture)));
        }

        [Serializable]
        private sealed class AcceptanceResult
        {
            public string schema;
            public string sourceRevisionId;
            public string sourceManifestSha256;
            public bool sourceBundleIntegrityPassed;
            public bool sourceRegistryEligible;
            public bool alteredPayloadRejected;
            public bool missingPayloadRejected;
            public string alteredError;
            public string missingError;
            public string fixtureRoot;
            public bool physicalSimulationExecuted;
            public bool victoryClaimed;
            public bool passed;
        }
    }
}
