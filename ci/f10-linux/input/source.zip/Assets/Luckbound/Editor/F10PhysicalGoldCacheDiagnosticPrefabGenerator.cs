using System;
using System.IO;
using Luckbound.Gameplay.Inventory;
using UnityEditor;
using UnityEngine;

namespace Luckbound.Editor
{
    /// <summary>Creates one uninitialized F10 gold-cache diagnostic prefab for a room owner to adopt.</summary>
    public static class F10PhysicalGoldCacheDiagnosticPrefabGenerator
    {
        public const string StonePrototypeSpritePath = "Assets/Luckbound/Art/Prototypes/MovementDemo/StonePrototype.png";
        public const string DiagnosticFolder = "Assets/Luckbound/Editor/Diagnostic/F10GoldCache";
        public const string PrefabPath = DiagnosticFolder + "/F10ExplorationGoldCacheDiagnostic.prefab";
        private const string DiagnosticRoot = "Assets/Luckbound/Editor/Diagnostic/";

        private static readonly Color GoldTint = new Color(240f / 255f, 193f / 255f, 90f / 255f, 1f);

        [MenuItem("Luckbound/Technical Diagnostic/Generate F10 Gold Cache Prefab")]
        private static void GenerateFromMenu()
        {
            GameObject generated = Generate();
            Debug.Log("Created the uninitialized F10 exploration gold-cache diagnostic prefab at " + AssetDatabase.GetAssetPath(generated) + ".");
        }

        /// <summary>Checks imported inputs and create-only destinations without writing assets.</summary>
        public static void PreflightOnly()
        {
            Preflight();
        }

        /// <summary>Creates an inactive, uninitialized pickup prefab; room composition owns initialization.</summary>
        public static GameObject Generate()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Diagnostic prefab generation is only allowed outside Play Mode.");

            Sprite sprite = Preflight();
            EnsureAssetFolder(DiagnosticFolder);
            var root = new GameObject("F10ExplorationGoldCacheDiagnostic");
            try
            {
                root.SetActive(false);
                SpriteRenderer renderer = root.AddComponent<SpriteRenderer>();
                renderer.sprite = sprite;
                renderer.color = GoldTint;
                renderer.sortingOrder = 10;

                BoxCollider2D trigger = root.AddComponent<BoxCollider2D>();
                trigger.size = Vector2.one;
                trigger.isTrigger = true;

                // Deliberately do not call Initialize here. The room owner instantiates this inactive root,
                // places it on cache.exploration, then initializes it with that room's scope and player.
                ExplorationGoldCachePickup2D pickup = root.AddComponent<ExplorationGoldCachePickup2D>();
                ValidatePrefabRoot(root, sprite, pickup);

                GameObject saved = PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
                if (saved == null || !File.Exists(GetProjectPath(PrefabPath)) || !File.Exists(GetProjectPath(PrefabPath + ".meta")))
                    throw new IOException("Unity did not persist the diagnostic cache prefab and its .meta sidecar.");
                AssetDatabase.ImportAsset(PrefabPath, ImportAssetOptions.ForceSynchronousImport);

                GameObject imported = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
                if (imported == null || !string.Equals(AssetDatabase.GetAssetPath(imported), PrefabPath, StringComparison.Ordinal))
                    throw new InvalidOperationException("Generated cache prefab did not import at its exact diagnostic path.");
                ExplorationGoldCachePickup2D importedPickup = imported.GetComponent<ExplorationGoldCachePickup2D>();
                ValidatePrefabRoot(imported, sprite, importedPickup);
                return imported;
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        internal static bool IsCreateOnlyDestination(bool assetExists, bool metaExists, bool importedAssetExists)
        {
            return !assetExists && !metaExists && !importedAssetExists;
        }

        internal static void ValidatePrefabRoot(GameObject root, Sprite expectedSprite, ExplorationGoldCachePickup2D pickup)
        {
            if (root == null || !string.Equals(root.name, "F10ExplorationGoldCacheDiagnostic", StringComparison.Ordinal) ||
                root.activeSelf || expectedSprite == null || pickup == null || !ReferenceEquals(pickup.gameObject, root))
                throw new InvalidOperationException("Cache diagnostic root must be inactive and contain its pickup on the root object.");

            SpriteRenderer renderer = root.GetComponent<SpriteRenderer>();
            Collider2D[] colliders = root.GetComponents<Collider2D>();
            BoxCollider2D box = root.GetComponent<BoxCollider2D>();
            if (renderer == null || renderer.sprite != expectedSprite || renderer.color != GoldTint ||
                box == null || colliders.Length != 1 || !box.enabled || !box.isTrigger || box.size != Vector2.one ||
                root.GetComponent<Rigidbody2D>() != null || pickup.HasPendingContact)
                throw new InvalidOperationException("Cache diagnostic prefab must keep the exact prototype sprite, gold tint, one unit trigger BoxCollider2D, no Rigidbody2D, and no pending contact.");
        }

        private static Sprite Preflight()
        {
            if (!PrefabPath.StartsWith(DiagnosticRoot, StringComparison.Ordinal) ||
                PrefabPath.StartsWith("Assets/Resources/", StringComparison.Ordinal))
                throw new InvalidOperationException("Cache diagnostic output must remain in the Editor-only diagnostic tree.");

            Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(StonePrototypeSpritePath);
            string spriteFullPath = GetProjectPath(StonePrototypeSpritePath);
            if (sprite == null || !AssetDatabase.Contains(sprite) ||
                !string.Equals(AssetDatabase.GetAssetPath(sprite), StonePrototypeSpritePath, StringComparison.Ordinal) ||
                !File.Exists(spriteFullPath) || !File.Exists(spriteFullPath + ".meta"))
                throw new FileNotFoundException("Imported StonePrototype Sprite and its .meta are required for the cache diagnostic prefab.", spriteFullPath);

            string outputFullPath = GetProjectPath(PrefabPath);
            bool destinationIsNew = IsCreateOnlyDestination(
                File.Exists(outputFullPath), File.Exists(outputFullPath + ".meta"),
                AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath) != null);
            if (!destinationIsNew || File.Exists(GetProjectPath(DiagnosticFolder)) ||
                AssetDatabase.IsValidFolder(DiagnosticFolder))
                throw new IOException("Cache diagnostic destination already exists; preserving existing assets: " + PrefabPath);

            ValidateFolderChain(DiagnosticFolder);
            return sprite;
        }

        private static void ValidateFolderChain(string folder)
        {
            string[] segments = folder.Split('/');
            if (segments.Length < 2 || segments[0] != "Assets")
                throw new ArgumentException("Diagnostic folders must be rooted under Assets/.", nameof(folder));
            string current = "Assets";
            for (int index = 1; index < segments.Length; index++)
            {
                string next = current + "/" + segments[index];
                string fullPath = GetProjectPath(next);
                bool imported = AssetDatabase.IsValidFolder(next);
                if (index < segments.Length - 1 && !imported && (File.Exists(fullPath) || Directory.Exists(fullPath)))
                    throw new InvalidOperationException("Diagnostic folder chain contains unimported content; preserving it: " + next);
                if (index == segments.Length - 1 && (imported || File.Exists(fullPath) || Directory.Exists(fullPath)))
                    throw new InvalidOperationException("Diagnostic destination folder already exists; preserving it: " + next);
                current = next;
            }
        }

        private static void EnsureAssetFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;
            int split = folder.LastIndexOf('/');
            string parent = folder.Substring(0, split);
            string name = folder.Substring(split + 1);
            EnsureAssetFolder(parent);
            string guid = AssetDatabase.CreateFolder(parent, name);
            if (string.IsNullOrWhiteSpace(guid) || !AssetDatabase.IsValidFolder(folder))
                throw new IOException("Unity failed to create the diagnostic folder: " + folder);
        }

        private static string GetProjectPath(string assetPath)
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            return Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }
    }
}
