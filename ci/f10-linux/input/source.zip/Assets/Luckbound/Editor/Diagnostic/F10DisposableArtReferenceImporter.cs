#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;

namespace Luckbound.EditorTools.Diagnostic
{
    /// <summary>One explicit, create-only import for the isolated F10 artwork diagnostic copy.</summary>
    public static class F10DisposableArtReferenceImporter
    {
        private const string CertificateRelativePath = "Logs/F10DisposableArt-20261116/copy-certificate.json";
        private const string ReferenceRelativePath = "docs/art/F01_bellator_32x48.png";
        private const string RecordRelativePath = "docs/art/records/ART-F01-BELLATOR-32X48.v1.json";
        private const string TargetAssetPath = "Assets/Luckbound/Editor/Diagnostic/F01_BellatorScaleReference.png";
        private const string ExpectedPngSha256 = "64f2078fc1c4d9183b896028918be04affc232d1a14a1ba2c6578fb7c502f457";
        private const string ExpectedRecordSha256 = "b2b61dca9e4b2327c3a0649f54fcbce9130e171d7d9371acde3ab41b90ed72d7";

        [Serializable]
        private sealed class CopyCertificate
        {
            public int schemaVersion;
            public string status;
            public string sourceRoot;
            public string copyRoot;
            public bool reparsePointsRejected;
            public bool fileIdentityChecksPassed;
            public bool f02ImportStagingAbsent;
            public ReferenceCertificate reference;
        }

        [Serializable]
        private sealed class ReferenceCertificate
        {
            public string sha256;
            public int width;
            public int height;
            public string creationMethod;
            public string status;
            public string sourceFileId;
            public string copyFileId;
        }

        public static void ExecuteImportCreateOnly()
        {
            string assetsRoot = Path.GetFullPath(Application.dataPath);
            string projectRoot = Path.GetFullPath(Path.Combine(assetsRoot, ".."));
            string certificatePath = Path.Combine(projectRoot, CertificateRelativePath.Replace('/', Path.DirectorySeparatorChar));
            string sourcePath = Path.Combine(projectRoot, ReferenceRelativePath.Replace('/', Path.DirectorySeparatorChar));
            string recordPath = Path.Combine(projectRoot, RecordRelativePath.Replace('/', Path.DirectorySeparatorChar));
            string targetPath = Path.GetFullPath(Path.Combine(projectRoot, TargetAssetPath.Replace('/', Path.DirectorySeparatorChar)));
            string metaPath = targetPath + ".meta";

            RequirePlainEntry(projectRoot);
            RequirePlainEntry(assetsRoot);
            RequirePlainEntry(Path.Combine(projectRoot, "Library"));
            RequirePlainEntry(Path.Combine(projectRoot, "ProjectSettings"));
            RequirePlainEntry(certificatePath);
            RequirePlainEntry(sourcePath);
            RequirePlainEntry(recordPath);
            if (File.Exists(Path.Combine(projectRoot, ".git")) || Directory.Exists(Path.Combine(projectRoot, ".git")))
                throw new InvalidOperationException("The disposable project must not contain a .git checkout/worktree link.");
            RequireF02ControlsAbsent(projectRoot);
            if (!IsUnderRoot(targetPath, assetsRoot) || IsUnderRoot(sourcePath, assetsRoot))
                throw new InvalidOperationException("The F01 reference source must remain outside Assets, and only the diagnostic destination may be inside Assets.");
            if (!File.Exists(certificatePath))
                throw new InvalidOperationException("The byte-copy certificate is missing; run the staging copy builder first.");
            if (ExistsAsAnyEntry(targetPath) || ExistsAsAnyEntry(metaPath))
                throw new InvalidOperationException("Create-only import refused because the PNG or its .meta destination already exists.");
            if (!File.Exists(sourcePath) || !File.Exists(recordPath))
                throw new InvalidOperationException("The copied F01 source or its provenance record is missing.");

            CopyCertificate certificate = JsonUtility.FromJson<CopyCertificate>(File.ReadAllText(certificatePath));
            if (certificate == null || certificate.schemaVersion != 1 ||
                !string.Equals(certificate.status, "verified", StringComparison.Ordinal) ||
                !PathEquals(certificate.copyRoot, projectRoot) ||
                PathEquals(certificate.sourceRoot, projectRoot) ||
                !certificate.reparsePointsRejected || !certificate.fileIdentityChecksPassed ||
                !certificate.f02ImportStagingAbsent ||
                certificate.reference == null ||
                !string.Equals(certificate.reference.sha256, ExpectedPngSha256, StringComparison.Ordinal) ||
                certificate.reference.width != 32 || certificate.reference.height != 48 ||
                !string.Equals(certificate.reference.creationMethod, "generated", StringComparison.Ordinal) ||
                !string.Equals(certificate.reference.status, "Prototype", StringComparison.Ordinal) ||
                string.IsNullOrEmpty(certificate.reference.sourceFileId) ||
                string.IsNullOrEmpty(certificate.reference.copyFileId) ||
                string.Equals(certificate.reference.sourceFileId, certificate.reference.copyFileId, StringComparison.Ordinal))
                throw new InvalidOperationException("The copy certificate is not a valid physical-copy attestation for this project root.");

            string approvedCopiesRoot = Path.Combine(certificate.sourceRoot,
                "Logs/F10DisposableArt-20261116/copies".Replace('/', Path.DirectorySeparatorChar));
            RequirePlainEntry(approvedCopiesRoot);
            if (!IsUnderRoot(projectRoot, approvedCopiesRoot))
                throw new InvalidOperationException("The certified project must remain beneath the source project's approved Logs copy root.");

            string originalSourcePath = Path.Combine(certificate.sourceRoot,
                ReferenceRelativePath.Replace('/', Path.DirectorySeparatorChar));
            RequirePlainEntry(certificate.sourceRoot);
            RequireF02ControlsAbsent(certificate.sourceRoot);
            RequirePlainEntry(originalSourcePath);
            if (!File.Exists(originalSourcePath) ||
                !string.Equals(Sha256(File.ReadAllBytes(originalSourcePath)), ExpectedPngSha256, StringComparison.Ordinal))
                throw new InvalidOperationException("The certified original F01 source no longer matches its frozen bytes.");

            byte[] source = File.ReadAllBytes(sourcePath);
            if (!string.Equals(Sha256(source), ExpectedPngSha256, StringComparison.Ordinal) ||
                !string.Equals(Sha256(File.ReadAllBytes(recordPath)), ExpectedRecordSha256, StringComparison.Ordinal))
                throw new InvalidOperationException("The copied PNG or generated F01 provenance record has an unexpected SHA-256.");
            VerifyPngHeader(source);
            string targetDirectory = Path.GetDirectoryName(targetPath);
            if (string.IsNullOrEmpty(targetDirectory) || !Directory.Exists(targetDirectory))
                throw new InvalidOperationException("The diagnostic Editor destination directory is missing from the copy overlay.");
            RequirePlainEntry(targetDirectory);

            using (var input = new MemoryStream(source, writable: false))
            using (var output = new FileStream(targetPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                input.CopyTo(output);

            AssetDatabase.ImportAsset(TargetAssetPath, ImportAssetOptions.ForceSynchronousImport);
            TextureImporter importer = AssetImporter.GetAtPath(TargetAssetPath) as TextureImporter;
            if (importer == null)
                throw new InvalidOperationException("Unity did not create a TextureImporter for the diagnostic source.");
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.filterMode = FilterMode.Point;
            importer.spritePixelsPerUnit = 16f;
            importer.mipmapEnabled = false;
            importer.npotScale = TextureImporterNPOTScale.None;
            importer.maxTextureSize = 64;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.crunchedCompression = false;
            var settings = new TextureImporterSettings();
            importer.ReadTextureSettings(settings);
            settings.spriteGenerateFallbackPhysicsShape = false;
            settings.spriteMeshType = SpriteMeshType.FullRect;
            importer.SetTextureSettings(settings);
            importer.SaveAndReimport();

            importer = AssetImporter.GetAtPath(TargetAssetPath) as TextureImporter;
            if (importer == null)
                throw new InvalidOperationException("The diagnostic TextureImporter disappeared after import.");
            importer.ReadTextureSettings(settings);
            if (importer.textureType != TextureImporterType.Sprite ||
                importer.spriteImportMode != SpriteImportMode.Single || importer.filterMode != FilterMode.Point ||
                Mathf.Abs(importer.spritePixelsPerUnit - 16f) > 0.001f || importer.mipmapEnabled ||
                importer.npotScale != TextureImporterNPOTScale.None || importer.maxTextureSize < 48 ||
                importer.textureCompression != TextureImporterCompression.Uncompressed || importer.crunchedCompression ||
                settings.spriteGenerateFallbackPhysicsShape || settings.spriteMeshType != SpriteMeshType.FullRect ||
                new[] { "Standalone", "Android", "iPhone", "WebGL" }.Any(platform => importer.GetPlatformTextureSettings(platform).overridden))
                throw new InvalidOperationException("Imported TextureImporter settings do not match the uncompressed Point/16 PPU diagnostic contract.");
            if (!File.Exists(metaPath) || string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(TargetAssetPath)) ||
                AssetDatabase.LoadAssetAtPath<Sprite>(TargetAssetPath) == null)
                throw new InvalidOperationException("Unity did not create the new .meta/GUID and a single Sprite asset.");
            Debug.Log("Imported the isolated F01 Bellator scale reference. It remains Prototype; no prefab/runtime binding was created.");
        }

        private static void RequireF02ControlsAbsent(string projectRoot)
        {
            foreach (string relative in new[] {
                "Assets/Luckbound/Editor/F02ImportStaging",
                "Assets/Luckbound/Editor/F02ImportStaging.meta",
                "ProjectSettings/Luckbound/F02ImportRecovery/pending",
                "Library/Luckbound/F02/Transactions" })
            {
                string path = Path.Combine(projectRoot, relative.Replace('/', Path.DirectorySeparatorChar));
                RequirePlainAncestors(path);
                if (ExistsAsAnyEntry(path))
                    throw new InvalidOperationException("F02 control state blocks the disposable import: " + path);
            }
            string assets = Path.Combine(projectRoot, "Assets");
            RequirePlainEntry(assets);
            var pending = new System.Collections.Generic.Stack<string>();
            pending.Push(assets);
            byte[] header = System.Text.Encoding.ASCII.GetBytes("Luckbound-F02-Sentinel");
            while (pending.Count != 0)
            {
                foreach (string path in Directory.GetFileSystemEntries(pending.Pop()))
                {
                    FileAttributes attributes = File.GetAttributes(path);
                    if ((attributes & FileAttributes.ReparsePoint) != 0)
                        throw new InvalidOperationException("Reparse entry blocks the disposable import: " + path);
                    if ((attributes & FileAttributes.Directory) != 0)
                    {
                        pending.Push(path);
                        continue;
                    }
                    if (Path.GetFileName(path).IndexOf("sentinel", StringComparison.OrdinalIgnoreCase) >= 0)
                        throw new InvalidOperationException("Sentinel-like asset blocks the disposable import: " + path);
                    using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        byte[] prefix = new byte[header.Length];
                        int count = 0;
                        while (count < prefix.Length)
                        {
                            int read = stream.Read(prefix, count, prefix.Length - count);
                            if (read == 0) break;
                            count += read;
                        }
                        if (count == header.Length && prefix.SequenceEqual(header))
                            throw new InvalidOperationException("F02 sentinel header blocks the disposable import: " + path);
                    }
                }
            }
        }

        private static void RequirePlainEntry(string path)
        {
            string fullPath = Path.GetFullPath(path);
            if (!ExistsAsAnyEntry(fullPath))
                throw new InvalidOperationException("Required physical-copy path is missing: " + fullPath);
            RequirePlainAncestors(fullPath);
        }

        private static void RequirePlainAncestors(string path)
        {
            string fullPath = Path.GetFullPath(path);
            for (string current = fullPath; !string.IsNullOrEmpty(current); current = Directory.GetParent(current)?.FullName)
            {
                if (ExistsAsAnyEntry(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidOperationException("Reparse points are forbidden in the certified disposable copy: " + current);
                if (string.Equals(current, Path.GetPathRoot(current), StringComparison.OrdinalIgnoreCase)) break;
            }
        }

        private static bool ExistsAsAnyEntry(string path)
        {
            if (File.Exists(path) || Directory.Exists(path)) return true;
            try { File.GetAttributes(path); return true; }
            catch (FileNotFoundException) { return false; }
            catch (DirectoryNotFoundException) { return false; }
        }

        private static bool IsUnderRoot(string path, string root)
        {
            string fullPath = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            return fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
        }

        private static bool PathEquals(string left, string right)
        {
            return !string.IsNullOrEmpty(left) && !string.IsNullOrEmpty(right) &&
                string.Equals(Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                    Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                    StringComparison.OrdinalIgnoreCase);
        }

        private static string Sha256(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", string.Empty).ToLowerInvariant();
        }

        private static void VerifyPngHeader(byte[] bytes)
        {
            if (bytes == null || bytes.Length < 26 || bytes[0] != 0x89 || bytes[1] != 0x50 ||
                bytes[2] != 0x4e || bytes[3] != 0x47 || bytes[12] != (byte)'I' || bytes[13] != (byte)'H' ||
                bytes[14] != (byte)'D' || bytes[15] != (byte)'R')
                throw new InvalidOperationException("The F01 source is not a PNG with an IHDR header.");
            uint width = ((uint)bytes[16] << 24) | ((uint)bytes[17] << 16) | ((uint)bytes[18] << 8) | bytes[19];
            uint height = ((uint)bytes[20] << 24) | ((uint)bytes[21] << 16) | ((uint)bytes[22] << 8) | bytes[23];
            if (width != 32 || height != 48 || bytes[24] != 8 || bytes[25] != 6)
                throw new InvalidOperationException("F01 source must remain exactly 32x48 PNG RGBA8.");
        }
    }
}
#endif
